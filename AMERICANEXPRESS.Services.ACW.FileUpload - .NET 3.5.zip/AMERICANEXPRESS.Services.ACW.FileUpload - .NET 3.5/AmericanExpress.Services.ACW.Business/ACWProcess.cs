﻿////-----------------------------------------------------------------------
//// <copyright file="ACWProcess.cs" company="NIIT">
////     Copyright (c) NIIT. All rights reserved.
//// </copyright>
//// <summary>
//// <Description>This file contains the Implementation of ACWProcess class.
////    It is defined for processing the Jobs for Cleaning/deleting the files</Description>
//// <Author>NIIT Technologies</Author>
//// <CreatedOn>07/09/2011</CreatedOn>
//// <Modified>
////     <On></On>
////     <Desc></Desc>
////     <By></By>
//// </Modified>
//// </summary>
////----------------------------------------------------------------------

using System;
using AmericanExpress.Services.ACW.BusinessInterface;
using System.Data;
using System.Configuration;
using System.IO;
using System.Xml;
using System.Globalization;
using System.Data.SqlClient;

namespace AmericanExpress.Services.ACW.Business
{
    public class ACWProcess : IACWProcess
    {
        #region Variables
        private int _threadId = 0;
        private ACWDAC _ACWDAC = null;
        string _isInfoLogRequired = string.Empty;
        //private bool isACWFoldersCreated = false;

        #endregion

        #region Constructor
        /// <summary>
        /// Initialise the thread and ACWDac object in constructor
        /// </summary>
        /// <param name="threadId">int</param>
        /// <param name="ACWDB">ACWDAC</param>
        /// <param name="infoLog">string</param>
        public ACWProcess(int threadId, ACWDAC ACWDB)
        {
            this._threadId = threadId;
            this._ACWDAC = ACWDB;
        }
        #endregion

        #region Method
        /// <summary>
        /// Method to start process for creating the ACW report files by depending upon the application last run time 
        /// & report duration from the database. 
        /// </summary>
        public void StartProcess()
        {
            int count = 0;       
            double hrs = 0;
            string Todaysdate = string.Empty;

            try
            {
               _ACWDAC.GetConfigurationSettings();

               _ACWDAC.CreateACWFolders();

                if (_ACWDAC.InformationLog != null)
                {
                    _isInfoLogRequired = _ACWDAC.InformationLog;
                }

                LogManager.LogInfoMessage(LogManager.source + " Started, threadid : " + _threadId, 2001, "Y");

                //Calculating hours since last run
                if (!string.IsNullOrEmpty(_ACWDAC.LastRuntime))
                {
                    DateTime t1 = Convert.ToDateTime(_ACWDAC.LastRuntime);
                    TimeSpan ts = DateTime.Now.Subtract(t1);
                    hrs = ts.TotalHours;
                }
                else //When service is run for the first time
                {
                    Todaysdate = System.DateTime.Now.ToString("yyyy-MM-dd");
                    _ACWDAC.GetACWData(Todaysdate);
                }

                //To ensure file creation only when time since last duration is greater than or equalto ReportDuration(configurable) 
               if (hrs >= _ACWDAC.ReportDuration)
               {
                   Todaysdate = System.DateTime.Now.ToString("yyyy-MM-dd");
                   _ACWDAC.GetACWData(Todaysdate);
               }
               else
               {
                   return;
               }

            }
            catch (ACWParserException acex)
            {
                LogManager.LogErrorMessage(acex.Message.ToString(), acex.ErrorCode);
            }
            catch (Exception e)
            {
                LogManager.LogErrorMessage("Error occured while processing " + LogManager.source + ", threadid : " + _threadId + ". " + count + " File(s) deleted. ", 5018, e);
            }
            finally
            {
                //disposing all objects                
            }

        }
        #endregion
    }
}
