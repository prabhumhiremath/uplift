﻿////-----------------------------------------------------------------------
//// <copyright file="ACWDAC.cs" company="NIIT">
////     Copyright (c) NIIT. All rights reserved.
//// </copyright>
//// <summary>
//// <Description>This file contains the Implementation of ACWDAC. This class is used
//// for interaction with database</Description>
//// <Author>NIIT Technologies</Author>
//// <CreatedOn>07/09/2011</CreatedOn>
//// <Modified>
////     <On></On>
////     <Desc></Desc>
////     <By></By>
//// </Modified>
//// </summary>
////----------------------------------------------------------------------
using System;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using System.IO;
using System.Text;
using EnterpriseDT.Net.Ftp;
using AmericanExpress.Services.ACW.BusinessEntities;
using AmericanExpress.Services.ACW.BusinessInterface;
using System.Diagnostics;
using System.Threading;
using System.Web;


namespace AmericanExpress.Services.ACW.Business
{
    /// <summary>
    /// ACWDAC Class Implementation
    /// </summary>
    public class ACWDAC
    {
        #region Variables

        private string _dbErrorCode; //to store DBError Code
        private SqlConnection _connACW; //for sql connection
        private SqlDataReader _sqlResult; //for reading records
        private string _sql = string.Empty; //to store sql statement
        private int _threadId = 0; //to store thread id
        private string _infoLog = "Y";
        private bool Isfilecreated = false;
        FileInfo[] localFileNames;

        //For FTP
        //FTPCredentials ftpCredentials;
        FTPCredentials ftpCredentials;
        int _statusUpdateWaitTime = 4000;
        ACWDAC ACWBusiness;
        ACWServiceBusinessEntities acwBusinessEntity;
        private IACWProcess acwBusinessInterface;
        #endregion

        #region Constructor
        /// <summary>
        /// Initialise the thread id number and ErrorCode in constructor
        /// </summary>
        /// <param name="threadID">int</param>
        /// <param name="infoLog">string</param>
        public ACWDAC(int threadID)
        {
            _threadId = threadID;
            //_dbErrorCode = ConfigurationManager.AppSettings["Common_DBERRORCODE"];
            _dbErrorCode = ConfigurationManager.AppSettings[Common._DBERRORCODE];
        }
        #endregion

        #region Properties
        /// <summary>
        /// This will get and set the Execution ID
        /// </summary>
        public int ExecutionID
        {
            get;
            set;
        }
        /// <summary>
        /// This will get and set the Organization Profile ID
        /// </summary>
        public string OrgnProfileID
        {
            get;
            set;
        }
        /// <summary>
        /// This will get and set the Organization Code
        /// </summary>
        public string OrgnCode
        {
            get;
            set;
        }
        /// <summary>
        /// This will get and set the Booking Country Code
        /// </summary>
        public string BookCountryCode
        {
            get;
            set;
        }
        /// <summary>
        /// This will get and set the Preference ID
        /// </summary>
        public string PreferenceID
        {
            get;
            set;
        }
        /// <summary>
        /// This will get and set the Report Preference
        /// </summary>
        public string ReportType
        {
            get;
            set;
        }
        /// <summary>
        /// This will get and set the Pos Tool
        /// </summary>
        public string PosTool
        {
            get;
            set;
        }
        /// <summary>
        /// This will get and set the Client Profile Name
        /// </summary>
        public string ClientProfileName
        {
            get;
            set;
        }

        //For FTP
        private string FTPClinet
        {
            get;
            set;
        }

        private string RequestType
        {
            get;
            set;
        }

        private string DataSource
        {
            get;
            set;
        }

        private string ProcessFileRetry_Interval
        {
            get;
            set;
        }

        private string ExecutionInterval_SFDC
        {
            get;
            set;
        }

        private string ExecutionInterval_GCSS
        {
            get;
            set;
        }

        private string ExecutionInterval_CP3
        {
            get;
            set;
        }


        #endregion

        #region Methods
        #region This will open the Database connection to the specified database in the app.config file.
        /// <summary>
        /// Method used to connect to the database. It returns true if connection open successfully else false
        /// </summary>
        /// <returns>bool</returns>
        public bool ConnectDatabase()
        {
            try
            {
                _connACW = new SqlConnection(ConfigManager.ConnectionString(Common._DBNAME));
                OpenConnection();
            }
            catch (Exception e)
            {
                if (_threadId == 0)
                {
                    LogManager.LogErrorMessage("Unable to connect to ACW Database to read thread count.", 5019, e);
                }
                else
                {
                    LogManager.LogErrorMessage("Unable to connect to ACW Database for threadid : " + _threadId + ".", 5001, e);
                }
                return false;
            }
            return true;
        }
        /// <summary>
        /// Method used to open the connection and logged the info
        /// </summary>
        private void OpenConnection()
        {
            try
            {
                _connACW.Open();
                if (_infoLog.ToUpper() == "Y")
                {
                    if (_threadId == 0)
                    {
                        //LogManager.LogInfoMessage("Connected successfully to ACW Database to read the thread count from application param table.", 2006);
                        LogManager.LogInfoMessage("Connected successfully to ACW Database to read the thread count from application param table.", 2006, "Y");
                    }
                    else
                    {
                        //LogManager.LogInfoMessage("Connected successfully to ACW Database for threadid : " + _threadId + ".", 2007);
                        LogManager.LogInfoMessage("Connected successfully to ACW Database for threadid : " + _threadId + ".", 2007, "Y");
                    }
                }
            }
            catch (Exception e)
            {
                _connACW.Dispose();
                throw new Exception("Unable to connect to ACW Database", e);
            }
        }
        #endregion

        #region This will close the Database connection.
        /// <summary>
        /// Method used to close the connection if it is open
        /// </summary>
        public void CloseConnection()
        {
            try
            {
                if (_connACW != null && _connACW.State == System.Data.ConnectionState.Open)
                    _connACW.Close();
            }
            finally
            {
                _connACW.Dispose();
            }
        }
        #endregion

        #region Read Mail Params
        /// <summary>
        /// Method used to retrieve the values from TBL_APPL_PARAM table related to EMail/ThreadCount
        /// </summary>
        /// <param name="criteria">string</param>
        /// <returns>DataSet</returns>
        /// 
        public void GetACWData(string todaysdate)
        {
            SqlDataAdapter da = null;
            DataTable dtFileDetails = new DataTable();
            
            try
            {

                
                SqlCommand cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@ToDate", SqlDbType.VarChar).Value = todaysdate;
                cmd.Parameters.AddWithValue("@Mode", SqlDbType.Char).Value = "T";
                cmd.CommandText = Common._SPGETACWREPORT;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = _connACW;
                cmd.CommandTimeout = 3600;
                da = new SqlDataAdapter(cmd);
                da.Fill(dtFileDetails);
                int count = dtFileDetails.Rows.Count;


                //this.FTPClinet = "Tumbleweed";
                //this.RequestType = "GET";
                //this.DataSource = "SFDC";
                //this.ProcessFileRetry_Interval = "60000";
                //this.LoadFTPCradentials(this.DataSource, "Initial", 0);

                //string directory = Server.MapPath("~/DesktopModules/SMSFunction/SMSText");
                //string location = ConfigurationSettings.AppSettings["TempACWreportlocation"].ToString();

                if (dtFileDetails.Rows.Count > 0 && dtFileDetails != null)
                {
                    //string directory = Path.GetDirectoryName(System.Reflection.Assembly.GetEntryAssembly().Location);
                    string directory = @"E:\AMERICANEXPRESS.Services.ACW.XmlParser\AmericanExpress.Services.ACW.Test\bin\Debug\FilesToUpload\OUT\";
                    //string directory = System.Web.HttpContext.Current.Server.MapPath(location);
                    //string directory = Server.MapPath("~/DesktopModules/SMSFunction/SMSText"); 
                    //string directory = @"D:\yogesh\";
                    //string directory = ResolveUrl(@"D:\yogesh\");
                    //string filename = String.Format("{0:yyyy-MM-dd}__{1}.txt", DateTime.Now, name);
                    string ACWfilenamepart = ConfigurationSettings.AppSettings["ACWFileNamePart"].ToString();
                    //string name = "ACW";
                    // string filename = String.Format("{1}.{0:MMddyyyy}.txt", DateTime.Now, name);
                    string ACWfilename = String.Format("{2}.{0:MMddyyyy}.{1:MMddyyyy}.txt", DateTime.Now, DateTime.Today.AddDays(-4), ACWfilenamepart);
                    string path = Path.Combine(directory, ACWfilename);
                    Isfilecreated = CreateFile(path, dtFileDetails);
                    da.Dispose();
                    //CreateFile(@"D:\yogesh\ACW.txt",fileDetails);
                    //da.Dispose();
                }

                    if (Isfilecreated)
                    {

                        DateTime lastruntime = DateTime.Now;
                        //{10/16/2012 1:18:14 PM}
                        string lastrantime = lastruntime.ToString("yyyy-MM-dd HH:mm:ss.fff");
                        //2012-10-16 13:18:14.441
                        UpdateLastRunTime(lastrantime);
                        // cmd.Parameters.AddWithValue("@AppName", SqlDbType.c).Value = appName;
                    }
                
                //da.Dispose();

                ///Start Uploading to tumbleweed

                //"ACW"
                FTPUpload("DMFile");

                ///End here


                
            }
            catch (SqlException sqlex)
            {
                if (isDBConnectionError(sqlex.Number))
                {
                   // throw new ACWParserException("Unable to connect to Cobra Database while executing " + Common._SPGETPENDINGJOBREQUEST + " for threadid : " + _threadId + " and Job : " + JobName + ".", 5014, sqlex);
                }
                else
                {
                    //throw new ACWParserException("SQL Error while executing " + Common._SPGETPENDINGJOBREQUEST + " for retrieving execution id for threadid : " + _threadId + ".", 5015, sqlex);
                    //LogManager.LogErrorMessage("SQL Error while executing " + Common._SPGETPENDINGJOBREQUEST + " for retrieving execution id for threadid : " + _threadId + ".", 5011, sqlex);
                }
            }
            catch (Exception e)
            {
                //throw new ACWParserException("Unable to connect to Cobra Database while executing " + Common._SPGETPENDINGJOBREQUEST + " for threadid : " + _threadId + ".", 5005, e);
                //LogManager.LogErrorMessage("Error while executing " + Common._SPGETPENDINGJOBREQUEST + " for retrieving execution id for threadid : " + _threadId + ".", 5016, e);
            }
            finally
            {
                CleanUpResources();
            }
        }

        private void UpdateLastRunTime(string lastupdatedtime)
        {
            try
            {
                SqlCommand cmdUpdate = new SqlCommand();
                cmdUpdate.Parameters.AddWithValue("@UpdatedDate", SqlDbType.VarChar).Value = lastupdatedtime;
                cmdUpdate.Parameters.AddWithValue("@Mode", SqlDbType.VarChar).Value = "U";
                cmdUpdate.CommandText = Common._SPGETACWREPORTCONFIGURATION;//"usp_GetACWCoralReport";
                cmdUpdate.CommandType = CommandType.StoredProcedure;
                cmdUpdate.Connection = _connACW;
                cmdUpdate.ExecuteNonQuery();
            }
            catch (SqlException sqlex)
            {
                if (isDBConnectionError(sqlex.Number))
                {
                    if (_threadId == 0)
                    {
                        throw new ACWParserException("Unable to connect to ACW Database while executing " + Common._SPGETACWREPORTCONFIGURATION + " for threadid : " + _threadId + ".", 5003, sqlex);
                    }
                    else
                    {
                        throw new ACWParserException("Unable to connect to ACW Database while executing threadid : " + _threadId + ".", 5003, sqlex);
                    }
                }

                else
                {
                    if (_threadId == 0)
                    {
                        LogManager.LogErrorMessage("SQL Error while executing " + Common._SPGETACWREPORTCONFIGURATION + ".", 5027, sqlex);
                    }

                    else
                    {
                        LogManager.LogErrorMessage("SQL Error while executing threadid : " + _threadId + ".", 5024, sqlex);
                    }


                }

            }

            catch (Exception e)
            {
                if (_threadId == 0)
                {
                    LogManager.LogErrorMessage("Error while executing " + Common._SPGETACWREPORTCONFIGURATION + " for retrieving execution id for threadid : " + _threadId + ".", 5028, e);
                }
                else
                {
                    LogManager.LogErrorMessage("Error while executing threadid : " + _threadId + ".", 5025, e);
                }

            }
            finally
            {
                CleanUpResources();
            }
            //throw new NotImplementedException();
        }

        /// <summary>
        /// Method to create the ACW txt file on the basis of data recived from the database & returns true 
        /// on successfull creation od the file
        /// 
        /// </summary>
        private bool CreateFile(string strFilePath, DataTable dtFiledtls)
        {
            // Create the CSV file to which data will be exported.
            //StreamWriter sw = new StreamWriter(Server.MapPath(strFilePath), false);
            try
            {
                StreamWriter sw = new StreamWriter(strFilePath, false);
                // First we will write the headers.
                int iColCount = dtFiledtls.Columns.Count;
                for (int i = 0; i < iColCount; i++)
                {
                    sw.Write(dtFiledtls.Columns[i]);
                    if (i < iColCount - 1)
                    {
                        sw.Write("|");
                    }
                }

                sw.Write(sw.NewLine);
                // Now write all the rows.
                foreach (DataRow dr in dtFiledtls.Rows)
                {
                    for (int i = 0; i < iColCount; i++)
                    {
                        if (!Convert.IsDBNull(dr[i]))
                        {
                            sw.Write(dr[i].ToString());

                        }
                        if (i < iColCount - 1)
                        {
                            sw.Write("|");
                        }
                    }
                    sw.Write(sw.NewLine);
                }
                sw.Close();

                return true;
            }
            catch (Exception ex)
            {
                return false;
            }

            //catch (ACWParserException acwex)
            //{
            //    throw new ACWParserException(acwex.Message.ToString(), acwex.ErrorCode, acwex);
            //}

            //catch (Exception e)
            //{
            //    //throw new JobSchedulerException("Unable to connect to Cobra Database while executing " + Common._SPGETPENDINGJOBREQUEST + " for threadid : " + _threadId + ".", 5005, e);
            //    LogManager.LogErrorMessage("Error while creating file for threadid : " + _threadId + ".", 5016, e);
            //}

         }

        //public DataSet GetFTPCradentials(string p, string p_2)
        //{
        //}

       
        /// <summary>
        /// Method to get the report configuration
        /// </summary>
        public DataTable GetACWReportConfiguration()
        {
            DataTable ACWconfigData = null;
            SqlDataAdapter sqlDataAdapter = null;
            try
            {
                ACWconfigData = new DataTable();
                SqlCommand cmdSelect = new SqlCommand();
                cmdSelect.Parameters.AddWithValue("@UpdatedDate", SqlDbType.VarChar).Value = DBNull.Value;
                cmdSelect.Parameters.AddWithValue("@Mode", SqlDbType.Char).Value = "S";
                cmdSelect.CommandText = Common._SPGETACWREPORTCONFIGURATION;
                cmdSelect.CommandType = CommandType.StoredProcedure;
                cmdSelect.Connection = _connACW;
                cmdSelect.CommandTimeout = 3600;

                sqlDataAdapter = new SqlDataAdapter(cmdSelect);
                sqlDataAdapter.Fill(ACWconfigData);
                sqlDataAdapter.Dispose();
            }
            catch (SqlException sqlex)
            {
                if (isDBConnectionError(sqlex.Number))
                {
                    if (_threadId == 0)
                    {
                        throw new ACWParserException("Unable to connect to ACW Database while executing " + Common._SPGETACWREPORTCONFIGURATION + " for threadid : " + _threadId + ".", 5003, sqlex);
                    }
                    else
                    {
                        throw new ACWParserException("Unable to connect to ACW Database while executing threadid : " + _threadId + ".", 5003, sqlex);
                    }
                }
                    
                else
                 {
                     if (_threadId == 0)
                     {
                         LogManager.LogErrorMessage("SQL Error while executing " + Common._SPGETACWREPORTCONFIGURATION + ".", 5027, sqlex);
                     }

                     else
                     {
                         LogManager.LogErrorMessage("SQL Error while executing threadid : " + _threadId + ".", 5024, sqlex);
                     }
                   
                 }
                    
             }
                
            catch (Exception e)
            {
                if (_threadId == 0)
                {
                    LogManager.LogErrorMessage("Error while executing " + Common._SPGETACWREPORTCONFIGURATION + " for retrieving execution id for threadid : " + _threadId + ".", 5028, e);
                }
                else
                {
                    LogManager.LogErrorMessage("Error while executing threadid : " + _threadId + ".", 5025, e);
                }
                
            }
            finally
            {
                CleanUpResources();
            }
            int count = ACWconfigData.Rows.Count;
            return ACWconfigData;
            
        }



        //private void LoadFTPCradentials(string DataSource, string CallType, int ThreadID)
        //{
        //    //pipelineDWBusiness = new PipelineDatawarehouseBusiness();
        //    ACWBusiness = new ACWDAC();
        //    acwBusinessEntity = new ACWServiceBusinessEntities();
        //    //acwBusinessEntity = new ACWServiceBusinessEntities();
        //    DataSet FTPCradentials = new DataSet();
        //    ftpCredentials = new FTPCredentials();
        //    bool DownloadStatus = false;

        //    try
        //    {
        //        acwBusinessEntity.FTPClient = this.FTPClinet;
        //        acwBusinessEntity.RequestType = this.RequestType;

        //        FTPCradentials = acwBusinessInterface.GetFTPCradentials(this.FTPClinet, this.RequestType);

        //        //FTPCradentials = DWBusinessInterface.GetFTPCradentials(acwBusinessEntity);
        //        FTPCradentials = acwBusinessInterface.GetFTPCradentials(acwBusinessEntity);

        //        switch (DataSource)
        //        {
        //            case ("SFDC"):
        //                if (CallType != "Initial")
        //                {
        //                    timerSFDC.Enabled = false;
        //                    timerSFDC.Dispose();
        //                }

        //                ftpCredentials.ftpClient = "Tumbleweed";
        //                DataRow[] drServerName = FTPCradentials.Tables[0].Select("CONFIG_PARAM_NM = 'FTP_SERVER_NAME'");
        //                ftpCredentials.serverName = drServerName[0][2].ToString();

        //                DataRow[] drUserID = FTPCradentials.Tables[0].Select("CONFIG_PARAM_NM = 'FTP_USER_ID'");
        //                ftpCredentials.userId = drUserID[0][2].ToString();

        //                DataRow[] drPassword = FTPCradentials.Tables[0].Select("CONFIG_PARAM_NM = 'FTP_PASSWORD'");
        //                ftpCredentials.password = drPassword[0][2].ToString();

        //                DataRow[] drRemoteDirectory = FTPCradentials.Tables[0].Select("CONFIG_PARAM_NM = 'FTP_REMOTE_DIRECTORY'");
        //                ftpCredentials.remoteDirectory = drRemoteDirectory[0][2].ToString();

        //                DataRow[] drRemoteFileName = FTPCradentials.Tables[0].Select("CONFIG_PARAM_NM = 'FTP_REMOTE_FILE_NAME_SFDC'");
        //                ftpCredentials.remoteFileName = drRemoteFileName[0][2].ToString();

        //                //ftpCredentials.remoteFileName = ftpCredentials.remoteFileName + String.Format("{0:yyyy/MM/dd}", Yesterday).Replace("/", "") + ".csv";

        //                DataRow[] drLocalDirectory = FTPCradentials.Tables[0].Select("CONFIG_PARAM_NM = 'FTP_LOCAL_DIRECTORY_NAME'");
        //                ftpCredentials.localDirectory = drLocalDirectory[0][2].ToString();

        //                //DataRow[] drLocalFileName = FTPCradentials.Tables[0].Select("CONFIG_PARAM_NM = 'FTP_LOCAL_FILE_NAME_SFDC'");
        //                //ftpCredentials.localFileName = drLocalFileName[0][2].ToString();

        //                //ftpCredentials.localFileName = ftpCredentials.localFileName + String.Format("{0:yyyy/MM/dd}", Yesterday).Replace("/", "") + ".csv";

        //                DataRow[] drPort = FTPCradentials.Tables[0].Select("CONFIG_PARAM_NM = 'FTP_PORT'");
        //                ftpCredentials.port = Int32.Parse(drPort[0][2].ToString());

        //                DataRow[] drFileType = FTPCradentials.Tables[0].Select("CONFIG_PARAM_NM = 'FTP_FILE_TYPE'");
        //                ftpCredentials.fileType = drFileType[0][2].ToString();

        //                DataRow[] drProtocol = FTPCradentials.Tables[0].Select("CONFIG_PARAM_NM = 'FTP_PROTOCOL'");
        //                ftpCredentials.protocol = drProtocol[0][2].ToString();

        //                DataRow[] drHandleMultipleFiles = FTPCradentials.Tables[0].Select("CONFIG_PARAM_NM = 'FTP_HANDLE_MULTIPLE_FILES'");
        //                ftpCredentials.handleMultipleFiles = drHandleMultipleFiles[0][2].ToString();

        //                DataRow[] drOperation = FTPCradentials.Tables[0].Select("CONFIG_PARAM_NM = 'FTP_OPERATION'");
        //                ftpCredentials.operation = drOperation[0][2].ToString();

        //                DataRow[] drWaitForExitDuration = FTPCradentials.Tables[0].Select("CONFIG_PARAM_NM = 'FTP_WAIT_FOR_EXIT_DURATION'");
        //                ftpCredentials.waitForExitDuration = Int32.Parse(drWaitForExitDuration[0][2].ToString());

        //                DataRow[] drDownloadlog = FTPCradentials.Tables[0].Select("CONFIG_PARAM_NM = 'FTP_DOWNLOAD_LOG'");
        //                @ftpCredentials.downloadlog = drDownloadlog[0][2].ToString();

        //                DataRow[] drTumbleweedClientLocation = FTPCradentials.Tables[0].Select("CONFIG_PARAM_NM = 'FTP_TUMBLEWEED_CLIENT_LOCATION'");
        //                @ftpCredentials.tumbleweedClientLocation = drTumbleweedClientLocation[0][2].ToString();

        //                DataRow[] drExecutionInterval = FTPCradentials.Tables[0].Select("CONFIG_PARAM_NM = 'EXECUTION_INTERVAL_SFDC'");
        //                this.ExecutionInterval_SFDC = drExecutionInterval[0][2].ToString();

        //                DataRow[] drExecutionIntervalGCSS = FTPCradentials.Tables[0].Select("CONFIG_PARAM_NM = 'EXECUTION_INTERVAL_GCSS'");
        //                this.ExecutionInterval_GCSS = drExecutionIntervalGCSS[0][2].ToString();

        //                DataRow[] drExecutionIntervalCP31 = FTPCradentials.Tables[0].Select("CONFIG_PARAM_NM = 'EXECUTION_INTERVAL_CP3'");
        //                this.ExecutionInterval_CP3 = drExecutionIntervalCP31[0][2].ToString();
        //                break;


        //            case ("GCSS"):

        //                if (CallType != "Initial")
        //                {
        //                    timerGCSS.Enabled = false;
        //                    timerGCSS.Dispose();
        //                }

        //                ftpCredentials.ftpClient = "Tumbleweed";
        //                DataRow[] drServerNameGCSS = FTPCradentials.Tables[0].Select("CONFIG_PARAM_NM = 'FTP_SERVER_NAME'");
        //                ftpCredentials.serverName = drServerNameGCSS[0][2].ToString();

        //                DataRow[] drUserIDGCSS = FTPCradentials.Tables[0].Select("CONFIG_PARAM_NM = 'FTP_USER_ID'");
        //                ftpCredentials.userId = drUserIDGCSS[0][2].ToString();

        //                DataRow[] drPasswordGCSS = FTPCradentials.Tables[0].Select("CONFIG_PARAM_NM = 'FTP_PASSWORD'");
        //                ftpCredentials.password = drPasswordGCSS[0][2].ToString();

        //                DataRow[] drRemoteDirectoryGCSS = FTPCradentials.Tables[0].Select("CONFIG_PARAM_NM = 'FTP_REMOTE_DIRECTORY'");
        //                ftpCredentials.remoteDirectory = drRemoteDirectoryGCSS[0][2].ToString();

        //                DataRow[] drRemoteFileNameGCSS_SATTEL = FTPCradentials.Tables[0].Select("CONFIG_PARAM_NM = 'FTP_REMOTE_FILE_NAME_GCSS_STTL'");
        //                ftpCredentials.remoteFileNameGCSS_SATTEL = drRemoteFileNameGCSS_SATTEL[0][2].ToString();

        //                //ftpCredentials.remoteFileNameGCSS_SATTEL = ftpCredentials.remoteFileNameGCSS_SATTEL + String.Format("{0:yyyy/MM/dd}", Yesterday).Replace("/", "") + ".dat";

        //                DataRow[] drRemoteFileNameGCSS_ACCUL = FTPCradentials.Tables[0].Select("CONFIG_PARAM_NM = 'FTP_REMOTE_FILE_NAME_GCSS_ACUL'");
        //                ftpCredentials.remoteFileNameGCSS_ACCUL = drRemoteFileNameGCSS_ACCUL[0][2].ToString();

        //                //ftpCredentials.remoteFileNameGCSS_ACCUL = ftpCredentials.remoteFileNameGCSS_ACCUL + String.Format("{0:yyyy/MM/dd}", Yesterday).Replace("/", "") + ".dat";


        //                DataRow[] drLocalDirectoryGCSS = FTPCradentials.Tables[0].Select("CONFIG_PARAM_NM = 'FTP_LOCAL_DIRECTORY_NAME'");
        //                ftpCredentials.localDirectory = drLocalDirectoryGCSS[0][2].ToString();

        //                //DataRow[] drLocalFileNameGCSS_SATTEL = FTPCradentials.Tables[0].Select("CONFIG_PARAM_NM = 'FTP_LOCAL_FILE_NAME_GCSS_STTL'");
        //                //ftpCredentials.localFileNameGCSS_SATTEL = drLocalFileNameGCSS_SATTEL[0][2].ToString();

        //                //ftpCredentials.localFileNameGCSS_SATTEL = ftpCredentials.localFileNameGCSS_SATTEL + String.Format("{0:yyyy/MM/dd}", Yesterday).Replace("/", "") + ".dat";

        //                //DataRow[] drLocalFileNameGCSS_ACCUL = FTPCradentials.Tables[0].Select("CONFIG_PARAM_NM = 'FTP_LOCAL_FILE_NAME_GCSS_ACUL'");
        //                //ftpCredentials.localFileNameGCSS_ACCUL = drLocalFileNameGCSS_ACCUL[0][2].ToString();

        //                //ftpCredentials.localFileNameGCSS_ACCUL = ftpCredentials.localFileNameGCSS_ACCUL + String.Format("{0:yyyy/MM/dd}", Yesterday).Replace("/", "") + ".dat";

        //                DataRow[] drPortGCSS = FTPCradentials.Tables[0].Select("CONFIG_PARAM_NM = 'FTP_PORT'");
        //                ftpCredentials.port = Int32.Parse(drPortGCSS[0][2].ToString());

        //                DataRow[] drFileTypeGCSS = FTPCradentials.Tables[0].Select("CONFIG_PARAM_NM = 'FTP_FILE_TYPE'");
        //                ftpCredentials.fileType = drFileTypeGCSS[0][2].ToString();

        //                DataRow[] drProtocolGCSS = FTPCradentials.Tables[0].Select("CONFIG_PARAM_NM = 'FTP_PROTOCOL'");
        //                ftpCredentials.protocol = drProtocolGCSS[0][2].ToString();

        //                DataRow[] drHandleMultipleFilesGCSS = FTPCradentials.Tables[0].Select("CONFIG_PARAM_NM = 'FTP_HANDLE_MULTIPLE_FILES'");
        //                ftpCredentials.handleMultipleFiles = drHandleMultipleFilesGCSS[0][2].ToString();

        //                DataRow[] drOperationGCSS = FTPCradentials.Tables[0].Select("CONFIG_PARAM_NM = 'FTP_OPERATION'");
        //                ftpCredentials.operation = drOperationGCSS[0][2].ToString();

        //                DataRow[] drWaitForExitDurationGCSS = FTPCradentials.Tables[0].Select("CONFIG_PARAM_NM = 'FTP_WAIT_FOR_EXIT_DURATION'");
        //                ftpCredentials.waitForExitDuration = Int32.Parse(drWaitForExitDurationGCSS[0][2].ToString());

        //                DataRow[] drDownloadlogGCSS = FTPCradentials.Tables[0].Select("CONFIG_PARAM_NM = 'FTP_DOWNLOAD_LOG'");
        //                @ftpCredentials.downloadlog = drDownloadlogGCSS[0][2].ToString();

        //                DataRow[] drTumbleweedClientLocationGCSS = FTPCradentials.Tables[0].Select("CONFIG_PARAM_NM = 'FTP_TUMBLEWEED_CLIENT_LOCATION'");
        //                @ftpCredentials.tumbleweedClientLocation = drTumbleweedClientLocationGCSS[0][2].ToString();

        //                DataRow[] drExecutionIntervalGCSS1 = FTPCradentials.Tables[0].Select("CONFIG_PARAM_NM = 'EXECUTION_INTERVAL_GCSS'");
        //                this.ExecutionInterval_GCSS = drExecutionIntervalGCSS1[0][2].ToString();
        //                break;


        //            case ("CP3"):


        //                if (CallType != "Initial")
        //                {
        //                    timerCP3.Enabled = false;
        //                    timerCP3.Dispose();
        //                }

        //                ftpCredentials.ftpClient = "Tumbleweed";
        //                DataRow[] drServerNameCP3 = FTPCradentials.Tables[0].Select("CONFIG_PARAM_NM = 'FTP_SERVER_NAME'");
        //                ftpCredentials.serverName = drServerNameCP3[0][2].ToString();

        //                DataRow[] drUserIDCP3 = FTPCradentials.Tables[0].Select("CONFIG_PARAM_NM = 'FTP_USER_ID'");
        //                ftpCredentials.userId = drUserIDCP3[0][2].ToString();

        //                DataRow[] drPasswordCP3 = FTPCradentials.Tables[0].Select("CONFIG_PARAM_NM = 'FTP_PASSWORD'");
        //                ftpCredentials.password = drPasswordCP3[0][2].ToString();

        //                DataRow[] drRemoteDirectoryCP3 = FTPCradentials.Tables[0].Select("CONFIG_PARAM_NM = 'FTP_REMOTE_DIRECTORY'");
        //                ftpCredentials.remoteDirectory = drRemoteDirectoryCP3[0][2].ToString();

        //                DataRow[] drRemoteFileNameCP3_SATTEL = FTPCradentials.Tables[0].Select("CONFIG_PARAM_NM = 'FTP_REMOTE_FILE_NAME_CP3_STTL'");
        //                ftpCredentials.remoteFileNameCP3_SATTEL = drRemoteFileNameCP3_SATTEL[0][2].ToString();

        //                //ftpCredentials.remoteFileNameCP3_SATTEL = ftpCredentials.remoteFileNameCP3_SATTEL + String.Format("{0:yyyy/MM/dd}", Yesterday).Replace("/", "") + ".dat";

        //                DataRow[] drRemoteFileNameCP3_ACCUL = FTPCradentials.Tables[0].Select("CONFIG_PARAM_NM = 'FTP_REMOTE_FILE_NAME_CP3_ACUL'");
        //                ftpCredentials.remoteFileNameCP3_ACCUL = drRemoteFileNameCP3_ACCUL[0][2].ToString();

        //                //ftpCredentials.remoteFileNameCP3_ACCUL = ftpCredentials.remoteFileNameCP3_ACCUL + String.Format("{0:yyyy/MM/dd}", Yesterday).Replace("/", "") + ".dat";


        //                DataRow[] drLocalDirectoryCP3 = FTPCradentials.Tables[0].Select("CONFIG_PARAM_NM = 'FTP_LOCAL_DIRECTORY_NAME'");
        //                ftpCredentials.localDirectory = drLocalDirectoryCP3[0][2].ToString();

        //                //DataRow[] drLocalFileNameCP3_SATTEL = FTPCradentials.Tables[0].Select("CONFIG_PARAM_NM = 'FTP_LOCAL_FILE_NAME_CP3_STTL'");
        //                //ftpCredentials.localFileNameCP3_SATTEL = drLocalFileNameCP3_SATTEL[0][2].ToString();

        //                //ftpCredentials.localFileNameCP3_SATTEL = ftpCredentials.localFileNameCP3_SATTEL + String.Format("{0:yyyy/MM/dd}", Yesterday).Replace("/", "") + ".dat";

        //                //DataRow[] drLocalFileNameCP3_ACCUL = FTPCradentials.Tables[0].Select("CONFIG_PARAM_NM = 'FTP_LOCAL_FILE_NAME_CP3_ACUL'");
        //                //ftpCredentials.localFileNameCP3_ACCUL = drLocalFileNameCP3_ACCUL[0][2].ToString();

        //                //ftpCredentials.localFileNameCP3_ACCUL = ftpCredentials.localFileNameCP3_ACCUL + String.Format("{0:yyyy/MM/dd}", Yesterday).Replace("/", "") + ".dat";

        //                DataRow[] drPortCP3 = FTPCradentials.Tables[0].Select("CONFIG_PARAM_NM = 'FTP_PORT'");
        //                ftpCredentials.port = Int32.Parse(drPortCP3[0][2].ToString());

        //                DataRow[] drFileTypeCP3 = FTPCradentials.Tables[0].Select("CONFIG_PARAM_NM = 'FTP_FILE_TYPE'");
        //                ftpCredentials.fileType = drFileTypeCP3[0][2].ToString();

        //                DataRow[] drProtocolCP3 = FTPCradentials.Tables[0].Select("CONFIG_PARAM_NM = 'FTP_PROTOCOL'");
        //                ftpCredentials.protocol = drProtocolCP3[0][2].ToString();

        //                DataRow[] drHandleMultipleFilesCP3 = FTPCradentials.Tables[0].Select("CONFIG_PARAM_NM = 'FTP_HANDLE_MULTIPLE_FILES'");
        //                ftpCredentials.handleMultipleFiles = drHandleMultipleFilesCP3[0][2].ToString();

        //                DataRow[] drOperationCP3 = FTPCradentials.Tables[0].Select("CONFIG_PARAM_NM = 'FTP_OPERATION'");
        //                ftpCredentials.operation = drOperationCP3[0][2].ToString();

        //                DataRow[] drWaitForExitDurationCP3 = FTPCradentials.Tables[0].Select("CONFIG_PARAM_NM = 'FTP_WAIT_FOR_EXIT_DURATION'");
        //                ftpCredentials.waitForExitDuration = Int32.Parse(drWaitForExitDurationCP3[0][2].ToString());

        //                DataRow[] drDownloadlogCP3 = FTPCradentials.Tables[0].Select("CONFIG_PARAM_NM = 'FTP_DOWNLOAD_LOG'");
        //                @ftpCredentials.downloadlog = drDownloadlogCP3[0][2].ToString();

        //                DataRow[] drTumbleweedClientLocationCP3 = FTPCradentials.Tables[0].Select("CONFIG_PARAM_NM = 'FTP_TUMBLEWEED_CLIENT_LOCATION'");
        //                @ftpCredentials.tumbleweedClientLocation = drTumbleweedClientLocationCP3[0][2].ToString();

        //                DataRow[] drExecutionIntervalCP32 = FTPCradentials.Tables[0].Select("CONFIG_PARAM_NM = 'EXECUTION_INTERVAL_CP3'");
        //                this.ExecutionInterval_CP3 = drExecutionIntervalCP32[0][2].ToString();
        //                break;
        //        }

        //        if (CallType != "Initial")
        //        {
        //            DownloadStatus = this.GetFiles_Tumbleweed(1, DataSource, ThreadID);
        //            ReinitializeTimer(DataSource);
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        LogManager.LogErrorMessage("Exception : Error While retriving File from Tumbleweed" + LogManager.source, 5006, ex);
        //    }
        //}


        //public DataSet GetFTPCradentials(string ftpClient, string reqType)
        //{
        //    SqlDataAdapter da = null;
        //    DataSet FTPCradentials = new DataSet();
        //    logManager = new LogManager();

        //    try
        //    {
        //        //LogDetails = "Executing procedure";
        //        //logManager.WriteToLogFile(LogDetails, 0);
        //        bool flag = ConnectDatabase();

        //        if (flag)
        //        {

        //            // _sql = "exec " + Common._SPGETACWREPORT + " " + "'" + todaysdate + "','" + Fifthdayfromtoday + "'";
        //            //_sql = "EXEC " + Common.USPGETFTPCRADENTIALS + " " + acwBusinessEntity.FTPClient;
        //            _sql = "exec " + Common.USPGETFTPCRADENTIALS + " " + "'" + ftpClient + "','" + reqType + "'";

        //            //_connACW
        //            SqlCommand cmd = new SqlCommand(_sql, _connACW);

        //            //SqlCommand cmd = new SqlCommand(_sql, _connDW);
        //            da = new SqlDataAdapter(cmd);
        //            da.Fill(FTPCradentials);

        //            da.Dispose();

        //            //LogDetails = "Executed Query Sucessfully.....";
        //            //logManager.WriteToLogFile(LogDetails, 0);

        //            //LogManager.LogInfoMessage(LogManager.source + " connected to database", 5001, "Y");

        //            CloseConnection();
        //        }

        //    }
        //    catch (Exception ex)
        //    {
        //        //LogDetails = "Error While retriving From Database : " + ex.ToString();
        //        //logManager.WriteToLogFile(LogDetails, 0);
        //    }
        //    return FTPCradentials;
        //}

        //public DataSet GetFTPCradentials(ACWServiceBusinessEntities acwBusinessEntity)
        //{
        //    SqlDataAdapter da = null;
        //    DataSet FTPCradentials = new DataSet();
        //    logManager = new LogManager();

        //    try
        //    {
        //        //LogDetails = "Executing procedure";
        //        //logManager.WriteToLogFile(LogDetails, 0);
        //        bool flag = ConnectDatabase();

        //        if (flag)
        //        {
        //            _sql = "EXEC " + Common.USPGETFTPCRADENTIALS + " " + acwBusinessEntity.FTPClient;

        //            SqlCommand cmd = new SqlCommand(_sql, _connDW);
        //            da = new SqlDataAdapter(cmd);
        //            da.Fill(FTPCradentials);

        //            da.Dispose();

        //            //LogDetails = "Executed Query Sucessfully.....";
        //            //logManager.WriteToLogFile(LogDetails, 0);

        //            //LogManager.LogInfoMessage(LogManager.source + " connected to database", 5001, "Y");

        //            CloseConnection();
        //        }

        //    }
        //    catch (Exception ex)
        //    {
        //        //LogDetails = "Error While retriving From Database : " + ex.ToString();
        //        //logManager.WriteToLogFile(LogDetails, 0);
        //    }
        //    return FTPCradentials;
        //}


        private void FTPUpload(string fileType)
        {


            string filename = string.Empty;
            //string credentialString = ConfigManager.GetSettings(fileType);
            string[] credentials = ConfigurationManager.ConnectionStrings[fileType].ConnectionString.Split('|');

            int i = 0;
            FTPCredentials ftpCredentials = new FTPCredentials();
            ftpCredentials.fileType = fileType;
            ftpCredentials.serverName = credentials[i++];
            ftpCredentials.userId = credentials[i++];
            ftpCredentials.password = credentials[i++];
            ftpCredentials.localFileName = credentials[i++];
            ftpCredentials.remoteFileName = credentials[i++];
            ftpCredentials.handleMultipleFiles = credentials[i++];
            ftpCredentials.localDirectory = credentials[i++];
            ftpCredentials.localMoveDirectory = credentials[i++];
            ftpCredentials.remoteDirectory = credentials[i++];
            ftpCredentials.operation = credentials[i++];
            ftpCredentials.tumbleweebCommandParams = credentials[i++].ToString().Trim();
            ftpCredentials.protocol = ConfigurationSettings.AppSettings["Protocol"];
            ftpCredentials.ftpClient = ConfigurationSettings.AppSettings["FTPClient"];
            ftpCredentials.port = Convert.ToInt32(ConfigurationSettings.AppSettings["Port"]);
            ftpCredentials.tumbleweedClientLocation = ConfigurationSettings.AppSettings["TumbleweedClientLocation"];
            ftpCredentials.waitForExitDuration = Convert.ToInt32(ConfigurationSettings.AppSettings["WaitForExitDuration"]);
            ftpCredentials.uploadLog = ConfigurationSettings.AppSettings["UploadLog"];
            ftpCredentials.downloadlog = ConfigurationSettings.AppSettings["Downloadlog"];

            //SendFiles_Tumbleweed
            GetLocalFileNames(ftpCredentials.localDirectory, ftpCredentials.localFileName);
            for (i = 0; i < localFileNames.Length; i++)
            {
                bool sent = false;
                filename = localFileNames[i].ToString();
                Put_Tumbleweed(ftpCredentials.localDirectory + "\\" + filename, filename + "_" + DateTime.Now.ToString("yyyy_MM_dd_HH_mm_ss") + ".log", filename, ftpCredentials);
                MoveFile(ftpCredentials.localDirectory + "\\" + filename, ftpCredentials.localMoveDirectory + "\\" + filename, filename, true);
                sent = true;
            }

        }
        private void MoveFile(string source, string destination, string filename, bool deleteExisting)
        {
            try
            {

                if (File.Exists(destination))
                {
                    if (deleteExisting == false)
                    {
                        String[] fileparts = destination.Split(".".ToCharArray());
                        String newfile;
                        if (fileparts.GetUpperBound(0) == 1)
                            newfile = fileparts[0] + DateTime.Now.ToString("yyyy_MM_dd_HH_mm_ss") + "." + fileparts[1];
                        else
                            newfile = fileparts[0] + DateTime.Now.ToString("yyyy_MM_dd_HH_mm_ss");

                        destination = newfile;
                    }
                    else
                    {
                        File.Delete(destination);
                    }
                }
                File.Move(source, destination);
                //LogManager.LogInfoMessage("Local file " + filename + " moved.", 2004);
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message);
            }
        }
        private void GetLocalFileNames(string fileLocation, string fileName)
        {
            DirectoryInfo dir = new DirectoryInfo(fileLocation);
            localFileNames = dir.GetFiles(fileName + "*");

        }
        private System.Diagnostics.Process CurrentSTProcess()
        {
            System.Diagnostics.Process process = null;
            foreach (System.Diagnostics.Process p in System.Diagnostics.Process.GetProcesses())
            {
                if (p.ProcessName.Contains("stclient"))
                {
                    process = p;
                    break;
                }
            }
            if (process == null)
            {
                process = new System.Diagnostics.Process();
            }
            else
            {
                process.Refresh();
            }

            return process;
        }
        private void Put_Tumbleweed(String localFilePath, String logfilename, String filename, FTPCredentials ftpCredentials)
        {
            string uploadstatus = "";
            string contents = "";
            int count = 0;
            int statusUpdateWaitTime = 4000;
            string uploadFileStatusPath = @ftpCredentials.uploadLog + "\\" + logfilename;
            string arguments = @ftpCredentials.protocol + "u://" +
                ftpCredentials.userId + ":" + ftpCredentials.password + "@" + ftpCredentials.serverName + ":" + ftpCredentials.port + "/" +
                ftpCredentials.remoteDirectory + " " + localFilePath + " /prefNoAskSched /quitWhenDone /hidden /prefRetries 0 /log /statusBAT "
                + uploadFileStatusPath;

            if (ftpCredentials.tumbleweebCommandParams != "")
                arguments = arguments + " " + ftpCredentials.tumbleweebCommandParams;


            Process process = CurrentSTProcess();
            GetRunningProcessDetails("After Object creation");
            try
            {
                if (File.Exists(uploadFileStatusPath))
                {
                    contents = File.ReadAllText(uploadFileStatusPath).ToUpper();
                    if (contents.IndexOf("ACTIVE") > 0 || contents.IndexOf("WAITING") > 0)
                    {
                        //throw new FTPException("Previous transfer is still in progress.");
                    }
                    else
                    {
                        File.Delete(uploadFileStatusPath);
                    }
                }
                DateTime timestamp = DateTime.Now;
                process.StartInfo.WorkingDirectory = @ftpCredentials.tumbleweedClientLocation;
                process.StartInfo.FileName = @ftpCredentials.tumbleweedClientLocation + "stclient.exe";
                process.StartInfo.Arguments = arguments;
                process.StartInfo.UseShellExecute = false;
                process.StartInfo.RedirectStandardOutput = false;
                process.StartInfo.RedirectStandardError = true;
                process.Start();
                count = GetRunningProcessDetails("After Start()");
                LogManager.LogInfoMessage("Instance of tumbleweed started with process id " + process.Id.ToString(), 9999);

                process.WaitForExit(ftpCredentials.waitForExitDuration);
                process.Close();
                count = GetRunningProcessDetails("After Close()");

                int sleepCount = 0;
                while (File.Exists(uploadFileStatusPath) == false && (DateTime.Compare(timestamp.AddMilliseconds(ftpCredentials.waitForExitDuration), DateTime.Now) > 0))
                {
                    sleepCount++;
                    Thread.Sleep(statusUpdateWaitTime);
                }
                LogManager.LogInfoMessage("Upload log file creation status is " + File.Exists(uploadFileStatusPath) + ", sleepcount : " + sleepCount, 9999);


                if (File.Exists(uploadFileStatusPath))
                {
                    sleepCount = 0;
                    contents = File.ReadAllText(uploadFileStatusPath).ToUpper();
                    while ((contents.IndexOf("ACTIVE") > 0 || contents.IndexOf("WAITING") > 0) && (DateTime.Compare(timestamp.AddMilliseconds(ftpCredentials.waitForExitDuration), DateTime.Now) > 0))
                    {
                        sleepCount++;
                        Thread.Sleep(statusUpdateWaitTime);
                        contents = File.ReadAllText(uploadFileStatusPath).ToUpper();

                    }
                    LogManager.LogInfoMessage("Upload status is " + contents + ", sleepcount : " + sleepCount, 9999);
                    if (contents.IndexOf("FILEDRIVESTATUS=") >= 0)
                    {
                        uploadstatus = contents.Split("\r\n".ToCharArray())[0].Substring(contents.LastIndexOf("FILEDRIVESTATUS=") + "FILEDRIVESTATUS=".Length).Trim();
                        if (uploadstatus.ToUpper().Trim() != "DONE")
                        {
                            throw new FTPException("File not uploaded sucessfully. Upload status is :" + uploadstatus);
                        }
                    }
                    else
                    {
                        throw new FTPException("File upload confirmation not received. Upload status is not available.");
                    }
                    LogManager.LogInfoMessage("Log File Created : " + uploadFileStatusPath, 2007);
                }
                else
                {
                    throw new FTPException("File upload confirmation not received. Upload log is not available.");
                }
                LogManager.LogInfoMessage("File " + filename + " sent on FTP server.", 2003);
            }
            catch (FTPException ex)
            {
                count = GetRunningProcessDetails("In Catch()");
                if (process != null)
                {
                    process.Dispose();
                }
                count = GetRunningProcessDetails("After Dispose()");
                KillDuplicateProcess();
                count = GetRunningProcessDetails("After Kill()");

                throw new FTPException("Error sending file.", 5302, ex);
            }

            catch (Exception ex)
            {
                count = GetRunningProcessDetails("In Catch()");
                if (process != null)
                {
                    process.Dispose();
                }
                count = GetRunningProcessDetails("After Dispose()");
                KillDuplicateProcess();
                count = GetRunningProcessDetails("After Kill()");

                throw new FTPException("Error sending file.", 5302, ex);
            }
        }
        private int GetRunningProcessDetails(string location)
        {
            String details = "";
            int count = 0;
            foreach (System.Diagnostics.Process p in System.Diagnostics.Process.GetProcesses())
            {
                if (p.ProcessName.Contains("stclient"))
                {
                    details = details + ", " + p.Id + ":" + p.ProcessName;
                    count++;
                }
            }
            LogManager.LogInfoMessage("Running instances [" + location + "] :" + details, 9999);
            return count;
        }
        private void KillDuplicateProcess()
        {
            int count = 0;
            int killcount = 0;
            System.Diagnostics.Process[] processes = System.Diagnostics.Process.GetProcesses();
            foreach (System.Diagnostics.Process p in processes)
            {
                if (p.ProcessName.Contains("stclient"))
                {
                    count++;
                    try
                    {
                        p.Kill();
                        killcount++;
                    }
                    catch (FTPException innerEx)
                    {
                        throw new FTPException("Error in killing 'tumblewewed client' instance. Process id is " + p.Id.ToString(), 5306, innerEx);
                    }

                    catch (Exception innerEx)
                    {
                        throw new FTPException("Error in killing 'tumblewewed client' instance. Process id is " + p.Id.ToString(), 5306, innerEx);
                    }
                }
            }
            LogManager.LogInfoMessage("tumbleweed instances running were " + count.ToString() + " instances killed are " + killcount.ToString(), 2009);
        }
        #endregion

        #region Check if its a DB COnnection error
        /// <summary>
        /// Method used to check the Error is database error which is defined in config file
        /// It returns true if it is DB Connection error else false
        /// </summary>
        /// <param name="SQLErrNumber">int</param>
        /// <returns>bool</returns>
        private bool isDBConnectionError(int SQLErrNumber)
        {
            try
            {
                string[] listedErrors = _dbErrorCode.Split(",".ToCharArray());
                for (int i = 0; i < listedErrors.Length; i++)
                {
                    if (listedErrors[i].Trim() == SQLErrNumber.ToString().Trim())
                    {
                        return true;
                    }
                }
                return false;
            }
            catch (Exception)
            {
                return false;
            }
        }
        #endregion

        #region Clean Up Resources
        /// <summary>
        /// Method used to clean up resources
        /// </summary>
        private void CleanUpResources()
        {
            if (_sqlResult != null)
            {
                if (!_sqlResult.IsClosed)
                    _sqlResult.Close();

                _sqlResult = null;
            }
        }
        #endregion
        #endregion
    }
}
