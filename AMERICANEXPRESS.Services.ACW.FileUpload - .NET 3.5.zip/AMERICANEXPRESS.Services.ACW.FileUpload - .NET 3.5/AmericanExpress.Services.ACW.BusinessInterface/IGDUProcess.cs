﻿////-----------------------------------------------------------------------
//// <copyright file="IGDUProcess.cs" company="NIIT">
////     Copyright (c) NIIT. All rights reserved.
//// </copyright>
//// <summary>
//// <Description>This file contains the Implementation of IGDUProcess Interface</Description>
//// <Author>NIIT Technologies</Author>
//// <CreatedOn>09/07/2011</CreatedOn>
//// <Modified>
////     <On></On>
////     <Desc></Desc>
////     <By></By>
//// </Modified>
//// </summary>
////----------------------------------------------------------------------
using System.Data;
//using AmericanExpress.Services.GDU.BusinessEntities;
namespace AmericanExpress.Services.ACW.BusinessInterface
{
    public interface IGDUProcess
    {
        /// <summary>
        /// This method is used for starting the process
        /// </summary>
        //void StartProcess(DataSet dsAppParam);
        void StartProcess();
        //DataSet GetFTPCradentials(ACWServiceBusinessEntities acwBusinessEntity);

        //DataSet GetFTPCradentials(string p, string p_2);
    }
}
