////-----------------------------------------------------------------------
//// <copyright file="AppLauncher.cs" company="NIIT">
////     Copyright (c) NIIT. All rights reserved.
//// </copyright>
//// <summary>
//// <Description>This class takes the parameter to run the application and run the application in new thread.</Description>
//// <Author>NIIT Technologies</Author>
//// <CreatedOn>09/07/2011</CreatedOn>
//// <Modified>
////     <On></On>
////     <Desc></Desc>
////     <By></By>
//// </Modified>
//// </summary>
////----------------------------------------------------------------------
using System;
using System.Threading;
using System.Configuration;
using System.Data;
using AmericanExpress.Services.ACW.Business;


namespace AmericanExpress.Services.ACW.FileUpload
{
    class AppLauncher
    {

        #region Variables
        string _message; //to store message
        int _threadId; //to store thread id
        int _threadNo; //to store number
        #endregion

        #region Constructor
        /// <summary>
        /// Constructor
        /// </summary>
        public AppLauncher()
        {
        }
        #endregion

        #region Methods
        /// <summary>
        /// Method used to set the thread no
        /// </summary>
        /// <param name="threadno">int</param>
        public void setThreadNO(int threadno)
        {
            _threadNo = threadno;
        }
        /// <summary>
        /// Method to Check the DB connection 
        /// and if sucessfully connect, then initiate FailSafe process
        /// </summary>
        public void RunACWReportParser(object parameter)
        {
            Thread currentThread = Thread.CurrentThread;
            _threadId = currentThread.ManagedThreadId;
            int SleepInterval = Convert.ToInt32(ConfigurationManager.AppSettings["TimeInterval"]);


            for (; ; )
            {
                try
                {
                    ACWDAC ACWDAC = new ACWDAC(_threadId);

                    if (ACWDAC.ConnectDatabase())
                    {
                        try
                        {
                            //Initiate the FailSafe process
                            ACWProcess ACWProcess = new ACWProcess(_threadId, ACWDAC);
                            ACWProcess.StartProcess();
                        }
                        catch (Exception e)
                        {
                            _message = "Error while processing in thread for threadid : " + _threadId + ".";
                            LogManager.LogErrorMessage(_message, 5001, e);
                        }
                        ACWDAC.CloseConnection();
                    }
                }
                catch (Exception e)
                {
                    _message = "Error while starting thread for threadid : " + _threadId + ".";
                    LogManager.LogErrorMessage(_message, 5002, e);
                }
                finally
                {
                    Thread.Sleep(SleepInterval); //Sleep the thread for configurable time, if thread ends sucessfully
                }
            }

        }
        #endregion
       
    }
}
