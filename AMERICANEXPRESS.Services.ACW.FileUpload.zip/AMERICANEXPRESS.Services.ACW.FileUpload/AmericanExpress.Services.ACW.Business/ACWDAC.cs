﻿////-----------------------------------------------------------------------
//// <copyright file="ACWDAC.cs" company="NIIT">
////     Copyright (c) NIIT. All rights reserved.
//// </copyright>
//// <summary>
//// <Description>This file contains the Implementation of ACWDAC. This class is used
//// for interaction with database</Description>
//// <Author>NIIT Technologies</Author>
//// <CreatedOn>10/09/2012</CreatedOn>
//// <Modified>
////     <On></On>
////     <Desc></Desc>
////     <By></By>
//// </Modified>
//// </summary>
////----------------------------------------------------------------------
using System;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using System.IO;
using System.Text;
using AmericanExpress.Services.ACW.BusinessInterface;
using System.Diagnostics;
using System.Threading;
using System.Web;


namespace AmericanExpress.Services.ACW.Business
{
    /// <summary>
    /// ACWDAC Class Implementation
    /// </summary>
    public class ACWDAC
    {
        #region Variables

        private string _dbErrorCode; //to store DBError Code
        private SqlConnection _connACW; //for sql connection
        private SqlDataReader _sqlResult; //for reading records
        private string _sql = string.Empty; //to store sql statement
        private int _threadId = 0; //to store thread id
        private bool Isfilecreated = false;
        FileInfo[] localFileNames;
        private string _infoLog = "Y";
        string mainDirectory = string.Empty;
        string ftpOutPath = string.Empty;
        string ftpMovedPath = string.Empty;
        string ftpUploadlogPath = string.Empty;
        string ftpDownloadlogPath = string.Empty;
        FTPCredentials ftpCredentials;
        
        #endregion

        #region Constructor
        /// <summary>
        /// Initialise the thread id number and ErrorCode in constructor
        /// </summary>
        /// <param name="threadID">int</param>
        /// <param name="infoLog">string</param>
        public ACWDAC(int threadID)
        {
            _threadId = threadID;
            _dbErrorCode = ConfigurationManager.AppSettings[Common._DBERRORCODE];
        }
        #endregion

        #region Properties

        public int ReportDuration
        {
            get;
            set;
        }

        public string LastRuntime
        {
            get;
            set;
        }

        public string InformationLog
        {
            get;
            set;
        }

        public string ACWFileNamePart
        {
            get;
            set;
        }

        public string TumbleweedExeName
        {
            get;
            set;
        }

        public double ReportDays
        {
            get;
            set;
        }

        
        #endregion

        #region Methods
        #region This will open the Database connection to the specified database in the app.config file.
        /// <summary>
        /// Method used to connect to the database. It returns true if connection open successfully else false
        /// </summary>
        /// <returns>bool</returns>
        public bool ConnectDatabase()
        {
            try
            {
                _connACW = new SqlConnection(ConfigManager.ConnectionString(Common._DBNAME));
                OpenConnection();
            }
            catch (Exception e)
            {
                if (_threadId == 0)
                {
                    LogManager.LogErrorMessage("Unable to connect to Database to read thread count.", 5019, e);
                }
                else
                {
                    LogManager.LogErrorMessage("Unable to connect to Database for threadid : " + _threadId + ".", 5001, e);
                }
                return false;
            }
            return true;
        }
        /// <summary>
        /// Method used to open the connection and logged the info
        /// </summary>
        private void OpenConnection()
        {
            try
            {
                _connACW.Open();
                if (_infoLog.ToUpper() == "Y")
                {
                    if (_threadId == 0)
                    {
                        LogManager.LogInfoMessage("Connected successfully to Database to read the thread count from application param table.", 2006, "Y");
                    }
                    else
                    {
                        LogManager.LogInfoMessage("Connected successfully to Database for threadid : " + _threadId + ".", 2007, "Y");
                    }
                }
            }
            catch (Exception e)
            {
                _connACW.Dispose();
                throw new Exception("Unable to connect to Database", e);
            }
        }
        #endregion

        #region This will close the Database connection.
        /// <summary>
        /// Method used to close the connection if it is open
        /// </summary>
        public void CloseConnection()
        {
            try
            {
                if (_connACW != null && _connACW.State == System.Data.ConnectionState.Open)
                    _connACW.Close();
            }
            finally
            {
                _connACW.Dispose();
            }
        }
        #endregion

        #region 
        /// <summary>
        /// Method used to pull the records for ACW file.
        /// </summary>
        /// <param name="todaysdate">string</param>
        /// <returns></returns>
        /// 
        public void GetACWData(string todaysdate)
        {
            SqlDataAdapter da = null;
            DataTable dtFileDetails = new DataTable();
            SqlCommand cmd = new SqlCommand();
            string acwDirectory = string.Empty;
            string acwFileNamePart = string.Empty;
            string acwFileName = string.Empty;
            string acwFilePath = string.Empty;

            try
            {
                cmd.Parameters.AddWithValue("@ToDate", SqlDbType.VarChar).Value = todaysdate;
                cmd.Parameters.AddWithValue("@Mode", SqlDbType.Char).Value = "T";
                cmd.CommandText = Common._SPGETACWREPORT;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = _connACW;
                cmd.CommandTimeout = 3600;
                da = new SqlDataAdapter(cmd);
                da.Fill(dtFileDetails);
                //int count = dtFileDetails.Rows.Count;

                if (dtFileDetails.Rows.Count > 0 && dtFileDetails != null)
                {
                    acwFileNamePart = ftpCredentials.FileType;
                    if (ftpCredentials.FileFormatType == "Y")
                    {
                        acwFileName = String.Format("{2}.{0:MMddyyyy}.{1:MMddyyyy}.txt", DateTime.Today.AddDays(ReportDays), DateTime.Now, acwFileNamePart);
                    }
                    else
                    {
                        acwFileName = acwFileNamePart + ".txt";//String.Format("{2}.{0:MMddyyyy}.{1:MMddyyyy}.txt", DateTime.Today.AddDays(ReportDays), DateTime.Now, acwFileNamePart);
                    }
                    //acwFileName = acwFileNamePart + ".txt";
                    acwFilePath = Path.Combine(ftpOutPath, acwFileName);
                    //Calling  the method for creating ACW file.
                    Isfilecreated = CreateFile(acwFilePath, dtFileDetails);
                }

                    if (Isfilecreated)
                    {
                        DateTime lastruntime = DateTime.Now;
                        string lastrantime = lastruntime.ToString("yyyy-MM-dd HH:mm:ss.fff");
                        UpdateLastRunTime(lastrantime);
                    }
                
               //Start Uploading to tumbleweed
                FTPUpload(ftpCredentials.FileType);
                     
            }
            catch (SqlException sqlex)
            {
                if (isDBConnectionError(sqlex.Number))
                {
                    throw new ACWParserException("Unable to connect to Database while executing " + Common._SPGETACWREPORT + " for threadid : " + _threadId + ".", 5014, sqlex);
                }
                else
                {
                    throw new ACWParserException("SQL Error while executing " + Common._SPGETACWREPORT + " for retrieving execution id for threadid : " + _threadId + ".", 5015, sqlex);
                    LogManager.LogErrorMessage("SQL Error while executing " + Common._SPGETACWREPORT + " for retrieving execution id for threadid : " + _threadId + ".", 5011, sqlex);
                }
            }
            catch (FTPException e)
            {
                throw new ACWParserException("Error in uploading files.", 5302, e);
            }
            catch (Exception e)
            {
                throw new ACWParserException("Unable to connect to Database while executing " + Common._SPGETACWREPORT + " for threadid : " + _threadId + ".", 5005, e);
                LogManager.LogErrorMessage("Error while executing " + Common._SPGETACWREPORT + " for retrieving execution id for threadid : " + _threadId + ".", 5016, e);
            }
            finally
            {
                da.Dispose();
                cmd.Dispose();
                dtFileDetails.Dispose();
                CleanUpResources();
            }
        }

        /// <summary>
        /// Method used to create FTP folders.
        /// </summary>
        /// <param></param>
        /// <returns></returns>
        /// 
        public void CreateACWFolders()
        {
             try
              {
                       mainDirectory = Path.GetDirectoryName(System.Reflection.Assembly.GetEntryAssembly().Location);
                       ftpOutPath = System.IO.Path.Combine(mainDirectory, ftpCredentials.OutFolder);
                       ftpMovedPath = System.IO.Path.Combine(mainDirectory, ftpCredentials.MovedFolder);
                       ftpUploadlogPath = System.IO.Path.Combine(mainDirectory, ftpCredentials.UploadLog);
                       ftpDownloadlogPath = System.IO.Path.Combine(mainDirectory, ftpCredentials.DownloadLog);
                       if (!Directory.Exists(ftpOutPath))
                       {
                           Directory.CreateDirectory(ftpOutPath);
                       }
                       if (!Directory.Exists(ftpMovedPath)) 
                       {
                           Directory.CreateDirectory(ftpMovedPath);
                       }
                       if (!Directory.Exists(ftpUploadlogPath)) 
                       {
                           Directory.CreateDirectory(ftpUploadlogPath);
                       }
                       if (!Directory.Exists(ftpDownloadlogPath)) 
                       {
                           Directory.CreateDirectory(ftpDownloadlogPath);
                       } 
                 }
             catch (Exception e)
              {
                  throw new Exception("Unable to create the folders", e);
                 
              }

         }


        /// <summary>
        /// Method used to get configuration settings from database.
        /// </summary>
        /// <param></param>
        /// <returns></returns>
        /// 
        public void GetConfigurationSettings()
        {
            DataTable dtACWConfigVal = null;
            ftpCredentials = new FTPCredentials();
            try
            {
                // Get the configuration values from the database 
                dtACWConfigVal = GetACWReportConfiguration();

                if (dtACWConfigVal != null && dtACWConfigVal.Rows.Count > 0)
                {
                    foreach (DataRow cnfgRow in dtACWConfigVal.Rows)
                    {
                        if (cnfgRow["APP_TYPE"].ToString() == "ACWReportDuration")
                        {
                            ReportDuration = int.Parse(cnfgRow["APPF_INDICATOR"].ToString());

                        }
                        if (cnfgRow["APP_TYPE"].ToString() == "ACWLastRunTime")
                        {
                            LastRuntime = cnfgRow["APPF_INDICATOR"].ToString();
                        }
                        if (cnfgRow["APP_TYPE"].ToString() == "ACWReportDays")
                        {
                            ReportDays = double.Parse(cnfgRow["APPF_INDICATOR"].ToString());

                        }
                        if (cnfgRow["APP_TYPE"].ToString() == "FTP_OutFolder")
                        {
                            ftpCredentials.OutFolder = cnfgRow["APPF_INDICATOR"].ToString();
                        }
                        if (cnfgRow["APP_TYPE"].ToString() == "FTP_MovedFolder")
                        {
                            ftpCredentials.MovedFolder = cnfgRow["APPF_INDICATOR"].ToString();
                        }
                        if (cnfgRow["APP_TYPE"].ToString() == "FTP_FileType")
                        {
                            ftpCredentials.FileType = cnfgRow["APPF_INDICATOR"].ToString();
                        }
                        if (cnfgRow["APP_TYPE"].ToString() == "FTP_ServerName")
                        {
                            ftpCredentials.ServerName = cnfgRow["APPF_INDICATOR"].ToString();
                        }
                        if (cnfgRow["APP_TYPE"].ToString() == "FTP_UserId")
                        {
                            ftpCredentials.UserId = cnfgRow["APPF_INDICATOR"].ToString();
                        }
                        if (cnfgRow["APP_TYPE"].ToString() == "FTP_Password")
                        {
                            ftpCredentials.Password = cnfgRow["APPF_INDICATOR"].ToString();
                        }
                        if (cnfgRow["APP_TYPE"].ToString() == "FTP_RemoteFileName")
                        {
                            ftpCredentials.RemoteFileName = cnfgRow["APPF_INDICATOR"].ToString();
                        }
                        if (cnfgRow["APP_TYPE"].ToString() == "FTP_HandleMultipleFiles")
                        {
                            ftpCredentials.HandleMultipleFiles = cnfgRow["APPF_INDICATOR"].ToString();
                        }
                        if (cnfgRow["APP_TYPE"].ToString() == "FTP_RemoteDirectory")
                        {
                            ftpCredentials.RemoteDirectory = cnfgRow["APPF_INDICATOR"].ToString();
                        }
                        if (cnfgRow["APP_TYPE"].ToString() == "FTP_Operation")
                        {
                            ftpCredentials.Operation = cnfgRow["APPF_INDICATOR"].ToString();
                        }
                        if (cnfgRow["APP_TYPE"].ToString() == "FTP_TumbleweebCommandParams")
                        {
                            ftpCredentials.TumbleweebCommandParams = cnfgRow["APPF_INDICATOR"].ToString();
                        }
                        if (cnfgRow["APP_TYPE"].ToString() == "FTP_Protocol")
                        {
                            ftpCredentials.Protocol = cnfgRow["APPF_INDICATOR"].ToString();
                        }
                        if (cnfgRow["APP_TYPE"].ToString() == "FTP_FtpClient")
                        {
                            ftpCredentials.FtpClient = cnfgRow["APPF_INDICATOR"].ToString();
                        }
                        if (cnfgRow["APP_TYPE"].ToString() == "FTP_Port")
                        {
                            ftpCredentials.Port = int.Parse(cnfgRow["APPF_INDICATOR"].ToString());
                        }
                        if (cnfgRow["APP_TYPE"].ToString() == "FTP_WaitForExitDuration")
                        {
                            ftpCredentials.WaitForExitDuration = int.Parse(cnfgRow["APPF_INDICATOR"].ToString());
                        }
                        if (cnfgRow["APP_TYPE"].ToString() == "FTP_UploadLog")
                        {
                            ftpCredentials.UploadLog = cnfgRow["APPF_INDICATOR"].ToString();
                        }
                        if (cnfgRow["APP_TYPE"].ToString() == "FTP_DownloadLog")
                        {
                            ftpCredentials.DownloadLog = cnfgRow["APPF_INDICATOR"].ToString();
                        }
                        if (cnfgRow["APP_TYPE"].ToString() == "FTP_FileNameFormat")
                        {
                            ftpCredentials.FileFormatType = cnfgRow["APPF_INDICATOR"].ToString();
                        }
                   }
                }

                ACWFileNamePart = ftpCredentials.FileType; 
                //Get the configuration values from the configuration file
                InformationLog = ConfigurationSettings.AppSettings["InformationLog"].ToString();
                TumbleweedExeName = ConfigurationSettings.AppSettings["TumbleweedExeName"].ToString();
             }
            catch (Exception Ex)
            {
                LogManager.LogErrorMessage("Unable to associate database properties to datatable, " + LogManager.source + ".", 5030, Ex);
            }
        }
        /// <summary>
        /// Method used to update lastruntime filed in the database as soon as the file is created
        /// </summary>
        /// <param name="lastupdatedtime">string</param>
        ///
        private void UpdateLastRunTime(string lastupdatedtime)
        {
            SqlCommand cmdUpdate = new SqlCommand();
            try
            {
                cmdUpdate.Parameters.AddWithValue("@UpdatedDate", SqlDbType.VarChar).Value = lastupdatedtime;
                cmdUpdate.Parameters.AddWithValue("@Mode", SqlDbType.VarChar).Value = "U";
                cmdUpdate.CommandText = Common._SPGETACWREPORTCONFIGURATION;
                cmdUpdate.CommandType = CommandType.StoredProcedure;
                cmdUpdate.Connection = _connACW;
                cmdUpdate.ExecuteNonQuery();
            }
            catch (SqlException sqlex)
            {
                if (isDBConnectionError(sqlex.Number))
                {
                    if (_threadId == 0)
                    {
                        throw new ACWParserException("Unable to connect to Database while executing " + Common._SPGETACWREPORTCONFIGURATION + " for threadid : " + _threadId + ".", 5003, sqlex);
                    }
                    else
                    {
                        throw new ACWParserException("Unable to connect to Database while executing threadid : " + _threadId + ".", 5003, sqlex);
                    }
                }

                else
                {
                    if (_threadId == 0)
                    {
                        LogManager.LogErrorMessage("SQL Error while executing " + Common._SPGETACWREPORTCONFIGURATION + ".", 5027, sqlex);
                    }

                    else
                    {
                        LogManager.LogErrorMessage("SQL Error while executing threadid : " + _threadId + ".", 5024, sqlex);
                    }
                }     
          }
            catch (Exception e)
            {
                if (_threadId == 0)
                {
                    LogManager.LogErrorMessage("Error while executing " + Common._SPGETACWREPORTCONFIGURATION + " for retrieving execution id for threadid : " + _threadId + ".", 5028, e);
                }
                else
                {
                    LogManager.LogErrorMessage("Error while executing threadid : " + _threadId + ".", 5025, e);
                }

            }
            finally
            {
                cmdUpdate.Dispose();
                CleanUpResources();
            }
        }

        /// <summary>
        /// Method to create the ACW txt file on the basis of data recived from the database & returns true 
        /// on successfull creation of the file
        /// </summary>
        /// <returns>bool</returns>
        private bool CreateFile(string strFilePath, DataTable dtFiledtls)
        {
            // Create the file 
            StreamWriter sw = new StreamWriter(strFilePath, false);
            try
            {
                // First we will write the headers.
                int iColCount = dtFiledtls.Columns.Count;
                for (int i = 0; i < iColCount; i++)
                {
                    sw.Write(dtFiledtls.Columns[i]);
                    if (i < iColCount - 1)
                    {
                        sw.Write("|");
                    }
                }

                sw.Write(sw.NewLine);
                // Now write all the rows.
                foreach (DataRow dr in dtFiledtls.Rows)
                {
                    for (int i = 0; i < iColCount; i++)
                    {
                        if (!Convert.IsDBNull(dr[i]))
                        {
                            sw.Write(dr[i].ToString());

                        }
                        if (i < iColCount - 1)
                        {
                            sw.Write("|");
                        }
                    }
                    sw.Write(sw.NewLine);
                }
                sw.Close();

                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
            finally
            {
                sw.Dispose();
            }
         }

            
        /// <summary>
        /// Method to get the report configuration
        /// </summary>
        /// <returns>DataTable</returns>
        public DataTable GetACWReportConfiguration()
        {
            DataTable ACWconfigData = null;
            SqlDataAdapter sqlDataAdapter = null;
            SqlCommand cmdSelect = new SqlCommand();
            try
            {
                ACWconfigData = new DataTable();
                cmdSelect.Parameters.AddWithValue("@UpdatedDate", SqlDbType.VarChar).Value = DBNull.Value;
                cmdSelect.Parameters.AddWithValue("@Mode", SqlDbType.Char).Value = "S";
                cmdSelect.CommandText = Common._SPGETACWREPORTCONFIGURATION;
                cmdSelect.CommandType = CommandType.StoredProcedure;
                cmdSelect.Connection = _connACW;
                cmdSelect.CommandTimeout = 3600;
                sqlDataAdapter = new SqlDataAdapter(cmdSelect);
                sqlDataAdapter.Fill(ACWconfigData);
                sqlDataAdapter.Dispose();
            }
            catch (SqlException sqlex)
            {
                if (isDBConnectionError(sqlex.Number))
                {
                    if (_threadId == 0)
                    {
                        throw new ACWParserException("Unable to connect to Database while executing " + Common._SPGETACWREPORTCONFIGURATION + " for threadid : " + _threadId + ".", 5003, sqlex);
                    }
                    else
                    {
                        throw new ACWParserException("Unable to connect to Database while executing threadid : " + _threadId + ".", 5003, sqlex);
                    }
                }
                    
                else
                 {
                     if (_threadId == 0)
                     {
                         LogManager.LogErrorMessage("SQL Error while executing " + Common._SPGETACWREPORTCONFIGURATION + ".", 5027, sqlex);
                     }

                     else
                     {
                         LogManager.LogErrorMessage("SQL Error while executing threadid : " + _threadId + ".", 5024, sqlex);
                     }
                   
                 }
                    
             }
                
            catch (Exception e)
            {
                if (_threadId == 0)
                {
                    LogManager.LogErrorMessage("Error while executing " + Common._SPGETACWREPORTCONFIGURATION + " for retrieving execution id for threadid : " + _threadId + ".", 5028, e);
                }
                else
                {
                    LogManager.LogErrorMessage("Error while executing threadid : " + _threadId + ".", 5025, e);
                }
                
            }
            finally
            {
                CleanUpResources();
                cmdSelect.Dispose();
            }
            int count = ACWconfigData.Rows.Count;
            return ACWconfigData;
            
        }

       /// <summary>
       /// Method used to upload the file to FTP
       /// </summary>
       private void FTPUpload(string fileType)
       {
               try
                   {

                       string filename = string.Empty;
                       int i = 0;
                       ftpCredentials.LocalDirectory = ftpOutPath;
                       ftpCredentials.LocalMoveDirectory = ftpMovedPath;
                       ftpCredentials.TumbleweedClientLocation = ConfigurationSettings.AppSettings["TumbleweedClientLocation"];
                       ftpCredentials.DownloadLog = ftpDownloadlogPath;
                       ftpCredentials.UploadLog = ftpUploadlogPath;


                       //Method to send files to Tumbleweed
                       GetLocalFileNames(ftpCredentials.LocalDirectory, ftpCredentials.FileType);
                       for (i = 0; i < localFileNames.Length; i++)
                       {
                           bool sent = false;
                           filename = localFileNames[i].ToString();
                           Put_Tumbleweed(ftpCredentials.LocalDirectory + "\\" + filename, filename + "_" + DateTime.Now.ToString("yyyy_MM_dd_HH_mm_ss") + ".log", filename, ftpCredentials);
                           MoveFile(ftpCredentials.LocalDirectory + "\\" + filename, ftpCredentials.LocalMoveDirectory + "\\" + filename, filename, true);
                           sent = true;
                       }
                   }
                 catch (Exception ex)
                   {
                       throw new FTPException("Error in uploading files : " + ex.Message);
                   }
     }

       /// <summary>
       /// Method to move the files
       /// </summary>
        private void MoveFile(string source, string destination, string filename, bool deleteExisting)
        {
            try
            {

                if (File.Exists(destination))
                {
                    if (deleteExisting == false)
                    {
                        String[] fileparts = destination.Split(".".ToCharArray());
                        String newfile;
                        if (fileparts.GetUpperBound(0) == 1)
                            newfile = fileparts[0] + DateTime.Now.ToString("yyyy_MM_dd_HH_mm_ss") + "." + fileparts[1];
                        else
                            newfile = fileparts[0] + DateTime.Now.ToString("yyyy_MM_dd_HH_mm_ss");

                        destination = newfile;
                    }
                    else
                    {
                        File.Delete(destination);
                    }
                }
                File.Move(source, destination);
                //LogManager.LogInfoMessage("Local file " + filename + " moved.", 2004);
            }
            catch (FTPException ex)
            {
                throw new FTPException("Error in moving file from " + source + " to " + destination + ".", 5305, ex);
            }
            
        }

        /// <summary>
        /// Gets the list of local files
        /// </summary>
        private void GetLocalFileNames(string fileLocation, string fileName)
        {
           
            try
            {
                DirectoryInfo dir = new DirectoryInfo(fileLocation);
                localFileNames = dir.GetFiles(fileName + "*");
            }
            catch (FTPException e)
            {
                throw new FTPException("Error reading file names from local directory, error message : " + e.Message);
            }
            
        }
        private System.Diagnostics.Process CurrentSTProcess()
        {
            System.Diagnostics.Process process = null;
            foreach (System.Diagnostics.Process p in System.Diagnostics.Process.GetProcesses())
            {
                if (p.ProcessName.Contains(TumbleweedExeName))
                {
                    process = p;
                    break;
                }
            }
            if (process == null)
            {
                process = new System.Diagnostics.Process();
            }
            else
            {
                process.Refresh();
            }

            return process;
        }

        /// <summary>
        /// Sample Arguments = "httpu://userid:password@fsgatewaytest.intra.aexp.com:80/inbox C:\\CTEFTP\\OUT\\CTE_TRX /prefNoAskSched /quitWhenDone /hidden /prefRetries 1 /log /RemoveOnError /statusBAT C:\\Temp\\SVN\\CTE\\trunk\\APPS\\FTPUtility\\bin\\Debug\\\\tumbleweed_uploadresult.bat"
        /// Details: 
        /// @ftpCredentials.protocol = "httpu" (for upload)
        /// ftpCredentials.userId = userid
        /// ftpCredentials.password = password
        /// ftpCredentials.serverName = fsgatewaytest.intra.aexp.com
        /// ftpCredentials.port = 80
        /// ftpCredentials.remoteDirectory = inbox
        /// localFilePath = C:\\CTEFTP\\OUT\\CTE_TRX 
        /// /prefNoAskSched = Use this option to suppress the prompts for schedules before initiating a file transfer.
        /// /quitWhenDone  =  This option terminates the Secure-Transport Windows client when all transfers are completed.
        /// /hidden = This option hides the SecureTransport Windows client. If an instance of the client GUI is already runningwhen this command is issued, it will 
        ///           hide that instance.
        /// /prefRetries 1 = This option specifies the number of times a file transfer must be attempted in the event of a file transfer failure. A value of 0 disables
        ///                  this option. The minimum value must be set to 1 to enable this option.
        /// /log  = This option is used to enable clientside connection logging. For every transfer, a log file is created in the STClient\Cache directory. The log 
        ///         file name is a combination of the host address and port number         
        /// /RemoveOnError = This option removes the task from the Transfer Queue if an error occurs for a transfer after exceeding the number of retries specified using
        ///                  /prefRetries command-line option.
        /// /statusBAT C:\\Temp\\SVN\\CTE\\trunk\\APPS\\FTPUtility\\bin\\Debug\\\\tumbleweed_uploadresult.bat"  = This option creates a batch file to capture the return status of the session. The file pointed at, 
        ///             filename.bat is deleted each time the transfer state of the SecureTransport Windows client changes, and filename.bat is automatically 
        ///             recreated with the following two lines: 
        ///             1. set SecureTransportStatus=FileDriveStatus 2. del filename.bat where FileDriveStatus is one of the following values:
        ///                • DONE -Transfer is done
        ///                • ACTIVE -Transfer is active
        ///                • STOP - Transfer has been stopped
        ///                • INVALID -The URL or local path is invalid
        ///                • ERROR -An error has occurred
        ///                • WAITING -Waiting to re-transfer
        ///                • NOTEXIST -Cannot find the source file(s) to be transferred
        /// </summary>
        /// <param name="localFilePath"></param>
        private void Put_Tumbleweed(String localFilePath, String logfilename, String filename, FTPCredentials ftpCredentials)
        {
            string uploadstatus = "";
            string contents = "";
            int count = 0;
            int statusUpdateWaitTime = 4000;
            string uploadFileStatusPath = @ftpCredentials.UploadLog + "\\" + logfilename;
            string arguments = @ftpCredentials.Protocol + "u://" +
                ftpCredentials.UserId + ":" + ftpCredentials.Password + "@" + ftpCredentials.ServerName + ":" + ftpCredentials.Port + "/" +
                ftpCredentials.RemoteDirectory + " " + localFilePath + " /prefNoAskSched /quitWhenDone /hidden /prefRetries 0 /log /statusBAT "
                + uploadFileStatusPath;

            if (ftpCredentials.TumbleweebCommandParams != "")
                arguments = arguments + " " + ftpCredentials.TumbleweebCommandParams;


            Process process = CurrentSTProcess();
            GetRunningProcessDetails("After Object creation");
            try
            {
                if (File.Exists(uploadFileStatusPath))
                {
                    contents = File.ReadAllText(uploadFileStatusPath).ToUpper();
                    if (contents.IndexOf("ACTIVE") > 0 || contents.IndexOf("WAITING") > 0)
                    {
                        throw new FTPException("Previous transfer is still in progress.");
                    }
                    else
                    {
                        File.Delete(uploadFileStatusPath);
                    }
                }
                DateTime timestamp = DateTime.Now;
                process.StartInfo.WorkingDirectory = @ftpCredentials.TumbleweedClientLocation;
                process.StartInfo.FileName = @ftpCredentials.TumbleweedClientLocation + TumbleweedExeName + ".exe";
                process.StartInfo.Arguments = arguments;
                process.StartInfo.UseShellExecute = false;
                process.StartInfo.RedirectStandardOutput = false;
                process.StartInfo.RedirectStandardError = true;
                process.Start();
                count = GetRunningProcessDetails("After Start()");
                LogManager.LogInfoMessage("Instance of tumbleweed started with process id " + process.Id.ToString(), 9999);

                process.WaitForExit(ftpCredentials.WaitForExitDuration);
                process.Close();
                count = GetRunningProcessDetails("After Close()");

                int sleepCount = 0;
                while (File.Exists(uploadFileStatusPath) == false && (DateTime.Compare(timestamp.AddMilliseconds(ftpCredentials.WaitForExitDuration), DateTime.Now) > 0))
                {
                    sleepCount++;
                    Thread.Sleep(statusUpdateWaitTime);
                }
                LogManager.LogInfoMessage("Upload log file creation status is " + File.Exists(uploadFileStatusPath) + ", sleepcount : " + sleepCount, 9999);


                if (File.Exists(uploadFileStatusPath))
                {
                    sleepCount = 0;
                    contents = File.ReadAllText(uploadFileStatusPath).ToUpper();
                    while ((contents.IndexOf("ACTIVE") > 0 || contents.IndexOf("WAITING") > 0) && (DateTime.Compare(timestamp.AddMilliseconds(ftpCredentials.WaitForExitDuration), DateTime.Now) > 0))
                    {
                        sleepCount++;
                        Thread.Sleep(statusUpdateWaitTime);
                        contents = File.ReadAllText(uploadFileStatusPath).ToUpper();

                    }
                    LogManager.LogInfoMessage("Upload status is " + contents + ", sleepcount : " + sleepCount, 9999);
                    if (contents.IndexOf("FILEDRIVESTATUS=") >= 0)
                    {
                        uploadstatus = contents.Split("\r\n".ToCharArray())[0].Substring(contents.LastIndexOf("FILEDRIVESTATUS=") + "FILEDRIVESTATUS=".Length).Trim();
                        if (uploadstatus.ToUpper().Trim() != "DONE")
                        {
                            throw new FTPException("File not uploaded sucessfully. Upload status is :" + uploadstatus);
                        }
                    }
                    else
                    {
                        throw new FTPException("File upload confirmation not received. Upload status is not available.");
                    }
                    LogManager.LogInfoMessage("Log File Created : " + uploadFileStatusPath, 2007);
                }
                else
                {
                    throw new FTPException("File upload confirmation not received. Upload log is not available.");
                }
                LogManager.LogInfoMessage("File " + filename + " sent on FTP server.", 2003);
            }
                        
            catch (Exception ex)
            {
                count = GetRunningProcessDetails("In Catch()");
                if (process != null)
                {
                    process.Dispose();
                }
                count = GetRunningProcessDetails("After Dispose()");
                KillDuplicateProcess();
                count = GetRunningProcessDetails("After Kill()");
                LogManager.LogErrorMessage("Couldn't find the Tumbleweed Client location.", 5302, ex);
                throw new FTPException("Error sending file.", 5302, ex);
            }
        }
        private int GetRunningProcessDetails(string location)
        {
            String details = "";
            int count = 0;
            foreach (System.Diagnostics.Process p in System.Diagnostics.Process.GetProcesses())
            {
                if (p.ProcessName.Contains(TumbleweedExeName))
                {
                    details = details + ", " + p.Id + ":" + p.ProcessName;
                    count++;
                }
            }
            LogManager.LogInfoMessage("Running instances [" + location + "] :" + details, 9999);
            return count;
        }
        private void KillDuplicateProcess()
        {
            int count = 0;
            int killcount = 0;
            System.Diagnostics.Process[] processes = System.Diagnostics.Process.GetProcesses();
            foreach (System.Diagnostics.Process p in processes)
            {
                if (p.ProcessName.Contains(TumbleweedExeName))
                {
                    count++;
                    try
                    {
                        p.Kill();
                        killcount++;
                    }
                    catch (FTPException innerEx)
                    {
                        throw new FTPException("Error in killing 'tumblewewed client' instance. Process id is " + p.Id.ToString(), 5306, innerEx);
                    }

                }
            }
            LogManager.LogInfoMessage("tumbleweed instances running were " + count.ToString() + " instances killed are " + killcount.ToString(), 2009);
        }
        #endregion

        #region Check if its a DB COnnection error
        /// <summary>
        /// Method used to check the Error is database error which is defined in config file
        /// It returns true if it is DB Connection error else false
        /// </summary>
        /// <param name="SQLErrNumber">int</param>
        /// <returns>bool</returns>
        private bool isDBConnectionError(int SQLErrNumber)
        {
            try
            {
                string[] listedErrors = _dbErrorCode.Split(",".ToCharArray());
                for (int i = 0; i < listedErrors.Length; i++)
                {
                    if (listedErrors[i].Trim() == SQLErrNumber.ToString().Trim())
                    {
                        return true;
                    }
                }
                return false;
            }
            catch (Exception)
            {
                return false;
            }
        }
        #endregion

        #region Clean Up Resources
        /// <summary>
        /// Method used to clean up resources
        /// </summary>
        private void CleanUpResources()
        {
            if (_sqlResult != null)
            {
                if (!_sqlResult.IsClosed)
                    _sqlResult.Close();

                _sqlResult = null;
            }
        }
        #endregion
        #endregion
    }
}
