﻿////-----------------------------------------------------------------------
//// <copyright file="Common.cs" company="NIIT">
////     Copyright (c) NIIT. All rights reserved.
//// </copyright>
//// <summary>
//// <Description> This file contains the Implementation of Common class</Description>
//// <Author>NIIT Technologies</Author>
//// <CreatedOn>07/09/2011</CreatedOn>
//// <Modified>
////     <On></On>
////     <Desc></Desc>
////     <By></By>
//// </Modified>
//// </summary>
////----------------------------------------------------------------------
using System;

namespace AmericanExpress.Services.ACW.Business
{
    /// <summary>
    /// Common Class Implementation
    /// </summary>
    static class Common
    {
        #region Constants

        public const string _DBNAME = "ConnectionInfo";
        public const string _DBNAMEAD = "ConnectionInfoAD";
        public const string _DBCONNECTIVITYFAILURE = "DBConnectivity Failure";
        public const string _DATABASEERROR = "Database Error";
        public const string _DBERRORCODE = "DBErrorCode";
        public const string _EXCEPTION = "Exception:";
        public const string _ERR_PROCESS = "Error in processing.";
        public const string _SUCCESS_PROCESS = "Processed successfully.";

        public const string _SPGETACWREPORT = "usp_GETACWREPORT_FILE";
        public const string _SPGETACWREPORTCONFIGURATION = "usp_GetACWReportConfiguration";
        public const string USPGETFTPCRADENTIALS = "usp_DW_GetFTPcradentials";

        #endregion
    }
}
