﻿////-----------------------------------------------------------------------
//// <copyright file="ACWProcess.cs" company="NIIT">
////     Copyright (c) NIIT. All rights reserved.
//// </copyright>
//// <summary>
//// <Description>This file contains the Implementation of ACWProcess class.
////    It is defined for processing the Jobs for Cleaning/deleting the files</Description>
//// <Author>NIIT Technologies</Author>
//// <CreatedOn>07/09/2011</CreatedOn>
//// <Modified>
////     <On></On>
////     <Desc></Desc>
////     <By></By>
//// </Modified>
//// </summary>
////----------------------------------------------------------------------

using System;
using AmericanExpress.Services.ACW.BusinessInterface;
using System.Data;
using System.Configuration;
using System.IO;
using System.Xml;
using System.Globalization;
using AmericanExpress.Services.ACW.BusinessEntities;
using System.Data.SqlClient;

namespace AmericanExpress.Services.ACW.Business
{
    public class ACWProcess : IACWProcess
    {
        #region Variables
        private int _threadId = 0;
        private ACWDAC _ACWDAC = null;
        string _isInfoLogRequired = string.Empty;
        private string _infoLog = "Y";

        #endregion

        #region Constructor
        /// <summary>
        /// Initialise the thread and ACWDac object in constructor
        /// </summary>
        /// <param name="threadId">int</param>
        /// <param name="ACWDB">ACWDAC</param>
        /// <param name="infoLog">string</param>
        public ACWProcess(int threadId, ACWDAC ACWDB)
        {
            this._threadId = threadId;
            this._ACWDAC = ACWDB;
        }
        #endregion

        #region Properties

        public int  ReportDuration
        {
            get;
            set;
        }

        public string LastRuntime
        {
            get;
            set;
        }

        #endregion


        #region Method
        /// <summary>
        /// Method to start process for creating the ACW report files by depending upon the application last run time 
        /// & report duration from the database. 
        /// </summary>
        public void StartProcess()
        {
            int count = 0;       
            double hrs = 0;
            DataTable dtACWConfigVal = null;

            try
            {

                if (ConfigurationSettings.AppSettings["InformationLog"] != null)
                {
                    _isInfoLogRequired = ConfigurationSettings.AppSettings["InformationLog"].ToString();
                }

                LogManager.LogInfoMessage(LogManager.source + " Started, threadid : " + _threadId, 2001, "Y");
                
                
                // Get the configuration values from the database 
                dtACWConfigVal =  _ACWDAC.GetACWReportConfiguration();

               if (dtACWConfigVal != null && dtACWConfigVal.Rows.Count > 0)
               {
                   foreach (DataRow cnfgRow in dtACWConfigVal.Rows)
                   {
                       if (cnfgRow["APP_TYPE"].ToString() == "ACWReportDuration")
                       {
                           ReportDuration = int.Parse(cnfgRow["APPF_INDICATOR"].ToString());
                       }
                       if (cnfgRow["APP_TYPE"].ToString() == "ACWLastRunTime")
                       {
                           LastRuntime = cnfgRow["APPF_INDICATOR"].ToString();
                           //2012-10-15 04:00:00.000
                       }
                   }
               }

               //string todaysdate = DateTime.Now.ToString("yyyy-MM-dd");
               //string todaysdate = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fffffff");
               //string todaysdatetime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff");
               ////2012-10-15 16:17:55.617

               //string[] formats = { "yyyy-MM-dd HH:mm:ss.fff" };
                
               //var LastrunTimedate = DateTime.ParseExact(LastRuntime, formats, new CultureInfo("en-US"), DateTimeStyles.None);
               //string Lastrantime = LastrunTimedate.ToString("yyyy-MM-dd HH:mm:ss.fff");
                //2012-06-28 12:39:43.000

               if (!string.IsNullOrEmpty(LastRuntime))
               {

                   DateTime t1 = Convert.ToDateTime(LastRuntime);
                   //6/28/2012 12:39:43 PM
                   //DateTime t2 = DateTime.Now;
                   //10/15/2012 4:38:31 PM
                   //{10/15/2012 4:00:00 AM}

                   TimeSpan ts = DateTime.Now.Subtract(t1);


                   //var hrs = ts.TotalHours;
                   hrs = ts.TotalHours;
                   //12.837440690805556
                   //36.071376074694442
                   //2619.9800889225276
               }

               if (string.IsNullOrEmpty(LastRuntime) && hrs==0)
                    {



                        //var Todaysdate = DateTime.Now.ToString("yyyy-MM-dd");
                        //var Todaysdate = "2012-06-25";
                        var Todaysdate = "2012-06-29";
                        //DateTime Fifthday = Getfifthfromtoday();
                        ////var Fifthfromtoday = Fifthday.ToString("yyyy-MM-dd");
                        //var Fifthfromtoday = "2012-06-29";
                        //_ACWDAC.GetPendingJobs(Todaysdate, Fifthfromtoday);
                        _ACWDAC.GetACWData(Todaysdate);
                        //_ACWDAC.GetACWData(Todaysdate, Fifthfromtoday);
                    }
               if (hrs >= ReportDuration)
               {



                   //var Todaysdate = DateTime.Now.ToString("yyyy-MM-dd");
                   var Todaysdate = "2012-06-25";
                   //DateTime Fifthday = Getfifthfromtoday();
                   //var Fifthfromtoday = Fifthday.ToString("yyyy-MM-dd");
                   //var Fifthfromtoday = "2012-06-29";
                   //_ACWDAC.GetPendingJobs(Todaysdate, Fifthfromtoday);
                   _ACWDAC.GetACWData(Todaysdate);
                   //_ACWDAC.GetACWData(Todaysdate, Fifthfromtoday);
               }
               else
               {
                   return;
               }



            }
            catch (ACWParserException acex)
            {
                LogManager.LogErrorMessage(acex.Message.ToString(), acex.ErrorCode, acex);
            }
            catch (Exception e)
            {
                LogManager.LogErrorMessage("Error occured while processing " + LogManager.source + ", threadid : " + _threadId + ". " + count + " File(s) deleted. ", 5018, e);
            }
            finally
            {
                //disposing all objects                
            }

        }

        

        
        #endregion
    }
}
