////-----------------------------------------------------------------------
//// <copyright file="ScheduleStarter.cs" company="NIIT">
////     Copyright (c) NIIT. All rights reserved.
//// </copyright>
//// <summary>
//// <Description>This class read the data from xml file and check the condition to  Execute/call the application.</Description>
//// <Author>NIIT Technologies</Author>
//// <CreatedOn>09/07/2011</CreatedOn>
//// <Modified>
////     <On></On>
////     <Desc></Desc>
////     <By></By>
//// </Modified>
//// </summary>
////----------------------------------------------------------------------

using System;
using System.Data;
using System.ServiceProcess;
using System.Xml;
using AmericanExpress.Services.ACW.FileUpload;
using System.Threading;
using System.Configuration;
using ACWBusiness = AmericanExpress.Services.ACW.Business;

namespace AmericanExpress.Services.ACW.FileUpload
{
    public class ScheduleStarter
    {
        int _threadCnt;
        
        #region StartApp
        // Check the parameter to start the applications
        public void StartApp()
        {
            _threadCnt = GetThreadCount();
            
            #region Execution
            //Call AppLaucher to start application in new thread.
            AppLauncher launcher = new AppLauncher();
            
            //Start No of Threads Mention in app param
            for (int j = 1; j <= _threadCnt; j++)
            {
                try
                {
                    launcher.setThreadNO(j);
                    ThreadPool.QueueUserWorkItem(launcher.RunACWReportParser, new object());
                } 
                catch (Exception ex)
                {
                    ACWBusiness.LogManager.LogErrorMessage("Unable to launch " + ACWBusiness.LogManager.source + " thread.", 5001, ex);
                }
                Thread.Sleep(200);  // Stop code execution  
            }
            
            #endregion            
       }
        #endregion

        #region Get Thread Count
        /// <summary>
        /// Getting no. of threads to run for service
        /// </summary>
        /// <returns>int</returns>
        public int GetThreadCount()
        {
            int ThreadCount = Convert.ToInt32(ConfigurationManager.AppSettings["ThreadCount"]);
            _threadCnt = ThreadCount;
            // Write code to getThread count from DB   
            return _threadCnt;
        }
        #endregion
    }
}


