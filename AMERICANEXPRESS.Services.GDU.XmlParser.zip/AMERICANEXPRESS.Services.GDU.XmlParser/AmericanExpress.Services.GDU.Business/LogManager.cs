////-----------------------------------------------------------------------
//// <copyright file="LogManager.cs" company="NIIT">
////     Copyright (c) NIIT. All rights reserved.
//// </copyright>
//// <summary>
//// <Description>This file contains the Implementation of LogManager class</Description>
//// <Author>NIIT Technologies</Author>
//// <CreatedOn>09/07/2011</CreatedOn>
//// <Modified>
////     <On></On>
////     <Desc></Desc>
////     <By></By>
//// </Modified>
//// </summary>
////----------------------------------------------------------------------
#region Imported Namespace
using System;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Configuration;
using System.IO;
using System.Collections.Generic;
using System.Text;
using Log = AmericanExpress.Util.Logging;
#endregion

namespace AmericanExpress.Services.GDU.Business
{
    /// <summary>
    /// Log Manager Implementation
    /// </summary>
    public class LogManager
    {
        static ICollection<string> categories;
        static bool stackTrace;
        static string unhandledLogPath;
        public static string source;

        /// <summary>
        /// Method for creating the Trace file - 31/Jan/3013
        /// </summary>
        /// <param name="ex"></param>
        public static void LogtoEvent(string ex)
        {
            try
            {
                string TraceInfo = ConfigurationManager.AppSettings["TraceInfo"].ToString();
                if (TraceInfo == "True")
                {
                    string TraceFile = Path.GetFullPath(ConfigurationManager.AppSettings["TraceFilePath"].ToString());
                    FileStream fs = null;
                    if (!File.Exists(TraceFile))
                    {
                        using (fs = File.Create(TraceFile))
                        {

                        }
                    }
                    if (File.Exists(TraceFile))
                    {
                        StringBuilder sb = new StringBuilder();
                        StreamReader sr = new StreamReader(TraceFile);
                        {
                            sb.Append(sr.ReadToEnd());
                            sb.AppendLine();
                        }
                        sr.Close();
                        TextWriter tw = new StreamWriter(TraceFile);
                        sb.AppendLine(ex.ToString());
                        tw.WriteLine(sb.ToString());
                        tw.Close();
                    }
                }
            }
            catch (Exception ex1)
            {
            }
        }


        /// <summary>
        /// Method used to log the information
        /// </summary>
        /// <param name="message">string</param>
        /// <param name="eventID">int</param>
        public static void LogInfoMessage(string message, int eventID)
        {
            try
            {
                IDictionary<string, string> dicAttributes = new Dictionary<String, String>();
                dicAttributes.Add("Event ID", eventID.ToString());
                Log.LogManager.LogEvent(message, Log.EventType.Information, categories, dicAttributes);
            }
            catch (Exception ex)
            {
                LogUnhandledError("InformationLog, " + message, eventID, ex);
            }
        }
        /// <summary>
        /// Method used to log the error message
        /// </summary>
        /// <param name="fixmessage">string</param>
        /// <param name="eventID">int</param>
        /// <param name="e">Exception</param>
        public static void LogErrorMessage(string fixmessage, int eventID, Exception e)
        {
            try
            {
                IDictionary<string, string> dicAttributes = new Dictionary<String, String>();
                dicAttributes.Add("Fix Message", fixmessage);
                if (stackTrace == true)
                {
                    Log.LogManager.LogError(e, eventID, categories, dicAttributes);
                }
                else
                {
                    //logging after consolidate the all errors
                    Log.LogManager.LogError(MessageConsolidation(e), eventID, categories, dicAttributes);
                }
            }
            catch (Exception ex)
            {
                LogUnhandledError("ErrorLog, " + fixmessage, eventID, ex);
            }
        }
        /// <summary>
        /// Method used for Logging errors the unhandled exception to text file
        /// in which logging mechanism failed 
        /// </summary>
        /// <param name="fixmessage">string</param>
        /// <param name="eventID">int</param>
        /// <param name="e">Exception</param>
        public static void LogUnhandledError(string fixmessage, int eventID, Exception e)
        {
            try
            {
                string datevalue = DateTime.Now.ToString("MM-dd-yyyy HH-mm-ss");
                //creating text file with date time stamp
                if (Directory.Exists(@unhandledLogPath) && unhandledLogPath != "")
                {
                    StreamWriter sw = File.CreateText(@unhandledLogPath + "\\" + source + "UnhandledError_" + datevalue + ".txt");
                    sw.WriteLine("Fix Message : " + fixmessage);
                    sw.WriteLine("EventID : " + eventID.ToString());
                    sw.WriteLine("StackTrace : " + e.StackTrace.ToString());
                    sw.Flush();
                    sw.Close();
                }
            }
            catch{}
        }
        /// <summary>
        /// Overloaded Method used for Logging errors the unhandled exception to text file
        /// in which logging mechanism failed 
        /// </summary>
        /// <param name="fixmessage">string</param>
        /// <param name="eventID">int</param>
        /// <param name="errorMessage">string</param>
        public static void LogUnhandledError(string fixmessage, int eventID, string errorMessage)
        {
            try
            {
                string datevalue = DateTime.Now.ToString("MM-dd-yyyy HH-mm-ss");
                //creating text file with date time stamp
                if (Directory.Exists(@unhandledLogPath) && unhandledLogPath != "")
                {
                    StreamWriter sw = File.CreateText(@unhandledLogPath + "\\" + source + "UnhandledError_" + datevalue + ".txt");
                    sw.WriteLine("Fix Message : " + fixmessage);
                    sw.WriteLine("EventID : " + eventID.ToString());
                    sw.WriteLine("Error Message : " + errorMessage);
                    sw.Flush();
                    sw.Close();
                }
                EventLog.WriteEntry(GetSource(), "Unhandled Exception : " + fixmessage + " " + errorMessage);
            }
            catch{ }
        }
        /// <summary>
        /// Overloaded Method used to log the error message
        /// </summary>
        /// <param name="fixmessage">string</param>
        /// <param name="eventID">int</param>
        public static void LogErrorMessage(string fixmessage, int eventID)
        {
            try
            {
                IDictionary<string, string> dicAttributes = new Dictionary<String, String>();
                dicAttributes.Add("Fix Message", fixmessage);
                Log.LogManager.LogError(" ", eventID, categories, dicAttributes);
            }
            catch (Exception ex)
            {
                LogUnhandledError("ErrorLog, " + fixmessage, eventID, ex);
            }
        }
        /// <summary>
        /// Method used to initialise the source
        /// and reading values from config
        /// </summary>
        public static void InitializeSource()
        {
            string source = GetSource();
            if (!EventLog.SourceExists(source))
            {
                EventLog.CreateEventSource(source, "Application");
            }

            categories = new List<string>();
            categories.Add("DefaultLog");
            categories.Add("ErrorLog");

            GetStackTrace(); //reading the stack trace value
            GetUnhandledLogPath(); //reading the log file path for storing the unhandled exception
        }
        /// <summary>
        /// Method used to consolidate all the inner exception
        /// </summary>
        /// <param name="ex">Exception</param>
        /// <returns>string</returns>
        private static string MessageConsolidation(Exception ex)
        {
            string message = ex.Message;
            while (true)
            {
                ex = ex.InnerException;
                if (ex == null) break;
                if (ex.GetType().Name.ToUpper() == "XmlParserException".ToUpper())
                {
                    message = message + ", Code: " + ((XmlParserException)ex).ErrorCode;
                }
                else
                {
                    if (ex.GetType().Name.ToUpper() == "SqlException".ToUpper())
                    {
                        message = message + ", SQLCode: " + ((SqlException)ex).Number;
                    }
                }
                message = message + " " + ex.Message;
            }
            return message;
        }
        /// <summary>
        /// Method used to read the EventSource value from config
        /// </summary>
        /// <returns>string</returns>
        private static string GetSource()
        {
            source = ConfigurationManager.AppSettings["EventSource"];
            return source;
        }
        /// <summary>
        /// Method used to read the StackTrace value from config
        /// </summary>
        /// <returns>string</returns>
        private static void GetStackTrace()
        {
            string logvalue = ConfigurationManager.AppSettings["StackTrace"];
            stackTrace = false;
            if (logvalue != null && logvalue.Trim().Length != 0)
            {
                if (logvalue.ToUpper() == "true".ToUpper())
                    stackTrace = true;
            }
        }
        /// <summary>
        /// Method used for getting log file path from config
        /// </summary>
        private static void GetUnhandledLogPath()
        {
            string logvalue = ConfigurationManager.AppSettings["UnhandledLogPath"];

            if (logvalue != null && logvalue.Trim().Length != 0)
            {
                unhandledLogPath = logvalue;
            }
        }
    }
}
