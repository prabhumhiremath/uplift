////-----------------------------------------------------------------------
//// <copyright file="AppLauncher.cs" company="NIIT">
////     Copyright (c) NIIT. All rights reserved.
//// </copyright>
//// <summary>
//// <Description>This class takes the parameter to run the application and run the application in new thread.</Description>
//// <Author>NIIT Technologies</Author>
//// <CreatedOn>09/07/2011</CreatedOn>
//// <Modified>
////     <On></On>
////     <Desc></Desc>
////     <By></By>
//// </Modified>
//// </summary>
////----------------------------------------------------------------------
using System;
using System.Threading;
using System.Configuration;
using System.Data;
using AmericanExpress.Services.GDU.Business;

namespace AmericanExpress.Services.GDU.XmlParser
{
    class AppLauncher
    {
        #region Variables
        string _message; //to store message
        int _threadId; //to store thread id
        int _threadNo; //to store number
        #endregion

        #region Constructor
        /// <summary>
        /// Constructor
        /// </summary>
        public AppLauncher()
        {
        }
        #endregion

        #region Methods
        /// <summary>
        /// Method used to set the thread no
        /// </summary>
        /// <param name="threadno">int</param>
        public void setThreadNO(int threadno)
        {
            _threadNo = threadno;
        }
        /// <summary>
        /// Method to Check the DB connection 
        /// and if sucessfully connect, then initiate FailSafe process
        /// </summary>
        public void RunXmlParser(object parameter)
        {
            Thread currentThread = Thread.CurrentThread;
            _threadId = currentThread.ManagedThreadId;
            int SleepInterval = Convert.ToInt32(ConfigurationManager.AppSettings["TimeInterval"]);
            DataSet dsAppParam = null;

            for (; ; )
            {
                try
                {
                    GDUDAC gduDAC = new GDUDAC(_threadId);

                    if (gduDAC.ConnectDatabase())
                    {
                        try
                        {
                            //Added on 17/july/2012***************************
                            // get the app params
                            LogManager.LogtoEvent("Get the file names for Thread ID - " + _threadId);
                            dsAppParam = gduDAC.GetAppParamValues();
                            //************************************************

                            //Initiate the FailSafe process
                            GDUProcess gduProcess = new GDUProcess(_threadId, gduDAC);
                            LogManager.LogtoEvent("STarting the Process");
                            gduProcess.StartProcess(dsAppParam);
                        }
                        catch (Exception e)
                        {
                            _message = "Error while processing in thread for threadid : " + _threadId + ".";
                            LogManager.LogErrorMessage(_message, 5001, e);
                            LogManager.LogtoEvent("Error while executing the Process");
                        }
                        gduDAC.CloseConnection();
                    }
                }
                catch (Exception e)
                {
                    _message = "Error while starting thread for threadid : " + _threadId + ".";
                    LogManager.LogErrorMessage(_message, 5002, e);
                }
                finally
                {
                    Thread.Sleep(SleepInterval); //Sleep the thread for configurable time, if thread ends sucessfully
                }
            }

        }
        #endregion
    }
}
