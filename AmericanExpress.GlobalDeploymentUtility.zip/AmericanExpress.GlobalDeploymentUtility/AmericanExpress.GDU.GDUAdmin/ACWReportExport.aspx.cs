﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text;
using System.Xml.Linq;
using AmericanExpress.GDU.Model;
using System.Collections.Generic;
using System.IO;
using AmericanExpress.GDU.Utilities.Diagnostics;
using AmericanExpress.GDU;

namespace AmericanExpress.GDU.GDUAdmin
{
    public partial class ACWReportExport : System.Web.UI.Page
    {
        GDUModel _gduModal;
        DataTable _dtDataTable;
        DataGrid dg;
        DataTable _dtDataTableDetails;

        const string LABEL = "UserName";
        public string strUserName = string.Empty;
        public string strVersion = string.Empty;
        protected string HdnUserIds = string.Empty;
        Boolean Flag = true;

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                _gduModal = new GDUModel();
                _dtDataTable = new DataTable();
                _dtDataTableDetails = new DataTable();
                if (!IsPostBack)
                {

                }
            }
            catch (Exception ex)
            {

            }
        }


        protected void btnClear_Click(object sender, EventArgs e)
        {
            txtDateFrom.Text = string.Empty;
            txtDateTo.Text = string.Empty;
        }

        private void ClearControls()
        {
            txtDateFrom.Text = "";
            txtDateTo.Text = "";
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                BindCSV();
                if (Flag == true)
                {
                    //open file in text format(08/11/12) by shweta
                    CreateCSV(@"AppToDownload\ACWSummary.txt", _dtDataTable);
                    string filePath = Server.MapPath(@"AppToDownload\ACWSummary.txt");
                    System.IO.FileInfo fileInfo = new System.IO.FileInfo(filePath);
                    Response.ContentType = "text/plain";
                    Response.AddHeader("Content-Disposition", "attachment;filename=ACWSummary.txt");
                    Response.AddHeader("Content-Length", fileInfo.Length.ToString());
                    Response.WriteFile(filePath);
                    //Response.End();
                    HttpContext.Current.ApplicationInstance.CompleteRequest();
                }
                else
                {
                    this.ClientScript.RegisterStartupScript(this.GetType(), "ACW", "alert('There is no data for selected criteria!');", true);
                }
            }
            catch (Exception ex)
            {
                LogManager.LogErrorMessage(ex, Convert.ToInt32(AdmConstants.MethodName.GWiz_ClientUsageReport_Search_Click));
            }
        }

        private void CreateCSV(string strFilePath, DataTable dt)
        {
            // Create the CSV file to which data will be exported.
            StreamWriter sw = new StreamWriter(Server.MapPath(strFilePath), false);
            // First we will write the headers.
            int iColCount = dt.Columns.Count;
            for (int i = 0; i < iColCount; i++)
            {
                sw.Write(dt.Columns[i]);
                if (i < iColCount - 1)
                {
                    sw.Write("|");
                }
            }

            sw.Write(sw.NewLine);
            // Now write all the rows.
            foreach (DataRow dr in dt.Rows)
            {
                for (int i = 0; i < iColCount; i++)
                {
                    if (!Convert.IsDBNull(dr[i]))
                    {
                        sw.Write(dr[i].ToString());
                    }
                    if (i < iColCount - 1)
                    {
                        sw.Write("|");
                    }
                }
                sw.Write(sw.NewLine);
            }
            sw.Close();
        }

        private void BindCSV()
        {
            string fromDate = string.Empty;
            string toDate = string.Empty;


            if (!string.IsNullOrEmpty(txtDateFrom.Text.Trim()))
            {
                fromDate = txtDateFrom.Text.Trim();
            }

            if (!string.IsNullOrEmpty(txtDateTo.Text.Trim()))
            {
                toDate = txtDateTo.Text.Trim();
            }
            else if (!string.IsNullOrEmpty(txtDateFrom.Text.Trim()))
            {
                toDate = System.DateTime.Now.ToShortDateString();
            }

            try
            {
                _dtDataTable = _gduModal.GetACWReportDetails(fromDate, toDate);

                if (_dtDataTable.Rows.Count == 0)
                {
                    Flag = false;
                }
                else
                {
                    Flag = true;
                    //for (int s = 0; s < _dtDataTable.Rows.Count; s++)
                    //{
                    //    string date1 = string.Empty;
                    //    date1 = _dtDataTable.Rows[s]["DATE"].ToString();
                    //    DateTime dt = Convert.ToDateTime(date1);
                    //    string st = dt.ToString("MM/dd/yyyy");
                    //    str.Append(st);
                    //}                   
                }

            }
            catch (Exception ex)
            {
                Label lbl = (Label)Master.FindControl("lblMsgPanel");
                string errmsg = ex.Message;
                lbl.Text = errmsg;
            }
        }
    }
}
