﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

namespace AmericanExpress.GDU
{
    public class AdmConstants
    {
        public const string CHARSET = "UTF-8";

        public const string IS_DEACTIVE = "IS_DEACTIVE";

        public enum GridSortingOrder
        {
            ASC,
            DESC
        }

        public enum CRUD_MODE
        {
            ADD,
            UPDATE,
            VIEW,
            ACTIVATE,
            DEACTIVATE
        }

        public enum HOME_TYPE
        {
            Account,
            LinkType,
            Category,
            Language,
            Carriers
        }

        public const string LOCATION = "Location";
        public const string OTHER_INFO = "OtherInfo";

        public const string KEY = "Key";
        public const string VALUE = "Value";

        public const string FALSE = "false";

        public const string MODE = "MODE";

        public const string MIN_DATE = "1/1/1973";
        public const string MAX_DATE = "12/31/2999";
        public const string JUNK_DATE = " 12:00:00 AM";

        public const string PLEASE_SELECT = "Please Select";

        
        public const string SP_LOC_CLIENT = "ClientSpecific";
        public const string SP_LOC_COUNTRY = "CountrySpecific";
        public const string SP_LOC_OTHERINFO = "OtherInfoSpecific";
        public const string NOT_AUTHORIZED = "NotAuthorized.aspx";

        public const string LINK_TYPE_CATEGORY = "CATEGORY";
        public const string LINK_TYPE_FILE = "File/URL Link";
        public const string LINK_TYPE_POPUP = "POPUP";
        public const string LINK_TYPE_URL = "URLLINK";

        public const string GENERAL_INFO = "generalInfo";
        public const string DELETE = "delete";

        public const string LINK = "Link";
        public const string LINK_TYPE_CODE = "LinkTypeCode";
        public const string LABEL_NAME = "LabelName";
        public const string LABEL_ID = "LabelID";
        public const string LANGUAGE_CODE = "LanguageCode";
        public const string DOWNLOAD_FLAG = "DownloadFlag";
        public const string HOVER_TEXT = "HoverText";
        public const string GENERAL_TEXT = "GeneralText";
        public const string CATEGORY_EDIT = "CategoryEdit";
        public const string GENERAL = "GENERAL";

        public const string TRANS_LINK_ID = "TransLinkID";
        public const string TRANS_LINK_DETAIL_ID = "TransLinkDetailId";
        public const string LINK_DETAIL_ID = "LinkDetailID";
        public const string TRANS_LABEL_ID = "TransLabelID";

        public const string UPLOADED_FILE = "UploadedFile";
        public const string SEARCH_RESULT = "SearchResult";
        public const string DIAPLAY = "display";

        public const string VALID_FROM_DATE = "ValidFrom_DT";
        public const string VALID_TO_DATE = "ValidTo_DT";

        public const string TBL_LINKDETAIL = "Table1";
        public const string TBL_LINKCATEGORYDETAIL = "Table2";
        public const string TBL_GENERALINFO = "Table3";

        public const string SELECT_ALL = "Select ALL";
        public const string SELECT_APPLICATION = "SELECT APPLICATION";
        public const string VERSION = "Version";

        public const string ZERO = "0";
        public const string CONSTUPLOAD_LOCATION = "TARGETLOCATION";
        public const string CONSTUPLOAD_LOCATIONTEMP = "TARGETLOCATIONTEMP";

        public const string CONST_RECORDPERPAGE = "RecordsPerPage";

        public enum MethodName
        {
            //------------------------------------------------------------------------------
            // GWiz Events
            GWiz_LocationMode_Page_Load = 3000,
            GWiz_LocationMode_LinkSearch_Click = 3001,
            GWiz_LocationMode_Save_Click = 3002,
            GWiz_LocationMode_InnerPopupSearch_Click = 3003,
            GWiz_LocationMode_CategorySave_Click = 3004,
            GWiz_LocationMode_AlertSave_Click = 3005,
            GWiz_LocationMode_SaveLink = 3006,

            GWiz_AccMapping_Page_Load = 3007,
            GWiz_AccMapping_Save_Click = 3008,

            GWiz_AggregationRule_Page_Load = 3009,
            GWiz_AggregationRule_Save_Click = 3010,

            GWiz_Carriers_Page_Load = 3011,
            GWiz_Carriers_Search_Click = 3012,
            GWiz_Carriers_Save_Click = 3013,

            GWiz_CityMapping_Page_Load = 3014,
            GWiz_CityMapping_Save_Click = 3015,

            GWiz_ClientDeploymentReport_Page_Load = 3016,
            GWiz_ClientDeploymentReport_Search_Click = 3017,
            GWiz_ClientDeploymentReport_Export_Click = 3018,
            GWiz_ClientDeploymentReport_grid_RowDataBound = 3019,
            GWiz_ClientDeploymentReport_grid_PageIndexChanging = 3020,

            GWiz_ClientUsageReport_Page_Load = 3121,
            GWiz_ClientUsageReport_Search_Click = 3122,
            GWiz_ClientUsageReport_Export_Click = 3123,
            GWiz_ClientUsageReport_grid_RowDataBound = 3124,

            GWiz_ContentSearch_Page_Load = 3125,
            GWiz_ContentSearch_Search_Click = 3126,

            GWiz_CountryMapping_Page_Load = 3127,
            GWiz_CountryMapping_Save_Click = 3128,

            GWiz_GlobalCategory_Page_Load = 3129,
            GWiz_GlobalCategory_GlobalCategorySave_Click = 3130,
            GWiz_GlobalCategory_DeleteLink_Click = 3131,
            GWiz_GlobalCategory_Add_Click = 3132,
            GWiz_GlobalCategory_Update_Click = 3133,
            GWiz_GlobalCategory_Delete_Click = 3134,
            GWiz_GlobalCategory_LMSaveGeneralInfo_Click = 3135,
            GWiz_GlobalCategory_LMDeleteGeneralInfo_Click = 3136,

            GWiz_GWizAdminReport_Page_Load = 3137,
            GWiz_GWizAdminReport_Search_Click = 3138,
            GWiz_GWizAdminReport_Export_Click = 3139,
            GWiz_GWizAdminReport_grdGWizReportGenerator_RowDataBond = 3140,
            GWiz_GWizAdminReport_grdGWizOtherInfoReportGenerator_RowDataBound = 3141,

            GWiz_GWizFeedbackReport_Page_Load = 3142,
            GWiz_GWizFeedbackReport_Search_Click = 3143,
            GWiz_GWizFeedbackReport_Export_Click = 3144,
            GWiz_GWizFeedbackReport_grdGWizReportGenerator_RowDataBound = 3145,

            GWiz_ManageAccount_Page_Load = 3146,
            GWiz_ManageAccount_Save_Click = 3147,

            GWiz_ManageCarrier_Page_Load = 3148,
            GWiz_ManageCarrier_Save_Click = 3149,

            GWiz_ManageCity_Page_Load = 3150,
            GWiz_ManageCity_Save_Click = 3151,

            GWiz_ManageClient_Page_Laod = 3152,
            GWiz_ManageClient_Save_Click = 3153,

            GWiz_ManageCountry_Page_Load = 3154,
            GWiz_ManageCountry_Save_Click = 3155,

            GWiz_ManageRole_Page_Load = 3156,
            GWiz_ManageRole_Save_Click = 3157,
            GWiz_ManageRole_Delete_Click = 3158,

            GWiz_ManageUser_Page_Load = 3159,
            GWiz_ManageUser_Save_Click = 3160,

            GWiz_OtherInfo_Page_Load = 3161,
            GWiz_OtherInfo_Search_Click = 3162,
            GWiz_OtherInfo_OtherInfoModeSave_Click = 3163,
            GWiz_OtherInfo_AddOtherInfoLabel_Click = 3164,
            GWiz_OtherInfo_UpdateOtherInfoLabel_Click = 3165,
            GWiz_OtherInfo_DeleteOtherInfoLabel_Click = 3166,
            GWiz_OtherInfo_InnerPopUpSearch_Click = 3167,
            GWiz_OtherInfo_CategorySave_Click = 3168,
            GWiz_OtherInfo_AlertSave_Click = 3169,

            GWiz_SearchAccount_Page_Load = 3170,
            GWiz_SearchAccount_Search_Click = 3171,
            GWiz_SearchAccount_ViewAccount = 3172,
            GWiz_SearchAccount_grid_RowDataBound = 3173,

            GWiz_SearchCarrier_Page_Load = 3174,
            GWiz_SearchCarrier_Search_Click = 3175,
            GWiz_SearchCarrier_ViewCarrier = 3176,
            GWiz_SearchCarrier_grid_RowDataBound = 3177,

            GWiz_SearchCity_Page_Load = 3178,
            GWiz_SearchCity_Search_Click = 3179,
            GWiz_SearchCity_ViewCity = 3180,
            GWiz_SearchCity_grid_RowDataBound = 3181,

            GWiz_SearchClient_Page_Load = 3182,
            GWiz_SearchClient_Search_Claick = 3183,
            GWiz_SearchClient_ViewClient = 3184,

            GWiz_SearchCountry_Page_Load = 3185,
            GWiz_SearchCountry_Search_Click = 3186,
            GWiz_SearchCountry_ViewCountry = 3187,
            GWiz_SearchCountry_grid_RowDataBound = 3188,

            GWiz_SearchRole_Page_Load = 3189,
            GWiz_SearchRole_Search_Click = 3190,
            GWiz_SearchRole_ViewRole = 3191,
            GWiz_SearchRole_grid_RowDataBound = 3192,

            GWiz_SearchUser_Page_Load = 3193,
            GWiz_SearchUser_Search_Click = 3194,

            GWiz_UploadFiles_Page_Load = 3195,
            GWiz_UploadFiles_Upload_Click = 3196,
            GWiz_UploadFiles_Save_Clcik = 3197,

            GWiz_SearchAPPF_Application_Page_Load = 3199,
            GWiz_SearchAPPF_Application_Search_Click = 3200,

            GWiz_ManageAPPFApp_Page_Load = 3201,
            GWiz_ManageAPPFApp_Save_Click = 3202,

            GWiz_Users_Page_Load = 3198,

            GWiz_AppfFocusOfficeGroup_Page_Load = 3203,
            GDU_AppfFocusOfficeGroup_Save_Click = 3204,

            GDU_PilotDeploymentReport_Export_Click = 3205
        };
    }
}
