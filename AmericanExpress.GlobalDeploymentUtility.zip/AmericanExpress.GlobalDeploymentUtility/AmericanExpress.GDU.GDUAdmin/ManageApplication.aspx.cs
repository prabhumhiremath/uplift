﻿
namespace AmericanExpress.GDU
{
    #region Page Level Namespace
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Linq;
    using System.Web;
    using System.Web.UI;
    using System.Web.UI.WebControls;
    using AmericanExpress.GDU.Model;
    using AmericanExpress.GDU.Utilities.Diagnostics;
    #endregion

    public partial class ManageClient : System.Web.UI.Page
    {
        private GDUModel gduModel;

        private void ShowHideButton(AdmConstants.CRUD_MODE mode)
        {
            switch (mode)
            {
                case AdmConstants.CRUD_MODE.UPDATE:
                    {
                        btnSave.Visible = true;
                        btnSave.Text = AdmConstants.CRUD_MODE.UPDATE.ToString();
                        btnModify.Visible = false;
                        btnDelete.Visible = false;
                        lblMsgPanel.Text = "";
                        break;
                    }

                case AdmConstants.CRUD_MODE.ADD:
                    {
                        btnDelete.Visible = false;
                        btnModify.Visible = false;
                        break;
                    }

                case AdmConstants.CRUD_MODE.VIEW:
                    {
                        bool IsDeactive = Convert.ToBoolean(Session[AdmConstants.IS_DEACTIVE]);
                        if (IsDeactive)
                        {
                            btnSave.Text = AdmConstants.CRUD_MODE.ACTIVATE.ToString();
                            ViewState[AdmConstants.MODE] = AdmConstants.CRUD_MODE.ACTIVATE.ToString();
                            btnDelete.Visible = false;
                            btnModify.Visible = false;
                            break;
                        }
                        else
                        {
                            btnSave.Visible = false;
                            break;
                        }
                    }
            }
        }


        private void PopulateControls(string ApplicationAbbr)
        {
            try
            {
                DataTable userDetail = this.GetApplication(ApplicationAbbr);
                if (userDetail != null)
                {
                    txtApplicationDeployPath.Text = userDetail.Rows[0]["ApplicationDeployPath"].ToString();
                    txtApplicationAbbr.Text = userDetail.Rows[0]["ApplicationAbbr"].ToString();
                    txtApplicationName.Text = userDetail.Rows[0]["ApplicationNM"].ToString();
                    txtExeName.Text = userDetail.Rows[0]["ApplicationExeName"].ToString();
                    ddlAppType.Items[0].Text = userDetail.Rows[0]["ApplicationType"].ToString();
                    if (userDetail.Rows[0]["ApplicationType"].ToString() == ".Net")
                    {
                        ddlAppType.Items[1].Text = "Other";
                        ddlAppType.Items[1].Value = "N";
                    }
                    else
                    {
                        ddlAppType.Items[1].Text = ".Net";
                        ddlAppType.Items[1].Value = "Y";
                    }
                    txtEntryPoint.Text = userDetail.Rows[0]["EntryPoint"].ToString();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            string validate = string.Empty;
            try
            {

                if (!Page.IsPostBack)
                {

                    this.gduModel = new  GDUModel();                  
                    if (Request.QueryString[AdmConstants.MODE].ToString().ToUpper().Equals("ADD"))
                    {
                        this.ShowHideButton(AdmConstants.CRUD_MODE.ADD);
                        ViewState[AdmConstants.MODE] = AdmConstants.CRUD_MODE.ADD.ToString();                     
                        txtApplicationAbbr.Enabled = true;

                    }
                    else
                    {

                        ViewState["AppId"] = Request.QueryString["AppId"].ToString();
                        this.ShowHideButton(AdmConstants.CRUD_MODE.VIEW);
                        this.EnableDisableTextbox(false);
                        this.PopulateControls(ViewState["AppId"].ToString());
                        txtApplicationAbbr.Enabled = false;
                    }
                }
            }
            catch (Exception ex)
            {
                LogManager.LogErrorMessage(ex, Convert.ToInt32(AdmConstants.MethodName.GWiz_ManageClient_Page_Laod));
                throw ex;
            }
        }

        private int ManageApplication(string actionmode, string applicationType,string abbriviation, string applicationName, string appId, string exeName, string applicationDeployPath, string entrypoint)
        {
            this.gduModel = new  GDUModel();
            int status = 0;
            this.gduModel.ManageApplication(actionmode, applicationType, abbriviation, exeName, applicationDeployPath, applicationName, appId, entrypoint);
            return status;
        } 

        protected void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
            
                lblMsgPanel.Text = string.Empty;         
                if (Session[AdmConstants.IS_DEACTIVE] != null)
                {
                    if (Session[AdmConstants.IS_DEACTIVE].Equals(true))
                    {
                        if (btnSave.Text == AdmConstants.CRUD_MODE.ACTIVATE.ToString())
                        {
                            this.ViewState[AdmConstants.MODE] = btnSave.Text;
                        }
                    }
                }


                this.ManageApplication(ViewState[AdmConstants.MODE].ToString(), ddlAppType.Text, txtApplicationAbbr.Text.Trim(), txtApplicationName.Text.Trim(), Request["AppId"], txtExeName.Text.Trim(), txtApplicationDeployPath.Text.Trim(), txtEntryPoint.Text.Trim());
                    Response.Redirect("SearchApplication.aspx");

              
                    //lblMsgPanel.Text = "Please enter values !!!";
            
              
            }

            catch (Exception ex)
            {
                LogManager.LogErrorMessage(ex, Convert.ToInt32(AdmConstants.MethodName.GWiz_ManageClient_Save_Click));
                string errmsg = ex.Message;
                lblMsgPanel.Text = errmsg;
            }
            finally
            {
                ViewState["InTransaction"] = null;
                ViewState["IsMapped"] = null;
            }
        }

        private DataTable GetApplication(string AppId)
        {
            gduModel = new GDUModel();
            bool isDeactive = Convert.ToBoolean(Session[AdmConstants.IS_DEACTIVE]);
            DataTable accDetail = this.gduModel.GetApplicationDetails(null, AppId, null, isDeactive, 0, 10, "App_Name", "ASC");
            if (accDetail.Rows.Count > 0)
            {
                return accDetail;
            }
            else
            {
                return null;
            }
        }
            

        private void EnableDisableTextbox(bool enableDisable)
        {
            txtApplicationDeployPath.Enabled = enableDisable;
            ddlAppType.Enabled = enableDisable;
            txtApplicationName.Enabled = enableDisable;
            txtExeName.Enabled = enableDisable;
            txtEntryPoint.Enabled = enableDisable;  
        }

        protected void btnModify_Click(object sender, EventArgs e)
        {           
            this.EnableDisableTextbox(true);
            this.ShowHideButton(AdmConstants.CRUD_MODE.UPDATE);
            ViewState[AdmConstants.MODE] = AdmConstants.CRUD_MODE.UPDATE.ToString();
        }

        /// <summary>
        /// delete button click event handler
        /// </summary>
        /// <param name="sender">The parameter is not used.</param>
        /// <param name="e">The parameter is not used.</param>
        protected void Delete_Click(object sender, EventArgs e)
        {
            ViewState[AdmConstants.MODE] = AdmConstants.CRUD_MODE.DEACTIVATE.ToString();
            this.btnSave_Click(sender, e);
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {

        }
    }
}
