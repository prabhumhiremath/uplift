﻿//-----------------------------------------------------------------------
// <copyright file="ManageUser.aspx.cs" company="NIIT Technologies">
//  Copyright (c) NIIT Technologies. All rights reserved.
// </copyright>
// <summary>
// <Description>Manages user creation/addition/deactivation</Description>
// <Author>NIIT Technologies</Author>
// <CreatedOn>12/1/2009</CreatedOn>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// </summary>
//-----------------------------------------------------------------------
namespace AmericanExpress.GDU.GDUAdmin
{
    #region Page level Namespace
    using System;
    using System.Collections;
    using System.Configuration;
    using System.Data;
    using System.Linq;
    using System.Web;
    using System.Web.Security;
    using System.Web.UI;
    using System.Web.UI.HtmlControls;
    using System.Web.UI.WebControls;
    using System.Web.UI.WebControls.WebParts;
    using System.Xml.Linq;
    using AmericanExpress.GDU;
    using AmericanExpress.GDU.Model;
    using System.Collections.Generic;
    using AmericanExpress.GDU.Utilities.Diagnostics;

    #endregion
    public partial class ManageFocusApplication : System.Web.UI.Page
    {
        /// <summary>
        /// creating object of model layer
        /// </summary>
        private GDUModel gduModel;
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                this.gduModel = new GDUModel();
                txtAppID.Enabled = false;
                txtAppName.Enabled = false;
                txtAppName.Attributes.Add("onkeypress", "javascript:return RestrictChar()");
                if (!Page.IsPostBack)
                {
                    ViewState["ID"] = Request.QueryString["APPID"].ToString();
                    this.PopulateControls(Convert.ToInt32(ViewState["ID"].ToString()));
                    btnSave.Text = "MODIFY";

                }
            }
            catch (Exception ex)
            {
                LogManager.LogErrorMessage(ex, Convert.ToInt32(AdmConstants.MethodName.GWiz_ManageAPPFApp_Page_Load));
            }

        }
        protected void btnSave_Click(object sender, EventArgs e)
        {
            string AppName = null;
            int AppCode = 0;
            if (btnSave.Text == "MODIFY")
            {
                txtAppName.Enabled = true;
                btnSave.Text = "UPDATE";
            }
            else
            {

                if (!string.IsNullOrEmpty(txtAppName.Text.Trim()))
                {
                    AppName = txtAppName.Text.Trim();
                }
                AppCode = Convert.ToInt32(ViewState["ID"]);
                ManageApplication(AppName, AppCode);
                Response.Redirect("SearchFocusApplication.aspx");
            }
        }
        #region "Methods"
        private int ManageApplication(string ApplicationName, int ID)
        {
            int status = 0;
            this.gduModel.ManageFocusApplication(ApplicationName, ID);
            return status;
        }
        private void PopulateControls(int AppID)
        {
            try
            {
                DataTable appDetail = this.GetAppDetails(AppID);
                if (appDetail != null)
                {
                    txtAppID.Text = appDetail.Rows[0]["AppID"].ToString();
                    txtAppName.Text = appDetail.Rows[0]["AppDESC"].ToString();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private DataTable GetAppDetails(int ID)
        {
            DataTable userDetail = this.gduModel.GetFocusAppDetails(ID);
            if (userDetail.Rows.Count > 0)
            {
                return userDetail;
            }
            else
            {
                return null;
            }
        }
        #endregion
    }
}
