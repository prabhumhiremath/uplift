﻿//-----------------------------------------------------------------------
// <copyright file="CountryMapping.aspx.cs" company="NIIT Technologies">
//  Copyright (c) NIIT Technologies. All rights reserved.
// </copyright>
// <summary>
// <Description>This is a Interface to define signatures for implementing Business Logic.</Description>
// <Author>NIIT Technologies</Author>
// <CreatedOn>04/05/2010</CreatedOn>
// <Modified> 
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// </summary>
//-----------------------------------------------------------------------

namespace AmericanExpress.GDU.GDUAdmin
{
    #region Page level Namespace
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Linq;
    using System.Web;
    using System.Web.UI;
    using System.Xml.Xsl;
    using System.Xml;
    using System.Xml.XPath;
    using System.Text;
    using System.IO;
    using System.Web.UI.HtmlControls;
    using AmericanExpress.GWizAdmin.Utility;

    using System.Web.UI.WebControls;
    using AmericanExpress.GDU.Model;
    using AmericanExpress.GDU;
    using System.Security.Principal;
    using AmericanExpress.GDU.Utilities.Diagnostics;

    #endregion
    public partial class ManageOfficeGroupMapping : System.Web.UI.Page
    {
        private GDUModel gduModel;
        public string _isNewRecord = "1";
        public int Intype = 0;
        public string ADS_id = string.Empty;
        public string strOFFICE_ID = string.Empty;
        public string MACHINE_NM = string.Empty;

        #region Events
        /// <summary>
        /// page load event
        /// </summary>
        /// <param name="sender">The parameter is not used.</param>
        /// <param name="e">The parameter is not used.</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                lblmsg.Visible = false;
                if (!IsPostBack)
                {
                    //if (Global.IsPageAuthorized(System.IO.Path.GetFileName(Request.Path)) == false)
                    //    Response.Redirect("NotAuthorized.aspx", false);
                    ViewState["OfficeID"] = null;
                    this.PopulateVirtualGroups();
                    this.PopulateRealGroups();
                    Session["AdsMappTable"] = null;


                }
            }
            catch (Exception ex)
            {
                LogManager.LogErrorMessage(ex, Convert.ToInt32(AdmConstants.MethodName.GWiz_CountryMapping_Page_Load));
                throw ex;
            }
        }
        protected void ddlVirtualGroupId_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {


                this.gduModel = new GDUModel();
                string Office_ID = string.Empty;
                Session["XsltMappTable"] = null;
                Session["AdsMappTable"] = null;
                lstAvailableAdsIDs.Items.Clear();
                Dictionary<string, string> dict = new Dictionary<string, string>();
                int InType = 1;
                DataTable XsltMappingDetails = this.gduModel.PopulateAppFGroupADSID(Office_ID, Convert.ToInt16(ddlVirtualGroupId.SelectedValue), InType, out dict);

                dict = DataTableToDictionary(XsltMappingDetails);
                Session["XsltMappTable"] = dict;
                bindxslt(dict);
                this.PopulateRealGroups();

            }
            catch (Exception ex)
            {
            }
        }

        private Dictionary<string, string> DataTableToDictionary(DataTable dtmapped)
        {
            Dictionary<string, string> returnDict = new Dictionary<string, string>();
            foreach (DataRow row in dtmapped.Rows)
            {
                returnDict.Add(row["OFFICE_ID"] + "|" + row["ADS_ID"] + "|" + row["MACHINE_NM"], row["ADS_ID"] + "- [" + row["MACHINE_NM"] + "]- " + "[" + row["USER_NM"] + "]" + "[" + row["OFFICE_DS"] + "]");
            }
            return returnDict;
        }

        protected void btnAddOfficeId_Click(object sender, EventArgs e)
        {
            try
            {
                Dictionary<string, string> dtmapp = new Dictionary<string, string>();
                dtmapp = this.AddMappingID(false);
                bindxslt(dtmapp);

            }
            catch (Exception ex)
            {

            }
        }

        protected void btnAddAllOfficeIds_Click(object sender, EventArgs e)
        {
            try
            {

                Dictionary<string, string> dtmapp = new Dictionary<string, string>();
                dtmapp = this.AddMappingID(true);
                bindxslt(dtmapp);

            }
            catch (Exception ex)
            {

            }
        }
        protected void btnDelOfficeId_Click(object sender, EventArgs e)
        {
            try
            {
                Dictionary<string, string> dtRemovemapp = new Dictionary<string, string>();
                Dictionary<string, string> AvilableMapping = new Dictionary<string, string>();
                dtRemovemapp = this.RemoveMappingID(false);
                AvilableMapping = (Dictionary<string, string>)Session["AdsMappTable"];
                bindxslt(dtRemovemapp);
                BindAdsList(AvilableMapping);
            }
            catch (Exception ex)
            {

            }
        }

        protected void btnDelAllOfficeIds_Click(object sender, EventArgs e)
        {
            try
            {
                Dictionary<string, string> dtRemovemapp = new Dictionary<string, string>();
                Dictionary<string, string> AvilableMapping = new Dictionary<string, string>();
                dtRemovemapp = this.RemoveMappingID(true);
                AvilableMapping = (Dictionary<string, string>)Session["AdsMappTable"];
                bindxslt(dtRemovemapp);
                BindAdsList(AvilableMapping);
            }
            catch (Exception ex)
            { }
        }
        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Session["XsltMappTable"] = null;
            Session["AdsMappTable"] = null;
            ddlVirtualGroupId.SelectedValue = "0";
            Response.Redirect("SearchApplication.aspx");

        }
        #endregion
        #region methods
        /// <summary>
        /// populate real country
        /// </summary>
        private void PopulateRealGroups()
        {
            this.gduModel = new GDUModel();
            Dictionary<string, string> dict = new Dictionary<string, string>();
            dict = this.gduModel.PopulateAppFGroup(string.Empty, Convert.ToInt16(ddlVirtualGroupId.SelectedValue), "Real");
            lstAvailableOfficeIDs.DataSource = dict;
            lstAvailableOfficeIDs.DataTextField = "Value";
            lstAvailableOfficeIDs.DataValueField = "Key";
            this.lstAvailableOfficeIDs.DataBind();
        }
        private void bindxslt(Dictionary<string, string> XsltMapping)
        {
            this.gduModel = new GDUModel();
            string result = gduModel.ReturnSearchResultXMLAdmin(XsltMapping);
            XsltArgumentList args = new XsltArgumentList();
            args.AddExtensionObject("gwiz:XslUtils", new XslExtensionsUtil());
            XslCompiledTransform xsl = new XslCompiledTransform(true);
            XsltSettings xsltSettings = new XsltSettings(true, true);
            xsl.Load(@AppDomain.CurrentDomain.BaseDirectory + "XML\\ADSOFFICE.xslt", xsltSettings, new XmlUrlResolver());
            XmlReader xmlReader = new XmlTextReader(new StringReader(result));
            System.IO.MemoryStream memoryStream = new MemoryStream();
            xsl.Transform(xmlReader, args, memoryStream);
            memoryStream.Position = 0;
            StreamReader streamReader = new StreamReader(memoryStream);
            string formattedXml = streamReader.ReadToEnd();
            divSearchResult.InnerHtml = formattedXml.Replace("&#xA;", "\\n");

        }

        /// <summary>
        /// populate virtual country
        /// </summary>
        private void PopulateVirtualGroups()
        {
            this.gduModel = new GDUModel();
            Dictionary<string, string> dict = new Dictionary<string, string>();
            dict = this.gduModel.PopulateAppFGroup(string.Empty, 0, "Virtual");
            ddlVirtualGroupId.DataSource = dict;
            ddlVirtualGroupId.DataTextField = "Value";
            ddlVirtualGroupId.DataValueField = "Key";
            this.ddlVirtualGroupId.DataBind();
            this.ddlVirtualGroupId.Items.Insert(0, new ListItem(AdmConstants.PLEASE_SELECT, "0"));
        }

        /// <summary>
        /// populate Mapped ADS 
        /// </summary>
        private DataTable PopulateADSIDs(int InType)
        {
            DataTable dtADSID = new DataTable();
            this.gduModel = new GDUModel();
            lstAvailableAdsIDs.Items.Clear();

            if (string.IsNullOrEmpty(strOFFICE_ID))
                strOFFICE_ID = GetAvailableOfficeIDs();

            Dictionary<string, string> dict = new Dictionary<string, string>();
            Dictionary<string, string> maindict = new Dictionary<string, string>();
            dtADSID = this.gduModel.PopulateAppFGroupADSID(strOFFICE_ID, Convert.ToInt16(ddlVirtualGroupId.SelectedValue), InType, out dict);

            return dtADSID;

        }

        /// <summary>
        /// bind list
        /// </summary>
        /// <param name="countryTable">country table</param>
        private void BindList(string ADS_ID, int InType)
        {
            this.gduModel = new GDUModel();
            string userid = string.Empty;
            userid = GetUserName();

            this.gduModel.ManageAppFGroupADSID(ADS_ID, userid, Convert.ToInt16(ddlVirtualGroupId.SelectedValue), InType);
        }

        private void BindAdsList(Dictionary<string, string> AdsIDTable)
        {
            lstAvailableAdsIDs.DataSource = AdsIDTable;
            lstAvailableAdsIDs.DataTextField = "Value";
            lstAvailableAdsIDs.DataValueField = "Key";
            this.lstAvailableAdsIDs.DataBind();
        }

        private string GetUserName()
        {
            string UserName = string.Empty;
            try
            {
                UserName = (WindowsIdentity.GetCurrent().Name.Substring(WindowsIdentity.GetCurrent().Name.LastIndexOf(@"\"))).Replace(@"\", "");
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return UserName;
        }

        #endregion


        protected string GetAvailableOfficeIDs()
        {
            String strOFFICEID = string.Empty;
            foreach (ListItem item in lstAvailableOfficeIDs.Items)
            {
                if (item.Selected)
                {

                    strOFFICEID = strOFFICEID + item.Value + ",";

                }
            }
            if (strOFFICEID.IndexOf(',') > 0)
            {
                strOFFICEID.Remove(strOFFICEID.LastIndexOf(','));
            }

            ViewState["OfficeID"] = strOFFICEID;

            return strOFFICEID;

        }

        protected void btnAddToList_Click(object sender, EventArgs e)
        {
            try
            {

                Session["AdsMappTable"] = null;
                Intype = 3;
                IEnumerable<KeyValuePair<string, string>> MappUnmapp;
                DataTable AdsMappingDetails = this.PopulateADSIDs(Intype);
                Dictionary<string, string> AdsIDdict = new Dictionary<string, string>();
                Dictionary<string, string> Finaldict = new Dictionary<string, string>();
                Dictionary<string, string> ExistAdsIDdict = new Dictionary<string, string>();
                Dictionary<string, string> XsltIDdict = new Dictionary<string, string>();

                AdsIDdict = DataTableToDictionary(AdsMappingDetails);
                MyComparer mycompare = new MyComparer();

                XsltIDdict = (Dictionary<string, string>)Session["XsltMappTable"];

                MappUnmapp = AdsIDdict.Except(XsltIDdict, mycompare);
                foreach (var AdsId in MappUnmapp)
                {

                    Finaldict.Add(AdsId.Key, AdsId.Value);
                }

                Session["AdsMappTable"] = Finaldict;

                BindAdsList((Dictionary<string, string>)Session["AdsMappTable"]);
                XsltIDdict = (Dictionary<string, string>)Session["XsltMappTable"];


                Session["XsltMappTable"] = XsltIDdict;
                bindxslt((Dictionary<string, string>)Session["XsltMappTable"]);

            }
            catch (Exception ex)
            {

            }
        }


        private Dictionary<string, string> AddMappingID(bool IsAll)
        {

            Dictionary<string, string> dtMapping = new Dictionary<string, string>();
            Dictionary<string, string> dtAdsMapping = new Dictionary<string, string>();
            Dictionary<string, string> dtKeyValueMapping = new Dictionary<string, string>();
            List<object> toRemove = new List<object>();
            DataRow AdsIDRow;
            string AdsID = string.Empty;
            if (Session["XsltMappTable"] != null)
            {
                dtKeyValueMapping = (Dictionary<string, string>)Session["XsltMappTable"];
            }
            if (Session["AdsMappTable"] != null)
            {
                dtAdsMapping = (Dictionary<string, string>)Session["AdsMappTable"];
            }
            if (Session["XsltMappTable"] == null || ((Session["AdsMappTable"] != null)))
            {

            }
            else
            {

            }
            foreach (ListItem i in lstAvailableAdsIDs.Items)
            {


                if (!IsAll)
                {

                    if (i.Selected)
                    {
                        AdsID = i.Value;

                        if (dtKeyValueMapping.Count == 0)
                        {
                            dtKeyValueMapping.Add(i.Value, i.Text);
                            toRemove.Add(i);

                            string[] Keys = new string[dtAdsMapping.Count];
                            dtAdsMapping.Keys.CopyTo(Keys, 0);
                            dtAdsMapping.Remove(i.Value);
                        }
                        else
                        {

                            dtKeyValueMapping.Add(i.Value, i.Text);
                            //  lstAvailableAdsIDs.Items.Remove(i);
                            toRemove.Add(i);
                            if (!this.IsAlreadyEsists(dtKeyValueMapping, AdsID))
                            {
                                dtKeyValueMapping.Add(i.Value, i.Text);
                            }
                            string[] Keys = new string[dtAdsMapping.Count];
                            dtAdsMapping.Keys.CopyTo(Keys, 0);
                            dtAdsMapping.Remove(i.Value);
                        }


                    }

                }

                else
                {

                    if (!this.IsAlreadyEsists(dtKeyValueMapping, AdsID))
                    {
                        dtKeyValueMapping.Add(i.Value, i.Text);
                        toRemove.Add(i);
                    }
                    string[] Keys = new string[dtAdsMapping.Count];
                    dtAdsMapping.Keys.CopyTo(Keys, 0);
                    dtAdsMapping.Remove(i.Value);

                }

            }
            foreach (ListItem item in toRemove)
            {
                lstAvailableAdsIDs.Items.Remove(item);
            }
            if (dtMapping.Count == 0)
            {
                Session["XsltMappTable"] = dtKeyValueMapping;
                Session["AdsMappTable"] = dtAdsMapping;

            }
            else
            {
                Session["XsltMappTable"] = dtMapping;
                Session["AdsMappTable"] = dtAdsMapping;
            }

            return (Dictionary<string, string>)Session["XsltMappTable"];
        }

        private Dictionary<string, string> RemoveMappingID(bool IsAll)
        {
            Dictionary<string, string> dtMapping = new Dictionary<string, string>();
            Dictionary<string, string> dtKeyValueMapping = new Dictionary<string, string>();
            dtMapping = (Dictionary<string, string>)Session["XsltMappTable"];

            string RemKey = string.Empty;
            if (((Session["XsltMappTable"] != null)))
            {
                if (!IsAll)
                {
                    if (!string.IsNullOrEmpty(hdnvalue.Value))
                    {

                        string MappRemove = hdnvalue.Value;
                        string TEMP = MappRemove.Substring(MappRemove.IndexOf(','));
                        string OFFICE_ID = MappRemove.Substring(0, MappRemove.IndexOf(','));

                        ADS_id = TEMP.Substring(1, TEMP.IndexOf('-') - 1);
                        MACHINE_NM = MappRemove.Substring(MappRemove.IndexOf('[') + 1, MappRemove.IndexOf("]") - MappRemove.IndexOf('[') - 1);
                        RemKey = OFFICE_ID + "|" + ADS_id + "|" + MACHINE_NM;
                        if (Session["AdsMappTable"] != null)
                        {
                            dtKeyValueMapping = (Dictionary<string, string>)Session["AdsMappTable"];
                        }

                        string[] Keys = new string[dtMapping.Count];
                        string[] Values = new string[dtMapping.Count];
                        dtMapping.Keys.CopyTo(Keys, 0);
                        dtMapping.Values.CopyTo(Values, 0);
                        int count = dtMapping.Count;
                        for (int i = 0; i <= count - 1; i++)
                        {
                            if (Keys[i].ToLower() == RemKey.ToLower())
                            {
                                dtKeyValueMapping.Add(Keys[i], Values[i]);
                                dtMapping.Remove(Keys[i]);
                            }
                        }
                        if (dtMapping.Count == 0)
                        {
                            Session["XsltMappTable"] = null;

                        }

                    }
                }
                else
                {
                    if (Session["AdsMappTable"] != null)
                    {
                        dtKeyValueMapping = (Dictionary<string, string>)Session["AdsMappTable"];
                    }

                    string[] Keys = new string[dtMapping.Count];
                    string[] Values = new string[dtMapping.Count];
                    dtMapping.Keys.CopyTo(Keys, 0);
                    dtMapping.Values.CopyTo(Values, 0);
                    int count = dtMapping.Count;
                    for (int i = 0; i <= count - 1; i++)
                    {

                        dtKeyValueMapping.Add(Keys[i], Values[i]);
                        dtMapping.Remove(Keys[i]);

                    }
                    if (dtMapping.Count == 0)
                    {
                        Session["XsltMappTable"] = null;

                    }


                }
            }
            Session["AdsMappTable"] = dtKeyValueMapping;
            Session["XsltMappTable"] = dtMapping;
            hdnvalue.Value = string.Empty;
            return (Dictionary<string, string>)Session["XsltMappTable"];
        }
        private bool IsAlreadyEsists(Dictionary<string, string> MappingTable, string Key)
        {
            bool isAlreadyCoun = false;
            foreach (KeyValuePair<String, String> entry in MappingTable)
            {
                if (entry.Key == Key)
                {
                    isAlreadyCoun = true;
                    break;
                }
            }

            return isAlreadyCoun;
        }

        protected void Save_Click(object sender, EventArgs e)
        {
            this.gduModel = new GDUModel();
            try
            {

                string StrValues = string.Empty;
                string userid = string.Empty;
                userid = GetUserName();
                Dictionary<string, string> dtMapping = new Dictionary<string, string>();

                if (Session["XsltMappTable"] != null)
                {
                    dtMapping = (Dictionary<string, string>)Session["XsltMappTable"];

                    foreach (KeyValuePair<String, String> entry in dtMapping)
                    {
                        StrValues += entry.Key + ",";

                    }
                    if (StrValues.IndexOf(',') > 0)
                    {
                        StrValues.Remove(StrValues.LastIndexOf(','));
                    }
                    this.gduModel.ManageAppFGroupADSID(StrValues, userid, Convert.ToInt16(ddlVirtualGroupId.SelectedValue), Intype);
                    lblmsg.Text = "Mapping Saved Sucessfully!!!!";
                    lblmsg.Visible = true;
                }

            }
            catch (Exception ex)
            {
                LogManager.LogErrorMessage(ex, Convert.ToInt32(AdmConstants.MethodName.GWiz_CountryMapping_Save_Click));
                throw ex;
            }
        }
        private void Clear()
        {
            Session["XsltMappTable"] = null;
            Session["AdsMappTable"] = null;
            lstAvailableAdsIDs.Items.Clear();
            divSearchResult.InnerHtml = "";
            ddlVirtualGroupId.SelectedValue = "0";

        }
    }
    public class MyComparer : IEqualityComparer<KeyValuePair<string, string>>
    {
        public bool Equals(KeyValuePair<string, string> x, KeyValuePair<string, string> y)
        {
            return x.Key.Equals(y.Key);
        }

        public int GetHashCode(KeyValuePair<string, string> obj)
        {
            return obj.Key.GetHashCode();
        }
    }


}
