﻿//-----------------------------------------------------------------------
// <copyright file="ManageRole.cs" company="">
//   
// </copyright>
// <summary>
// 
// NIIT Technolgies
// 27/03/2009
// 
//</summary>

namespace AmericanExpress.GDU
{
    #region using

    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Linq;
    using System.Web;
    using System.Web.UI;
    using System.Web.UI.WebControls;
    using AmericanExpress.GDU.Model;
    using AmericanExpress.GDU.Utilities.Diagnostics;
    #endregion

    /// <summary>
    /// This is main entry point for ManageRole module
    /// </summary>
    public partial class ManageRole : System.Web.UI.Page
    {
        private GDUModel gduModel;
        #region methods
        protected void manageRole(string roleCd, string roleName, int clientId, DateTime modifiedDt, string flag, string authorizedFunctionIds, string roleTypeCD, string System_CD)//, ref string outRoleCd, ref int outClientId)
        {
            gduModel = new GDUModel();
            this.gduModel.ManageRole(roleCd, roleName, clientId, modifiedDt, flag, authorizedFunctionIds, roleTypeCD, System_CD);
        }

        /// <summary>
        /// LoadSystem
        /// </summary>       
        protected void LoadRoles()
        {
            try
            {
                Dictionary<string, string> objDictonary = new Dictionary<string, string>();
                objDictonary = gduModel.PopulateRoleMaster();
                this.ddlRole.DataSource = objDictonary;
                ddlRole.DataValueField = AdmConstants.KEY;
                ddlRole.DataTextField = AdmConstants.VALUE;
                ddlRole.DataBind();
                //this.ddlRole.Items.Insert(0, new ListItem("All", "0-All"));
                ddlRole.Items.Insert(0, "Select Role Type");
            }
            catch (Exception ex)
            {
                //throw Common.HandleException(ex, Common.MethodName.ManageRole_LoadSystem);
            }
        }

        /// <summary>
        /// ReadRole
        /// </summary>
        protected void ReadRole()
        {
            try
            {
                string roleId = Convert.ToString(ViewState["RoleId"]);
                int clientId = Convert.ToInt32(ViewState["ClientCode"].ToString());
                bool isDeactive = false;
                isDeactive = Convert.ToBoolean(Session[AdmConstants.IS_DEACTIVE]);
                DataTable dtSearchRole = gduModel.GetRoleDetails(clientId, roleId, null, isDeactive, "GD", 0, 5000, "ROLE_NM", "ASC");
                if (!Convert.IsDBNull(dtSearchRole.Rows[0]["CLIENT_ID"]))
                {
                    //foreach (ListItem item in ddlApplication.Items)
                    //{
                    //    if (item.Value.Contains("-") && (Convert.ToInt32(item.Value.Split('-')[0]) == clientId))
                    //        item.Selected = true;
                    //    //ddlClient.Items.FindByValue(sysCode).Selected = true;
                    //}

                }
                if (!Convert.IsDBNull(dtSearchRole.Rows[0]["ROLE_CD"]))
                {
                    foreach (ListItem item in ddlRole.Items)
                    {
                        if ((Convert.ToString(item.Value) == dtSearchRole.Rows[0]["ROLETYPE_CD"].ToString()))
                            item.Selected = true;
                    }
                }
                txtRoleCd.Text = dtSearchRole.Rows[0]["ROLE_CD"].ToString();
                txtRole.Text = dtSearchRole.Rows[0]["ROLE_NAME"].ToString();
                ViewState["ModifiedOn"] = dtSearchRole.Rows[0]["MODIFIED_DT"];
                txtRoleCd.Enabled = false;
            }
            catch (Exception ex)
            {
                //throw Common.HandleException(ex, Common.MethodName.ManageRole_ReadRole);
            }
        }

        /// <summary>
        /// LoadFunctionOnEdit
        /// </summary>
        /// <param name="roleId">roleId</param>
        /// <param name="sysCode">sysCode</param>
        protected void LoadFunctionOnEdit(string funcType, string roleId, int clientID, string SYSTEM_CD)
        {
            try
            {
                DataTable dtFunction = new DataTable();
                dtFunction = gduModel.GetFunctionDetails(funcType, roleId, clientID, SYSTEM_CD);
                lbAuthorizedFunction.DataTextField = dtFunction.Columns[1].ToString();
                lbAuthorizedFunction.DataValueField = dtFunction.Columns[0].ToString();
                lbAuthorizedFunction.DataSource = dtFunction;
                lbAuthorizedFunction.DataBind();
                if (lbAuthorizedFunction.Items[0].Value == "0")
                    lbAuthorizedFunction.Items.Remove(lbAuthorizedFunction.Items[0]);

            }
            catch (Exception ex)
            {
                //throw Common.HandleException(ex, Common.MethodName.ManageRole_LoadFunctionOnEdit);
            }
        }

        /// <summary>
        /// LoadFunctions
        /// </summary>
        /// <param name="roleId">roleId</param>
        /// <param name="code">code</param>
        protected void LoadFunctions(string funcType, string roleId, int clientID, string SYSTEM_CD)
        {
            try
            {
                DataTable dtFunction = new DataTable();
                dtFunction = gduModel.GetFunctionDetails(funcType, roleId, clientID, SYSTEM_CD);
                lbAvailableFunction.DataTextField = dtFunction.Columns[1].ToString();
                lbAvailableFunction.DataValueField = dtFunction.Columns[0].ToString();
                lbAvailableFunction.DataSource = dtFunction;
                lbAvailableFunction.DataBind();
                if (lbAvailableFunction.Items[0].Value == "0")
                    lbAvailableFunction.Items.Remove(lbAvailableFunction.Items[0]);
            }
            catch (Exception ex)
            {
                //throw Common.HandleException(ex, Common.MethodName.ManageRole_LoadFunctions);
            }
        }

        /// <summary>
        /// EnableDisableTextbox
        /// </summary>
        /// <param name="isEnableDisable">isEnableDisable</param>
        private void EnableDisableTextbox(bool isEnableDisable)
        {
            txtRoleCd.Enabled = isEnableDisable;
            txtRole.Enabled = isEnableDisable;
            ddlSystemName.Enabled = isEnableDisable;
            ddlRole.Enabled = isEnableDisable;
            lbAvailableFunction.Enabled = isEnableDisable;
        }

        /// <summary>
        /// ShowHideButton
        /// </summary>
        /// <param name="mode">mode</param>
        private void ShowHideButton(string mode)
        {
            switch (mode)
            {
                case "Update":
                    btnSave.Visible = true;
                    btnSave.Text = "UPDATE";
                    btnModify.Visible = false;
                    btnDelete.Visible = false;
                    btnAdd.Disabled = false;
                    btnAddAll.Disabled = false;
                    btnDel.Disabled = false;
                    btnDelAll.Disabled = false;
                    break;
                case "Add":
                    btnDelete.Visible = false;
                    btnModify.Visible = false;
                    break;
                case "View":
                    bool deactive = Convert.ToBoolean(Session[AdmConstants.IS_DEACTIVE]);
                    if (deactive)
                    {
                        btnSave.Text = AdmConstants.CRUD_MODE.ACTIVATE.ToString();
                        btnDelete.Visible = false;
                        btnModify.Visible = false;
                    }
                    else
                    {
                        btnAdd.Disabled = true;
                        btnAddAll.Disabled = true;
                        btnDel.Disabled = true;
                        btnDelAll.Disabled = true;
                        btnSave.Visible = false;
                    }
                    break;
            }
        }
        #endregion

        #region events
        /// <summary>
        /// Page_Load
        /// </summary>
        /// <param name="sender">object sender</param>
        /// <param name="e">EventArgs e</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            string validate = string.Empty;
            try
            {
                this.gduModel = new GDUModel();
                //ddlRole.Attributes.Add("onChange", "showFunction();");
                //Page.ClientScript.RegisterStartupScript(Type.GetType("System.String"), "addScript", "showRoleFunction()", true);
                if (!Page.IsPostBack)
                {
                    //cvSystem.ErrorMessage = "Select Client";//Global.getErrorDesc(1033);//Select system
                    //cvRoleCd.ErrorMessage = Global.getErrorDesc(1034);//Enter role code
                    //cvRole.ErrorMessage = Global.getErrorDesc(1035);//Enter role
                    //cvAuthorizedFunction.ErrorMessage = Global.getErrorDesc(1036);//Assign alteast one function
                    //if (Global.IsPageAuthorized(System.IO.Path.GetFileName(Request.Path)) == false)
                    //    Response.Redirect("NotAuthorized.aspx", false);
                    //validate = this.gwizModel.UserAuthentication();
                    //if (validate == AdmConstants.FALSE)
                    //{
                    //    Response.Redirect("NotAuthorized.aspx", false);
                    //}
                    // this.LoadRoles();
                    if (Request.QueryString["Mode"].Equals("Add"))
                    {
                        ViewState["AddEdit"] = "Add";
                        //lblHeading.Text = "Add";
                        this.ShowHideButton("Add");
                        this.LoadFunctions("Available", string.Empty, 0, "GD");
                    }                    
                    else
                    {
                        ddlSystemName.SelectedIndex = 1;
                        ddlRole.SelectedIndex = 1;
                        ViewState["RoleId"] = Convert.ToString(Request.QueryString["RoleId"]);
                        ViewState["ClientCode"] = Convert.ToString(Request.QueryString["ClientCode"]);
                        //lblHeading.Text = "View";
                        this.ShowHideButton("View");
                        this.EnableDisableTextbox(false);
                        this.ReadRole();
                        this.LoadFunctions("Available", Convert.ToString(ViewState["RoleId"]), Convert.ToInt32(ViewState["ClientCode"].ToString()), "GD");
                        this.LoadFunctionOnEdit("Authorized", Convert.ToString(ViewState["RoleId"]), Convert.ToInt32(ViewState["ClientCode"].ToString()), "GD");
                    }
                }
                //ucMsgPanel.HidePanel();
            }
            catch (Exception ex)
            {
                LogManager.LogErrorMessage(ex, Convert.ToInt32(AdmConstants.MethodName.GWiz_ManageRole_Page_Load));
                //throw Common.HandleException(ex, Common.MethodName.ManageRole_Page_Load);

            }

        }

        /// <summary>
        /// cvRoleCd_ServerValidate
        /// </summary>
        /// <param name="source">Object source</param>
        /// <param name="args">System.Web.UI.WebControls.ServerValidateEventArgs args</param>
        protected void cvRoleCd_ServerValidate(Object source, System.Web.UI.WebControls.ServerValidateEventArgs args)
        {
            args.IsValid = !string.IsNullOrEmpty(txtRoleCd.Text.ToString());
        }
        /// <summary>
        /// cvRole_ServerValidate
        /// </summary>
        /// <param name="source">Object source</param>
        /// <param name="args">System.Web.UI.WebControls.ServerValidateEventArgs args</param>
        protected void cvRole_ServerValidate(Object source, System.Web.UI.WebControls.ServerValidateEventArgs args)
        {
            args.IsValid = !string.IsNullOrEmpty(txtRole.Text.ToString());
        }
        /// <summary>
        /// cvSystem_ServerValidate
        /// </summary>
        /// <param name="source">Object source</param>
        /// <param name="args">System.Web.UI.WebControls.ServerValidateEventArgs args</param>
        protected void cvSystem_ServerValidate(Object source, System.Web.UI.WebControls.ServerValidateEventArgs args)
        {
            args.IsValid = !ddlSystemName.SelectedItem.Text.Equals("Select System");
        }
        /// <summary>
        /// cvlbAuthorizedFunction_ServerValidate
        /// </summary>
        /// <param name="source">Object source</param>
        /// <param name="args">System.Web.UI.WebControls.ServerValidateEventArgs args</param>
        protected void cvlbAuthorizedFunction_ServerValidate(Object source, System.Web.UI.WebControls.ServerValidateEventArgs args)
        {
            if (!ddlSystemName.SelectedItem.Text.Equals("Select System"))
                args.IsValid = !string.IsNullOrEmpty(hdAuthorizedFunctionIds.Value.ToString());
        }

        /// <summary>
        /// This event is save role records
        /// </summary>
        /// <param name="sender">object sender</param>
        /// <param name="e">EventArgs e</param>    
        protected void btnSave_Click(object sender, EventArgs e)
        {
            string roleId;
            string role;
            int clientID;
            string roleType_CD;

            DateTime modifiedOn;
            try
            {
                if (Session[AdmConstants.IS_DEACTIVE] != null)
                {
                    if (Session[AdmConstants.IS_DEACTIVE].Equals(true))
                    {
                        if (btnSave.Text == AdmConstants.CRUD_MODE.ACTIVATE.ToString())
                        {
                            this.ViewState["AddEdit"] = btnSave.Text;
                        }
                    }
                }

                if (ViewState["AddEdit"].Equals("Add"))
                {
                    roleId = txtRoleCd.Text.Trim().ToString();//ddlRole.SelectedValue.ToString();
                    role = txtRole.Text.Trim().ToString(); //ddlRole.SelectedItem.ToString();//
                    clientID = 0;
                    roleType_CD = "AD";


                    manageRole(roleId, role, clientID, DateTime.Now, ViewState["AddEdit"].ToString(), hdAuthorizedFunctionIds.Value.ToString(), roleType_CD,"GD");


                }
                if (ViewState["AddEdit"].Equals("Update") || ViewState["AddEdit"].Equals("ACTIVATE"))
                {
                    roleId = Convert.ToString(ViewState["RoleId"]);
                    clientID = Convert.ToInt32(ViewState["ClientCode"].ToString());
                    modifiedOn = Convert.ToDateTime(ViewState["ModifiedOn"]);
                    role = txtRole.Text.Trim().ToString();//ddlRole.SelectedItem.ToString();//
                    roleType_CD = "AD";

                    manageRole(roleId, role, clientID, modifiedOn, ViewState["AddEdit"].ToString(), hdAuthorizedFunctionIds.Value.ToString(), roleType_CD,"GD");

                }

                Response.Redirect("SearchRole.aspx");

            }
            catch (Exception ex)
            {
                LogManager.LogErrorMessage(ex, Convert.ToInt32(AdmConstants.MethodName.GWiz_ManageRole_Save_Click));
                lblMsgPanel.Text = ex.Message;

            }

        }
        /// <summary>
        /// This  event modify role records
        /// </summary>
        /// <param name="sender">object sender</param>
        /// <param name="e">EventArgs e</param>
        protected void btnModify_Click(object sender, EventArgs e)
        {
            this.EnableDisableTextbox(true);
            this.ShowHideButton("Update");
            ViewState["AddEdit"] = "Update";
            //lblHeading.Text = "Edit";
            ddlSystemName.Enabled = false;
            ddlRole.Enabled = false;
            txtRoleCd.Enabled = false;
        }
        /// <summary>
        /// This event will delete role
        /// </summary>
        /// <param name="sender">object sender</param>
        /// <param name="e">EventArgs e</param>
        protected void btnDelete_Click(object sender, EventArgs e)
        {
            string roleId;
            int clientID;
            string role;
            DateTime modifiedOn;
            string roleType_CD;

            try
            {

                roleId = Convert.ToString(ViewState["RoleId"]);
                clientID = Int32.Parse(ViewState["ClientCode"].ToString());
                modifiedOn = Convert.ToDateTime(ViewState["ModifiedOn"]);
                role = txtRole.Text.Trim().ToString();//ddlRole.SelectedItem.ToString();//txtRole.Text.Trim().ToString();
                roleType_CD = "AD";

                manageRole(roleId, role, clientID, modifiedOn, "Delete", hdAuthorizedFunctionIds.Value.ToString(), roleType_CD,"GD");

                Response.Redirect("SearchRole.aspx");

            }
            catch (Exception ex)
            {
                LogManager.LogErrorMessage(ex, Convert.ToInt32(AdmConstants.MethodName.GWiz_ManageRole_Delete_Click));
                lblMsgPanel.Text = ex.Message;
            }
        }
        #endregion
        protected void ddlClient_SelectedIndexChanged(object sender, EventArgs e)
        {

            if (ddlSystemName.SelectedIndex > 0)
                this.LoadFunctions("Available", string.Empty, Convert.ToInt32(ddlSystemName.SelectedValue.Split('-')[0]), "GD");

        }
    }
}
