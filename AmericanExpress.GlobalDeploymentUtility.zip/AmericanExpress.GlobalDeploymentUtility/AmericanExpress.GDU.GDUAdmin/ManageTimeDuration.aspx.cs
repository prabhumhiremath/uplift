﻿//-----------------------------------------------------------------------
// <copyright file="ManageUser.aspx.cs" company="NIIT Technologies">
//  Copyright (c) NIIT Technologies. All rights reserved.
// </copyright>
// <summary>
// <Description>Manages user creation/addition/deactivation</Description>
// <Author>NIIT Technologies</Author>
// <CreatedOn>12/1/2009</CreatedOn>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// </summary>
//-----------------------------------------------------------------------
namespace AmericanExpress.GDU.GDUAdmin
{
    #region Page level Namespace
    using System;
    using System.Collections;
    using System.Configuration;
    using System.Data;
    using System.Linq;
    using System.Web;
    using System.Web.Security;
    using System.Web.UI;
    using System.Web.UI.HtmlControls;
    using System.Web.UI.WebControls;
    using System.Web.UI.WebControls.WebParts;
    using System.Xml.Linq;
    using AmericanExpress.GDU.Model;
    using AmericanExpress.GDU;
    using System.Collections.Generic;
    using System.Security.Principal;
    using AmericanExpress.GDU.Utilities.Diagnostics;
    #endregion
    public partial class ManageTimeDuration : System.Web.UI.Page
    {
        private GDUModel gduModel;
        #region "Events"
        /// <summary>
        /// Page Load event handler
        /// </summary>
        /// <param name="sender">The parameter is not used.</param>
        /// <param name="e">The parameter is not used.</param>
        protected void Page_Load(object sender, EventArgs e)
        {

            if (!IsPostBack)
            {
                BindPreviousTime();
                btnSave.Text = "MODIFY";

            }


        }
        /// <summary>
        /// Save button click event handler
        /// </summary>
        /// <param name="sender">The parameter is not used.</param>
        /// <param name="e">The parameter is not used.</param>
        protected void Save_Click(object sender, EventArgs e)
        {
            int EntryTime;
            string UserId = string.Empty;
            string Result = string.Empty;
            char TimeFormat;
            if (btnSave.Text == "MODIFY")
            {
                txtTime.Enabled = true;
                ddlTimeFormat.Enabled = true;
                btnSave.Text = "UPDATE";
            }
            else
            {
                EntryTime = Convert.ToInt32(txtTime.Text);
                UserId = GetUserName();
                TimeFormat = Convert.ToChar(ddlTimeFormat.SelectedItem.Value);

                if (ddlTimeFormat.SelectedItem.Value.ToString() == "H")
                {
                    if (EntryTime >= Int32.Parse(ConfigurationManager.AppSettings["TimeDurationMinValue"].ToString()) && EntryTime <= Int32.Parse(ConfigurationManager.AppSettings["TimeDurationMaxValue"].ToString()))
                    {
                        Result = this.ManageDurationTime(EntryTime, UserId, TimeFormat);
                        if (Result == "Success")
                        {
                            Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "Resutl", "<script language='javascript'> alert('Record Updated Sucessfully')</script>");
                            txtTime.Text = EntryTime.ToString();
                            txtTime.Enabled = false;
                            ddlTimeFormat.Enabled = false;
                            btnSave.Text = "MODIFY";
                        }
                    }
                    else
                    {
                        Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "Resutl", "<script language='javascript'> alert('Enter Time Duration between 1- 24 Hour')</script>");
                    }
                }
                else if (ddlTimeFormat.SelectedItem.Value.ToString() == "M")
                {
                    if (EntryTime >= Int32.Parse(ConfigurationManager.AppSettings["TimeDurationMinValue"].ToString()) && EntryTime <= (Int32.Parse(ConfigurationManager.AppSettings["TimeDurationMaxValue"].ToString()) * 60))
                    {
                        Result = this.ManageDurationTime(EntryTime, UserId, TimeFormat);
                        if (Result == "Success")
                        {
                            Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "Resutl", "<script language='javascript'> alert('Record Updated Sucessfully')</script>");
                            txtTime.Text = EntryTime.ToString();
                            txtTime.Enabled = false;
                            ddlTimeFormat.Enabled = false;
                            btnSave.Text = "MODIFY";
                        }
                    }
                    else
                    {
                        Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "Resutl", "<script language='javascript'> alert('Enter Time Duration between 1- 1440 Minute')</script>");
                    }
                }


            }
        }
        #endregion


        #region "Methods"

        private string ManageDurationTime(int Time, string UserId, char TimeFormat)
        {
            this.gduModel = new GDUModel();
            return this.gduModel.ManageEntryTime(Time, UserId, TimeFormat);
        }
        private string GetUserName()
        {
            string UserName = string.Empty;
            try
            {
                UserName = (WindowsIdentity.GetCurrent().Name.Substring(WindowsIdentity.GetCurrent().Name.LastIndexOf(@"\"))).Replace(@"\", "");
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return UserName;
        }

        private void BindPreviousTime()
        {
            int PreviousTime = 0;
            Char TimeFormat;
            try
            {
                gduModel = new GDUModel();
                PreviousTime = gduModel.GetTimeDuration(out TimeFormat);
                if (!string.IsNullOrEmpty(PreviousTime.ToString()))
                {
                    txtTime.Text = PreviousTime.ToString();
                    txtTime.Enabled = false;
                }
                if (ddlTimeFormat.Items.FindByValue(TimeFormat.ToString()) != null)
                {
                    this.ddlTimeFormat.SelectedValue = TimeFormat.ToString();
                    ddlTimeFormat.Enabled = false;

                }

            }
            catch (Exception ex)
            {
            }
        }
        #endregion

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("SearchApplication.aspx");
        }

    }
}
