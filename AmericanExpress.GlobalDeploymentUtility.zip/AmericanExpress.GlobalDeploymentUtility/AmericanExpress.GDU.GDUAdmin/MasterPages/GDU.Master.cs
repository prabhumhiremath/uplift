﻿
//-----------------------------------------------------------------------
// <copyright file="GDU.Master.cs" company="NIIT Technologies">
//  Copyright (c) NIIT Technologies. All rights reserved.
// </copyright>
// <summary>
// <Description>The generic functions implemented in master</Description>
// <Author>NIIT Technologies</Author>
// <CreatedOn>11/02/2009</CreatedOn>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// </summary>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.Xml.Linq;
using AmericanExpress.GDU.Model;
using System.Data;

namespace AmericanExpress.GDU.MasterPages
{
    public partial class GDU : System.Web.UI.MasterPage
    {
        public string title = string.Empty;
        private GDUModel gduModel; 

        protected void Page_Load(object sender, EventArgs e)
        {
            title = "Global Deployment Utility"; //+System.Configuration.ConfigurationSettings.AppSettings[AdmConstants.VERSION].ToString();
            this.Page.Title = title;
            if (!Page.IsPostBack)
            {
                GetMenus1();
            }
            //lblMsgPanel.Visible = false;
            lblMsgPanel.Text = "";
        }
        private void GetMenus()
        {
            try
            {

                //Response.Write(this.Request.Url.AbsolutePath.Substring(1,));
                XElement xmlMenu;
                string apppath = this.Request.Url.AbsolutePath;
                if (apppath.Contains("/Reports/"))
                {
                    xmlMenu = XElement.Load(Server.MapPath("~/App_Data/Menu_Report.xml"));
                    //headerAnchor.HRef = "../LocationMode.aspx";
                    imgTransparent.Src = "../Images/transparent.gif";
                }
                else
                {
                     xmlMenu = XElement.Load(Server.MapPath(@"App_Data\Menu.xml"));
                     //headerAnchor.HRef = "../LocationMode.aspx";
                     imgTransparent.Src = "../Images/transparent.gif";
                }
                //XElement xmlMenu = XElement.Load(Server.MapPath("~/App_Data/Menu.xml"));
                StringBuilder strMenu = new StringBuilder();
                strMenu.Append("<ul class='jd_menu' id='cssmenu1'>");
                strMenu.Append("\n<li class='seprator'></li>");
                foreach (XElement element in xmlMenu.Elements())
                {
                    if (element.HasAttributes)
                    {
                        strMenu.Append("\n <li><a ");
                        for (int j = 0; j < element.Attributes().Count(); j++)
                        {
                            if (element.Attributes().ElementAt(j).Name.ToString() != "name")
                            {
                                strMenu.Append(element.Attributes().ElementAt(j).ToString() + " ");
                            }
                        }
                        strMenu.Append(">" + element.Attribute("name").Value.ToString() + "</a></li>");

                        //strMenu.Append("\n <li><a " + element.Attribute("Id").ToString() + " " +
                        //    element.Attribute("Url").ToString() + " " + element.Attribute("Class").ToString() +
                        //    ">" + element.Attribute("Name").Value.ToString() + "</a></li>");
                    }
                    if (element.HasElements)
                    {
                        strMenu.Append("<ul>");
                        foreach (XElement subMenuElement in element.Elements())
                        {
                            strMenu.Append("\n<li><a ");
                            if (subMenuElement.HasAttributes)
                            {
                                for (int i = 0; i < subMenuElement.Attributes().Count(); i++)
                                {
                                    strMenu.Append(subMenuElement.Attributes().ElementAt(i).ToString() + " ");
                                }
                            }
                            strMenu.Append(">" + subMenuElement.Value.ToString() + "</a></li>");
                            //strMenu.Append("\n<li><a " + subMenuElement.Attribute("Style").ToString() + " " +
                            //subMenuElement.Attribute("Url").ToString() + ">" + subMenuElement.Value.ToString() + "</a></li>");
                        }
                        strMenu.Append(" </ul>");
                    }
                    strMenu.Append("\n<li class='seprator'></li>");
                }
                strMenu.Append("</ul>");
                divMenu.InnerHtml = strMenu.ToString();

            }
            catch (Exception ex)
            {
                string str = ex.Message;
            }
        }

        private void GetMenus1()
        {
            //this.gwizModel = new GwizModel();
            string userId;
            string System_CD = "GD";
            try
            {

                gduModel = new GDUModel();

                userId = System.Web.HttpContext.Current.Request.LogonUserIdentity.Name.Substring(System.Web.HttpContext.Current.Request.LogonUserIdentity.Name.LastIndexOf(@"\") + 1);
                DataTable dtUserMenu = gduModel.GetUserMenu(userId, "GetMenu", System_CD);
                string parentMenuName;
                string childMenuName;
                string childMenuURL;

                DataRow[] drsParentMenu = dtUserMenu.Select("FunctionParentId=0", "DispOrderNo");

                StringBuilder strMenu = new StringBuilder();
                imgTransparent.Src = "../Images/transparent.gif";

                strMenu.Append("<ul class='jd_menu' id='cssmenu1'>");
                strMenu.Append("\n<li class='seprator'></li>");



                foreach (DataRow drParentMenu in drsParentMenu)
                {
                    //userMenu = parentMenu[counterParent];
                    //if (userMenu.UserMenuItemDetails.Count > 0 || !string.IsNullOrEmpty(userMenu.ParentURL))
                    //{
                    parentMenuName = drParentMenu["FunctionName"].ToString();

                    if (string.IsNullOrEmpty(drParentMenu["FunctionPageUrlTxt"].ToString()))
                        strMenu.Append("<li><a ID='" + "menu" + parentMenuName.Split(' ')[0] + "' href='#'>" + parentMenuName + "</a>");
                        else
                        strMenu.Append("<li><a href='" + drParentMenu["FunctionPageUrlTxt"].ToString() + "'>" + parentMenuName + "</a>");

                    DataRow[] drsChildMenu = dtUserMenu.Select("FunctionParentId="+Convert.ToInt32(drParentMenu["FunctionId"]));

                    if (drsChildMenu.Length > 0)
                        {
                            strMenu.Append("<ul>");
                            foreach (DataRow drChildMenu in drsChildMenu)
                            {
                                childMenuName = drChildMenu["FunctionName"].ToString();

                                childMenuURL = drChildMenu["FunctionPageUrlTxt"].ToString();

                                if (childMenuURL.ToLower().StartsWith("http"))
                                    strMenu.Append("<li><a href='" + ResolveUrl(childMenuURL).Replace("MasterPages/","") + "' target='new' >" + childMenuName + "</a></li>");
                                else
                                    strMenu.Append("<li><a href='" + ResolveUrl(childMenuURL).Replace("MasterPages/", "") + "'>" + childMenuName + "</a></li>");

                            }
                            strMenu.Append("</ul>");
                        }

                    strMenu.Append("</li>");
                    strMenu.Append("<li class='seprator'></li>");
                    //}
                }

                strMenu.Append("</ul>");

                divMenu.InnerHtml = strMenu.ToString();

              /*  //Response.Write(this.Request.Url.AbsolutePath.Substring(1,));
                XElement xmlMenu;
                string apppath = this.Request.Url.AbsolutePath;
                if (apppath.Contains("/Reports/"))
                {
                    xmlMenu = XElement.Load(Server.MapPath("~/App_Data/Menu_Report.xml"));
                    //headerAnchor.HRef = "../LocationMode.aspx";
                    imgTransparent.Src = "../Images/transparent.gif";
                }
                else
                {
                     xmlMenu = XElement.Load(Server.MapPath(@"App_Data\Menu.xml"));
                     //headerAnchor.HRef = "../LocationMode.aspx";
                     imgTransparent.Src = "../Images/transparent.gif";
                }
                //XElement xmlMenu = XElement.Load(Server.MapPath("~/App_Data/Menu.xml"));
                StringBuilder strMenu = new StringBuilder();
                strMenu.Append("<ul class='jd_menu' id='cssmenu1'>");
                strMenu.Append("\n<li class='seprator'></li>");
                foreach (XElement element in xmlMenu.Elements())
                {
                    if (element.HasAttributes)
                    {
                        strMenu.Append("\n <li><a ");
                        for (int j = 0; j < element.Attributes().Count(); j++)
                        {
                            if (element.Attributes().ElementAt(j).Name.ToString() != "name")
                            {
                                strMenu.Append(element.Attributes().ElementAt(j).ToString() + " ");
                            }
                        }
                        strMenu.Append(">" + element.Attribute("name").Value.ToString() + "</a></li>");

                        //strMenu.Append("\n <li><a " + element.Attribute("Id").ToString() + " " +
                        //    element.Attribute("Url").ToString() + " " + element.Attribute("Class").ToString() +
                        //    ">" + element.Attribute("Name").Value.ToString() + "</a></li>");
                    }
                    if (element.HasElements)
                    {
                        strMenu.Append("<ul>");
                        foreach (XElement subMenuElement in element.Elements())
                        {
                            strMenu.Append("\n<li><a ");
                            if (subMenuElement.HasAttributes)
                            {
                                for (int i = 0; i < subMenuElement.Attributes().Count(); i++)
                                {
                                    strMenu.Append(subMenuElement.Attributes().ElementAt(i).ToString() + " ");
                                }
                            }
                            strMenu.Append(">" + subMenuElement.Value.ToString() + "</a></li>");
                            //strMenu.Append("\n<li><a " + subMenuElement.Attribute("Style").ToString() + " " +
                            //subMenuElement.Attribute("Url").ToString() + ">" + subMenuElement.Value.ToString() + "</a></li>");
                        }
                        strMenu.Append(" </ul>");
                    }
                    strMenu.Append("\n<li class='seprator'></li>");
                }
                strMenu.Append("</ul>");
                divMenu.InnerHtml = strMenu.ToString();*/

            }
            catch (Exception ex)
            {
                string str = ex.Message;
            }
        }
    }

}
