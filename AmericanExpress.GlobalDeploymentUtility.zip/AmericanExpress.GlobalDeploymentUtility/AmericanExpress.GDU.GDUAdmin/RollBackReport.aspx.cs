﻿//-----------------------------------------------------------------------
// <copyright file="RollBackReport.cs" company="NIIT Technologies">
//  Copyright (c) NIIT Technologies. All rights reserved.
// </copyright>
// <summary>
// <Description>GDU admin reports</Description>
// <Author>NIIT Technologies</Author>
// <CreatedOn>11/12/2009</CreatedOn>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// </summary>
//-----------------------------------------------------------------------

using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using AmericanExpress.GDU.Model;
using System.Collections.Generic;
using System.IO;
using AmericanExpress.GDU.Utilities.Diagnostics;
using System.Threading;

namespace AmericanExpress.GDU.Reports
{
    public partial class RollBackReport : System.Web.UI.Page
    {
        GDUModel _gduModal;
        DataTable _dtDataTable;

        const string LABEL = "App_NM";
        public string strUserName = string.Empty;
        public string strVersion = string.Empty;
        public int nonMaxVersion = 0;
        string clientID = string.Empty;
        public int App_ID = 0;

        protected int currentPage, pageSize, startRecord;
        int PageSize = Convert.ToInt32(ConfigurationManager.AppSettings["DefaultPageSize"].ToString());

        /// <summary>
        /// Page load
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                string validate = string.Empty;
                //Initializing DataTable variable 
                _gduModal = new GDUModel();
                _dtDataTable = new DataTable();
                ddlClient.Visible = false;

                if (!IsPostBack)
                {

                    if (Global.IsPageAuthorized(System.IO.Path.GetFileName(Request.Path)) == false)
                        Response.Redirect("NotAuthorized.aspx", false);
                    //Populate_Client();
                    Populate_User();
                    //Populate_Version();
                    PopulateApplication();
                    this.pnlButtonRow.Visible = false;
                    this.pnlReport.Visible = false;
                }
                else
                {
                    grdGWizReportGenerator.DataSource = null;
                    grdGWizReportGenerator.DataBind();
                }
            }
            catch (Exception ex)
            {
                LogManager.LogErrorMessage(ex, Convert.ToInt32(AdmConstants.MethodName.GWiz_ClientDeploymentReport_Page_Load));
                throw ex;
            }
        }

        /// <summary>
        /// populates client drop down 
        /// </summary>
        private void Populate_Client()
        {
            //Dictionary<string, string> objDictonary = new Dictionary<string, string>();
            //objDictonary = _gduModal.PopulateClientInfo(null, 0);
            //this.ddlClient.DataSource = objDictonary;
            //ddlClient.DataValueField = AdmConstants.KEY;
            //ddlClient.DataTextField = AdmConstants.VALUE;
            //ddlClient.DataBind();
            ddlClient.Items.Insert(0, new ListItem(AdmConstants.SELECT_ALL, "0-SELECT ALL"));
        }

        private void PopulateApplication()
        {
            try
            {
                _gduModal = new GDUModel();
                Dictionary<string, string> objDictonary = new Dictionary<string, string>();
                objDictonary = _gduModal.PopulateApplicationInfo();
                this.ddlApplication.DataSource = objDictonary;
                ddlApplication.DataValueField = AdmConstants.KEY;
                ddlApplication.DataTextField = AdmConstants.VALUE;
                ddlApplication.DataBind();

                ddlApplication.Items.Insert(0, new ListItem(AdmConstants.SELECT_ALL, "SELECT ALL"));

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        /// <summary>
        /// populates account drop down 
        /// </summary>
        private void Populate_User()
        {
            Dictionary<string, string> objDictonary = new Dictionary<string, string>();
            objDictonary = _gduModal.PopulateUsers("0", "RollBack", "Y", "GD", 0, 5000, "User_NM", "ASC");
            this.ddlUser.DataSource = objDictonary;
            ddlUser.DataValueField = AdmConstants.KEY;
            ddlUser.DataTextField = AdmConstants.VALUE;
            ddlUser.DataBind();

            ddlUser.Items.Insert(0, new ListItem(AdmConstants.SELECT_ALL, "SELECT ALL"));
        }

        protected void ddlClient_SelectedIndexChanged(object sender, EventArgs e)
        {
            Populate_User();
        }

        //private void Populate_Version()
        //{
        //    Dictionary<string, string> objDictonary = new Dictionary<string, string>();
        //    objDictonary = _gwizModal.PopulateVersion();
        //    this.ddlVersion.DataSource = objDictonary;
        //    ddlVersion.DataValueField = AdmConstants.KEY;
        //    ddlVersion.DataTextField = AdmConstants.VALUE;
        //    ddlVersion.DataBind();

        //    ddlVersion.Items.Insert(0, new ListItem(AdmConstants.SELECT_ALL, "SELECT ALL"));
        //}

        /// <summary>
        /// populates client drop down 
        /// </summary>


        /// <summary>
        /// search click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                //===========================
                ViewState["SortExp"] = LABEL;
                ViewState["SortOrder"] = AdmConstants.GridSortingOrder.ASC;
                //===========================

                CurrentPage = 0;
                BindGrid();
            }
            catch (Exception ex)
            {
                LogManager.LogErrorMessage(ex, Convert.ToInt32(AdmConstants.MethodName.GWiz_ClientDeploymentReport_Search_Click));
                throw ex;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnClear_Click(object sender, EventArgs e)
        {
            ddlClient.SelectedIndex = 0;
            Populate_User();
            ddlUser.SelectedIndex = 0;
            //ddlVersion.Items.Clear();
            //ddlVersion.Items.Add("Select ALL");
            //this.ddlVersion.DataSource = null;
            //this.ddlVersion.DataBind();
            ddlApplication.SelectedIndex = 0;
            chkdisplay.Checked = false;
            grdGWizReportGenerator.DataSource = null;
            grdGWizReportGenerator.EmptyDataText = "";
            grdGWizReportGenerator.DataBind();
            btnExport.Visible = false;

            ddlApplication.SelectedIndex = 0;
            txtDateFrom.Text = string.Empty;
            txtDateTo.Text = string.Empty;
            lblRecordCount.Text = "";
            PagingRow.Style.Add("display", "none");
        }

        /// <summary>
        /// Exports the Report Data to Excel;
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnExport_Click(object sender, EventArgs e)
        {
            DataTable dt;
            try
            {
                dt = new DataTable();
                string fromDate = string.Empty;
                string toDate = string.Empty;
                string RollBack = string.Empty;

                if (ddlClient.SelectedItem.ToString().Equals(AdmConstants.SELECT_ALL, StringComparison.InvariantCultureIgnoreCase))
                    clientID = null;
                else
                    clientID = ddlClient.SelectedItem.Value.Split('-')[0].ToString();

                if (ddlUser.Text.ToString().Equals(AdmConstants.SELECT_ALL, StringComparison.InvariantCultureIgnoreCase))
                    strUserName = null;
                else
                    strUserName = ddlUser.SelectedValue.ToString();

                //if (ddlVersion.Text.ToString().Equals(AdmConstants.SELECT_ALL, StringComparison.InvariantCultureIgnoreCase))
                //    strVersion = null;
                //else
                //    strVersion = ddlVersion.SelectedValue.ToString();
                if (!string.IsNullOrEmpty(txtDateFrom.Text.Trim()))
                {
                    fromDate = txtDateFrom.Text.Trim();
                }

                if (!string.IsNullOrEmpty(txtDateTo.Text.Trim()))
                {
                    toDate = txtDateTo.Text.Trim();
                }
                else if (!string.IsNullOrEmpty(txtDateFrom.Text.Trim()))
                {
                    toDate = System.DateTime.Now.ToShortDateString();
                }

                if (ddlApplication.Text.ToString().Equals(AdmConstants.SELECT_ALL, StringComparison.InvariantCultureIgnoreCase))
                    App_ID = 0;
                else
                    App_ID = Int32.Parse(ddlApplication.SelectedValue.ToString().Substring(0, ddlApplication.SelectedValue.ToString().IndexOf("~")));

                if (chkdisplay.Checked == true)
                {
                    RollBack = "Y";
                }
                else
                {
                    RollBack = "N";
                }

                dt = _gduModal.GetAppUploadedDataTableEXPORT(strUserName, fromDate, toDate, RollBack, App_ID, ViewState["SortExp"].ToString(), ViewState["SortOrder"].ToString());

                Response.Clear();
                Response.ContentType = "application/vnd.ms-excel";
                Response.AddHeader("Content-Disposition", "attachment;filename=ApplicationUploadedReport.xls");
                Response.BufferOutput = true;
                Response.ContentEncoding = System.Text.Encoding.UTF8;
                Response.Charset = "";
                EnableViewState = false;
                StringWriter strWriter = new StringWriter();
                Html32TextWriter htmlWriter = new Html32TextWriter(strWriter);
                dt.Columns["RollBack"].ColumnName = "[RollBack]";
                grdGWizReportGenerator.DataSource = dt.DefaultView;
                grdGWizReportGenerator.DataBind();
                this.ClearControls(grdGWizReportGenerator);
                grdGWizReportGenerator.RenderControl(htmlWriter);
                Response.Write(strWriter.ToString());
                Response.Flush();
                Response.End();
                //HttpContext.Current.ApplicationInstance.CompleteRequest();
                BindGrid();

            }
            catch (ThreadAbortException tex)
            {
            }
            catch (Exception ex)
            {
                LogManager.LogErrorMessage(ex, Convert.ToInt32(AdmConstants.MethodName.GWiz_ClientDeploymentReport_Export_Click));
            }
            finally
            {
                dt = null;
            }
        }

        private void ClearControls(Control control)
        {
            for (int i = control.Controls.Count - 1; i >= 0; i--)
            {
                ClearControls(control.Controls[i]);
            }
            if (!(control is TableCell))
            {
                if (control.GetType().GetProperty("SelectedItem") != null)
                {
                    LiteralControl literal = new LiteralControl();
                    control.Parent.Controls.Add(literal);
                    try
                    {
                        literal.Text = (string)control.GetType().GetProperty("SelectedItem").GetValue(control, null);
                    }
                    catch
                    {
                    }
                    control.Parent.Controls.Remove(control);
                }
                else
                    if (control.GetType().GetProperty("Text") != null)
                    {
                        LiteralControl literal = new LiteralControl();
                        control.Parent.Controls.Add(literal);
                        literal.Text = (string)control.GetType().GetProperty("Text").GetValue(control, null);
                        control.Parent.Controls.Remove(control);
                    }
            }
            return;
        }

        public override void VerifyRenderingInServerForm(Control control) { }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="allowPaging"></param>
        private void BindGrid()
        {
            string fromDate = string.Empty;
            string toDate = string.Empty;
            string RollBack = string.Empty;

            if (ddlClient.SelectedItem.ToString().Equals(AdmConstants.SELECT_ALL, StringComparison.InvariantCultureIgnoreCase))
                clientID = null;
            else
                clientID = ddlClient.SelectedItem.Value.Split('-')[0].ToString();

            if (ddlUser.Text.ToString().Equals(AdmConstants.SELECT_ALL, StringComparison.InvariantCultureIgnoreCase))
                strUserName = null;
            else
                strUserName = ddlUser.SelectedValue.ToString();

            //if (ddlVersion.Text.ToString().Equals(AdmConstants.SELECT_ALL, StringComparison.InvariantCultureIgnoreCase))
            //    strVersion = null;
            //else
            //    strVersion = ddlVersion.SelectedValue.ToString();
            if (!string.IsNullOrEmpty(txtDateFrom.Text.Trim()))
            {
                fromDate = txtDateFrom.Text.Trim();
            }

            if (!string.IsNullOrEmpty(txtDateTo.Text.Trim()))
            {
                toDate = txtDateTo.Text.Trim();
            }
            else if (!string.IsNullOrEmpty(txtDateFrom.Text.Trim()))
            {
                toDate = System.DateTime.Now.ToShortDateString();
            }

            if (ddlApplication.Text.ToString().Equals(AdmConstants.SELECT_ALL, StringComparison.InvariantCultureIgnoreCase))
                App_ID = 0;
            else
                App_ID = Int32.Parse(ddlApplication.SelectedValue.ToString().Substring(0, ddlApplication.SelectedValue.ToString().IndexOf("~")));


            try
            {
                if (chkdisplay.Checked == true)
                {
                    RollBack = "Y";
                }
                else
                {
                    RollBack = "N";
                }

                _dtDataTable = _gduModal.GetAppUploadedDataTable(strUserName, fromDate, toDate, RollBack, App_ID, CurrentPage, PageSize, ViewState["SortExp"].ToString(), ViewState["SortOrder"].ToString());


                if (_dtDataTable.Rows.Count > 0)
                {
                    //lblRecordCount.Text = "Total Records: " + _dtDataTable.Rows.Count.ToString();
                    btnExport.Visible = true;

                    grdGWizReportGenerator.DataSource = _dtDataTable;
                    grdGWizReportGenerator.DataBind();
                    lblRecordCount.Text = "Total Records: " + _dtDataTable.Rows[0]["TotalRecord"].ToString();
                    if (int.Parse(_dtDataTable.Rows[0]["TotalRecord"].ToString()) % PageSize > 0)
                    {
                        ViewState["TotalPages"] = Convert.ToInt32(int.Parse(_dtDataTable.Rows[0]["TotalRecord"].ToString()) / PageSize);
                    }
                    else
                    {
                        ViewState["TotalPages"] = Convert.ToInt32(int.Parse(_dtDataTable.Rows[0]["TotalRecord"].ToString()) / PageSize) - 1;
                    }
                    //ShowTotalNumberOfRecords();
                    ShowPageNumbers();
                    ShowPagingLinks();
                    //PagingRow.Visible = true;
                    PagingRow.Style.Add("display", "block");

                }
                else
                {
                    //lblRecordCount.Text = "Total Records: 0";
                    btnExport.Visible = false;

                    lblRecordCount.Text = "Total Records: 0";
                    grdGWizReportGenerator.DataSource = null;
                    grdGWizReportGenerator.DataBind();
                    CurrentPage = 0;
                    ViewState["CurrentPage"] = null;
                    PagingRow.Style.Add("display", "none");
                }

                DataRow[] dtRow = _dtDataTable.Select("USER_NM <> null");
                //grdGWizReportGenerator.EmptyDataText = "There is no record";
                //BindingGridControl(allowPaging);
            }
            catch (Exception ex)
            {
                Label lbl = (Label)Master.FindControl("lblMsgPanel");
                string errmsg = ex.Message;
                lbl.Text = errmsg;
            }

            //Show the visibility   
            this.pnlReport.Visible = true;
            this.pnlButtonRow.Visible = true;
        }

        /// <summary>
        /// binding repeater control.
        /// </summary>
        private void BindingGridControl(bool allowPaging)
        {
            DataView dvSearch = new DataView();
            dvSearch = _dtDataTable.DefaultView;
            if (this.ViewState["SortExp"] != null && !this.ViewState["SortExp"].Equals(""))
            {
                dvSearch.Sort = this.ViewState["SortExp"].ToString()
                         + " " + this.ViewState["SortOrder"].ToString();
            }

            grdGWizReportGenerator.AllowPaging = allowPaging;
            if (allowPaging)
            {
                grdGWizReportGenerator.PageSize = 20;
            }

            grdGWizReportGenerator.DataSource = dvSearch;
            grdGWizReportGenerator.DataBind();
        }

        /// <summary>
        /// report generator data bound event.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void grdGWizReportGenerator_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            DataRowView drv = null;
            drv = (DataRowView)e.Row.DataItem;
            try
            {

                if (e.Row.RowType == DataControlRowType.Header)
                {
                    if (this.ViewState["SortExp"] == null)
                        this.ViewState["SortExp"] = "";

                    int sortColumnIndex = GetSortColumnIndex(grdGWizReportGenerator, this.ViewState["SortExp"].ToString());
                    AddSortImage(sortColumnIndex, e.Row, this.GridViewSortDirection);
                }
            }
            catch (Exception ex)
            {
                LogManager.LogErrorMessage(ex, Convert.ToInt32(AdmConstants.MethodName.GWiz_ClientDeploymentReport_grid_RowDataBound));
                throw ex;
            }
        }

        /// <summary>
        /// This is PageIndexChanging event
        /// </summary>
        /// <param name="sender">object sender</param>
        /// <param name="e">GridViewPageEventArgs e</param>
        protected void grdGWizReportGenerator_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                grdGWizReportGenerator.PageIndex = e.NewPageIndex;
                BindGrid();
            }
            catch (Exception ex)
            {
                LogManager.LogErrorMessage(ex, Convert.ToInt32(AdmConstants.MethodName.GWiz_ClientDeploymentReport_grid_PageIndexChanging));
                throw ex;
            }
        }



        /// <summary>
        /// This is Sorting event
        /// </summary>
        /// <param name="sender">object sender</param>
        /// <param name="e">GridViewSortEventArgs e</param>
        protected void grdGWizReportGenerator_Sorting(object sender, GridViewSortEventArgs e)
        {
            try
            {
                CurrentPage = 0;
                ViewState["CurrentPage"] = null;
                if (this.GridViewSortDirection == SortDirection.Ascending)
                {
                    this.GridViewSortDirection = SortDirection.Descending;
                    ViewState["SortOrder"] = AdmConstants.GridSortingOrder.DESC;
                }
                else
                {
                    this.GridViewSortDirection = SortDirection.Ascending;
                    ViewState["SortOrder"] = AdmConstants.GridSortingOrder.ASC;
                }
                grdGWizReportGenerator.PageIndex = 0;
                ViewState["SortExp"] = e.SortExpression;
                BindGrid();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }



        /// <summary>
        /// GridViewSortDirection
        /// </summary>
        public SortDirection GridViewSortDirection
        {
            get
            {
                if (ViewState["sortDirection"] == null)
                    ViewState["sortDirection"] = SortDirection.Ascending;
                return (SortDirection)ViewState["sortDirection"];
            }
            set { ViewState["sortDirection"] = value; }
        }

        /// <summary>
        /// This is used to retrieve sorted column index no.
        /// </summary>
        /// <param name="gridObject">This is the grid view object.</param>
        /// <param name="sortExpression">This is the sort expression.</param>
        /// <returns>int</returns>
        public static int GetSortColumnIndex(GridView gridObject, string sortExpression)
        {
            string sortExpressionString = null;
            foreach (DataControlField field in gridObject.Columns)
            {
                if (sortExpression != "")
                    sortExpressionString = sortExpression.ToString();

                if (field.SortExpression == sortExpressionString)
                {
                    return gridObject.Columns.IndexOf(field);
                }
            }
            return -1;
        }

        /// <summary>
        /// This will set the Up/Down image for sorted column.
        /// </summary>
        /// <param name="columnIndex">This is the column index.</param>
        /// <param name="headerRow">This is the grid view header row.</param>
        /// <param name="strgrdSortDirection">This is the sort direction.</param>
        public static void AddSortImage(int columnIndex, GridViewRow headerRow, SortDirection strgrdSortDirection)
        {
            if (columnIndex == -1) return;
            if (strgrdSortDirection == SortDirection.Ascending)
                headerRow.Cells[columnIndex].Attributes.Add("class", "sortUp");
            else
                headerRow.Cells[columnIndex].Attributes.Add("class", "sortDown");
        }

        public int CurrentPage
        {
            get
            {
                // look for current page in ViewState 
                object current = this.ViewState["CurrentPage"];
                if (current == null)
                    return 0; // default page index of 0 
                else
                    return (int)current;
            }
            set
            {
                this.ViewState["CurrentPage"] = value;
            }
        }
        protected void LinkButtonFirst_Click(object sender, EventArgs e)
        {
            // Set viewstate variable to the next page 
            CurrentPage = 0;
            BindGrid();
        }
        protected void LinkButtonPrevious_Click(object sender, EventArgs e)
        {
            // Set viewstate variable to the previous page 
            CurrentPage -= 1;
            BindGrid();
        }
        protected void LinkButtonNext_Click(object sender, EventArgs e)
        {
            // Set viewstate variable to the next page 
            CurrentPage += 1;
            BindGrid();
        }
        protected void LinkButtonLast_Click(object sender, EventArgs e)
        {
            // Set viewstate variable to the last page 
            CurrentPage = int.Parse(ViewState["TotalPages"].ToString());
            BindGrid();
        }
        //To show total page numbers 
        //private void ShowTotalNumberOfRecords()
        //{
        //    int i, j;
        //    if (CurrentPage == 0)
        //        i = 1;
        //    else
        //        i = (CurrentPage * PageSize) + 1;
        //    LabelPageFirstRecord.Text = i.ToString();
        //    if (CurrentPage == int.Parse(ViewState["TotalPages"].ToString()))
        //        LabelPageLastRecord.Text = LabelTotalRecords.Text;
        //    else
        //    {
        //        j = ((CurrentPage + 1) * PageSize);
        //        LabelPageLastRecord.Text = j.ToString();
        //    }
        //}
        //To show current page number 
        private void ShowPageNumbers()
        {
            int startPagenumber, endPageNumber;
            if (CurrentPage < 3)
            {
                startPagenumber = 1;
                endPageNumber = 5;
            }
            else if (CurrentPage > (int.Parse(ViewState["TotalPages"].ToString()) - 2))
            {
                startPagenumber = int.Parse(ViewState["TotalPages"].ToString()) - 3;
                endPageNumber = int.Parse(ViewState["TotalPages"].ToString()) + 1;
                if (startPagenumber == 0)
                {
                    startPagenumber = 1;
                    endPageNumber += 1;
                }
            }
            else
            {
                startPagenumber = CurrentPage - 1;
                endPageNumber = CurrentPage + 3;
            }
            int linkButtonNumber = 1;
            LinkButton lnkbtn;
            for (int k = startPagenumber; k <= endPageNumber; k++)
            {
                lnkbtn = (LinkButton)(tdPageNumbers.FindControl("LinkButton" + linkButtonNumber.ToString()));
                lnkbtn.Text = k.ToString();
                linkButtonNumber++;
            }
            for (int idLoop = 1; idLoop <= 5; idLoop++)
            {
                lnkbtn = (LinkButton)(tdPageNumbers.FindControl("LinkButton" + idLoop.ToString()));
                if (int.Parse(lnkbtn.Text) == (CurrentPage + 1))
                {
                    lnkbtn.Enabled = false;
                    lnkbtn.CssClass = "PagerLinkSelected";
                }
                else if (int.Parse(lnkbtn.Text) > (int.Parse(ViewState["TotalPages"].ToString()) + 1))
                {
                    lnkbtn.Visible = false;
                }
                else
                {
                    lnkbtn.Enabled = true;
                    lnkbtn.CssClass = "PagerLinkStyle";
                    lnkbtn.BackColor = System.Drawing.Color.Empty;
                    lnkbtn.Visible = true;
                }
            }
        }
        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            LinkButton lnkbtn = (LinkButton)sender;
            CurrentPage = (int.Parse(lnkbtn.Text) - 1);
            BindGrid();
        }
        private void ShowPagingLinks()
        {
            if (CurrentPage == int.Parse(ViewState["TotalPages"].ToString()))
            {
                LinkButtonNext.Enabled = false;
                LinkButtonLast.Enabled = false;
            }
            else
            {
                LinkButtonNext.Enabled = true;
                LinkButtonLast.Enabled = true;
            }
            if (CurrentPage == 0)
            {
                LinkButtonPrevious.Enabled = false;
                LinkButtonFirst.Enabled = false;
            }
            else
            {
                LinkButtonPrevious.Enabled = true;
                LinkButtonFirst.Enabled = true;
            }
        }

    }

}


