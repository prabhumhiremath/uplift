﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.IO;
using Shell32;

namespace AmericanExpress.GDU.GDUAdmin
{
    public partial class Upload : System.Web.UI.Page
    {
        string _targetLocationTemp = string.Empty;
        string _targetLocation = string.Empty;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                GetAllFileFolder();
            }
        }

        private void GetAllFileFolder()
        {
            lblServerPath.Text = Server.MapPath("~").ToString();
            DirectoryInfo rootDir = new DirectoryInfo(lblServerPath.Text);
            TreeNode RootNode = RecurseNodes(rootDir);
            Treeview1.Nodes.Add(RootNode);
            Treeview1.CollapseAll();
        }

        private TreeNode RecurseNodes(DirectoryInfo thisDir)
        {
            TreeNode thisDirNode = new TreeNode(thisDir.Name, null, "Images/img11.gif");
            DirectoryInfo[] subDirs = thisDir.GetDirectories();
            foreach (DirectoryInfo subDir in subDirs)
            {
                thisDirNode.ChildNodes.Add(RecurseNodes(subDir));
            }

            FileInfo[] files = thisDir.GetFiles();
            foreach (FileInfo file in files)
            {
                TreeNode thisFileNode = new TreeNode(file.Name + " ( " + file.LastWriteTime + " ) ", null, "Images/fileimage3.gif");
                thisDirNode.ChildNodes.Add(thisFileNode);
            }
            return thisDirNode;
        }

        protected void btnUpload_Click(object sender, EventArgs e)
        {
            lblServerPath.Text = lblServerPath.Text + txtPath.Text;

            _targetLocation = lblServerPath.Text;
            _targetLocationTemp = lblServerPath.Text + "\\Temp";

            if (rd1.Checked)
            {
                this.ValidateFolderPaths(_targetLocation, _targetLocationTemp);
                HttpFileCollection uploadedFiles = Request.Files;
                for (int i = 0; i < uploadedFiles.Count; i++)
                {
                    HttpPostedFile userPostedFile = uploadedFiles[i];
                    try
                    {
                        if (userPostedFile.ContentLength > 0)
                        {
                            string fileName = System.IO.Path.GetFileName(userPostedFile.FileName);
                            string filepath = string.Empty;
                            if (fileName.Contains(".zip"))
                            {
                                filepath = _targetLocationTemp;
                            }
                            else
                            {
                                filepath = _targetLocation;
                            }
                            filepath = filepath + "\\" + fileName;
                            userPostedFile.SaveAs(filepath);
                            lblResponse.Text += "<u>File #" + (i + 1) + "</u><br>";
                            lblResponse.Text += "File Content Type: " + userPostedFile.ContentType + "<br>";
                            lblResponse.Text += "File Size: " + userPostedFile.ContentLength + "kb<br>";
                            lblResponse.Text += "File Name: " + userPostedFile.FileName + "<br>";
                            if (fileName.Contains(".zip"))
                            {
                                lblResponse.Text += "File Name sent for unzip <br>";
                                try
                                {
                                    this.ZipUtility(_targetLocation, filepath);
                                }
                                catch (Exception ex)
                                {
                                    lblResponse.Text += "Not able to complate the process<br>";
                                }
                            }
                            else
                            {
                                lblResponse.Text += "Location where saved: " + filepath + "<p>";
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        lblResponse.Text += "Error: <br>" + ex.Message;

                    }
                }
            }
            else
            {
                try
                {
                    if (fileInput.PostedFile != null)
                    {
                        fileInput.PostedFile.SaveAs(lblServerPath.Text + "/" + fileInput.PostedFile.FileName.ToString().Substring(fileInput.PostedFile.FileName.ToString().LastIndexOf("\\") + 1));
                    }
                }
                catch (Exception ex)
                {
                }
            }

            GetAllFileFolder();
        }

        private void ValidateFolderPaths(string _targetLocation, string _targetLocationTemp)
        {
            // Check if Parent folder exists.
            if (!Directory.Exists(_targetLocation))
            {
                Directory.CreateDirectory(_targetLocation);
            }
            // Check if temp location exists.
            if (!Directory.Exists(_targetLocationTemp))
            {
                Directory.CreateDirectory(_targetLocationTemp);
            }
        }

        private void ZipUtility(string outputDirectory, string inputFileName)
        {
            lblResponse.Text += "unziping folder <br>";
            Shell shell = new ShellClass();
            string folderName = System.IO.Path.GetFileNameWithoutExtension(inputFileName);
            if (Directory.Exists(outputDirectory))
            {
                DirectoryInfo dirInfo = new DirectoryInfo(outputDirectory);
                FileInfo[] arrFiles = dirInfo.GetFiles();
                foreach (FileInfo file in arrFiles)
                {
                    file.Delete();
                }
            }
            lblResponse.Text += "Copying Folder at " + outputDirectory + "<br>";
            Folder sourceFolder = shell.NameSpace(inputFileName);
            Folder destinationFolder2 = shell.NameSpace(outputDirectory);
            Shell32.FolderItems items = sourceFolder.Items();
            destinationFolder2.CopyHere(items, 16);
            lblResponse.Text += "Unzip complete <br>";
        }
    }
}
