﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;
using System.IO;
using System.Xml.Xsl;
using AmericanExpress.GWiz.Utility;
using AmericanExpress.GWiz.ModelClient;
namespace AmericanExpress.GWiz.GWizClientWeb
{
    public partial class _Default : System.Web.UI.Page
    {
        GWizModelClient gm;
        #region public properties
        public string GlobalAccount
        {
            get;
            set;
        }
        private string IsFeedback
        {
            get;
            set;
        }
        private string IsConguration
        {
            get;
            set;
        }
        private string LangCD
        {
            get;
            set;
        }
        private string CarrierCode
        {
            get;
            set;
        }
        private bool IsClicked
        {
            get;
            set;
        }
        private bool IsModel
        {
            get;
            set;
        }
        private bool IsRefil
        {
            get;
            set;
        }
        private bool IsAutomatedSearch
        {
            get;
            set;
        }
        public string GeneralDescription
        {
            get;
            set;
        }
        #endregion
        private bool IsFirstHit;
        private bool IsFirstWatch = true;
        private bool IsLoaded;
        private bool IsClosed;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                alertDiv.Attributes.Add("style","display:none");
                PopulateAccount();
                PopulateCountry();
                PopulateOtherInfo();
                
            }
        }
        //private static string GetXmlString(string strFile)
        //{
        //    // Load the xml file into XmlDocument object.
        //    XmlDocument xmlDoc = new XmlDocument();

        //    try
        //    {
        //        xmlDoc.Load(strFile);
        //    }
        //    catch (XmlException e)
        //    {
        //        Console.WriteLine(e.Message);
        //    }
        //    // Now create StringWriter object to get data from xml document.
        //    StringWriter sw = new StringWriter();
        //    XmlTextWriter xw = new XmlTextWriter(sw);
        //    xmlDoc.WriteTo(xw);
        //    return sw.ToString();
        //}

       
        private void PopulateAccount()
        {
            try
            {
                gm = new GWizModelClient();
                Dictionary<string, string> objDictonary = new Dictionary<string, string>();
                objDictonary = gm.PopulateAccount(string.Empty);
                PopulateCombo(objDictonary, ddlAccount);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        private void PopulateCityFrom()
        {
            gm = new GWizModelClient();
            Dictionary<string, string> objDictonary = new Dictionary<string, string>();
            try
            {
                //string CountryFrom = cmbContryFrom.SelectedValue.ToString();
                //KeyValuePair<string, string> cmbfrmCountry = (KeyValuePair<string, string>)(ddlfrmCity.SelectedValue!= null ? ddlfrmCity.SelectedValue: "Country");
                string CountryFrom = ddlFromCountry.SelectedValue;
                objDictonary = gm.PopulateCity(CountryFrom);
                PopulateCombo(objDictonary, ddlfrmCity);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void PopulateCityTo()
        {
            gm = new GWizModelClient();
            Dictionary<string, string> objDictonary = new Dictionary<string, string>();
            //string CountryTo = cmbContryTo.SelectedValue.ToString();
            try
            {
                //KeyValuePair<string, string> cmbtoCountry = (KeyValuePair<string, string>)(cmbContryTo.SelectedItem != null ? cmbContryTo.SelectedItem : "Country");
                string CountryTo = ddlToCountry.SelectedValue;
                objDictonary = gm.PopulateCity(CountryTo);
                PopulateCombo(objDictonary, ddlToCity);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void PopulateCountry()
        {
            gm = new GWizModelClient();
            Dictionary<string, string> objDictonary = new Dictionary<string, string>();
            try
            {
                objDictonary = gm.PopulateCountry();
                PopulateCombo(objDictonary, ddlFromCountry);
                PopulateCombo(objDictonary, ddlToCountry);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        private void PopulateOtherInfo()
        {
            gm = new GWizModelClient();
            Dictionary<string, string> objDictonary = new Dictionary<string, string>();
            try
            {
                objDictonary = gm.PopulateOtherInfo(string.Empty);
                PopulateCombo(objDictonary, ddlOtherInfo);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        private void PopulateCombo(Dictionary<string, string> DataDict, DropDownList cmbBox)
        {
            cmbBox.DataSource = DataDict;
            cmbBox.DataTextField = "Value";
            cmbBox.DataValueField = "Key";
            cmbBox.DataBind();
            cmbBox.SelectedValue = "0";

        }

        protected void ddlFromCountry_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                PopulateCityFrom();
               

            }
            catch (Exception ex)
            {
            }

        }

        protected void ddlToCountry_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                PopulateCityTo();
                

            }
            catch (Exception ex)
            {
            }
        }
        private string GetXMLString()
        {
            gm = new GWizModelClient();
            string Resultxml = string.Empty;
            List<string> ResultString = new List<string>();
            ResultString = gm.ReturnSearchXMLClientWeb(SearchCriteria());
            Resultxml = ResultString[0].ToString();
            GeneralDescription = ResultString[1].ToString();
            return Resultxml;
        }
        private void  GetOtherInfoString()
        {
            gm = new GWizModelClient();
            string cmbOtherinfoItem = ddlOtherInfo.SelectedValue;
            List<string> ResultString = new List<string>();
            string inputDate = DateTime.Now.ToShortDateString();
            ResultString = gm.ReturnOtherInfoWebXML(cmbOtherinfoItem, IsFeedback, ddlOtherInfo.SelectedItem.ToString(), LangCD, IsConguration,inputDate);
            string xml = ResultString[0];
            GeneralDescription = ResultString[1];
            RenderDiv(xml);
        }
        private List<string> SearchCriteria()
        {
            string AccCode = string.Empty;
            string CountryFrm = string.Empty;
            string CountryTo = string.Empty;
            string CityFrm = string.Empty;
            string CityTo = string.Empty;
            KeyValuePair<string, string> cmbAcc = new KeyValuePair<string, string>();
            KeyValuePair<string, string> cmbfrmCountry = new KeyValuePair<string, string>();
            KeyValuePair<string, string> cmbtoCountry = new KeyValuePair<string, string>();
            KeyValuePair<string, string> cmbfrmCity = new KeyValuePair<string, string>();
            KeyValuePair<string, string> cmbtoCity = new KeyValuePair<string, string>();

            //string LanguageCD = ConfigurationSettings.AppSettings["LanguageCode"].ToString();
            if (LangCD == string.Empty)
            {
                LangCD = "ENG";
            }
            string LanguageRestc = "";
            if (ddlAccount.SelectedValue != null)
            {




                //string IsFeedback = ConfigurationSettings.AppSettings["IsFeedback"].ToString();
            }
            List<string> Criteria = new List<string>();
            if (ddlAccount.SelectedIndex != -1)
            {
                AccCode = ddlAccount.SelectedValue;
            }
            if (ddlFromCountry.SelectedIndex != -1)
            {
                CountryFrm = ddlFromCountry.SelectedValue;
            }
            if (ddlToCountry.SelectedIndex != -1)
            {
                CountryTo = ddlToCountry.SelectedValue;
            }
            if (ddlfrmCity.SelectedIndex != -1)
            {
                CityFrm = ddlfrmCity.SelectedValue;
            }
            if (ddlToCity.SelectedIndex != -1)
            {
                CityTo = ddlToCity.SelectedValue;
            }
            Criteria.Add(AccCode);
            Criteria.Add(CountryFrm);
            Criteria.Add(CountryTo);
            Criteria.Add(CityFrm);
            Criteria.Add(CityTo);
            Criteria.Add("");
            Criteria.Add("");
            if (ddlAccount.SelectedIndex>0)
            {
                Criteria.Add(ddlAccount.SelectedItem.ToString());
            }
            else
            {
                Criteria.Add(string.Empty);
            }
            if (ddlFromCountry.SelectedIndex> 0)
            {
                Criteria.Add(ddlFromCountry.SelectedItem.ToString());
            }
            else
            {
                Criteria.Add(string.Empty);
            }
            if (ddlToCountry.SelectedIndex>0)
            {
                Criteria.Add(ddlToCountry.SelectedItem.ToString());
            }
            else
            {
                Criteria.Add(string.Empty);
            }
            if (ddlfrmCity.SelectedIndex>0)
            {
                Criteria.Add(ddlfrmCity.SelectedItem.ToString());
            }
            else
            {
                Criteria.Add(string.Empty);
            }
            if (ddlToCity.SelectedIndex>0)
            {
                Criteria.Add(ddlToCity.SelectedItem.ToString());
            }
            else
            {
                Criteria.Add(string.Empty);
            }
            Criteria.Add(string.Empty);
            bool IsAdimn = false;
            Criteria.Add(AmericanExpress.GWiz.ModelClient.Constants.CONSTZERO);
            Criteria.Add(IsAdimn.ToString());
            //Criteria.Add(string.Empty);
            if (!string.IsNullOrEmpty(CarrierCode))
            {
                Criteria.Add(CarrierCode);
            }
            else
            {
                Criteria.Add(string.Empty);
            }
            if (!string.IsNullOrEmpty(LangCD))
            {
                Criteria.Add(LangCD);
            }
            else
            {
                Criteria.Add(string.Empty);
            }
            if (!string.IsNullOrEmpty(LanguageRestc))
            {
                Criteria.Add(LanguageRestc);
            }
            else
            {
                Criteria.Add(string.Empty);
            }
            if (!string.IsNullOrEmpty(IsConguration))
            {
                Criteria.Add(IsConguration);
            }
            else
            {
                Criteria.Add(string.Empty);
            }
            Criteria.Add(DateTime.Now.ToShortDateString());
            CarrierCode = string.Empty;
            return Criteria;
        }

        protected void ddlAccount_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                string xml = GetXMLString();
                RenderDiv(xml); 
            }
            catch (Exception ex)
            { 
            
            }
        }

        private void RenderDiv(string xml)
        {

            try
            {
                XsltArgumentList args = new XsltArgumentList();
                args.AddExtensionObject("gwiz:XslUtils", new XslExtensionsUtil());

                XslCompiledTransform xsl = new XslCompiledTransform(true);
                XsltSettings xsltSettings = new XsltSettings(true, true);

                xsl.Load(@AppDomain.CurrentDomain.BaseDirectory + "xsl\\G-Wiz.xslt", xsltSettings, new XmlUrlResolver());

                XmlReader myXmlReader = new XmlTextReader(new StringReader(xml));

                System.IO.MemoryStream mStream = new MemoryStream();
                xsl.Transform(myXmlReader, args, mStream);
                mStream.Position = 0;
                StreamReader strStream = new StreamReader(mStream);
                string FormattedXml = strStream.ReadToEnd();
                TestRender.InnerHtml = FormattedXml.Replace("&#xA;", "\\n");
                if (GeneralDescription != string.Empty)
                {
                    alertDiv.Attributes.Add("style", "display:block");
                    emGeneralSegment.InnerHtml = GeneralDescription;
                }
                else
                {
                    alertDiv.Attributes.Add("style", "display:none");
                }
            }
            catch (Exception ex)
            { 
            
            }
        
        }

       

       
      
        protected void btnSearch_Click(object sender, EventArgs e)
        {
            if (ddlOtherInfo.SelectedIndex > 0)
            {
                GetOtherInfoString();
                ddlAccount.SelectedIndex = 0;
                ddlfrmCity.SelectedIndex = 0;
                ddlFromCountry.SelectedIndex = 0;
                ddlToCountry.SelectedIndex = 0;
                ddlToCity.SelectedIndex = 0;
            }
            else
            {
                string xml = GetXMLString();
                RenderDiv(xml);
            }

        }

        protected void btnCLear_Click(object sender, ImageClickEventArgs e)
        {
            ddlOtherInfo.SelectedIndex = 0;
            RenderDiv("<G-Wiz></G-Wiz>");
            alertDiv.Attributes.Add("style", "display:none");
        }

       

       

       
    }
}

