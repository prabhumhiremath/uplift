﻿//-----------------------------------------------------------------------
// <copyright file="XslExtensionsUtil.cs" company="NIIT Technologies">
//  Copyright (c) NIIT Technologies. All rights reserved.
// </copyright>
// <summary>
// <Description>This class used for xslt </Description>
// <Author>NIIT Technologies</Author>
// <CreatedOn>07/15/2009</CreatedOn>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// </summary>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AmericanExpress.GWiz.Utility
{
    public class XslExtensionsUtil
    {
        /// <summary>
        /// For Getting the Image directory for Image
        /// </summary>
        /// <returns></returns>
        public string GetImageDirectory()
        {
            return string.Format(@"{0}/images", Environment.CurrentDirectory.Replace("\\", "/"));
        }

        /// <summary>
        /// To getting the stylesheet directory
        /// </summary>
        /// <returns></returns>
        public string GetStyleDirectory()
        {
            return string.Format(@"{0}/css", Environment.CurrentDirectory.Replace("\\", "/"));
        }
        
        /// <summary>
        /// For gettig the script directory
        /// </summary>
        /// <returns></returns>
        public string GetScriptDirectory()
        {
            return string.Format(@"{0}/script", Environment.CurrentDirectory.Replace("\\", "/"));
        }
    }
}
