﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace AmericanExpress.GDU.Service.DataContracts
{
    [DataContract]
   public class ACWCoralReportDetails
    {
        [DataMember]
        public string AdsId
        {
            get;
            set;
        }

        [DataMember]
        public string Server
        {
            get;
            set;
        }

        [DataMember]
        public string StartDt
        {
            get;
            set;
        }

        [DataMember]
        public string EndDt
        {
            get;
            set;
        }
        [DataMember]
        public string TIMEZONE
        {
            get;
            set;
        }

        [DataMember]
        public string ACWDuration
        {
            get;
            set;
        }
    }
}
