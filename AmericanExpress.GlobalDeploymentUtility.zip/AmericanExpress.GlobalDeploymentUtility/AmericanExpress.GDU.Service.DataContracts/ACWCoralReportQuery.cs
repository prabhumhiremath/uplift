﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace AmericanExpress.GDU.Service.DataContracts
{
    [DataContract]
    public  class ACWCoralReportQuery
    {
        [DataMember]
        public string AppName
        {
            get;
            set;
        }

        [DataMember]
        public string FromDate
        {
            get;
            set;
        }

        [DataMember]
        public string ToDate
        {
            get;
            set;
        }

        [DataMember]
        public string OfficeId
        {
            get;
            set;
        }

        [DataMember]
        public string UserName
        {
            get;
            set;
        }

        [DataMember]
        public int GroupId
        {
            get;
            set;
        }
        
    }
}
