﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace AmericanExpress.GDU.Service.DataContracts
{
    [DataContract]
    public class AppFocusOfficeDetails
    {
        /// <summary>
        /// 
        /// </summary>
        [DataMember]
        public int ID
        {
            get;
            set;
        }
        [DataMember]
        public string Office_ID
        {
            get;
            set;
        }
        [DataMember]
        public string Office_Desc
        {
            get;
            set;
        }

        [DataMember]
        public bool ISACTIVE
        {
            get;
            set;
        }

        [DataMember]
        public string ISREPORT
        {
            get;
            set;
        }

        [DataMember]
        public int TotalRecords
        {
            get;
            set;
        }
    }
}
