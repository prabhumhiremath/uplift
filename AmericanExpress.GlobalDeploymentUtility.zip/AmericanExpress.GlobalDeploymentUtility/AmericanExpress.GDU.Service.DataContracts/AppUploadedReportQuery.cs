﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace AmericanExpress.GDU.Service.DataContracts
{
    [DataContract]
    public class AppUploadedReportQuery
    {
        [DataMember]
        public string UserId
        {
            get;
            set;
        }

        [DataMember]
        public string From_DT
        {
            get;
            set;
        }

        [DataMember]
        public string To_Date
        {
            get;
            set;
        }

        [DataMember]
        public string RollBack
        {
            get;
            set;
        }

        [DataMember]
        public string User_Name
        {
            get;
            set;
        }

        [DataMember]
        public int App_ID
        {
            get;
            set;
        }

        [DataMember]
        public string APP_TYPE
        {
            get;
            set;
        }

        [DataMember]
        public int CurrentPage
        {
            get;
            set;
        }
        [DataMember]
        public int PageSize
        {
            get;
            set;
        }
        [DataMember]
        public string SortExpression
        {
            get;
            set;
        }
        [DataMember]
        public string SortOrder
        {
            get;
            set;
        }
    }
}
