﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;
namespace AmericanExpress.GDU.Service.DataContracts
{
    [DataContract]
   public class ClientReleaseQuery
    {
        /// <summary>
        /// 
        /// </summary>
        [DataMember]
        public Int64 RELEASE_ID
        {
            get;
            set;
        }
        /// <summary>
        /// 
        /// </summary>
        [DataMember]
        public string RELEASE_VERSION
        {
            get;
            set;
        }
        /// <summary>
        /// 
        /// </summary>
        [DataMember]
        public string RELEASE_DT
        {
            get;
            set;
        }
        /// <summary>
        /// 
        /// </summary>
        [DataMember]
        public string CREATED_USER_ID
        {
            get;
            set;
        }
        /// <summary>
        /// 
        /// </summary>
        [DataMember]
        public DateTime CREATED_DT
        {
            get;
            set;
        }
        /// <summary>
        /// 
        /// </summary>
        [DataMember]
        public string MODIFIED_USER_ID
        {
            get;
            set;
        }
        /// <summary>
        /// 
        /// </summary>
        [DataMember]
        public DateTime MODIFIED_DT
        {
            get;
            set;
        }

        [DataMember]
        public int App_ID
        {
            get;
            set;
        }

        [DataMember]
        public string System_CD
        {
            get;
            set;
        }

       

        [DataMember]
        public bool IsConnected
        {
            get;
            set;
        }

        [DataMember]
        public string IsRollBack
        {
            get;
            set;
        }

        [DataMember]
        public string IP
        {
            get;
            set;
        }

        [DataMember]
        public string APP_TYPE
        {
            get;
            set;
        }

        [DataMember]
        public string Computer_NM
        {
            get;
            set;
        }
    }
}
