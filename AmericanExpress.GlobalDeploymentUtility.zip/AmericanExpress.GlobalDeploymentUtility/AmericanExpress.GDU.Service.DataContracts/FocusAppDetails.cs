﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace AmericanExpress.GDU.Service.DataContracts
{
    [DataContract]
    public class FocusAppDetails
    {
        /// <summary>
        /// 
        /// </summary>
        [DataMember]
        public string App_Id
        {
            get;
            set;
        } 

        [DataMember]
        public string APP_DS
        {
            get;
            set;
        }

        [DataMember]
        public Int32 ID
        {
            get;
            set;
        }

        [DataMember]
        public int TotalRecords
        {
            get;
            set;
        }


    }
}
