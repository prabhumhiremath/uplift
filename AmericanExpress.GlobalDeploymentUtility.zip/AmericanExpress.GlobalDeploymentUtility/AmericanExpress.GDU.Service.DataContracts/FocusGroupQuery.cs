﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace AmericanExpress.GDU.Service.DataContracts
{
    [DataContract]
  public  class FocusGroupQuery
    {
        /// <summary>
        /// 
        /// </summary>
       [DataMember]
        public int ID
        {
            get;
            set;
        }
        [DataMember]
        public string GROUP_NM
        {
            get;
            set;
        }
        [DataMember]
        public string USER_ID
        {
            get;
            set;
        }
        [DataMember]
        public string MODE
        {
            get;
            set;
        }
        [DataMember]
        public bool ISACTIVE
        {
            get;
            set;
        }

        [DataMember]
        public int CurrentPage
        {
            get;
            set;
        }
        [DataMember]
        public int PageSize
        {
            get;
            set;
        }
        [DataMember]
        public string SortExpression
        {
            get;
            set;
        }
        [DataMember]
        public string SortOrder
        {
            get;
            set;
        }
    
    }
       [DataContract]
  public  class AppfOfficeAdsQuery
    {
        /// <summary>
        /// 
        /// </summary>
        [DataMember]
        public string ADS_ID
        {
            get;
            set;
        }
        [DataMember]
        public string OFFICE_ID
        {
            get;
            set;
        }
       [DataMember]
        public int Type
        {
            get;
            set;
        }
       [DataMember]
       public int GROUP_ID
       {
           get;
           set;
       }
       [DataMember]
       public string CreatedUserID
       {
           get;
           set;
       }
      
      
    
    }
}
