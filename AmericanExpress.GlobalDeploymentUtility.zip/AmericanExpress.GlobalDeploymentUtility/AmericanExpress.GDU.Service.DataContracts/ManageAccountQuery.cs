﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;
namespace AmericanExpress.GDU.Service.DataContracts
{
    [DataContract]
   public class ManageAccountQuery
    {
        [DataMember]
        public String AccountType
        {
            get;
            set;
        }
        [DataMember]
        /// <summary>
        /// 
        /// </summary>
        public string AccountCode
        {
            get;
            set;
        }
        [DataMember]
        /// <summary>
        /// 
        /// </summary>
        public string AccountName
        {
            get;
            set;
        }

        [DataMember]
        /// <summary>
        /// 
        /// </summary>
        public int ClientID
        {
            get;
            set;
        }
        [DataMember]
        /// <summary>
        /// 
        /// </summary>
        public bool IsVirtual
        {
            get;
            set;
        }
        [DataMember]
        /// <summary>
        /// 
        /// </summary>
        public bool IsGlobal
        {
            get;
            set;
        }
        [DataMember]
        /// <summary>
        /// 
        /// </summary>
        public string Mode
        {
            get;
            set;
        }
        [DataMember]
        /// <summary>
        /// 
        /// </summary>
        public string CreatedUserID
        {
            get;
            set;
        }
        [DataMember]
        /// <summary>
        /// 
        /// </summary>
        public string ModifiedUserID
        {
            get;
            set;
        }
        [DataMember]
        /// <summary>
        /// 
        /// </summary>
        public string MacID
        {
            get;
            set;
        }
        [DataMember]

        /// <summary>
        /// 
        /// </summary>
        public DateTime CreatedUserDate
        {
            get;
            set;
        }
        [DataMember]
        /// <summary>
        /// 
        /// </summary>
        public DateTime ModifiedUserDate
        {
            get;
            set;
        }
        [DataMember]
        ///<summary>
        /// 
        /// </summary>
        public String IPAddress
        {
            get;
            set;
        }
        [DataMember]
        ///<summary>
        /// 
        /// </summary>
        public String ComputerName
        {
            get;
            set;
        }
        [DataMember]
        /// <summary>
        /// 
        /// </summary>
        public bool IsDeactive
        {
            get;
            set;
        }
    }
}
