﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace AmericanExpress.GDU.Service.DataContracts
{
    [DataContract]
    public class ManageFunctionDetails
    {
             
        [DataMember]
        public Int32 FuntionId
        {
            get;
            set;
        }


        [DataMember]
        public string FunctionName
        {
            get;
            set;
        }

    }
}
