﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace AmericanExpress.GDU.Service.DataContracts
{
   [DataContract]
    public class ManageFunctionQuery
    {

       [DataMember]
       public string FunctionType
       {
           get;
           set;
       }
        
       [DataMember]
        public Int32 ClientId
        {
            get;
            set;
        }

       
        [DataMember]
        public string RoleCode
        {
            get;
            set;
        }

        [DataMember]
        public string System_CD
        {
            get;
            set;
        }
       

    }
}
