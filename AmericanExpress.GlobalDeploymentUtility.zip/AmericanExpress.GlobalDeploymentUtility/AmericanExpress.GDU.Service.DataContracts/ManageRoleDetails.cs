﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace AmericanExpress.GDU.Service.DataContracts
{
    [DataContract]
    public class ManageRoleDetails
    {
             
        [DataMember]
        public Int32 ClientId
        {
            get;
            set;
        }

        [DataMember]
        public string RoleCode
        {
            get;
            set;
        }

        [DataMember]
        public string RoleName
        {
            get;
            set;
        }

        [DataMember]
        public string ClientName
        {
            get;
            set;

        }

        [DataMember]
        public DateTime ModifiedDate
        {
            get;
            set;
        }

        [DataMember]
        public string RoleTypeCD
        {
            get;
            set;
        }

        [DataMember]
        public string ClientAbbr
        {
            get;
            set;
        }

        [DataMember]
        public string SYSTEM_NAME
        {
            get;
            set;
        }
        [DataMember]
        public int TotalRecord
        {
            get;
            set;
        }
    }
}
