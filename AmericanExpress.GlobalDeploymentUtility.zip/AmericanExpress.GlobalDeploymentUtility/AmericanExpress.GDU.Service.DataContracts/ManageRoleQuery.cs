﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace AmericanExpress.GDU.Service.DataContracts
{
   [DataContract]
    public class ManageRoleQuery
    {
        
       [DataMember]
        public Int32 ClientId
        {
            get;
            set;
        }

        [DataMember]
        public string RoleName
        {
            get;
            set;
        }

        [DataMember]
        public string RoleCode
        {
            get;
            set;
        }
       
        [DataMember]
      
        public bool IsDeactive
        {
            get;
            set;
        }

        [DataMember]

        public Int32 FunctionId
        {
            get;
            set;
        }

        [DataMember]

        public string CreatedBy
        {
            get;
            set;
        }

        [DataMember]

        public DateTime ModifiedDt
        {
            get;
            set;
        }

        [DataMember]

        public string Flag
        {
            get;
            set;
        }

        [DataMember]

        public string AuthorizedFunctionIds
        {
            get;
            set;
        }

        [DataMember]
        public string RoleTypeCD
        {
            get;
            set;
        }

        [DataMember]
        public string System_CD
        {
            get;
            set;
        }

        [DataMember]
        public int CurrentPage
        {
            get;
            set;
        }
        [DataMember]
        public int PageSize
        {
            get;
            set;
        }
        [DataMember]
        public string SortExpression
        {
            get;
            set;
        }
        [DataMember]
        public string SortOrder
        {
            get;
            set;
        }
    }
}
