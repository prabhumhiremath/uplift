﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;
namespace AmericanExpress.GDU.Service.DataContracts
{
    [DataContract]
   public class MappingDetails
    {
        [DataMember]
        public string Mapping_CD
        {
            get;
            set;
        }
        [DataMember]
        public string Virtual_CD
        {
            get;
            set;
        }
        [DataMember]
        public string Real_CD
        {
            get;
            set;
        }
        [DataMember]
        public string Real_NM
        {
            get;
            set;
        }
        [DataMember]
        public string Mode
        {
            get;
            set;
        }
        [DataMember]
        public string InTransaction
        {
            get;
            set;
        }
    }
}
