﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;
namespace AmericanExpress.GDU.Service.DataContracts
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
   public class MappingQuery
    {
        [DataMember]
        public string Input_CD
        {
            get;
            set;
        }
        [DataMember]
        public string Mapping_Input_Type
        {
            get;
            set;
        }
        [DataMember]
        public string Input_Type
        {
            get;
            set;
        }
    }
}
