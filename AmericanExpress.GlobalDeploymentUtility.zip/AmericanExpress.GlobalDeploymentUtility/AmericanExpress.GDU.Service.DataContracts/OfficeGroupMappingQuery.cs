﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace AmericanExpress.GDU.Service.DataContracts
{
    [DataContract]
  public class OfficeGroupMappingQuery
    {
        /// <summary>
        /// 
        /// </summary>
        [DataMember]
        public int GroupID
        {
            get;
            set;
        }
        [DataMember]
        public string OfficeID
        {
            get;
            set;
        }
        [DataMember]
        public string OfficeDS
        {
            get;
            set;
        }

        [DataMember]
        public string CreatedUserID
        {
            get;
            set;
        }
    }
}
