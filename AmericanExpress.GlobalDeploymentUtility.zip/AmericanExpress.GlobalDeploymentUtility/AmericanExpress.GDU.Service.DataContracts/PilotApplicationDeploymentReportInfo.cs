﻿//-----------------------------------------------------------------------
// <copyright file="ClientDeploymentInfo.cs" company="NIIT Technologies">
//  Copyright (c) NIIT Technologies. All rights reserved.
// </copyright>
// <summary>
// <Description>This a CountryQuery class which contains attributes for country.</Description>
// <Author>NIIT Technologies</Author>
// <CreatedOn>15/02/2010</CreatedOn>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// </summary>
//-----------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;
namespace AmericanExpress.GDU.Service.DataContracts
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class PilotApplicationDeploymentReportInfo
    {
        #region Public Properties
       
        /// <summary>
        /// Gets or stes the UserId.
        /// </summary>
        [DataMember]
        public string UserId
        {
            get;
            set;
        }
        /// <summary>
        /// Gets or Stes the IPAddress.
        /// </summary>
        [DataMember]
        public string IPAddress
        {
            get;
            set;
        }
        /// <summary>
        /// Gets or sets the NACId.
        /// </summary>
        [DataMember]
        public string NACId
        {
            get;
            set;
        }
        /// <summary>
        /// Gets or sets the ExeVersion.
        /// </summary>
        [DataMember]
        public string ExeVersionNo
        {
            get;
            set;
        }
        /// <summary>
        /// Gets or sets the ExeTimeStamp.
        /// </summary>
        [DataMember]
        public DateTime ExeTimeStamp
        {
            get;
            set;
        }
        /// <summary>
        /// Gets or Stes the TimeStamp.
        /// </summary>
        [DataMember]
        public DateTime TimeStamp
        {
            get;
            set;
        }
        /// <summary>
        /// Gets or Sets the ApplicationPath.
        /// </summary>
        [DataMember]
        public string ApplicationPath
        {
            get;
            set;
        }
        /// <summary>
        /// Gets or Sets the Latest Version.
        /// </summary>
        [DataMember]
        public string LatestVersionNo
        {
            get;
            set;
        }
        /// <summary>
        /// Gets or Sets the Computer Name.
        /// </summary>
        [DataMember]
        public string ComputerName
        {
            get;
            set;
        }

        [DataMember]
        public string App_ID
        {
            get;
            set;
        }

        [DataMember]
        public string System_CD
        {
            get;
            set;
        }

        [DataMember]
        public string App_Name
        {
            get;
            set;
        }

        [DataMember]
        public int TotalRecords
        {
            get;
            set;
        }
        #endregion
    }
}
