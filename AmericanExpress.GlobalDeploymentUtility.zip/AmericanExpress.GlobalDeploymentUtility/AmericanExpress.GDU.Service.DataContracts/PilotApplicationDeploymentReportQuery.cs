﻿//-----------------------------------------------------------------------
// <copyright file="ClientDeployementInput.cs" company="NIIT Technologies">
//  Copyright (c) NIIT Technologies. All rights reserved.
// </copyright>
// <summary>
// <Description>This a CityInput class which contains attributes for CityInput</Description>
// <Author>NIIT Technologies</Author>
// <CreatedOn>15/02/2010</CreatedOn>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// </summary>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace AmericanExpress.GDU.Service.DataContracts
{
    [DataContract]
    public  class PilotApplicationDeploymentReportQuery
    {
        [DataMember]
        public string UserId
        {
            get;
            set;
        }

        [DataMember]
        public string Version
        {
            get;
            set;
        }

        [DataMember]
        public int NonMaxFlag
        {
            get;
            set;
        }

        [DataMember]
        public string clientId
        {
            get;
            set;
        }

        [DataMember]
        public string App_ID
        {
            get;
            set;
        }

        [DataMember]
        public string System_CD
        {
            get;
            set;
        }

        [DataMember]
        public int PageIndex
        {
            get;
            set;
        }

        [DataMember]
        public int PageSize
        {
            get;
            set;
        }

        [DataMember]
        public string SortColumn
        {
            get;
            set;
        }

        [DataMember]
        public string SortOrder
        {
            get;
            set;
        }
    }
}
