﻿//-----------------------------------------------------------------------
// <copyright file="CityQuery.cs" company="NIIT Technologies">
//  Copyright (c) NIIT Technologies. All rights reserved.
// </copyright>
// <summary>
// <Description>This a CityQuery class which contains attributes for city.</Description>
// <Author>NIIT Technologies</Author>
// <CreatedOn>11/05/2009</CreatedOn>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// </summary>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;
namespace AmericanExpress.GDU.Service.DataContracts
{
   
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
   public class RoleQuery
    {
       
        /// <summary>
        /// 
        /// </summary>
        [DataMember]
        public string UserId
        {
            get;
            set;
        }
        [DataMember]
        public string RoleType
        {
            get;
            set;
        }

        [DataMember]
        public string RoleCD
        {
            get;
            set;
        }

        [DataMember]
        public string System_CD
        {
            get;
            set;
        }
    }
}
