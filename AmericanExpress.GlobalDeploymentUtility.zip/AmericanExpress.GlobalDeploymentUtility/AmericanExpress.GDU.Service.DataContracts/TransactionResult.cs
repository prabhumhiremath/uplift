﻿//-----------------------------------------------------------------------
// <copyright file="TransactionResult.cs" company="NIIT Technologies">
//  Copyright (c) NIIT Technologies. All rights reserved.
// </copyright>
// <summary>
// <Description>This a TransactionResult class which contains attributes for TransactionResult</Description>
// <Author>NIIT Technologies</Author>
// <CreatedOn>11/12/2009</CreatedOn>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// </summary>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;
namespace AmericanExpress.GDU.Service.DataContracts
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
   public class TransactionResult
    {
        /// <summary>
        /// 
        /// </summary>
        [DataMember]
        public string TransactionType
        {
            get;
            set;
        }

        /// <summary>
        /// 
        /// </summary>
        [DataMember]
        public string TransactionId
        {
            get;
            set;
        }
    }
}
