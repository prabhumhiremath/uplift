﻿//-----------------------------------------------------------------------
// <copyright file="TransitDataQuery.cs" company="NIIT Technologies">
//  Copyright (c) NIIT Technologies. All rights reserved.
// </copyright>
// <summary>
// <Description>This a TransitDataQuery class which contains attributes for Transit Data.</Description>
// <Author>NIIT Technologies</Author>
// <CreatedOn>05/08/2012</CreatedOn>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// </summary>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace AmericanExpress.GDU.Service.DataContracts
{
    [DataContract]
    public class TransitDataQuery
    {
        [DataMember]
        public string code
        {
            get;
            set;
        }

        /// <summary>
        /// 
        /// </summary>
        /// 
        [DataMember]
        public string mode
        {
            get;
            set;
        }
    }
}
