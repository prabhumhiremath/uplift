﻿//-----------------------------------------------------------------------
// <copyright file="UserDetails.cs" company="NIIT Technologies">
//  Copyright (c) NIIT Technologies. All rights reserved.
// </copyright>
// <summary>
// <Description>This a UserDetails class which contains attributes for UserDetails</Description>
// <Author>NIIT Technologies</Author>
// <CreatedOn>11/23/2009</CreatedOn>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// </summary>
//-----------------------------------------------------------------------


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace AmericanExpress.GDU.Service.DataContracts
{

        [DataContract]
        public class UserDetails
        {
            /// <summary>
            /// 
            /// </summary>
            [DataMember]
            public string UserId
            {
                get;
                set;
            }

            /// <summary>
            /// 
            /// </summary>
            [DataMember]
            public string UserName
            {
                get;
                set;
            }

            /// <summary>
            /// 
            /// </summary>
            [DataMember]
            public bool IsDeactive
            {
                get;
                set;
            }
            /// <summary>
            /// 
            /// </summary>
            [DataMember]
            public string Language
            {
                get;
                set;
            }

            /// <summary>
            /// 
            /// </summary>
            [DataMember]
            public string LanguageCode
            {
                get;
                set;
            }
            /// <summary>
            /// 
            /// </summary>
            [DataMember]
            public string EmailAddress
            {
                get;
                set;
            }
            /// <summary>
            /// 
            /// </summary>
            [DataMember]
            public string UserRole
            {
                get;
                set;
            }
            /// <summary>
            /// 
            /// </summary>
            [DataMember]
            public string UserRoleCode
            {
                get;
                set;
            }
            
            /// <summary>
            /// 
            /// </summary>
            [DataMember]
            public string DomainName
            {
                get;
                set;
            }

            /// <summary>
            /// 
            /// </summary>
            [DataMember]
            public string Mode
            {
                get;
                set;
            }

            /// <summary>
            /// 
            /// </summary>
            [DataMember]
            public string CreatedUserID
            {
                get;
                set;
            }

            /// <summary>
            /// 
            /// </summary>
            [DataMember]
            public string ModifiedUserID
            {
                get;
                set;
            }

            /// <summary>
            /// 
            /// </summary>
            [DataMember]
            public string MacID
            {
                get;
                set;
            }


            /// <summary>
            /// 
            /// </summary>
            [DataMember]
            public DateTime CreatedUserDate
            {
                get;
                set;
            }
            /// <summary>
            /// 
            /// </summary>
            [DataMember]
            public DateTime ModifiedUserDate
            {
                get;
                set;
            }

            ///<summary>
            /// 
            /// </summary>
            [DataMember]
            public String IPAddress
            {
                get;
                set;
            }

            ///<summary>
            /// 
            /// </summary>
            [DataMember]
            public String ComputerName
            {
                get;
                set;
            }


            [DataMember]
            public Int32 DefaultClientID
            {
                get;
                set;
            }

            [DataMember]
            public Int32 App_ID
            {
                get;
                set;
            }

            [DataMember]
            public int TotalRecord
            {
                get;
                set;
            }

        }
    }


