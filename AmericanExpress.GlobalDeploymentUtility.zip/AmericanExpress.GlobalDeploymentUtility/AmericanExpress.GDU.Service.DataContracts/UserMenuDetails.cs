﻿//-----------------------------------------------------------------------
// <copyright file="UserDetails.cs" company="NIIT Technologies">
//  Copyright (c) NIIT Technologies. All rights reserved.
// </copyright>
// <summary>
// <Description>This a UserDetails class which contains attributes for UserDetails</Description>
// <Author>NIIT Technologies</Author>
// <CreatedOn>11/23/2009</CreatedOn>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// </summary>
//-----------------------------------------------------------------------


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace AmericanExpress.GDU.Service.DataContracts
{

    [DataContract]
    public class UserMenuDetails
    {

        [DataMember]
        public Int32 FunctionId
        {
            get;
            set;
        }

        /// <summary>
        /// 
        /// </summary>
        [DataMember]
        public string FunctionName
        {
            get;
            set;
        }

        [DataMember]
        public string FunctionPageUrlTxt
        {
            get;
            set;
        }
        /// <summary>
        /// 
        /// </summary>
        /// 
        [DataMember]
        public Int32 FunctionParentId
        {
            get;
            set;
        }


        [DataMember]
        public Int32 DispOrderNo
        {
            get;
            set;
        }



    }
    }


