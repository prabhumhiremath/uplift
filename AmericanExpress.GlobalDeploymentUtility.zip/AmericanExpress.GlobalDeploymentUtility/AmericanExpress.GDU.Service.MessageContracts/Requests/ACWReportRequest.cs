﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using AmericanExpress.GDU.Service.DataContracts;

namespace AmericanExpress.GDU.Service.MessageContracts.Requests
{
    [MessageContract]
    public class ACWReportRequest
    {       
        [MessageBodyMember]
        public ACWCoralReportQuery PopulateRequest
        {
            get;
            set;
        }

    }
}
