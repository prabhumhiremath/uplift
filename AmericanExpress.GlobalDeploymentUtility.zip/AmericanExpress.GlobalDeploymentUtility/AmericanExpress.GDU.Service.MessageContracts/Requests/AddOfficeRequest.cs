﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using AmericanExpress.GDU.Service.DataContracts;

namespace AmericanExpress.GDU.Service.MessageContracts.Requests
{
    [MessageContract]
    public class AddOfficeRequest
    {
        [MessageBodyMember]
        public AddOfficeQuery SearchRequest
        {
            get;
            set;
        }
    }

    [MessageContract]
    public class AddOfficeManipulateRequest
    {
        /// <summary>
        /// 
        /// </summary>
        [MessageBodyMember]
        public AddOfficeQuery ManipulateRequest
        {
            get;
            set;
        }
    }
}
