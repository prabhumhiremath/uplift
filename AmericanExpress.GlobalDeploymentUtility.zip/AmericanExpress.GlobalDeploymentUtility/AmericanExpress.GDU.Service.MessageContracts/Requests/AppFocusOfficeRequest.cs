﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using AmericanExpress.GDU.Service.DataContracts;

namespace AmericanExpress.GDU.Service.MessageContracts.Requests
{
    [MessageContract]
    public class AppFocusOfficeSearchRequest
    {
        [MessageBodyMember]
        public AppFocusOfficeQuery SearchRequest
        {
            get;
            set;
        }
    }
    [MessageContract]
    public class AppFocusOfficeManuplateRequest
    {
        [MessageBodyMember]
        public AppFocusOfficeQuery ManipulateRequest
        {
            get;
            set;
        }
    }

}
