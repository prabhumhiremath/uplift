﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using AmericanExpress.GDU.Service.DataContracts;

namespace AmericanExpress.GDU.Service.MessageContracts.Requests
{
    [MessageContract]
    public class ApplicationRequest
    {
        [MessageHeader]
        public StandardInput ServiceInput
        {
            get;
            set;
        }
        /// <summary>
        /// 
        /// </summary>
        [MessageBodyMember]
        public ApplicationQuery PopulateRequest
        {
            get;
            set;
        }
    }
}
