﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using AmericanExpress.GDU.Service.DataContracts;

namespace AmericanExpress.GDU.Service.MessageContracts.Requests
{
    [MessageContract]
    public class ManageAppFocusRequest
    {
        [MessageBodyMember]
        public ManageAppFocusQuery SearchRequest
        {
            get;
            set;
        }
    }

    [MessageContract]
    public class AppFocusManipulateRequest
    {
        /// <summary>
        /// 
        /// </summary>
        [MessageBodyMember]
        public ManageAppFocusQuery ManipulateRequest
        {
            get;
            set;
        }
    }
}
