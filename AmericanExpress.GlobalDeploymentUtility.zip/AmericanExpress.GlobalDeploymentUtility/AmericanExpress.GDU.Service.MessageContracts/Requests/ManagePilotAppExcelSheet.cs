﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using AmericanExpress.GDU.Service.DataContracts;

namespace AmericanExpress.GDU.Service.MessageContracts.Requests
{
    [MessageContract]
    public class ManagePilotAppExcelSheetRequest
    {
        [MessageBodyMember]
        public ManagePilotAppExcelSheetQuery SearchRequest
        {
            get;
            set;
        }
    }

    [MessageContract]
    public class PilotAppExcelSheetManipulateRequest
    {
        /// <summary>
        /// 
        /// </summary>
        [MessageBodyMember]
        public ManagePilotAppExcelSheetQuery ManipulateRequest
        {
            get;
            set;
        }
    }
}
