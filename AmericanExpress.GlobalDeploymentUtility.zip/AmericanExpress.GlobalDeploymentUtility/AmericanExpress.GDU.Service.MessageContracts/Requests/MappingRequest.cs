﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using AmericanExpress.GDU.Service.DataContracts;
namespace AmericanExpress.GDU.Service.MessageContracts.Requests
{
    /// <summary>
    /// 
    /// </summary>
    [MessageContract]
  public  class MappingRequest
    {

        /// <summary>
        /// 
        /// </summary>
        [MessageBodyMember]
        public MappingQuery MappingInput
        {
            get;
            set;
        } 
    }
}
