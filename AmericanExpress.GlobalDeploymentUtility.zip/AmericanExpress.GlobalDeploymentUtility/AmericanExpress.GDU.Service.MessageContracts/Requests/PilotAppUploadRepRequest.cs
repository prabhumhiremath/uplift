﻿//-----------------------------------------------------------------------
// <copyright file="PilotAppUploadRepRequest.cs" company="NIIT Technologies">
//  Copyright (c) NIIT Technologies. All rights reserved.
// </copyright>
// <summary>
// <Description>This a CityRequest class which contains messagecontract query for city.</Description>
// <Author>NIIT Technologies</Author>
// <CreatedOn>17/10/2011</CreatedOn>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// </summary>
//-----------------------------------------------------------------------


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using AmericanExpress.GDU.Service.DataContracts;

namespace AmericanExpress.GDU.Service.MessageContracts.Requests
{
    [MessageContract]
    public class PilotAppUploadRepRequest
    {
        [MessageBodyMember]
        public PilotAppRepQuery PopulateRequest
        {
            get;
            set;
        }

    }
}
