﻿//-----------------------------------------------------------------------
// <copyright file="UserRequest.cs" company="NIIT Technologies">
//  Copyright (c) NIIT Technologies. All rights reserved.
// </copyright>
// <summary>
// <Description>This a UserSearchRequest class which contains datacontract's for user requests.</Description>
// <Author>NIIT Technologies</Author>
// <CreatedOn>11/18/2009</CreatedOn>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// </summary>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using AmericanExpress.GDU.Service.DataContracts;

namespace AmericanExpress.GDU.Service.MessageContracts.Requests
{
    [MessageContract]
    public class UserSearchRequest
    {


        /// <summary>
        /// 
        /// </summary>
        [MessageBodyMember]
        public UserQuery SearchRequest
        {
            get;
            set;
        }
    }
    [MessageContract]
    public class UserManipulateRequest
    {


        /// <summary>
        /// 
        /// </summary>
        [MessageBodyMember]
        public UserQuery ManipulateRequest
        {
            get;
            set;
        }
    }


}
