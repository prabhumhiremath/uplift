﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AmericanExpress.GDU.Service.DataContracts;
using System.ServiceModel;

namespace AmericanExpress.GDU.Service.MessageContracts.Responses
{
    [MessageContract]
    public  class ACWReportResponse
    {
        [MessageHeader]
        public StandardResponse ServiceResponse
        {
            get;
            set;
        }

        [MessageBodyMember]
        public ACWCoralReportDetails[] PopulateResponse
        {
            get;
            set;
        }


    }
}
