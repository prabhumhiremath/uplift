﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using AmericanExpress.GDU.Service.DataContracts;

namespace AmericanExpress.GDU.Service.MessageContracts.Responses
{
    [MessageContract]
   public class AppFOfficeGroupMappingResponse
    {
        [MessageHeader]
        public StandardResponse ServiceResponse
        {
            get;
            set;
        }
        [MessageBodyMember]
        /// <summary>
        /// 
        /// </summary>

        public AppFocusOfficeDetails[] MappingDetail
        {
            get;
            set;
        } 
    }
}
