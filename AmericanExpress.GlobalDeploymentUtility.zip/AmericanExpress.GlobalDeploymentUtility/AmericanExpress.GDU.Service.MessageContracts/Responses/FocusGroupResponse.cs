﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using AmericanExpress.GDU.Service.DataContracts;

namespace AmericanExpress.GDU.Service.MessageContracts.Responses
{
    [MessageContract]
    public class FoucsGroupSearchResponse
    {
        /// <summary>
        ///  
        /// </summary>
        [MessageBodyMember]
        public FocusGroupDetails[] SearchResponse
        {
            get;
            set;
        }
    }
    [MessageContract]
    public class FocusGroupStandardResponse
    {
        [MessageHeader]
        public StandardResponse ServiceResponse
        {
            get;
            set;
        }
    }
    [MessageContract]
    public class PopulateFocusGroupResponse
    {
        [MessageHeader]
        public StandardResponse ServiceResponse
        {
            get;
            set;
        }
        [MessageBodyMember]
        public PopulateFocusGroupDetails[] PopulateResponse
        {
            get;
            set;
        }
    }
    [MessageContract]
    public class AppfOfficeAdsIDResponse
    {
        [MessageHeader]
        public StandardResponse ServiceResponse
        {
            get;
            set;
        }
        [MessageBodyMember]
        public PopulateAppfOfficeAdsID[] PopulateResponse
        {
            get;
            set;
        }
    }
}
