﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using AmericanExpress.GDU.Service.DataContracts;

namespace AmericanExpress.GDU.Service.MessageContracts.Responses
{
    [MessageContract]
    public class OfficeGroupMappingReportResponse
    {
        [MessageHeader]
        public StandardResponse ServiceResponse
        {
            get;
            set;
        }
        /// <summary>
        /// 
        /// </summary>
        [MessageBodyMember]
        public OfficeGroupMappingReportInfo[] PopulateResponse
        {
            get;
            set;
        }
    }
}
