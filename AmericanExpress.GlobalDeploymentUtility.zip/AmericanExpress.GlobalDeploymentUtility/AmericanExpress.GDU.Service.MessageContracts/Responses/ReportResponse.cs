﻿//-----------------------------------------------------------------------
// <copyright file="ReportResponse.cs" company="NIIT Technologies">
//  Copyright (c) NIIT Technologies. All rights reserved.
// </copyright>
// <summary>
// <Description>This a ReportResponse class which contains ReportResponse messagecontract which has collection of ReportDetails.</Description>
// <Author>NIIT Technologies</Author>
// <CreatedOn>11/23/2009</CreatedOn>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// </summary>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AmericanExpress.GDU.Service.DataContracts;
using System.ServiceModel;

namespace AmericanExpress.GDU.Service.MessageContracts.Responses
{
    /// <summary>
    /// 
    /// </summary>
    [MessageContract]
    public class ReportResponse
    {
       [MessageBodyMember]
        public ReportDetails[] PopulateResponse
        {
            get;
            set;
        }
    }
}
