﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using AmericanExpress.GDU.Service.DataContracts;

namespace AmericanExpress.GDU.Service.MessageContracts.Responses
{   
    [MessageContract]
    public class TravelSuiteAppFocusReportResponse
    {
        [MessageHeader]
        public StandardResponse ServiceResponse
        {
            get;
            set;
        }

        [MessageBodyMember]
        public TravelSuiteAppFocusReportDetails[] PopulateResponse
        {
            get;
            set;
        }

    }
}
