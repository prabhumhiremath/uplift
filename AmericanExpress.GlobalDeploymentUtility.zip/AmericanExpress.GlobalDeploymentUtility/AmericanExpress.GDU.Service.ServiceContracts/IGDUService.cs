﻿//-----------------------------------------------------------------------
// <copyright file="IGWizService.cs" company="NIIT Technologies">
//  Copyright (c) NIIT Technologies. All rights reserved.
// </copyright>
// <summary>
// <Description>This a interface which defines all the operation contracts.</Description>
// <Author>NIIT Technologies</Author>
// <CreatedOn>11/03/2009</CreatedOn>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// </summary>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.ServiceModel.Activation;
using AmericanExpress.GDU.Service.MessageContracts.Responses;
using AmericanExpress.GDU.Service.MessageContracts.Requests;

namespace AmericanExpress.GDU.Service.ServiceContract
{
    [ServiceContract(Namespace = "http://www.americanexpress.com/wsdl/GDUWCF/")]
    public interface IGDUService
    {
        #region Link

        //[OperationContract(Name = "SearchLink")]
        //SearchLinkResponse SearchLink(SearchLinkRequest request);

        //[OperationContract(Name = "ManupulateLink")]
        //ManupulateResponse ManupulateLink(ManupulateLinkRequest request);

        //[OperationContract(Name = "DeleteLink")]
        //ManupulateResponse DeleteLink(DeleteLinkRequest request);

        //[OperationContract(Name = "SearchLinkClientAlert")]
        //SearchLinkResponse SearchLinkClientAlert(SearchLinkRequest request);

        //[OperationContract(Name = "SearchClientTotalAlert")]
        //SearchClientTotalAlertResponse SearchClientTotalAlert(SearchLinkRequest request);

        //[OperationContract(Name = "SearchOtherInfoTotalAlert")]
        //SearchOtherInfoTotalAlertResponse SearchOtherInfoTotalAlert(SearchOtherInfoRequest request);


        #endregion

        #region GeneralInfo

        //[OperationContract(Name = "ManupulateGeneralInfo")]
        //ManupulateResponse ManupulateGeneralInfoLink(ManupulateGeneralInfoLinkRequest request);

        //[OperationContract(Name = "ManupulateGeneralInfoOtherInfoDetail")]
        //ManupulateResponse ManupulateGeneralInfoOtherInfoDetail(ManupulateGeneralInfoOtherInfoRequest request);

        #endregion

        #region OtherInfo Link

        //[OperationContract(Name = "SearchOtherInfo")]
        //SearchOtherInfoResponse SearchOtherInfo(SearchOtherInfoRequest request);

        //[OperationContract(Name = "ManupulateOtherInfoDetail")]
        //ManupulateResponse ManupulateOtherInfoDetail(ManupulateOtherInfoRequest request);

        //[OperationContract(Name = "DeleteOtherInfo")]
        //ManupulateResponse DeleteOtherInfo(DeleteOtherInfoRequest request);

        #endregion

        #region Other Info

        //[OperationContract(Name = "ManupulateOtherInfo")]
        //ManupulateResponse ManupulateOtherInfo(OtherInfoRequest request);
        //[OperationContract(Name = "DeleteOtherInfo")]
        //ManupulateResponse DeleteOtherInfo(OtherInfoRequest request);
        //[OperationContract(Name = "PopulateOtherInfoCategory")]
        //PopulateCategoryResponse PopulateOtherInfoCategory(OtherInfoRequest request);
        #endregion

        #region Global Category
        //[OperationContract(Name = "ManupulateGlobalCategory")]
        //ManupulateResponse ManupulateGlobalCategory(GlobalCategoryRequest request);
        //[OperationContract(Name = "DeleteGlobalCategory")]
        //ManupulateResponse DeleteGlobalCategory(GlobalCategoryRequest request);

        //[OperationContract(Name = "PopulateGlobalCategory")]
        //PopulateCategoryResponse PopulateGlobalCategory();


        #endregion

        #region Language

        [OperationContract(Name = "PopulateLanguage")]
        PopulateLanguageResponse PopulateLanguage();

        #endregion

        #region Link Type

        //[OperationContract(Name = "PopulateLinkType")]
        //PopulateLinkTypeResponse PopulateLinkType();

        #endregion

        #region Category

        //[OperationContract(Name = "PopulateCategory")]
        //PopulateCategoryResponse PopulateCategory(SearchLinkRequest request);

        #endregion

        #region Account

        //[OperationContract(Name = "PopulateAccount")]
        //PopulateAccountResponse PopulateAccount(AccountRequest request);

        //[OperationContract(Name = "SearchAccounts")]
        //ManageAccountResponse SearchAccounts(ManageAccountRequest Request);

        //[OperationContract(Name = "ManageAccounts")]
        //ManupulateResponse ManageAccounts(AccountManipulateRequest Request);

        #endregion


        #region Client

        //[OperationContract(Name = "PopulateClientResponse")]
        //PopulateClientResponse PopulateClientResponse(ClientRequest request);

        //[OperationContract(Name = "SearchClients")]
        //ManageClientResponse SearchClients(ManageClientRequest Request);

        //[OperationContract(Name = "ManageClients")]
        //ManupulateResponse ManageClients(ClientManipulateRequest Request);

        #endregion

        #region Role

        [OperationContract(Name = "SearchRoles")]
        ManageRoleResponse SearchRoles(ManageRoleRequest Request);

        [OperationContract(Name = "SearchClientRoles")]
        ManageRoleResponse SearchClientRoles(ManageRoleRequest Request);

        [OperationContract(Name = "ManageRole")]
        ManupulateResponse ManageRole(RoleManipulateRequest Request);

        [OperationContract(Name = "PopulateRole")]
        RoleResponse PopulateRoles(PopulateRoleRequest Request);

        #endregion

        #region Functions

        [OperationContract(Name = "PopulateFunctions")]
        FunctionResponse PopulateFunctions(FunctionRequest request);

        #endregion


        #region Country

        //[OperationContract(Name = "PopulateCountry")]
        //PopulateCountryResponse LoadCountry(PopulateCountryRequest request);

        //[OperationContract(Name = "LoadCountry")]
        //PopulateCountryResponse PopulateCountry(PopulateCountryRequest request);

        #endregion

        #region City

        //[OperationContract(Name = "PopulateCity")]
        //PopulateCityResponse PopulateCity(PopulateCityRequest Request);
        //[OperationContract(Name = "LoadCity")]
        //PopulateCityResponse PopulateCity(PopulateCityRequest Request,string strJquery);

        #endregion

        #region Carrier

        //[OperationContract(Name = "PopulateCarrier")]
        //PopulateCarrierResponse PopulateCarrier();

        //[OperationContract(Name = "SearchCarriers")]
        //DisplayCarrierSearchResponse SearchCarriers(CarrierSearchRequest Request);

        //[OperationContract(Name = "ManageCarriers")]
        //[FaultContract(typeof(CustomFaultMsg))]
        //CarrierStandardResponse ManageCarriers(CarrierManupulateRequest Request);

        #endregion

        #region OtherInfo

        //[OperationContract(Name = "PopulateOtherInfo")]
        //PopulateOtherInfoResponse PopulateOtherInfo();
        #endregion

        #region Feedback
        //[OperationContract(Name = "FeedbackResponse")]
        //ManupulateResponse FeedbackResponse(FeedbackRequest request);

        //[OperationContract(Name = "PopulateFeedbackType")]
        //PopulateFeedbackType PopulateFeedbackType();
        #endregion

        #region TransactionId
        //[OperationContract(Name = "GetTransactionId")]
        //TransactionResponse GetTransactionId(TransactionRequest request);
        #endregion

        #region Reporting Functions
        //[OperationContract(Name = "PopulateGwizReport")]
        //ReportResponse PopulateGwizReport(ReportRequest Request);

        //[OperationContract(Name = "PopulateGWizOtherInfoReport")]
        //OtherInfoReportResponse PopulateGWizOtherInfoReport(OtherInfoReportRequest Request);


        //[OperationContract(Name = "PupulateGWizBrokenInfoReport")]
        //ReportResponse PupulateGWizBrokenInfoReport();

        //[OperationContract(Name = "PupulateGWizOtherBrokenInfoReport")]
        //OtherInfoReportResponse PupulateGWizOtherBrokenInfoReport();

        //[OperationContract(Name = "PupulateGWizFeedbackTypeReport")]
        //FeedbackTypeReportResponse PupulateGWizFeedbackTypeReport(FeedbackReportRequest Request);

        [OperationContract(Name = "PopulateGWizClientDeploymentReport")]
        ClientDeploymentReportResponse PopulateGWizClientDeploymentReport(ClientDeploymentReportRequest Request);

        [OperationContract(Name = "PopulateGWizClientUsageReport")]
        ClientUsageReportResponse PopulateGWizClientUsageReport(ClientUsageReportRequest Request);

        [OperationContract(Name = "PopulateGWizAppUploadedReport")]
        AppUploadedReportResponse PopulateGWizAppUploadedReport(AppUploadedReportRequest Request);

        #endregion

        [OperationContract(Name = "SearchAppUsers")]
        AppUserSearchResponse SearchAppUsers(AppUserSearchRequest Request);

        [OperationContract(Name = "ManageAppUsers")]
        [FaultContract(typeof(CustomFaultMsg))]
        AppUserStandardResponse ManageAppUsers(AppUserManipulateRequest Request);

        [OperationContract(Name = "PopulateAppInfo")]
        ApplicationInfoResponse PopulateAppInfo();

        #region User

        //[OperationContract(Name = "PopulateUser")]
        //PopulateUserResponse PopulateUser();

        [OperationContract(Name = "SearchUsers")]
        UserSearchResponse SearchUsers(UserSearchRequest Request);

        [OperationContract(Name = "PopulateSearchUsers")]
        UserSearchResponse PopulateSearchUsers(UserSearchRequest Request);

        [OperationContract(Name = "ManageUsers")]
        [FaultContract(typeof(CustomFaultMsg))]
        UserStandardResponse ManageUsers(UserManipulateRequest Request);

        #endregion

        #region Version

        [OperationContract(Name = "SearchVersion")]
        VerSearchResponse SearchVersions(AppUserSearchRequest request);

        #endregion

        #region ManageCountry
        //[OperationContract(Name = "SearchCountry")]
        //ManageCountryResponse SearchCountry(ManageCountryRequest Request);

        //[OperationContract(Name = "ManageCountry")]
        //ManupulateResponse ManageCountry(CountryManipulateRequest Request);
        #endregion


        //[OperationContract(Name = "SearchCities")]
        //ManageCityResponse SearchCities(ManageCityRequest Request);

        //[OperationContract(Name = "ManageCities")]
        //ManupulateResponse ManageCities(CityManipulateRequest Request);

        //[OperationContract(Name = "MapCountry")]
        //ManupulateResponse MapCountry(CountryMappingRequest Request);
        #region UserRole

        [OperationContract(Name = "PopulateUserRole")]
        PopulateUserRoleResponse PopulateUserRole();

        #endregion

        #region Aggregation
        //[OperationContract(Name = "PopulateAggregationRule")]
        //PopulateAggregationRuleResponse PopulateAggregationRule();

        //[OperationContract(Name = "ManageAggregationRule")]
        //StandardAggregationRuleResponse ManageAggregationRule(AggregationRuleRequest Request);
        #endregion

        #region User Authentication

        [OperationContract(Name = "UserAuthentication")]
        UserAuthenticationResponse UserAuthentication(UserAuthenticationRequest request);

        #endregion

        #region ClientDeploymentDetail
        [OperationContract(Name = "ClientDeploymentDetailResponse")]
        ManupulateResponse ClientDeploymentDetailResponse(ClientDeploymentRequest request);
        #endregion

        #region ClientUsageDetail
        [OperationContract(Name = "ClientUsageDetailResponse")]
        ManupulateResponse ClientUsageDetailResponse(ClientUsageRequest request);
        #endregion

        #region Application

        [OperationContract(Name = "PopulateApplicationResponse")]
        PopulateApplicationResponse PopulateApplicationResponse(ApplicationRequest request);

        [OperationContract(Name = "SearchApplication")]
        ManageApplicationResponse SearchApplication(ManageApplicationRequest Request);

        [OperationContract(Name = "ManageApplication")]
        ManupulateResponse ManageApplication(ApplicationManipulateRequest Request);

        #endregion

        #region AppFocus

        [OperationContract(Name = "ManageAppFocus")]
        ManupulateResponse ManageAppFocus(AppFocusManipulateRequest Request);

        #endregion

        #region Search Label

        //[OperationContract(Name = "SearchLabel")]
        //SearchLabelResponse SearchLabel(SearchLabelRequest request);

        #endregion

        #region Mapping AccCountryCity
        //[OperationContract(Name = "MapAccount")]
        //ManupulateResponse MapAccount(AccountMappingRequest Request);
        //[OperationContract(Name = "MapCity")]
        //ManupulateResponse MapCity(CityMappingRequest Request);
        //[OperationContract(Name = "PopulateClientInfo")]
        //ClientInfoResponse PopulateClientInfo();
        //[OperationContract(Name = "MappingDetails")]
        //MappingResponse MappingDetails(MappingRequest Request);
        #endregion
        [OperationContract(Name = "ClientReleaseResponse")]
        ManupulateResponse ClientReleaseResponse(ClientReleaseRequest request);

        //[OperationContract(Name = "PopulateClientAcc")]
        //PopulateClientAccResponse PopulateClientAcc(ClientAccRequest request);

        [OperationContract(Name = "SearchUserMenu")]
        UserMenuResponse SearchUserMenu(UserSearchRequest request);

        //[OperationContract(Name = "PopulateUserClientInfo")]
        //ClientInfoResponse PopulateUserClientInfo(UserSearchRequest request);

        [OperationContract(Name = "ManageUserPersonalProfile")]
        UserStandardResponse ManageUserPersonalProfile(UserManipulateRequest Request);

        [OperationContract(Name = "PopulateRoleMaster")]
        RoleMasterResponse PopulateRoleMaster();

        #region EntryDurationTime

        [OperationContract(Name = "ManageTimeDuration")]
        [FaultContract(typeof(CustomFaultMsg))]
        DurationTimeStandardResponse ManageTimeDuration(TimeDurationManipulateRequest Request);

        [OperationContract(Name = "SearchTimeDuration")]
        DurationTimeSearchResponse SearchTimeDuration(TimeDurationSearchRequest Request);

        #endregion

        #region AppFocusReport
        [OperationContract(Name = "PopulateAppFocusReport")]
        AppFocusReportResponse PopulateAppFocusReport(AppFocusReportRequest Request);
        #endregion

        #region AppFocusReportDetail
        [OperationContract(Name = "PopulateAppFocusReportDetail")]
        AppFocusReportResponse PopulateAppFocusReportDetail(AppFocusReportRequest Request);

        [OperationContract(Name = "PopulateAppUserFocusReportDetail")]
        AppFocusReportResponse PopulateAppUserFocusReportDetail(AppFocusReportRequest Request);

        #endregion

        [OperationContract(Name = "PopulateFocusReportApplicationName")]
        RptFocusAppNameResponse PopulateFocusReportApplicationName();
        [OperationContract(Name = "PopulateFocusReportOfficeID")]
        RptFocusOfficeIDResponse PopulateFocusReportOfficeID(FocusGroupRequest request);
        //RptFocusOfficeIDResponse PopulateFocusReportOfficeID();

        [OperationContract(Name = "SearchFocusApplication")]
        FoucsApplicationSearchResponse SearchFocusApplication(FocusApplicationSearchRequest Request);
        [OperationContract(Name = "PopulateSearchFocusApplication")]
        FoucsApplicationSearchResponse PopulateSearchFocusApplication(FocusApplicationSearchRequest Request);
        [OperationContract(Name = "ManageFocusApplication")]
        [FaultContract(typeof(CustomFaultMsg))]
        FocusApplicationStandardResponse ManageFocusApplication(FocusApplicationManipulateRequest Request);

        #region AppFocusOffice
        [OperationContract(Name = "SearchAppFocusOffice")]
        AppFocusOfficeSearchResponse SearchAppFocusOffice(AppFocusOfficeSearchRequest Request);
        [OperationContract(Name = "ManageAppFocusOffice")]
        ApplFocusOfficeStandardResponse ManageAppFocusOffice(AppFocusOfficeManuplateRequest Request);
        #endregion

        #region FocusGroup
        [OperationContract(Name = "SearchAPPFocusGroup")]
        FoucsGroupSearchResponse SearchAPPFocusGroup(FocusGroupSearchRequest Request);
        [OperationContract(Name = "ManageAppFocusGroup")]
        FocusGroupStandardResponse ManageAppFocusGroup(FocusGroupManipulateRequest Request);

        [OperationContract(Name = "LoadOfficeGroup")]
        PopulateFocusGroupResponse LoadOfficeGroup(FocusGroupRequest request);
        [OperationContract(Name = "GetMappingOfficeGroupDetails")]
        AppFOfficeGroupMappingResponse GetMappingOfficeGroupDetails(FocusGroupMappingRequest Request);
        [OperationContract(Name = "MappedOfficeGroupdtls")]
        FocusGroupStandardResponse MappedOfficeGroupdtls(FocusGroupMappingRequest Request);

        [OperationContract(Name = "PopulateAppFOfficeADSID")]
        AppfOfficeAdsIDResponse PopulateAppFOfficeADSID(AppFOfficeAdsIDRequest request);
        [OperationContract(Name = "ManageAppFOfficeADSID")]
        AppfOfficeAdsIDResponse ManageAppFOfficeADSID(AppFOfficeAdsIDRequest request);

        #endregion

        #region ApplicationVersion
        [OperationContract(Name = "SearchPreVersions")]
        VerSearchResponse SearchPreVersions(AppUserSearchRequest request);
        [OperationContract(Name = "UpdateAppPreVersion")]
        ManupulateResponse UpdateAppPreVersion(ClientReleaseRequest request);
        #endregion

        #region OfficeGroupMappingReport
        [OperationContract(Name = "PopulateOfficeGroupMappingReport")]
        OfficeGroupMappingReportResponse PopulateOfficeGroupMappingReport(OficeGroupMappingReportRequest Request);
        #endregion

        #region PilotApplicationUploadReport
        [OperationContract(Name = "PopulatePilotAppUploadReport")]
        AppUploadedReportResponse PopulatePilotAppUploadReport(AppUploadedReportRequest Request);

        [OperationContract(Name = "PopulatePilotUserDetails")]
        PilotAppUploadRepResponse PopulatePilotUserDetails(PilotAppUploadRepRequest Request);
        #endregion

        #region PilotApp_ImportExcelData
        [OperationContract(Name = "ImportPilotAppData")]
        ManupulateResponse ImportPilotAppData(PilotAppExcelSheetManipulateRequest Request);
        #endregion

        #region PopulateTravelSuiteAppFocusReport
        [OperationContract(Name = "PopulateTravelSuiteAppFocusReport")]
        TravelSuiteAppFocusReportResponse PopulateTravelSuiteAppFocusReport(TravelSuiteAppFocusReportRequest Request);
        #endregion

        #region PopulatePilotApplicationDeploymentReport
        [OperationContract(Name = "PopulatePilotApplicationDeploymentReport")]
        PilotApplicationDeploymentReportResponse PopulatePilotApplicationDeploymentReport(PilotApplicationDeploymentReportRequest Request);
        #endregion

        #region CheckPilotAppUser
        [OperationContract(Name = "CheckPilotAppUser")]
        ManupulateResponse CheckPilotAppUser(PilotAppUploadRepRequest Request);
        #endregion

        #region AppFocus
        [OperationContract(Name = "AddOffice")]
        ManupulateResponse AddOffice(AddOfficeManipulateRequest Request);
        #endregion

        #region PopulateACWCoralReport
        [OperationContract(Name = "PopulateACWReport")]
        ACWReportResponse PopulateACWReport(ACWReportRequest Request);
        #endregion PopulateACWCoralReport

        #region PopulateAppFIndicator
        [OperationContract(Name = "PopulateAppFIndicator")]
        AppFocusIndicatorResponse PopulateAppFIndicator();
        #endregion PopulateACWCoralReport

        #region PopulateGlobalAlert
        //[OperationContract(Name = "PopulateGlobalAlert")]
        //GlobalAlertResponse PopulateGlobalAlert();


        //[OperationContract(Name = "SearchLinkGlobalAlert")]
        ////SearchLinkResponse SearchLinkGlobalAlert();
        //SearchLinkResponse SearchLinkGlobalAlert(ClientGlobalAlertRequest Request);
        #endregion PopulateGlobalAlert

        #region Populate PendingApproval
        //[OperationContract(Name = "PopulatePendingApproval")]
        //PendingApprovalResponse PopulatePendingApproval(PendingApprovalRequest Request);
        #endregion

        #region Populate Transit Data
        [OperationContract(Name = "SearchTransitData")]
        TransitDataResponse SearchTransitData(TransitDataRequest Request);
        #endregion

        #region Manage Pending Approval
        //[OperationContract(Name = "ManagePendingApproval")]
        //ManupulateResponse ManagePendingApproval(ManagePendingApprovalRequest Request);
        #endregion

        //[OperationContract(Name = "GetAuditTrial")]
        //AuditTrialResponse GetAuditTrial(AuditTrialRequest Request);

        [OperationContract(Name = "GetAppLatestVersion")]
        GetAppLatestVersionResponse GetAppLatestVersion(GetAppLatestVersionRequest Request);
    }
}