﻿using System;
using System.IO;
using System.Text;
using System.Collections;
using System.DirectoryServices;
using System.Security.Principal;

//namespace FormsAuth
namespace AmericanExpress.GWiz.Service.ServiceImplimentation
{
    public class LdapAuthentication
    {
        private String _path;
        private String _filterAttribute;

        public LdapAuthentication()
        {
            //_path = path;
            //_path = "LDAP://inniit-tech/CN=Subhash Dutta,OU=Noida-CH,OU=Delhi,DC=IN,DC=NIIT-Tech,DC=com";
        }

        public bool IsAuthenticated(String sDomain, String sUser)
        {

            try
            {
                //Get the User's Domain and and User name
                String domainAndUsername;
                WindowsIdentity currIdentity = WindowsIdentity.GetCurrent();
                if ((sDomain.Trim() == "") && (sUser.Trim() == ""))
                    domainAndUsername = currIdentity.Name;
                else
                    domainAndUsername = sDomain + @"\" + sUser;

                String strDomain;
                String strUser;

                //Normally if the domain is present you get a string like DOMAINNAME\username, remove the domain
                int hasDomain = domainAndUsername.IndexOf(@"\");
                if (hasDomain > 0)
                {
                    strDomain = domainAndUsername.Split('\\')[0];
                    strUser = domainAndUsername.Remove(0, hasDomain + 1);
                }
                else
                {
                    strDomain = "inniit-tech";
                    strUser = domainAndUsername;
                }

                _path = "LDAP://" + strDomain;
                DirectoryEntry entry = new DirectoryEntry(_path);
                DirectorySearcher mySearcher = new DirectorySearcher(entry);
                mySearcher.Filter = ("(anr= " + strUser + ")");
                foreach (SearchResult result in mySearcher.FindAll())
                {
                    _path = result.GetDirectoryEntry().Path;
                    _filterAttribute = (String)result.Properties["cn"][0];
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error authenticating user. " + ex.Message);
            }

            return true;
        }

        public String GetGroups()
        {
            DirectorySearcher search = new DirectorySearcher(_path);
            search.Filter = "(cn=" + _filterAttribute + ")";
            search.PropertiesToLoad.Add("memberOf");
            StringBuilder groupNames = new StringBuilder();

            try
            {
                SearchResult result = search.FindOne();

                int propertyCount = result.Properties["memberOf"].Count;

                String dn;
                int equalsIndex, commaIndex;

                for (int propertyCounter = 0; propertyCounter < propertyCount; propertyCounter++)
                {
                    dn = (String)result.Properties["memberOf"][propertyCounter];

                    equalsIndex = dn.IndexOf("=", 1);
                    commaIndex = dn.IndexOf(",", 1);
                    if (-1 == equalsIndex)
                    {
                        return null;
                    }

                    groupNames.Append(dn.Substring((equalsIndex + 1), (commaIndex - equalsIndex) - 1));
                    groupNames.Append("|");

                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error obtaining group names. " + ex.Message);
            }
            return groupNames.ToString();
        }

        //public bool OpenDoc()
        //{
        //    try
        //    {
        //        SPSite site = new SPSite("http://3087k-ch-amex:1000/");
        //        SPWeb web = site.RootWeb;

        //        SPFile objFile;
        //        objFile = web.GetFile("http://3087k-ch-amex:1000/Shared%20Documents/GWiz_DB.xls");
        //        byte[] binFile = objFile.OpenBinary();
        //        FileStream fStream = new FileStream("E:\\Subhash\\" + objFile.Name, FileMode.Create);
        //        BinaryWriter w = new BinaryWriter(fStream);
        //        w.Write(binFile);
        //        w.Close();

        //        return true;
        //    }
        //    catch (Exception ex)
        //    {
        //        return false;
        //    }
        //}

    }
}
