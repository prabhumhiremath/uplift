﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AmericanExpress.GDU.Util.DataAccessHelper;

namespace AmericanExpress.GDU.Util.DBSchemaHelper
{
    public class DBStoredProcedure
    {
        Dictionary<string, DBParameter> _parameters;

        public Dictionary<string, DBParameter> Parameters
        {
            get { return _parameters; }
            set { _parameters = value; }
        }
        string _procName;

        public string ProcName
        {
            get { return _procName; }
            set { _procName = value; }
        }
    }
}
