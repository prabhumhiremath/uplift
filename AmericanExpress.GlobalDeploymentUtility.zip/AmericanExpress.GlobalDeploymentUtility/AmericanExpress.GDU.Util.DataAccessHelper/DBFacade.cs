﻿//-----------------------------------------------------------------------
// <copyright file="DBFacade.cs" company="NIIT Technologies">
//  Copyright (c) NIIT Technologies. All rights reserved.
// </copyright>
// <summary>
// <Description>Class encapsulates AmericanExpress.Util.RDBMSServices</Description>
// <Author>NIIT Technologies</Author>
// <CreatedOn>05/15/2009</CreatedOn>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// </summary>
//-----------------------------------------------------------------------
#region Using - Aliasing
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Data.Common;
using AmericanExpress.Util.RDBMSServices;
#endregion

namespace AmericanExpress.GDU.Util.DataAccessHelper
{
    /// <summary>
    /// Class representing Facade for Rdbms services
    /// </summary>
    public class DBFacade
    {
        #region Private class members
        private Dictionary<ParamTypes, DbType> _dbTypesAllowed;
        private Database _database = null;
        private DbConnection _connection = null;
        private DbTransaction _transaction = null;
        private int _commandTimeout = -1;
        #endregion

        #region Public methods
        /// <summary>
        /// public constructor for the class. The parameter should  exactly match the name specified in config file
        /// </summary>
        /// <param name="connectionName">databse reference name to connect to</param>
        public DBFacade(string connectionName)
        {
            Initialize();
            _database = DatabaseFactory.CreateDatabase(connectionName);

        }


        /// <summary>
        /// public overloaded constructor for the class,command timeout . The parameter should  exactly match the name specified in config file
        /// </summary>
        /// <param name="connectionName"></param>
        public DBFacade(string connectionName,int commandTimeout)
        {
            Initialize();
            _commandTimeout = commandTimeout;
            _database = DatabaseFactory.CreateDatabase(connectionName);

        }

        /// <summary>
        /// Exceutes commands on database with given parameters
        /// </summary>
        /// <param name="spName">name of teh stored procedure to execute</param>
        /// <param name="inputs">input and output parameter collection by ref</param>
        /// <returns>execution status of the command</returns>
        public int ExecuteSPAsNonQuery(string spName, ref DBParameter[] inputs)
        {
            DbCommand dbCommand = null;
            int intReturnValue;
            dbCommand = _database.GetStoredProcCommand(spName);

            if (_commandTimeout != -1)
            {
                dbCommand.CommandTimeout = _commandTimeout;
            }
            for (int i = 0; i < inputs.Length; i++)
            {
                if (inputs[i].Direction == ParamDirection.input)
                {
                    _database.AddInParameter(dbCommand, inputs[i].ParamName, _dbTypesAllowed[inputs[i].ParamType], inputs[i].Value);
                }
                else if (inputs[i].Direction == ParamDirection.output)
                {
                    _database.AddOutParameter(dbCommand, inputs[i].ParamName, _dbTypesAllowed[inputs[i].ParamType], inputs[i].Size);
                }
            }

            if (_transaction != null)
            {
                intReturnValue = _database.ExecuteNonQuery(dbCommand, _transaction);
            }
            else
            {
                intReturnValue = _database.ExecuteNonQuery(dbCommand);
            }

            for (int i = 0; i < inputs.Length; i++)
            {
                if (inputs[i].Direction == ParamDirection.output)
                {
                    inputs[i].Value = _database.GetParameterValue(dbCommand, inputs[i].ParamName).ToString();

                }
            }




            return intReturnValue;
        }

        /// <summary>
        /// Executes Stored Procedure and returns query output as dataset
        /// </summary>
        /// <param name="spName">Name of the stored procedure to execute</param>
        /// <param name="inputs">input and output parameter collection by ref</param>
        /// <returns>Dataset with query output</returns>
        public DataSet ExecuteSPForDataset(string spName, ref DBParameter[] inputs)
        {
            DataSet returnDataset = null;

            DbCommand dbCommand = _database.GetStoredProcCommand(spName);
            if (_commandTimeout != -1)
            {
                dbCommand.CommandTimeout = _commandTimeout;
            }
            if (inputs != null)
            {
                for (int i = 0; i < inputs.Length; i++)
                {
                    if (inputs[i].Direction == ParamDirection.input)
                    {
                        _database.AddInParameter(dbCommand, inputs[i].ParamName, _dbTypesAllowed[inputs[i].ParamType], inputs[i].Value);
                    }
                    else if (inputs[i].Direction == ParamDirection.output)
                    {
                        _database.AddOutParameter(dbCommand, inputs[i].ParamName, _dbTypesAllowed[inputs[i].ParamType], inputs[i].Size);
                    }
                }
            }
            if (_transaction != null)
            {
                returnDataset = _database.ExecuteDataSet(dbCommand, _transaction);
            }
            else
            {
                returnDataset = _database.ExecuteDataSet(dbCommand);
            }

            if (inputs != null)
            {
                for (int i = 0; i < inputs.Length; i++)
                {
                    if (inputs[i].Direction == ParamDirection.output)
                    {
                        inputs[i].Value = _database.GetParameterValue(dbCommand, inputs[i].ParamName).ToString();

                    }
                }
            }

            return returnDataset;
        }

        /// <summary>
        /// Executes stored proceudre at database and returns 
        /// data reader reference to the resultant records
        /// </summary>
        /// <param name="spName">Name of the stored procedure</param>
        /// <param name="inputs">input and output parameter collection by ref</param>
        /// <returns>Data Reader reference for the resulting records</returns>
        public IDataReader ExecuteSPForReader(string spName, ref DBParameter[] inputs)
        {
            IDataReader reader = null;
            DbCommand dbCommand = _database.GetStoredProcCommand(spName);
            if (_commandTimeout != -1)
            {
                dbCommand.CommandTimeout = _commandTimeout;
            }
            for (int i = 0; i < inputs.Length; i++)
            {
                if (inputs[i].Direction == ParamDirection.input)
                {
                    _database.AddInParameter(dbCommand, inputs[i].ParamName, _dbTypesAllowed[inputs[i].ParamType], inputs[i].Value);
                }
                else if (inputs[i].Direction == ParamDirection.output)
                {
                    _database.AddOutParameter(dbCommand, inputs[i].ParamName, _dbTypesAllowed[inputs[i].ParamType], inputs[i].Size);
                }
            }
            if (_transaction != null)
            {
                reader = _database.ExecuteReader(dbCommand, _transaction);
            }
            else
            {
                reader = _database.ExecuteReader(dbCommand);
            }
            return reader;

        }

        /// <summary>
        /// starts a transaction. Make sure to call RollBackTransaction or CommitTransaction method
        /// once this method is invoked.Throws AlreadyInTransaction exception if 
        /// previous transaction is not closed. Throws FailedToStartTransaction exception if fails to
        /// start a new transaction.
        /// </summary>
        public void BeginTransaction()
        {
            if (_transaction != null)
            {
                throw new AlreadyInTransaction();
            }
            _connection = _database.CreateConnection();
            _connection.Open();
            _transaction = _connection.BeginTransaction();
            if (_transaction == null)
            {
                throw new FailedToStartTransaction();
            }
        }

        /// <summary>
        /// Commits a transaction after executing this method, transaction cannot be rolled back
        /// </summary>
        public void CommitTransaction()
        {
            _transaction.Commit();
            _transaction = null;

			CloseConnection();
        }

		public void CloseConnection()
		{
			if (_connection != null)
				_connection.Close();
		}

        /// <summary>
        /// Undoes transactional changes
        /// </summary>
        public void RollBackTransaction()
        {
            _transaction.Rollback();
            _transaction = null;
			CloseConnection();
        }
        #endregion

        #region Private methods
        /// <summary>
        /// Initializes the dbtypes dictionary restricting types used
        /// </summary>
        private void Initialize()
        {
            _dbTypesAllowed = new Dictionary<ParamTypes, DbType>();
            _dbTypesAllowed.Add(ParamTypes.Integer, DbType.Int32);
            _dbTypesAllowed.Add(ParamTypes.Float, DbType.Decimal);
            _dbTypesAllowed.Add(ParamTypes.String, DbType.String);
            _dbTypesAllowed.Add(ParamTypes.DateTime, DbType.DateTime);
        }
        #endregion
    }
}
