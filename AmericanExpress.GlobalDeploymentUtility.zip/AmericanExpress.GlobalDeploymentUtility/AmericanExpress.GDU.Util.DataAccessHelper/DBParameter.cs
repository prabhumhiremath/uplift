﻿//-----------------------------------------------------------------------
// <copyright file="DBParameter.cs" company="NIIT Technologies">
//  Copyright (c) NIIT Technologies. All rights reserved.
// </copyright>
// <summary>
// <Description>Class encapsulates DB stored procedure Parameter</Description>
// <Author>NIIT Technologies</Author>
// <CreatedOn>05/15/2009</CreatedOn>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// </summary>
//-----------------------------------------------------------------------
#region Using - Aliasing
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
#endregion

namespace AmericanExpress.GDU.Util.DataAccessHelper
{
    /// <summary>
    /// Class represents stored procedure parameter
    /// </summary>
    public class DBParameter
    {
        #region Private class members
        private string _paramName;
        private ParamTypes _paramType;
        private object _value;
        private ParamDirection _direction;
        private int _size;
        #endregion

        #region Public methods
        /// <summary>
        /// Class constructor for instiantiating a new object of parameter
        /// </summary>
        /// <param name="paramName">parameter name generally starts with @</param>
        /// <param name="paramType">ParamTypes enumerator</param>
        /// <param name="value">object type</param>
        /// <param name="direction">ParamDirection enumerator</param>
        /// <param name="size">field size</param>
        public DBParameter(string paramName, ParamTypes paramType, object value, ParamDirection direction, int size)
        {
            this._paramName = paramName;
            this._paramType = paramType;
            this._value = value;
            this._direction = direction;
            this._size = size;
        }
        #endregion

        #region Public properties
        /// <summary>
        /// returns Parameter Name
        /// </summary>
        public string ParamName
        {
            get { return _paramName; }
        }

        /// <summary>
        /// Returns parameter type - ParamTypes enumerator value
        /// </summary>
        public ParamTypes ParamType
        {
            get { return _paramType; }
        }

        /// <summary>
        /// Sets and gets parameter value
        /// </summary>
        public object Value
        {
            get { return this._value; }
            set { this._value = value; }
        }

        /// <summary>
        /// returns parameter direction ParamDirection enumerator type value
        /// </summary>
        public ParamDirection Direction
        {
            get { return _direction; }
        }
        public int Size
        {
            get { return _size; }
        }
        #endregion
    }
}
