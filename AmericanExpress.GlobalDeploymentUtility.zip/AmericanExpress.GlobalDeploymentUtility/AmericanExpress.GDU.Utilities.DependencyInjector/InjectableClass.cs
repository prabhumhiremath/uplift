﻿//-----------------------------------------------------------------------
// <copyright file="InjectableClass.cs" company="NIIT Technologies">
//  Copyright (c) NIIT Technologies. All rights reserved.
// </copyright>
// <summary>
// <Description>Class to be extended by objects that support dependency injection</Description>
// <Author>NIIT Technologies</Author>
// <CreatedOn>05/15/2009</CreatedOn>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// </summary>
//-----------------------------------------------------------------------

#region Namespace - Aliasing
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;
using System.Configuration;
#endregion

namespace AmericanExpress.GDU.Utilities.DependencyInjector
{
    /// <summary>
    /// Abstract class to be extended by classes that need to support dependency injection
    /// </summary>
    public abstract class InjectableClass
    {
        #region Private class members
        private string _libraryName = string.Empty;
        #endregion

        #region Public methods
        /// <summary>
        /// Class constructor that enables injection. 
        /// This constructor will never be called directly
        /// </summary>
        public InjectableClass()
        {

            inject();
        }
        #endregion

        #region private methods
        /// <summary>
        /// helper method for enabling injection
        /// </summary>
        internal virtual void inject()
        {
            Type type = this.GetType();
            InjectionDependencyAttribute injectionDependencyAttribute = null;
            PropertyInfo servicePropertyInfo = null;
            PropertyInfo[] props = type.GetProperties();
            string implementationlibraryName=string.Empty;
            foreach (PropertyInfo prop in props)
            {
                object[] attributes = prop.GetCustomAttributes(false);

                foreach (object attribute1 in attributes)
                {
                    if (attribute1 is InjectionDependencyAttribute)
                    {

                        injectionDependencyAttribute = (InjectionDependencyAttribute)attribute1;
                        servicePropertyInfo = prop;

                        break;
                    }
                }

                if (injectionDependencyAttribute != null)
                {
                    implementationlibraryName = ConfigurationManager.AppSettings[injectionDependencyAttribute.ImplementationLibrary].ToString();
                    break;
                }
            }
            object obj = getObject(implementationlibraryName, servicePropertyInfo.PropertyType);
            servicePropertyInfo.SetValue(this, obj, null);


        }

        /// <summary>
        ///   Factory method for creating object of a given type from a given assembly
        /// </summary>
        /// <param name="assemblyName"></param>
        /// <param name="typeName"></param>
        /// <returns></returns>
        private static object getObject(string assemblyName, Type typeName)
        {
            Assembly asm = Assembly.Load(assemblyName);
            object obj = null;
            Type[] types = asm.GetTypes();
            foreach (Type typ in types)
            {
                Type[] interfaceTypes = typ.GetInterfaces();

                foreach (Type type in interfaceTypes)
                {
                    if (type.Name.Equals(typeName.Name))
                    {
                        obj = asm.CreateInstance(assemblyName + "." + typ.Name);
                        break;
                    }

                }
                if (obj != null)
                {
                    break;
                }
            }

            return obj;
        }

        #endregion
    }

  }

