﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AmericanExpress.GDU.Utilities.ExceptionMgmt
{
    public class Constants
    {
        public const string EXCEPTIONS_INFORMATION_FILE_PATH = "ExceptionFilePath";
        public const string EXCEPTIONS_XML_ELEMENT_NAME = "Name";
        public const string EXCEPTIONS_XML_ELEMENT_CODE = "ErrorCode";
        public const string EXCEPTIONS_XML_ELEMENT_MSG = "ErrorMsg";
    }
}
