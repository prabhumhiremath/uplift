﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AmericanExpress.GDU.Utilities.ExceptionMgmt
{
    public class UIException : Exception
    {
        public UIException() : base() { }
        public UIException(string message) : base(message) { }
    }

    public class InvalidCarrierException : UIException
    {
        public InvalidCarrierException(string message): base(message){}
    }
}
