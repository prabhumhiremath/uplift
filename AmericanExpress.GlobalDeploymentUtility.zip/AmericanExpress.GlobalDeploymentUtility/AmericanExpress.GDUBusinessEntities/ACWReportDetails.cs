﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AmericanExpress.GDU.BusinessEntities
{
   public class ACWReportDetails
    {
       public StandardResponse STDResponse
       {
           get;
           set;
       }

       public string ADSId
       {
           get;
           set;
       }

       public string Server
       {
           get;
           set;
       }

       public string StartDt
       {
           get;
           set;
       }

       public string EndDt
       {
           get;
           set;
       }

       public string TIMEZONE
       {
           get;
           set;
       }

       public string ACWDuration
       {
           get;
           set;
       }
    }
}
