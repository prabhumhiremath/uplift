﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AmericanExpress.GDU.BusinessEntities
{
  public  class ACWReportInput
  {
      #region public properties

      public StandardInput STDinput
      {
          get;
          set;  
      }

      public string AppName
      {
          get;
          set;
      }

      public string FromDate
      {
          get;
          set;
      }

      public string ToDate
      {
          get;
          set;
      }

      public string OfficeId
      {
          get;
          set;
      }

      public string UserName
      {
          get;
          set;  
      }

      public int GroupId
      {
          get;
          set;  
      }

      #endregion
  }
}
