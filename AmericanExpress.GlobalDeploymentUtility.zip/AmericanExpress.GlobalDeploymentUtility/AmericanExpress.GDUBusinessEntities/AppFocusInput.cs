﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AmericanExpress.GDU.BusinessEntities
{
    public class AppFocusInput
    {
        public StandardResponse STDResponse
        {
            get;
            set;
        }

        public string xmlData
        {
            get;
            set;
        }
        public string Computer_Name
        {
            get;
            set;
        }

        public string IP
        {
            get;
            set;
        }

        public string ADS_ID
        {
            get;
            set;
        }
    }
}
