﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AmericanExpress.GDU.BusinessEntities
{
    public class AppUploadedReportInput
    {
        public StandardResponse STDResponse
        {
            get;
            set;
        }

        public string UserId
        {
            get;
            set;
        }

        public string Version
        {
            get;
            set;
        }

        public string From_Dt
        {
            get;
            set;
        }

        public string To_Date
        {
            get;
            set;
        }

        public string RollBack
        {
            get;
            set;
        }

        public int App_ID
        {
            get;
            set;
        }

        public string IP
        {
            get;
            set;
        }

        public string Upload_Dt
        {
            get;
            set;
        }

        public string User_Name
        {
            get;
            set;
        }

        public string APP_TYPE
        {
            get;
            set;
        }
       
        public int CurrentPage
        {
            get;
            set;
        }
       
        public int PageSize
        {
            get;
            set;
        }
        
        public string SortExpression
        {
            get;
            set;
        }
       
        public string SortOrder
        {
            get;
            set;
        }
    }
}
