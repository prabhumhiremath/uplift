﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AmericanExpress.GDU.BusinessEntities
{
    public class AppUserDetails
    {

        public string UserId
        {
            get;
            set;
        }

        public string UserName
        {
            get;
            set;
        }

        /// <summary>
        /// 
        /// </summary>
        public string AppName
        {
            get;
            set;
        }

        public string Role_CD
        {
            get;
            set;
        }

        public int App_ID
        {
            get;
            set;
        }

        /// <summary>
        /// 
        /// </summary>
        public bool IsDeactive
        {
            get;
            set;
        }

        public string EntryPoint
        {
            get;
            set;
        }

        public string InFlag
        {
            get;
            set;
        }

        public int TotalRecords
        {
            get;
            set;
        }
    }
}
