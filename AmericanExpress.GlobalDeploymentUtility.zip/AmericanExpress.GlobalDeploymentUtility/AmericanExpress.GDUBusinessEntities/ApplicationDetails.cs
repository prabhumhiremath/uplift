﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AmericanExpress.GDU.BusinessEntities
{
    public class ApplicationDetails
    {
        public StandardResponse STDResponse
        {
            get;
            set;
        }
        public int AppID
        {
            get;
            set;
        }
        public string AppDeployPath
        {
            get;
            set;
        }
        public string AppAbbrName
        {
            get;
            set;
        }

        public string AppExeName
        {
            get;
            set;
        }

        public string AppAbbr
        {
            get;
            set;
        }

        public string EntryPoint
        {
            get;
            set;
        }

        public string App_Type
        {
            get;
            set;
        }


    }
}
