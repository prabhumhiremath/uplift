﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AmericanExpress.GDU.BusinessEntities
{
   public class ClientRelease
    {
       public ClientReleaseInput ClientReleaseVer
       {
           get;
           set;
       }

       public ClientReleaseDtlInput[] ClientReleaseDtl
       {
           get;
           set;
       }
    }
}
