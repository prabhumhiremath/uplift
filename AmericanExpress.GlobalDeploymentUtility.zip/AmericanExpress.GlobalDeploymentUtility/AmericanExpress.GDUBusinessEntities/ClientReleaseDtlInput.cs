﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AmericanExpress.GDU.BusinessEntities
{
   public class ClientReleaseDtlInput
    {
       /// <summary>
       /// 
       /// </summary>
       public Int64 RELEASE_ID
       {
           get;
           set;
       }
       /// <summary>
       /// 
       /// </summary>
       public string FILE_NM
       {
           get;
           set;
       }
       /// <summary>
       /// 
       /// </summary>
       public string FILE_VERSION
       {
           get;
           set;
       }
       /// <summary>
       /// 
       /// </summary>
       public string FILE_PATH
       {
           get;
           set;
       }
       /// <summary>
       /// 
       /// </summary>
       public string CREATED_USER_ID
       {
           get;
           set;
       }
       /// <summary>
       /// 
       /// </summary>
       public DateTime CREATED_DT
       {
           get;
           set;
       }
       /// <summary>
       /// 
       /// </summary>
       public string MODIFIED_USER_ID
       {
           get;
           set;
       }
       /// <summary>
       /// 
       /// </summary>
       public DateTime MODIFIED_DT
       {
           get;
           set;

       }
    }
}
