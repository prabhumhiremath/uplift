﻿//-----------------------------------------------------------------------
// <copyright file="ClientUsageInput.cs" company="NIIT Technologies">
//  Copyright (c) NIIT Technologies. All rights reserved.
// </copyright>
// <summary>
// <Description>This a CityInput class which contains attributes for CityInput</Description>
// <Author>NIIT Technologies</Author>
// <CreatedOn>15/02/2010</CreatedOn>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// </summary>
//-----------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AmericanExpress.GDU.BusinessEntities
{
    public class ClientUsageInput
    {
        /// <summary>
        /// 
        /// </summary>
        public StandardResponse STDResponse
        {
            get;
            set;
        }
        /// <summary>
        /// Gets or Stes the TransID
        /// </summary>
        public int TransID
        {
            get;
            set;
        }
        /// <summary>
        /// Gets or Stes the IPAddress.
        /// </summary>
        public string IP
        {
            get;
            set;
        }
        /// <summary>
        /// Gets or sets the NACId.
        /// </summary>
        public string NACId
        {
            get;
            set;
        }
        /// <summary>
        /// Gets or sets the ExeVersion.
        /// </summary>        
        public string Version
        {
            get;
            set;
        }
        /// <summary>
        /// Gets or sets the ExeTimeStamp.
        /// </summary>
        public string Start_DT
        {
            get;
            set;
        }
        /// <summary>
        /// Gets or Stes the TimeStamp.
        /// </summary>
        public string End_DT
        {
            get;
            set;
        }
        /// <summary>
        /// Gets or Sets the Computer Name.
        /// </summary>
        public string ComputerName
        {
            get;
            set;
        }

        public string TotalUsage
        {
            get;
            set;
        }

        public string System_CD
        {
            get;
            set;
        }

        public int App_ID
        {
            get;
            set;
        }
    }
}
