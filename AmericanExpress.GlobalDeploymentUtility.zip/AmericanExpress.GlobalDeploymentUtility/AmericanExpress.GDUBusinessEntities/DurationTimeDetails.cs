﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AmericanExpress.GDU.BusinessEntities
{
   public class DurationTimeDetails
    {
        
        /// <summary>
        /// 
        /// </summary>
        public int TimeDuration
        {
            get;
            set;
        }

        public Char TimeFormat
        {
            get;
            set;
        }      
    }
}
