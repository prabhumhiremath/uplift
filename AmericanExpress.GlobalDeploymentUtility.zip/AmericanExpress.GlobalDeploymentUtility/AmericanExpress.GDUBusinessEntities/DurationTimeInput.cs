﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AmericanExpress.GDU.BusinessEntities
{
   public class DurationTimeInput
    {
        #region Public Properties
        /// <summary>
        /// 
        /// </summary>

        public int TimeDuration
        {
            get;
            set;
        }
        public string UserId
        {
            get;
            set;
        }

        public Char TimeFormat
        {
            get;
            set;
        }
        #endregion
    }
}
