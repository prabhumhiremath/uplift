﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AmericanExpress.GDU.BusinessEntities
{
   public class FocusAppInput
    {
       public string App_DESC
       {
           get;
           set;
       }
        public string App_ID
        {
            get;
            set;
        }
        public int ID
        {
            get;
            set;
        }
       
        public int CurrentPage
        {
            get;
            set;
        }
        
        public int PageSize
        {
            get;
            set;
        }
        
        public string SortExpression
        {
            get;
            set;
        }
        
        public string SortOrder
        {
            get;
            set;
        }
    }
}
