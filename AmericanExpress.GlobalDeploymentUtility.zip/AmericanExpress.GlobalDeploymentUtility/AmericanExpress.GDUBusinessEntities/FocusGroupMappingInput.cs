﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AmericanExpress.GDU.BusinessEntities
{
    public class FocusGroupMappingInput
    {
        public int GROUP_ID
        {
            get;
            set;
        }
        public string OFFICE_ID
        {
            get;
            set;
        }
        public string OFFICE_DS
        {
            get;
            set;
        }
        public string CreatedUserID
        {
            get;
            set;
        }
    }
    public class AppFOfficeAdsMappingID
    {
        public StandardInput STDinput
        {
            get;
            set;
        }
        public int TYPE
        {
            get;
            set;
        }
        public string ADS_ID
        {
            get;
            set;
        }
        public string OFFICE_ID
        {
            get;
            set;
        }
        public int GROUP_ID
        {
            get;
            set;
        }
        public string CreatedUserID
        {
            get;
            set;
        }
    }
}
