﻿//-----------------------------------------------------------------------
// <copyright file="LanguageDetails.cs" company="NIIT Technologies">
//  Copyright (c) NIIT Technologies. All rights reserved.
// </copyright>
// <summary>
// <Description>This a LanguageDetails class which contains attributes for LanguageDetails</Description>
// <Author>NIIT Technologies</Author>
// <CreatedOn>11/16/2009</CreatedOn>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// </summary>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AmericanExpress.GDU.BusinessEntities
{
    /// <summary>
    /// 
    /// </summary>
    public class LanguageDetails
    {
        /// <summary>
        /// 
        /// </summary>
        public StandardResponse STDResponse
        {
            get;
            set;
        }
        /// <summary>
        /// 
        /// </summary>
        public string LanguageCode
        {
            get;
            set;
        }

        /// <summary>
        /// 
        /// </summary>
        public string LanguageName
        {
            get;
            set;
        }

        public string DomainName
        {
            get;
            set;
        }
        /// <summary>
        /// 
        /// </summary>
        public string CreatedUserID
        {
            get;
            set;
        }

        /// <summary>
        /// 
        /// </summary>
        public string ModifiedUserID
        {
            get;
            set;
        }

        /// <summary>
        /// 
        /// </summary>
        public string MacID
        {
            get;
            set;
        }


        /// <summary>
        /// 
        /// </summary>
        public DateTime CreatedUserDate
        {
            get;
            set;
        }
        /// <summary>
        /// 
        /// </summary>
        public DateTime ModifiedUserDate
        {
            get;
            set;
        }

        ///<summary>
        /// 
        /// </summary>
        public string IPAddress
        {
            get;
            set;
        }

        ///<summary>
        /// 
        /// </summary>
        public string ComputerName
        {
            get;
            set;
        } 


    }
}
