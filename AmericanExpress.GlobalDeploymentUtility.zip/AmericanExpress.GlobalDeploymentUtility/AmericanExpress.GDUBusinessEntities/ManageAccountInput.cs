﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AmericanExpress.GDU.BusinessEntities
{
   public class ManageAccountInput
    {
       public string AccountType
       {
           get;
           set;
       }
        /// <summary>
        /// 
        /// </summary>
        public string AccountCode
        {
            get;
            set;
        }
        /// <summary>
        /// 
        /// </summary>
        public string AccountName
        {
            get;
            set;
        }
        /// <summary>
        /// 
        /// </summary>
        public bool  IsVirtual
        {
            get;
            set;
        }

        /// <summary>
        /// 
        /// </summary>
        public bool IsGlobal
        {
            get;
            set;
        }

        /// <summary>
        /// 
        /// </summary>
        public int ClientID
        {
            get;
            set;
        }
        /// <summary>
        /// 
        /// </summary>
        public string Mode
        {
            get;
            set;
        }
        /// <summary>
        /// 
        /// </summary>
        public string CreatedUserID
        {
            get;
            set;
        }

        /// <summary>
        /// 
        /// </summary>
        public string ModifiedUserID
        {
            get;
            set;
        }

        /// <summary>
        /// 
        /// </summary>
        public string MacID
        {
            get;
            set;
        }


        /// <summary>
        /// 
        /// </summary>
        public DateTime CreatedUserDate
        {
            get;
            set;
        }
        /// <summary>
        /// 
        /// </summary>
        public DateTime ModifiedUserDate
        {
            get;
            set;
        }

        ///<summary>
        /// 
        /// </summary>
        public String IPAddress
        {
            get;
            set;
        }

        ///<summary>
        /// 
        /// </summary>
        public String ComputerName
        {
            get;
            set;
        }

        /// <summary>
        /// 
        /// </summary>
        public bool IsDeactive
        {
            get;
            set;
        }
    }
}
