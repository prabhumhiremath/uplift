﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace AmericanExpress.GDU.BusinessEntities
{
 
    public class ManageRoleInput
    {
        
     
        public Int32 ClientId
        {
            get;
            set;
        }

        public string RoleId
        {
            get;
            set;
        }


      
        public string RoleName
        {
            get;
            set;
        }

       
   
      
        public bool IsDeactive
        {
            get;
            set;
        }

        public Int32 FunctionId
        {
            get;
            set;
        }

      

        public string CreatedBy
        {
            get;
            set;
        }

   

        public DateTime ModifiedDt
        {
            get;
            set;
        }

  

        public string Flag
        {
            get;
            set;
        }

       

        public string AuthorizedFunctionIds
        {
            get;
            set;
        }

        public string RoleTypeCD
        {
            get;
            set;
        }

        public string System_CD
        {
            get;
            set;
        }
       
        public int CurrentPage
        {
            get;
            set;
        }
        
        public int PageSize
        {
            get;
            set;
        }
        
        public string SortExpression
        {
            get;
            set;
        }
        
        public string SortOrder
        {
            get;
            set;
        }
    }
}
