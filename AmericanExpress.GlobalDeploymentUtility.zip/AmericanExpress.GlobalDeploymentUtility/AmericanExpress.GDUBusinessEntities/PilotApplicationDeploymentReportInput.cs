﻿//-----------------------------------------------------------------------
// <copyright file="ClientDeployementInput.cs" company="NIIT Technologies">
//  Copyright (c) NIIT Technologies. All rights reserved.
// </copyright>
// <summary>
// <Description>This a CityInput class which contains attributes for CityInput</Description>
// <Author>NIIT Technologies</Author>
// <CreatedOn>15/02/2010</CreatedOn>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// </summary>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AmericanExpress.GDU.BusinessEntities
{
    public class PilotApplicationDeploymentReportInput
    {

        #region Public Properties
        /// <summary>
        /// 
        /// </summary>
        public StandardResponse STDResponse
        {
            get;
            set;
        }
        /// <summary>
        /// 
        /// </summary>
        /// 
        public string UserId
        {
            get;
            set;
        }

        public string Version
        {
            get;
            set;
        }

        public int NonMaxFlag
        {
            get;
            set;
        }
        public string clientId
        {
            get;
            set;
        }

        public string System_CD
        {
            get;
            set;
        }

        public string App_ID
        {
            get;
            set;
        }
        
        public int PageIndex
        {
            get;
            set;
        }
        
        public int PageSize
        {
            get;
            set;
        }
        
        public string SortColumn
        {
            get;
            set;
        }
        
        public string SortOrder
        {
            get;
            set;
        }

        #endregion
    }
}
