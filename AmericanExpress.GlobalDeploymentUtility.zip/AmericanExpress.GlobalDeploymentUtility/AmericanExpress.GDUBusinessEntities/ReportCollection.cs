﻿//-----------------------------------------------------------------------
// <copyright file="ReportCollection.cs" company="NIIT Technologies">
//  Copyright (c) NIIT Technologies. All rights reserved.
// </copyright>
// <summary>
// <Description>This a ReportCollection class which contains attributes for ReportCollection</Description>
// <Author>NIIT Technologies</Author>
// <CreatedOn>11/23/2009</CreatedOn>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// </summary>
//-----------------------------------------------------------------------

using System;
using AmericanExpress.GDU.BusinessEntities;

public class ReportCollection
{
    /// <summary>
    /// 
    /// </summary>
    public StandardResponse STDResponse
    {
        get;
        set;
    }
    public string Account
    {
        get;
        set;
    }
    public string Country
    {
        get;
        set;
    }
    public string City
    {
        get;
        set;
    }
    public string lc_Link_Type
    {
        get;
        set;
    }
    public string lc_Label
    {
        get;
        set;
    }
    public string lc_Link
    {
        get;
        set;
    }
    public string lc_File_Path
    {
        get;
        set;
    }
    public string lc_Language
    {
        get;
        set;
    }
    public string lc_Hover_Txt
    {
        get;
        set;
    }
    public string lcd_Link_Type
    {
        get;
        set;
    }
    public string lcd_Label
    {
        get;
        set;
    }
    public string lcd_Link
    {
        get;
        set;
    }
    public string lcd_File_Path
    {
        get;
        set;
    }
    public string lcd_Language
    {
        get;
        set;
    }
    public string lcd_Hover_Txt
    {
        get;
        set;
    }
}
