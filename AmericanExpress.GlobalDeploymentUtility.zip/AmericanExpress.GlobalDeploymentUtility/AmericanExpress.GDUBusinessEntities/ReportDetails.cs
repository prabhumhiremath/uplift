﻿//-----------------------------------------------------------------------
// <copyright file="ReportDetails.cs" company="NIIT Technologies">
//  Copyright (c) NIIT Technologies. All rights reserved.
// </copyright>
// <summary>
// <Description>This a ReportDetails class which contains attributes for ReportDetails</Description>
// <Author>NIIT Technologies</Author>
// <CreatedOn>11/23/2009</CreatedOn>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// </summary>
//-----------------------------------------------------------------------

using System;

namespace AmericanExpress.GDU.BusinessEntities
{
    public class ReportDetails
    {
        /// <summary>
        /// 
        /// </summary>
        public StandardResponse STDResponse
        {
            get;
            set;
        }
        public string Link_ID
        {
            get;
            set;
        }
        public string Link_Dtl_ID
        {
            get;
            set;
        }
        public string Link_Cat_Dtl_ID
        {
            get;
            set;
        }
        public string Account
        {
            get;
            set;
        }
        public string Country
        {
            get;
            set;
        }
        public string City
        {
            get;
            set;
        }
        public string lc_Link_Type
        {
            get;
            set;
        }
        public string lc_LinkType_NM
        {
            get;
            set;
        }
        public string lc_file_type
        {
            get;
            set;
        }
        public string lc_Label
        {
            get;
            set;
        }
        public string lc_Link
        {
            get;
            set;
        }

        public string lc_Language
        {
            get;
            set;
        }
        public string lc_Hover_Txt
        {
            get;
            set;
        }
        public string lcd_Link_Type
        {
            get;
            set;
        }
        public string lcd_Label
        {
            get;
            set;
        }
        public string lcd_Link
        {
            get;
            set;
        }
        public string lcd_File_Path
        {
            get;
            set;
        }
        public string lcd_Hover_Txt
        {
            get;
            set;
        }
        public string lcd_language
        {
            get;
            set;
        }

        /// <summary>
        /// 
        /// </summary>
        public string CreatedUserID
        {
            get;
            set;
        }

        /// <summary>
        /// 
        /// </summary>
        public string ModifiedUserID
        {
            get;
            set;
        }

        /// <summary>
        /// 
        /// </summary>
        public string MacID
        {
            get;
            set;
        }


        /// <summary>
        /// 
        /// </summary>
        public DateTime CreatedUserDate
        {
            get;
            set;
        }
        /// <summary>
        /// 
        /// </summary>
        public DateTime ModifiedUserDate
        {
            get;
            set;
        }

        ///<summary>
        /// 
        /// </summary>
        public string IPAddress
        {
            get;
            set;
        }

        ///<summary>
        /// 
        /// </summary>
        public string ComputerName
        {
            get;
            set;
        }
        public string Client
        {
            get;
            set;
        }
    }
}