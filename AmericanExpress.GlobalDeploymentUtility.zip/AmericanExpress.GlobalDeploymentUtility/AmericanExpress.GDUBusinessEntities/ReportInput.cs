﻿//-----------------------------------------------------------------------
// <copyright file="ReportInput.cs" company="NIIT Technologies">
//  Copyright (c) NIIT Technologies. All rights reserved.
// </copyright>
// <summary>
// <Description>This a ReportInput class which contains attributes for ReportInput</Description>
// <Author>NIIT Technologies</Author>
// <CreatedOn>11/23/2009</CreatedOn>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// </summary>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AmericanExpress.GDU.BusinessEntities
{
    public class ReportInput
    {
        /// <summary>
        /// 
        /// </summary>
        public StandardResponse STDResponse
        {
            get;
            set;
        }
        public string strAccount
        {
            get;
            set;
        }

        public string strCountry
        {
            get;
            set;
        }

        public string strCity
        {
            get;
            set;
        }
        public string strOtherInfo
        {
            get;
            set;
        }
        public string strClientId
        {
            get;
            set;
        }
    }
}