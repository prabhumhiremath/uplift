﻿//-----------------------------------------------------------------------
// <copyright file="AccountDetails.cs" company="NIIT Technologies">
//  Copyright (c) NIIT Technologies. All rights reserved.
// </copyright>
// <summary>
// <Description>This a AccountDetails class which contains attributes for AccountDetails.</Description>
// <Author>NIIT Technologies</Author>
// <CreatedOn>11/03/2009</CreatedOn>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// </summary>
//-----------------------------------------------------------------------


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AmericanExpress.GDU.BusinessEntities
{
   
   public class RoleDetails
    {
       /// <summary>
       /// 
       /// </summary>
       /// 

       public StandardResponse STDResponse
       {
           get;
           set;
       }
        
        public string RoleClientId
        {
            get;
            set;
        }


       
        public string RoleName
        {
            get;
            set;
        }

        public string RoleClientAbbr
        {
            get;
            set;
        }
    }
}
