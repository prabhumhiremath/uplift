﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AmericanExpress.GDU.BusinessEntities
{
  public  class RoleMasterDetails
    {
        /// <summary>
        /// 
        /// </summary>
        public StandardResponse STDResponse
        {
            get;
            set;
        }
        public string RoleCD
      {
          get;
          set;
      }
      public string RoleName
      {
          get;
          set;
      }
     
    }
}
