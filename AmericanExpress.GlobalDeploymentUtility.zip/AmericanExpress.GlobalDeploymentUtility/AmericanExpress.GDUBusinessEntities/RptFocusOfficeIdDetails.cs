﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AmericanExpress.GDU.BusinessEntities
{
   public class RptFocusOfficeIdDetails
    {
        public StandardResponse STDResponse
        {
            get;
            set;
        }
        public string OfficeID
        {
            get;
            set;
        }

        public string Office_DESC
        {
            get;
            set;
        }
    }
}
