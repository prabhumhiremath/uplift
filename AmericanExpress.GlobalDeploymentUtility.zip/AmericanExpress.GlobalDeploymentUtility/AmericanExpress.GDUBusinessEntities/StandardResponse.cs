﻿//-----------------------------------------------------------------------
// <copyright file="StandardResponse.cs" company="NIIT Technologies">
//  Copyright (c) NIIT Technologies. All rights reserved.
// </copyright>
// <summary>
// <Description>This a StandardResponse class which contains attributes for StandardResponse</Description>
// <Author>NIIT Technologies</Author>
// <CreatedOn>11/06/2009</CreatedOn>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// </summary>
//-----------------------------------------------------------------------


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AmericanExpress.GDU.BusinessEntities
{

    /// <summary>
    /// status enumeration
    /// </summary>
    public enum StdResponseCode
    {
        Success,
        Failed
    }
    /// <summary>
    /// Std response class, a part of all message contracts
    /// </summary>
   public class StandardResponse
    {
        #region Public Properties
        /// <summary>
        /// standard response code 
        /// </summary>
        public StdResponseCode ResponseCodeStatus
        {
            get;
            set;
        }

        /// <summary>
        /// response message
        /// </summary>
        public string ResponseMessage
        {
            get;
            set;
        }
        #endregion
    }
}
