﻿//-----------------------------------------------------------------------
// <copyright file="TransactionIdInput.cs" company="NIIT Technologies">
//  Copyright (c) NIIT Technologies. All rights reserved.
// </copyright>
// <summary>
// <Description>This a TransactionIdInput class which contains attributes for TransactionIdInput</Description>
// <Author>NIIT Technologies</Author>
// <CreatedOn>11/10/2009</CreatedOn>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// </summary>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AmericanExpress.GDU.BusinessEntities
{
   public class TransactionIdInput
    {
        /// <summary>
        /// 
        /// </summary>
        public string AccountCode
        {
            get;
            set;
        }
        /// <summary>
        /// 
        /// </summary>
        public string CountryCode
        {
            get;
            set;
        }
        /// <summary>
        /// 
        /// </summary>
        public string CityCode
        {
            get;
            set;
        }
        /// <summary>
        /// 
        /// </summary>
        public string OtherInfoCode
        {
            get;
            set;
        }
        public string GlobalCatCode
        {
            get;
            set;
        }
        /// <summary>
        /// 
        /// </summary>
        public string CarrierCode
        {
            get;
            set;
        }

        public string DomainName
        {
            get;
            set;
        }

        public string ComputerName
        {
            get;
            set;
        }

        /// <summary>
        /// 
        /// </summary>

        public string IPAddress
        {
            get;
            set;
        }

        /// <summary>
        /// 
        /// </summary>

        public string CreatedUserID
        {
            get;
            set;
        }

        /// <summary>
        /// 
        /// </summary>

        public string ModifiedUserID
        {
            get;
            set;
        }

        /// <summary>
        /// 
        /// </summary>

        public string MacID
        {
            get;
            set;
        }

        /// <summary>
        /// 
        /// </summary>

        public DateTime CreatedUserDate
        {
            get;
            set;
        }
        /// <summary>
        /// 
        /// </summary>

        public DateTime ModifiedUserDate
        {
            get;
            set;
        }
       
        public int clientID
        {
            get;
            set;
        }
    }
}
