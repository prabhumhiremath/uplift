﻿//-----------------------------------------------------------------------
// <copyright file="TransitDataDetails.cs" company="NIIT Technologies">
//  Copyright (c) NIIT Technologies. All rights reserved.
// </copyright>
// <summary>
// <Description>This a AccountDetails class which contains attributes for Transit Data Details.</Description>
// <Author>NIIT Technologies</Author>
// <CreatedOn>05/08/2012</CreatedOn>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// </summary>
//-----------------------------------------------------------------------


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
namespace AmericanExpress.GDU.BusinessEntities
{
    public class TransitDataDetails
    {
        public string filePath
        {
            get;
            set;
        }
    }
}
