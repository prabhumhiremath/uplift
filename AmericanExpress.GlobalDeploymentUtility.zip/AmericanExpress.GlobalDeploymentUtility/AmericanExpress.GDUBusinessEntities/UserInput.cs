﻿//-----------------------------------------------------------------------
// <copyright file="UserInput.cs" company="NIIT Technologies">
//  Copyright (c) NIIT Technologies. All rights reserved.
// </copyright>
// <summary>
// <Description>This a UserInput class which contains attributes for UserInput</Description>
// <Author>NIIT Technologies</Author>
// <CreatedOn>11/23/2009</CreatedOn>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// </summary>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AmericanExpress.GDU.BusinessEntities
{
    public class UserInput
    {

        /// <summary>
        /// 
        /// </summary>
        public string UserId
        {
            get;
            set;
        }

        /// <summary>
        /// 
        /// </summary>
        public string UserName
        {
            get;
            set;
        }
        /// <summary>
        /// 
        /// </summary>
        public string Language
        {
            get;
            set;
        }
        /// <summary>
        /// 
        /// </summary>
        public string LanguageCode
        {
            get;
            set;
        }

        /// <summary>
        /// 
        /// </summary>
        public string EmailAddress
        {
            get;
            set;
        }
        /// <summary>
        /// 
        /// </summary>
        public string UserRole
        {
            get;
            set;
        }
        /// <summary>
        /// 
        /// </summary>
        public string UserRoleCode
        {
            get;
            set;
        }

        /// <summary>
        /// 
        /// </summary>
        public string DomainName
        {
            get;
            set;
        }

        /// <summary>
        /// 
        /// </summary>
        public string Mode
        {
            get;
            set;
        }

        /// <summary>
        /// 
        /// </summary>
        public string CreatedUserID
        {
            get;
            set;
        }

        /// <summary>
        /// 
        /// </summary>
        public string ModifiedUserID
        {
            get;
            set;
        }

        /// <summary>
        /// 
        /// </summary>
        public string MacID
        {
            get;
            set;
        }


        /// <summary>
        /// 
        /// </summary>
        public DateTime CreatedUserDate
        {
            get;
            set;
        }
        /// <summary>
        /// 
        /// </summary>
        public DateTime ModifiedUserDate
        {
            get;
            set;
        }

        ///<summary>
        /// 
        /// </summary>
        public String IPAddress
        {
            get;
            set;
        }

        ///<summary>
        /// 
        /// </summary>
        public String ComputerName
        {
            get;
            set;
        }

        /// <summary>
        /// 
        /// </summary>
        public bool IsDeactive
        {
            get;
            set;
        }

        /// <summary>
        /// 
        /// </summary>
        public Int32 ClientId
        {
            get;
            set;
        }

        /// <summary>
        /// 
        /// </summary>
        public string AuthorizedRoleIds
        {
            get;
            set;
        }

        public string System_CD
        {
            get;
            set;
        }


        public Int32 DefaultClientID
        {
            get;
            set;
        }

 
        public int App_ID
        {
            get;
            set;
        }

     
        public string IsGrouping
        {
            get;
            set;
        }

      
        public string RequestedBy
        {
            get;
            set;
        }
        
        public int CurrentPage
        {
            get;
            set;
        }
        
        public int PageSize
        {
            get;
            set;
        }
        
        public string SortExpression
        {
            get;
            set;
        }
        
        public string SortOrder
        {
            get;
            set;
        }
    }
}
