﻿//-----------------------------------------------------------------------
// <copyright file="UserRoleDetails.cs" company="NIIT Technologies">
//  Copyright (c) NIIT Technologies. All rights reserved.
// </copyright>
// <summary>
// <Description>This a UserRoleDetails class which contains attributes for UserRoleDetails</Description>
// <Author>NIIT Technologies</Author>
// <CreatedOn>11/23/2009</CreatedOn>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// </summary>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AmericanExpress.GDU.BusinessEntities
{
    public class UserMenuDetails
    {


        public Int32 FunctionId
        {
            get;
            set;
        }

        /// <summary>
        /// 
        /// </summary>
        public string FunctionName
        {
            get;
            set;
        }

        public string FunctionPageUrlTxt
        {
            get;
            set;
        }
        /// <summary>
        /// 
        /// </summary>
        public Int32 FunctionParentId
        {
            get;
            set;
        }

        public Int32 DispOrderNo
        {
            get;
            set;
        }

       

    }

}