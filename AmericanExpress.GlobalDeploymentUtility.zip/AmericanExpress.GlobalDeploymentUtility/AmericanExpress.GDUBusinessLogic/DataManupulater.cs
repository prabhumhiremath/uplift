﻿//-----------------------------------------------------------------------
// <copyright file="GWizBusiness.cs" company="NIIT Technologies">
//  Copyright (c) NIIT Technologies. All rights reserved.
// </copyright>
// <summary>
// <Description>This a AccountDetails class which contains attributes for AccountDetails.</Description>
// <Author>NIIT Technologies</Author>
// <CreatedOn>11/03/2009</CreatedOn>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// </summary>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Serialization;
using System.IO;
using AmericanExpress.GDU.BusinessEntities;
using AmericanExpress.GDU.Util.DataAccessHelper;
using AmericanExpress.GDU.Util.DBSchemaHelper;
using AmericanExpress.GDU.Utilities.ExceptionMgmt;
using AmericanExpress.GDU.Utilities.Diagnostics;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
namespace AmericanExpress.GDU.BusinessLogic
{
    public partial class GWizBusiness
    {
        #region Private Variables
        StandardResponse std;
        #endregion

        //public string UpdateAccount(AccountDetails Request)
        //{
        //    return string.Empty;
        //}

        //public string UpdateCity(CityDetails Request)
        //{
        //    return string.Empty;
        //}

        //public string UpdateCountry(CountryDetails Request)
        //{
        //    return string.Empty;
        //}

        //public string DeleteAccount(AccountDetails Request)
        //{
        //    return string.Empty;
        //}

        //public string DeleteCity(CityDetails Request)
        //{
        //    return string.Empty;
        //}

        //public string DeleteCountry(CountryDetails Request)
        //{
        //    return string.Empty;
        //}

        private static string UTF8ByteArrayToString(byte[] characters)
        {
            UTF8Encoding encoding = new UTF8Encoding();
            string constructedString = encoding.GetString(characters);
            return (constructedString);
        }

        //public StandardResponse UpdateLinks(Link[] Request)
        //{

        //    StandardResponse Std = new StandardResponse();
        //    string fileUrl = string.Empty;
        //    string SourcePath = string.Empty;


        //    DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);

        //    try
        //    {
        //        string SharePointURL = ConfigurationSettings.AppSettings[Constants.CONSTSPURL];
        //        string SharePointUploadURL = ConfigurationSettings.AppSettings[Constants.CONSTSPUPURL];

        //        if (Request[0].LinkDetails[0].LinkCategoryDetails != null && Request[0].LinkDetails[0].LinkCategoryDetails[0] != null)
        //        {
        //            if (Request[0].LinkDetails[0].LinkCategoryDetails[0].LinkType == 1)
        //            {
        //                SourcePath = Request[0].LinkDetails[0].LinkCategoryDetails[0].Link.ToString();
        //                //Replacing Sharepoint File URL
        //                Request[0].LinkDetails[0].LinkCategoryDetails[0].Link = Request[0].LinkDetails[0].LinkCategoryDetails[0].Link.Replace(SharePointUploadURL, string.Empty);

        //            }
        //        }
        //        else if (Request[0].LinkDetails[0] != null)
        //        {
        //            if (Request[0].LinkDetails[0].LinkType == 1)
        //            {
        //                SourcePath = Request[0].LinkDetails[0].Link.ToString();
        //                //Replacing SharePoint URL
        //                Request[0].LinkDetails[0].Link = Request[0].LinkDetails[0].Link.Replace(SharePointUploadURL, string.Empty);
        //            }
        //        }               


        //        DBStoredProcedure sp;
        //        if (Request[0].AccountCode == string.Empty && Request[0].CountryCode == string.Empty && Request[0].CityCode == string.Empty)
        //        {
        //            sp = proc[Constants.CONSTSPCARRIERGLOBAL];
        //        }
        //        else
        //        {
        //            sp = proc[Constants.CONSTSPLOCATIONMODENAME];
        //        }
        //        string xmlString = null;
        //        MemoryStream memoryStream = new MemoryStream();
        //        XmlSerializer inputXML = new XmlSerializer(Request.GetType());
        //        XmlTextWriter xmlTextWriter = new XmlTextWriter(memoryStream, Encoding.UTF8);
        //        inputXML.Serialize(xmlTextWriter, Request);
        //        memoryStream = (MemoryStream)xmlTextWriter.BaseStream;
        //        xmlString = UTF8ByteArrayToString(memoryStream.ToArray());
        //        sp.Parameters["@inXmlLink"].Value = xmlString.ToString().Substring(1);
        //        proc.ExecuteSP(sp);
        //        Std.ResponseCodeStatus = StdResponseCode.Success;
        //        try
        //        {
        //            if (!Request[0].LinkDetails[0].IsApprove)
        //            {
        //                //if (ConfigurationSettings.AppSettings["IsEmailOn"].ToString() == "True")                          
        //                AppFocusIndicatorDetails[] emailIndicator;
        //                emailIndicator = this.PopulateAppFocusIndicator();
        //                string SPfileUrl = string.Empty;
        //                string fileLabel_Name = string.Empty;
        //                if (emailIndicator[3].AppFocusIndicator.ToString() == "True")
        //                {
                            
        //                        SPfileUrl = "";
                           

        //                    if (Request[0].LinkDetails[0].LinkCategoryDetails != null && Request[0].LinkDetails[0].LinkCategoryDetails[0] != null)
        //                        fileLabel_Name = Request[0].LinkDetails[0].LinkCategoryDetails[0].LabelName.ToString();
        //                    else
        //                        fileLabel_Name = Request[0].LinkDetails[0].LabelName.ToString();


                           
        //                }
        //            }
        //        }
        //        catch (Exception ex)
        //        {

        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        if (ex is SharePointException)
        //        {
        //            Std.ResponseCodeStatus = StdResponseCode.Failed;
        //            Std.ResponseMessage = ex.Message;
        //            LogManager.LogErrorMessage(ex, 9078);
        //        }
        //        else
        //        {
        //            Std.ResponseCodeStatus = StdResponseCode.Failed;
        //            string msg = ExceptionManager.GetErrorMessage(8051);
        //            LogManager.LogErrorMessage(ex, 9078);
        //        }
        //    }
        //    finally
        //    {
        //        proc = null;
        //    }

        //    return Std;
        //}

        //public StandardResponse UpdateGeneralInfoLinks(GeneralInfoLink[] Request)
        //{
        //    StandardResponse Std = new StandardResponse();
        //    DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
        //    try
        //    {
        //        DBStoredProcedure sp = proc[Constants.CONSTSPADDUPDATEGENERALINFO];
        //        string xmlString = null;
        //        MemoryStream memoryStream = new MemoryStream();
        //        XmlSerializer inputXML = new XmlSerializer(Request.GetType());
        //        XmlTextWriter xmlTextWriter = new XmlTextWriter(memoryStream, Encoding.UTF8);
        //        inputXML.Serialize(xmlTextWriter, Request);
        //        memoryStream = (MemoryStream)xmlTextWriter.BaseStream;
        //        xmlString = UTF8ByteArrayToString(memoryStream.ToArray());
        //        sp.Parameters["@inXmlLink"].Value = xmlString.ToString().Substring(1);
        //        proc.ExecuteSP(sp);
        //        Std.ResponseCodeStatus = StdResponseCode.Success;
        //    }
        //    catch (Exception ex)
        //    {
        //        if (ex is SharePointException)
        //        {
        //            Std.ResponseCodeStatus = StdResponseCode.Failed;
        //            Std.ResponseMessage = ex.Message;
        //            LogManager.LogErrorMessage(ex, 9078);
        //        }
        //        else
        //        {
        //            Std.ResponseCodeStatus = StdResponseCode.Failed;
        //            string msg = ExceptionManager.GetErrorMessage(8051);
        //            LogManager.LogErrorMessage(ex, 9078);
        //        }
        //    }
        //    finally
        //    {
        //        proc = null;
        //    }

        //    return Std;
        //}

        //public StandardResponse DeleteLink(DeleteLink Request)
        //{
        //    string mode = Request.Mode;
        //    StandardResponse std = new StandardResponse();
        //    DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
        //    try
        //    {
        //        if (string.IsNullOrEmpty(mode))
        //        {
        //            DBStoredProcedure sp = proc[Constants.CONSTSPDELETELINKSNAME];
        //            int linkid = 0;
        //            int linkdetailid = 0;
        //            int linkcategorydetailid = 0;

        //            linkid = Request.LinkID;
        //            linkdetailid = Request.LinkDetailID[0].LinkDetailID;
        //            linkcategorydetailid = Request.LinkDetailID[0].LinkCategoryDetailID[0].LinkCategoryDetailID;

        //            sp.Parameters["@inLinkId"].Value = linkid;
        //            sp.Parameters["@inLinkDetailId"].Value = linkdetailid;
        //            sp.Parameters["@inLinkCategoryDetailId"].Value = linkcategorydetailid;
        //            proc.ExecuteSP(sp);
        //        }
        //        else if (mode == "GeneralInfo")
        //        {
        //            DBStoredProcedure sp = proc[Constants.CONSTSPDELETEGENERALINFO];
        //            int linkid = 0;
        //            int linkdetailid = 0;

        //            linkid = Request.LinkID;
        //            linkdetailid = Request.LinkDetailID[0].LinkDetailID;

        //            sp.Parameters["@inLinkId"].Value = linkid;
        //            sp.Parameters["@inLinkDetailId"].Value = linkdetailid;
        //            proc.ExecuteSP(sp);
        //        }
        //        else if (mode == "OtherInfo_GeneralInfo")
        //        {
        //            DBStoredProcedure sp = proc[Constants.CONSTSPDELETE_OTHERINFO_GENERALINFO];
        //            int linkid = 0;
        //            int linkdetailid = 0;

        //            linkid = Request.LinkID;
        //            linkdetailid = Request.LinkDetailID[0].LinkDetailID;

        //            sp.Parameters["@inLinkId"].Value = linkid;
        //            sp.Parameters["@inOiLinkDetailId"].Value = linkdetailid;
        //            proc.ExecuteSP(sp);
        //        }
        //        else
        //        {
        //            DBStoredProcedure sp = proc[Constants.CONSTDELETEOTHERLINKSNAME];
        //            int linkid = 0;
        //            int linkdetailid = 0;
        //            int linkcategorydetailid = 0;

        //            linkid = Request.LinkID;
        //            linkdetailid = Request.LinkDetailID[0].LinkDetailID;
        //            linkcategorydetailid = Request.LinkDetailID[0].LinkCategoryDetailID[0].LinkCategoryDetailID;

        //            sp.Parameters["@inOtherInfoLabelId"].Value = linkid;
        //            sp.Parameters["@inOtherInfoId"].Value = linkdetailid;
        //            sp.Parameters["@inOtherInfoDetailId"].Value = linkcategorydetailid;
        //            proc.ExecuteSP(sp);
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        std.ResponseCodeStatus = StdResponseCode.Failed;
        //        ExceptionManager.HandleException(ex, 8000);//Need to be updated for actual Business error code 
        //    }
        //    finally
        //    {
        //        proc = null;
        //    }
        //    std.ResponseCodeStatus = StdResponseCode.Success;
        //    return std;
        //}

        //public StandardResponse SaveFeedback(FeedbackInput Request)
        //{
        //    int status;
        //    std = new StandardResponse();
        //    DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
        //    DBStoredProcedure sp = proc[Constants.CONSTSPSAVEFEEDBACKNAME];
        //    try
        //    {
        //        sp.Parameters["@inADSId"].Value = Request.AdsId;
        //        sp.Parameters["@inMode"].Value = Request.Mode;
        //        sp.Parameters["@inLinkTypeCode"].Value = Request.LinkTypeCode;
        //        if (Request.LabelId == 0)
        //        {
        //            sp.Parameters["@inLabelId"].Value = DBNull.Value;
        //        }
        //        else
        //        {
        //            sp.Parameters["@inLabelId"].Value = Request.LabelId;
        //        }
        //        sp.Parameters["@inRating"].Value = Request.Rating;
        //        sp.Parameters["@Remarks"].Value = Request.FeedbackRemark;
        //        sp.Parameters["@inCreatedUserId"].Value = Request.CreatedUserId;
        //        sp.Parameters["@inCreatedDate"].Value = Request.CreatedDate;
        //        sp.Parameters["@inModifiedUserId"].Value = Request.ModifiedUserID;
        //        sp.Parameters["@inModifiedDate"].Value = Request.ModifiedDate;
        //        sp.Parameters["@inFeedbackType_CD"].Value = Request.FeedBackType;
        //        sp.Parameters["@Client_ID"].Value = Request.ClientID;
        //        proc.ExecuteSP(sp);
        //        status = int.Parse(sp.Parameters["@outStatus"].Value.ToString());
        //        if (status == 9876)
        //        {
        //            string msg = ExceptionManager.GetErrorMessage(status);
        //            std.ResponseCodeStatus = StdResponseCode.Failed;
        //            std.ResponseMessage = msg;
        //        }
        //        else
        //        {
        //            std.ResponseCodeStatus = StdResponseCode.Success;
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        std.ResponseCodeStatus = StdResponseCode.Failed;
        //        string msg = ExceptionManager.GetErrorMessage(8051);//Need to be updated for actual Business error code 
        //        std.ResponseMessage = msg;
        //        LogManager.LogErrorMessage(ex, 9078);
        //    }
        //    finally
        //    {
        //        proc = null;

        //    }


        //    return std;

        //}

        public StandardResponse ManageApplication(ManageApplicationInput Request)
        {
            StandardResponse std = new StandardResponse();

            int status = 0;
            DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
            DBStoredProcedure sp = proc[Constants.CONSTSPMANAGEAPPLICATION];
            try
            {
                sp.Parameters["@applicationName"].Value = Request.ApplicationNM;
                sp.Parameters["@applicationAbbr"].Value = Request.ApplicationAbbr;
                sp.Parameters["@applicationDeployPath"].Value = Request.ApplicationDeployPath;
                sp.Parameters["@applicationType"].Value = Request.AppType;
                sp.Parameters["@applicationExeName"].Value = Request.AppExeName;
                sp.Parameters["@inFlag"].Value = Request.AppMode;
                sp.Parameters["@appId"].Value = Request.AppId;
                sp.Parameters["@IsActive"].Value = 1;
                sp.Parameters["@EntryPoint"].Value = Request.EntryPoint;

                proc.ExecuteSP(sp);

                status = int.Parse(sp.Parameters["@outStatus"].Value.ToString());
                if (status != 0)
                {
                    string message = ExceptionManager.GetErrorMessage(status);
                    std.ResponseMessage = message;
                    std.ResponseCodeStatus = StdResponseCode.Failed;
                }
                else
                {
                    std.ResponseCodeStatus = StdResponseCode.Success;
                }



                return std;
            }
            catch (Exception ex)
            {
                std.ResponseCodeStatus = StdResponseCode.Failed;
                LogManager.LogErrorMessage(ex, 8101); ;///DO NOT KNOW WHAT SECOND PARAMETER IS? 
            }
            finally
            {
                proc = null;


            }
            return std;


        }

        public StandardResponse ManageAppFocus(ManageAppFocusInput Request)
        {
            StandardResponse std = new StandardResponse();

            int status = 0;
            DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
            DBStoredProcedure sp = proc[Constants.CONSTSPMANAGEAPPFOCUSUSAGE];
            try
            {
                XmlDocument xDoc = new XmlDocument();
                xDoc.LoadXml(Request.XmlData.ToString());
                string FileGUID = System.Guid.NewGuid().ToString();
                //xDoc.Save(ConfigurationSettings.AppSettings["AppFocusFilePath"].ToString() + "\\" + FileGUID + ".xml");
                xDoc.Save(ConfigurationSettings.AppSettings["AppFocusFilePath"].ToString() + "\\" + FileGUID + ".xml");

                sp.Parameters["@INXMLFILENAME"].Value = FileGUID + ".xml";
                sp.Parameters["@ADS_ID"].Value = Request.ADSId;
                sp.Parameters["@COMPUTER_NM"].Value = Request.ComputerName;
                sp.Parameters["@IP_ADDR_TXT"].Value = Request.IPAddress;
                sp.Parameters["@CURRENT_ENDDATE"].Value = Request.currentEndDate;
                sp.Parameters["@FILE_TYPE"].Value = Request.FILE_TYPE;
                proc.ExecuteSP(sp);
                status = int.Parse(sp.Parameters["@OUTSTATUS"].Value.ToString());
                if (status != 0)
                {
                    string message = ExceptionManager.GetErrorMessage(status);
                    std.ResponseMessage = message;
                    std.ResponseCodeStatus = StdResponseCode.Failed;
                }
                else
                {
                    std.ResponseCodeStatus = StdResponseCode.Success;
                }
                return std;
            }
            catch (Exception ex)
            {
                std.ResponseCodeStatus = StdResponseCode.Failed;
                LogManager.LogErrorMessage(ex, 8101); ;///DO NOT KNOW WHAT SECOND PARAMETER IS? 
            }
            finally
            {
                proc = null;


            }
            return std;


        }

        public StandardResponse ManageAppUsers(AppUserInput Request)
        {
            StandardResponse std = new StandardResponse();

            int status = 0;
            DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
            DBStoredProcedure sp = proc[Constants.CONSTEDITAPPUSERROLE];
            string authorizedRoleIds = string.Empty;

            try
            {

                //if (!string.IsNullOrEmpty(authorizedRoleIds) && authorizedRoleIds.Length > 1 && (Request.Mode != "ACTIVATE" || Request.Mode != "DEACTIVATE"))
                //{
                //if (Request.Mode == "UPDATE")
                //{
                sp = proc[Constants.CONSTEDITAPPUSERROLE];
                sp.Parameters["@inUserId"].Value = Request.UserId;
                proc.ExecuteSP(sp);
                //}

                string AuthRole = Request.AuthorizedRoleIds;
                string[] split = AuthRole.Split(',');

                foreach (string item in split)
                {
                    if (item != null && item != "")
                    {
                        sp = proc[Constants.CONSTMANAGEAPPUSERROLE];
                        sp.Parameters["@inUserId"].Value = Request.UserId;
                        sp.Parameters["@inUserRoleCode"].Value = Request.Role_CD;
                        sp.Parameters["@inCreatedBy"].Value = Request.UserId;
                        sp.Parameters["@inModifiedDt"].Value = Request.ModifiedUserDate;
                        sp.Parameters["@AppAbbrName"].Value = item.ToString();
                        proc.ExecuteSP(sp);
                    }
                }


                //string[] allRoleIdClientId = authorizedRoleIds.Remove(authorizedRoleIds.Length - 1, 1).Split(',');
                //for (int index = 0; index < allRoleIdClientId.Length; index++)
                //{
                //    string[] roleIdClientId = allRoleIdClientId[index].Split('-');
                //    sp = proc[Constants.CONSTMANAGEAPPUSERROLE];
                //    sp.Parameters["@inUserId"].Value = Request.UserId;
                //    sp.Parameters["@inUserRoleCode"].Value = Request.Role_CD;
                //    sp.Parameters["@inCreatedBy"].Value = Request.UserId;
                //    sp.Parameters["@inModifiedDt"].Value = Request.ModifiedUserDate;
                //    sp.Parameters["@AppAbbrName"].Value = Request.UserId;
                //    proc.ExecuteSP(sp);

                // authorizedRoleIds = Request.AuthorizedRoleIds;

                //status = int.Parse(sp.Parameters["@outStatus"].Value.ToString());
                //    if (status != 0)
                //    {
                //        string message = ExceptionManager.GetErrorMessage(status);
                //        std.ResponseMessage = message;
                //        std.ResponseCodeStatus = StdResponseCode.Failed;
                //        switch (status)
                //        {

                //            case 9100:
                //                {
                //                    throw new UserExistsException(std.ResponseMessage, status);
                //                    break;
                //                }
                //            case 9101:
                //                {
                //                    throw new UserUpdateException(std.ResponseMessage, status);
                //                    break;
                //                }
                //            case 9102:
                //                {
                //                    throw new UserDeactivateException(std.ResponseMessage, status);
                //                    break;
                //                }
                //        }

                //    }
                //    else
                //    {
                //        std.ResponseCodeStatus = StdResponseCode.Success;
                //    } ameters["@inClientId"].Value = roleIdClientId[1];
                //    sp.Parameters["@inRoleCd"].Value = roleIdClientId[0];
                //    sp.Parameters["@inCreatedBy"].Value = Request.ModifiedUserID;
                //    proc.ExecuteSP(sp);
                //}
                //}
                std.ResponseCodeStatus = StdResponseCode.Success;
                return std;
            }
            catch (Exception ex)
            {
                std.ResponseCodeStatus = StdResponseCode.Failed;
                ExceptionManager.HandleException(ex, 1000);///DO NOT KNOW WHAT SECOND PARAMETER IS? 
            }
            finally
            {
                proc = null;


            }
            return std;


        }

        //public StandardResponse UpdateOtherInfo(OtherInfo Request)
        //{            
        //    string fileUrl = string.Empty;
        //    string SourcePath = string.Empty;
        //    string OtherInfoLabelName = string.Empty;           

        //    string SharePointURL = ConfigurationSettings.AppSettings[Constants.CONSTSPURL];
        //    string SharePointUploadURL = ConfigurationSettings.AppSettings[Constants.CONSTSPUPURL];
        //    if (Request.OtherInfoDetails != null && Request.OtherInfoDetails[0] != null)
        //    {
        //        if (Request.OtherInfoDetails[0].LinkType == 1)
        //        {
        //            SourcePath = Request.OtherInfoDetails[0].Link.ToString();
        //            Request.OtherInfoDetails[0].Link = Request.OtherInfoDetails[0].Link.Replace(SharePointUploadURL, string.Empty);
        //        }
        //    }
        //    else if (!string.IsNullOrEmpty(Request.Link))
        //    {
        //        if (Request.LinkType == 1)
        //        {
        //            SourcePath = Request.Link;
        //            Request.Link = Request.Link.Replace(SharePointUploadURL, string.Empty);
        //        }
        //    }
            
        //    StandardResponse std = new StandardResponse();
        //    DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
        //    DBStoredProcedure sp = proc[Constants.CONSTSPOTHERNAME];

        //    string xmlString = null;
        //    MemoryStream memoryStream = new MemoryStream();
        //    XmlSerializer inputXML = new XmlSerializer(Request.GetType());
        //    XmlTextWriter xmlTextWriter = new XmlTextWriter(memoryStream, Encoding.UTF8);
        //    inputXML.Serialize(xmlTextWriter, Request);
        //    memoryStream = (MemoryStream)xmlTextWriter.BaseStream;
        //    xmlString = UTF8ByteArrayToString(memoryStream.ToArray());

        //    try
        //    {
        //        sp.Parameters["@inXmlLink"].Value = xmlString.ToString().Substring(1);
        //        proc.ExecuteSP(sp);
        //        std.ResponseCodeStatus = StdResponseCode.Success;
        //        try
        //        {
        //            if (!Request.IsApprove)
        //            {
        //                AppFocusIndicatorDetails[] emailIndicator;
        //                emailIndicator = this.PopulateAppFocusIndicator();
        //                string SPfileUrl = string.Empty;
        //                string fileLabel_Name = string.Empty;
                       
        //            }
        //        }
        //        catch (Exception ex)
        //        {
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        std.ResponseCodeStatus = StdResponseCode.Failed;
        //        string msg = ExceptionManager.GetErrorMessage(8051);//Need to be updated for actual Business error code 
        //        std.ResponseMessage = msg;
        //        LogManager.LogErrorMessage(ex, 9078);
        //    }
        //    finally
        //    {
        //        proc = null;
        //    }


        //    return std;
        //}

        //public StandardResponse UpdateGeneralInfoOtherInfo(GeneralInfoOtherInfoDetails Request)
        //{
        //    StandardResponse std = new StandardResponse();
        //    DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
        //    DBStoredProcedure sp = proc[Constants.CONSTSPADDUPDATE_OTHERINFO_GENERALINFO];

        //    string xmlString = null;
        //    MemoryStream memoryStream = new MemoryStream();
        //    XmlSerializer inputXML = new XmlSerializer(Request.GetType());
        //    XmlTextWriter xmlTextWriter = new XmlTextWriter(memoryStream, Encoding.UTF8);
        //    inputXML.Serialize(xmlTextWriter, Request);
        //    memoryStream = (MemoryStream)xmlTextWriter.BaseStream;
        //    xmlString = UTF8ByteArrayToString(memoryStream.ToArray());

        //    try
        //    {
        //        sp.Parameters["@inXmlLink"].Value = xmlString.ToString().Substring(1);
        //        proc.ExecuteSP(sp);
        //        std.ResponseCodeStatus = StdResponseCode.Success;
        //    }
        //    catch (Exception ex)
        //    {
        //        std.ResponseCodeStatus = StdResponseCode.Failed;
        //        string msg = ExceptionManager.GetErrorMessage(8051);//Need to be updated for actual Business error code 
        //        std.ResponseMessage = msg;
        //        LogManager.LogErrorMessage(ex, 9078);
        //    }
        //    finally
        //    {
        //        proc = null;
        //    }


        //    return std;
        //}

        #region OTHER INFO

        //public StandardResponse AddUpdateOtherInfoLink(OtherInfoInput Request)
        //{
        //    int status = 0;
        //    StandardResponse std = new StandardResponse();
        //    DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
        //    DBStoredProcedure sp = proc[Constants.CONSTSPADDEDITINFONAME];

        //    sp.Parameters["@otherinfolabelId"].Value = Request.OtherInfoLabel_ID;
        //    sp.Parameters["@otherinfolabelName"].Value = Request.OtherInfoLabel_NM;
        //    sp.Parameters["@activeId"].Value = Request.ActiveID;
        //    sp.Parameters["@createdUserId"].Value = Request.CreatedUserID;
        //    sp.Parameters["@modifiedUserId"].Value = Request.ModifiedUserID;

        //    try
        //    {
        //        proc.ExecuteSP(sp);
        //        status = int.Parse(sp.Parameters["@outStatus"].Value.ToString());
        //        if (status == 0)
        //            std.ResponseCodeStatus = StdResponseCode.Success;
        //        else
        //            std.ResponseCodeStatus = StdResponseCode.Failed;
        //    }
        //    catch (Exception ex)
        //    {
        //        std.ResponseCodeStatus = StdResponseCode.Failed;
        //        string msg = ExceptionManager.GetErrorMessage(8051);//Need to be updated for actual Business error code 
        //        std.ResponseMessage = msg;
        //        LogManager.LogErrorMessage(ex, 9078);
        //    }
        //    finally
        //    {
        //        proc = null;
        //    }


        //    return std;
        //}

        //public StandardResponse DeleteOtherInfo(OtherInfoInput Request)
        //{
        //    StandardResponse std = new StandardResponse();
        //    DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
        //    DBStoredProcedure sp = proc[Constants.CONSTSPDELETEOTHERNAME];
        //    try
        //    {
        //        sp.Parameters["@otherinfolabelId"].Value = Request.OtherInfoLabel_ID;
        //        proc.ExecuteSP(sp);
        //        std.ResponseCodeStatus = StdResponseCode.Success;
        //    }
        //    catch (Exception ex)
        //    {
        //        std.ResponseCodeStatus = StdResponseCode.Failed;
        //        string msg = ExceptionManager.GetErrorMessage(8051);//Need to be updated for actual Business error code 
        //        std.ResponseMessage = msg;
        //        LogManager.LogErrorMessage(ex, 9078);
        //    }
        //    finally
        //    {
        //        proc = null;
        //    }

        //    return std;
        //}

        #endregion

        #region Globalcategory

        //public StandardResponse AddUpdateGlobalCategory(GlobalCategoryInput Request)
        //{
        //    StandardResponse std = new StandardResponse();
        //    DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
        //    DBStoredProcedure sp = proc[Constants.CONSTADDSPGLOBALNAME];
        //    try
        //    {
        //        sp.Parameters["@labelId"].Value = Request.LabelID;
        //        sp.Parameters["@labelName"].Value = Request.LabelName;
        //        sp.Parameters["@activeId"].Value = Request.ActiveID;
        //        sp.Parameters["@createdUserId"].Value = Request.CreatedUserID;
        //        sp.Parameters["@modifiedUserId"].Value = Request.ModifiedUserID;
        //        proc.ExecuteSP(sp);
        //        std.ResponseCodeStatus = StdResponseCode.Success;
        //    }
        //    catch (Exception ex)
        //    {
        //        std.ResponseCodeStatus = StdResponseCode.Failed;
        //        string msg = ExceptionManager.GetErrorMessage(8051);//Need to be updated for actual Business error code 
        //        std.ResponseMessage = msg;
        //        LogManager.LogErrorMessage(ex, 9078);
        //    }
        //    finally
        //    {
        //        proc = null;
        //    }

        //    return std;
        //}

        //public StandardResponse DeleteGlobalcategory(GlobalCategoryInput Request)
        //{
        //    StandardResponse std = new StandardResponse();
        //    DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
        //    DBStoredProcedure sp = proc[Constants.CONSTSPDELETEGLOBALNAME];
        //    try
        //    {
        //        sp.Parameters["@labelId"].Value = Request.LabelID;
        //        proc.ExecuteSP(sp);
        //        std.ResponseCodeStatus = StdResponseCode.Success;
        //    }
        //    catch (Exception ex)
        //    {
        //        std.ResponseCodeStatus = StdResponseCode.Failed;
        //        string msg = ExceptionManager.GetErrorMessage(8051);//Need to be updated for actual Business error code 
        //        std.ResponseMessage = msg;
        //        LogManager.LogErrorMessage(ex, 9078);
        //    }
        //    finally
        //    {
        //        proc = null;
        //    }

        //    return std;
        //}

        #endregion

        #region Carrier


        //public StandardResponse ManageCarriers(CarrierInput Request)
        //{
        //    StandardResponse std = new StandardResponse();

        //    int status = 0;
        //    DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
        //    DBStoredProcedure sp = proc[Constants.CONSTSPCARRIERNAME];
        //    try
        //    {
        //        sp.Parameters["@inCarrierCode"].Value = Request.CarrierCode;
        //        sp.Parameters["@inCarrierName"].Value = Request.CarrierName;
        //        sp.Parameters["@inCreatedBy"].Value = Request.ModifiedUserID;
        //        sp.Parameters["@inModifiedDt"].Value = Request.ModifiedDate;
        //        sp.Parameters["@inFlag"].Value = Request.Mode;
        //        proc.ExecuteSP(sp);

        //        status = int.Parse(sp.Parameters["@outStatus"].Value.ToString());
        //        if (status != 0)
        //        {
        //            string message = ExceptionManager.GetErrorMessage(status);
        //            std.ResponseMessage = message;
        //            std.ResponseCodeStatus = StdResponseCode.Failed;
        //            switch (status)
        //            {

        //                case 9000:
        //                    {
        //                        throw new CarrierExistsException(std.ResponseMessage, status);
        //                        break;
        //                    }
        //                case 9001:
        //                    {
        //                        throw new CarrierUpdateException(std.ResponseMessage, status);
        //                        break;
        //                    }
        //                case 9002:
        //                    {
        //                        throw new CarrierDeactivateException(std.ResponseMessage, status);
        //                        break;
        //                    }
        //            }

        //        }
        //        else
        //        {
        //            std.ResponseCodeStatus = StdResponseCode.Success;
        //        }



        //        return std;
        //    }
        //    catch (Exception ex)
        //    {
        //        std.ResponseCodeStatus = StdResponseCode.Failed;
        //        ExceptionManager.HandleException(ex, 1000);///DO NOT KNOW WHAT SECOND PARAMETER IS? 
        //    }
        //    finally
        //    {
        //        proc = null;


        //    }
        //    return std;


        //}

        #endregion

        #region Manage Account

        /// <summary>
        /// 
        /// </summary>
        /// <param name="Request"></param>
        /// <returns></returns>
        //public StandardResponse ManageAccounts(ManageAccountInput Request)
        //{
        //    StandardResponse std = new StandardResponse();

        //    int status = 0;
        //    DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
        //    DBStoredProcedure sp = proc["usp_ManageAccounts"];
        //    try
        //    {
        //        sp.Parameters["@inAccountCode"].Value = Request.AccountCode;
        //        sp.Parameters["@inAccountName"].Value = Request.AccountName;
        //        sp.Parameters["@inCreatedBy"].Value = Request.CreatedUserID;
        //        sp.Parameters["@inIsVirtual"].Value = Request.IsVirtual;
        //        sp.Parameters["@inIsGlobal"].Value = Request.IsGlobal;
        //        sp.Parameters["@inCreatedDate"].Value = Request.CreatedUserDate;
        //        sp.Parameters["@inModifiedDt"].Value = Request.ModifiedUserDate;
        //        sp.Parameters["@inModifiedBy"].Value = Request.ModifiedUserID;
        //        sp.Parameters["@inFlag"].Value = Request.Mode;
        //        sp.Parameters["@inClientID"].Value = Request.ClientID;

        //        proc.ExecuteSP(sp);

        //        status = int.Parse(sp.Parameters["@outStatus"].Value.ToString());
        //        if (status != 0)
        //        {
        //            string message = ExceptionManager.GetErrorMessage(status);
        //            std.ResponseMessage = message;
        //            std.ResponseCodeStatus = StdResponseCode.Failed;
        //        }
        //        else
        //        {
        //            std.ResponseCodeStatus = StdResponseCode.Success;
        //        }



        //        return std;
        //    }
        //    catch (Exception ex)
        //    {
        //        std.ResponseCodeStatus = StdResponseCode.Failed;
        //        LogManager.LogErrorMessage(ex, 8101); ;///DO NOT KNOW WHAT SECOND PARAMETER IS? 
        //    }
        //    finally
        //    {
        //        proc = null;


        //    }
        //    return std;


        //}
        #endregion

        //#region Manage Country

        ///// <summary>
        ///// 
        ///// </summary>
        ///// <param name="Request"></param>
        ///// <returns></returns>
        //public StandardResponse ManageCountry(ManageCountryInput Request)
        //{
        //    StandardResponse std = new StandardResponse();

        //    int status = 0;
        //    DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
        //    DBStoredProcedure sp = proc["usp_ManageCountry"];
        //    try
        //    {
        //        sp.Parameters["@inCountryCode"].Value = Request.CountryCode;
        //        sp.Parameters["@inCountryName"].Value = Request.CountryName;
        //        sp.Parameters["@inCreatedBy"].Value = Request.CreatedUserID;
        //        sp.Parameters["@inIsVirtual"].Value = Request.IsVirtual;
        //        sp.Parameters["@inIsGlobal"].Value = Request.IsGlobal;
        //        sp.Parameters["@inCreatedDate"].Value = Request.CreatedUserDate;
        //        sp.Parameters["@inModifiedDt"].Value = Request.ModifiedUserDate;
        //        sp.Parameters["@inModifiedBy"].Value = Request.ModifiedUserID;
        //        sp.Parameters["@inIsActive"].Value = Request.IsDeactive;
        //        sp.Parameters["@inFlag"].Value = Request.Mode;


        //        proc.ExecuteSP(sp);

        //        status = int.Parse(sp.Parameters["@outStatus"].Value.ToString());
        //        if (status != 0)
        //        {
        //            string message = ExceptionManager.GetErrorMessage(status);
        //            std.ResponseMessage = message;
        //            std.ResponseCodeStatus = StdResponseCode.Failed;
        //        }
        //        else
        //        {
        //            std.ResponseCodeStatus = StdResponseCode.Success;
        //        }



        //        return std;
        //    }
        //    catch (Exception ex)
        //    {
        //        std.ResponseCodeStatus = StdResponseCode.Failed;
        //        LogManager.LogErrorMessage(ex, 8101); ;///DO NOT KNOW WHAT SECOND PARAMETER IS? 
        //    }
        //    finally
        //    {
        //        proc = null;


        //    }
        //    return std;


        //}
        //#endregion

        //#region Manage City

        ///// <summary>
        ///// 
        ///// </summary>
        ///// <param name="Request"></param>
        ///// <returns></returns>
        //public StandardResponse ManageCities(ManageCityInput Request)
        //{
        //    StandardResponse std = new StandardResponse();

        //    int status = 0;
        //    DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
        //    DBStoredProcedure sp = proc["usp_ManageCities"];
        //    try
        //    {
        //        sp.Parameters["@inCityCode"].Value = Request.CityCode;
        //        sp.Parameters["@inCityName"].Value = Request.CityName;
        //        sp.Parameters["@inCreatedBy"].Value = Request.CreatedUserID;
        //        sp.Parameters["@inIsVirtual"].Value = Request.IsVirtual;
        //        sp.Parameters["@inIsGlobal"].Value = Request.IsGlobal;
        //        sp.Parameters["@inCreatedDate"].Value = Request.CreatedUserDate;
        //        sp.Parameters["@inModifiedDt"].Value = Request.ModifiedUserDate;
        //        sp.Parameters["@inModifiedBy"].Value = Request.ModifiedUserID;
        //        sp.Parameters["@inFlag"].Value = Request.Mode;
        //        sp.Parameters["@inCountryCode"].Value = Request.CountryCode;

        //        proc.ExecuteSP(sp);

        //        status = int.Parse(sp.Parameters["@outStatus"].Value.ToString());
        //        if (status != 0)
        //        {
        //            string message = ExceptionManager.GetErrorMessage(status);
        //            std.ResponseMessage = message;
        //            std.ResponseCodeStatus = StdResponseCode.Failed;
        //        }
        //        else
        //        {
        //            std.ResponseCodeStatus = StdResponseCode.Success;
        //        }



        //        return std;
        //    }
        //    catch (Exception ex)
        //    {
        //        std.ResponseCodeStatus = StdResponseCode.Failed;
        //        LogManager.LogErrorMessage(ex, 8101); ;///DO NOT KNOW WHAT SECOND PARAMETER IS? 
        //    }
        //    finally
        //    {
        //        proc = null;


        //    }
        //    return std;


        //}
        //#endregion

        //public StandardResponse MapCountry(CountryMappingInput[] Request)
        //{
        //    StandardResponse Std = new StandardResponse();
        //    try
        //    {
        //        DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
        //        DBStoredProcedure sp = proc["usp_ManageCounMapping"];

        //        string xmlString = null;
        //        MemoryStream memoryStream = new MemoryStream();
        //        XmlSerializer inputXML = new XmlSerializer(Request.GetType());
        //        XmlTextWriter xmlTextWriter = new XmlTextWriter(memoryStream, Encoding.UTF8);
        //        inputXML.Serialize(xmlTextWriter, Request);
        //        memoryStream = (MemoryStream)xmlTextWriter.BaseStream;
        //        xmlString = UTF8ByteArrayToString(memoryStream.ToArray());
        //        sp.Parameters["@XMLCollectionString"].Value = xmlString.ToString().Substring(39);
        //        proc.ExecuteSP(sp);
        //        Std.ResponseCodeStatus = StdResponseCode.Success;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //    return Std;
        //}

        #region Users

        /// <summary>
        /// 
        /// </summary>
        /// <param name="Request"></param>
        /// <returns></returns>
        public StandardResponse ManageUsers(UserInput Request)
        {
            StandardResponse std = new StandardResponse();

            int status = 0;
            DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
            DBStoredProcedure sp = proc[Constants.CONSTSPUSERNAME];
            string authorizedRoleIds = string.Empty;

            try
            {
                sp.Parameters["@inUserId"].Value = Request.UserId;
                sp.Parameters["@inUserName"].Value = Request.UserName;
                sp.Parameters["@inEmailAddress"].Value = Request.EmailAddress;
                sp.Parameters["@inLanguageCode"].Value = Request.LanguageCode;
                sp.Parameters["@inUserRoleCode"].Value = Request.UserRoleCode;
                sp.Parameters["@inCreatedBy"].Value = Request.ModifiedUserID;
                sp.Parameters["@inModifiedDt"].Value = Request.ModifiedUserDate;
                sp.Parameters["@inFlag"].Value = Request.Mode;
                sp.Parameters["@inDefaultClientId"].Value = Request.DefaultClientID;
                sp.Parameters["@System_CD"].Value = Request.System_CD;
                proc.ExecuteSP(sp);

                authorizedRoleIds = Request.AuthorizedRoleIds;

                status = int.Parse(sp.Parameters["@outStatus"].Value.ToString());
                if (status != 0)
                {
                    string message = ExceptionManager.GetErrorMessage(status);
                    std.ResponseMessage = message;
                    std.ResponseCodeStatus = StdResponseCode.Failed;
                    switch (status)
                    {

                        case 9100:
                            {
                                throw new UserExistsException(std.ResponseMessage, status);
                                break;
                            }
                        case 9101:
                            {
                                throw new UserUpdateException(std.ResponseMessage, status);
                                break;
                            }
                        case 9102:
                            {
                                throw new UserDeactivateException(std.ResponseMessage, status);
                                break;
                            }
                    }

                }
                else
                {
                    std.ResponseCodeStatus = StdResponseCode.Success;
                }
                if (!string.IsNullOrEmpty(authorizedRoleIds) && authorizedRoleIds.Length > 1 && (Request.Mode != "ACTIVATE" || Request.Mode != "DEACTIVATE"))
                {
                    string[] allRoleIdClientId = authorizedRoleIds.Remove(authorizedRoleIds.Length - 1, 1).Split(',');
                    for (int index = 0; index < allRoleIdClientId.Length; index++)
                    {
                        string[] roleIdClientId = allRoleIdClientId[index].Split('-');
                        sp = proc[Constants.CONSTMANAGEUSERROLE];
                        sp.Parameters["@inUserId"].Value = Request.UserId;
                        sp.Parameters["@inClientId"].Value = roleIdClientId[1];
                        sp.Parameters["@inRoleCd"].Value = roleIdClientId[0];
                        sp.Parameters["@inCreatedBy"].Value = Request.ModifiedUserID;
                        proc.ExecuteSP(sp);
                    }
                }

                return std;
            }
            catch (Exception ex)
            {
                std.ResponseCodeStatus = StdResponseCode.Failed;
                ExceptionManager.HandleException(ex, 1000);///DO NOT KNOW WHAT SECOND PARAMETER IS? 
            }
            finally
            {
                proc = null;


            }
            return std;


        }

        public StandardResponse ManageUserProfile(UserInput Request)
        {
            StandardResponse std = new StandardResponse();

            DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
            DBStoredProcedure sp = proc[Constants.CONSTMNAGEUSERPROFILE];
            try
            {
                sp.Parameters["@inUserId"].Value = Request.UserId;
                sp.Parameters["@inUserName"].Value = Request.UserName;
                sp.Parameters["@inEmail"].Value = Request.EmailAddress;

                proc.ExecuteSP(sp);
                std.ResponseCodeStatus = StdResponseCode.Success;

                return std;
            }
            catch (Exception ex)
            {
                std.ResponseCodeStatus = StdResponseCode.Failed;
                LogManager.LogErrorMessage(ex, 8101);
            }
            finally
            {
                proc = null;


            }
            return std;
        }

        #endregion

        //#region AggregationRule
        ///// <summary>
        ///// Saves aggregation Rule
        ///// </summary>
        ///// <param name="ruleXml"></param>
        ///// <returns></returns>
        //public StandardResponse ManageAggregationRule(AggregationRule[] Request)
        //{
        //    int status = 0;
        //    StandardResponse std = new StandardResponse();
        //    DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
        //    DBStoredProcedure sp = proc[Constants.CONSTSPAGGRIGATIONNAME];
        //    string xmlString = null;
        //    MemoryStream memoryStream = new MemoryStream();
        //    XmlSerializer inputXML = new XmlSerializer(Request.GetType());
        //    XmlTextWriter xmlTextWriter = new XmlTextWriter(memoryStream, Encoding.UTF8);
        //    inputXML.Serialize(xmlTextWriter, Request);
        //    memoryStream = (MemoryStream)xmlTextWriter.BaseStream;
        //    xmlString = UTF8ByteArrayToString(memoryStream.ToArray());
        //    sp.Parameters["@inXml"].Value = xmlString.ToString().Substring(1);
        //    try
        //    {
        //        proc.ExecuteSP(sp);

        //    }
        //    catch (Exception ex)
        //    {
        //        std.ResponseCodeStatus = StdResponseCode.Failed;
        //    }

        //    return std;
        //}
        //#endregion

        #region DeploymentDetails
        /// <summary>
        /// 
        /// </summary>
        /// <param name="Request"></param>
        /// <returns></returns>
        public StandardResponse AddClientDeploymentDetail(ClientDeployementInput Request)
        {
            std = new StandardResponse();
            DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
            DBStoredProcedure sp = proc[Constants.CONSTSPDEPLOYMENTDETAIL];
            try
            {
                sp.Parameters["@inUserId"].Value = Request.UserId;
                sp.Parameters["@inIP"].Value = Request.IPAddress;
                sp.Parameters["@inNacId"].Value = Request.NACId;
                sp.Parameters["@inExeVersionNo"].Value = Request.ExeVersionNo;
                sp.Parameters["@inExeTimeStamp"].Value = Request.ExeTimeStamp;
                sp.Parameters["@inRecordTimeStamp"].Value = Request.TimeStamp;
                sp.Parameters["@inApplicationPath"].Value = Request.ApplicationPath;
                sp.Parameters["@inLatestVersionNo"].Value = Request.LatestVersionNo;
                sp.Parameters["@inComputerName"].Value = Request.ComputerName;
                sp.Parameters["@inApp_ID"].Value = Request.App_ID;
                sp.Parameters["@APPCODEBASE"].Value = Request.App_Name;
                proc.ExecuteSP(sp);
                std.ResponseCodeStatus = StdResponseCode.Success;
            }
            catch (Exception ex)
            {
                std.ResponseCodeStatus = StdResponseCode.Failed;
                string msg = ExceptionManager.GetErrorMessage(8051);//Need to be updated for actual Business error code 
                std.ResponseMessage = msg;
                LogManager.LogErrorMessage(ex, 9078);
            }
            finally
            {
                proc = null;

            }
            return std;
        }
        #endregion

        #region UsageDetails
        /// <summary>
        /// 
        /// </summary>
        /// <param name="Request"></param>
        /// <returns></returns>
        public StandardResponse AddClientUsageDetail(ClientUsageInput Request)
        {
            std = new StandardResponse();
            DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
            DBStoredProcedure sp = proc[Constants.CONSTSPUSAGEDETAIL];

            try
            {
                string xmlString = null;
                MemoryStream memoryStream = new MemoryStream();
                XmlSerializer inputXML = new XmlSerializer(Request.GetType());
                XmlTextWriter xmlTextWriter = new XmlTextWriter(memoryStream, Encoding.UTF8);
                inputXML.Serialize(xmlTextWriter, Request);
                memoryStream = (MemoryStream)xmlTextWriter.BaseStream;
                xmlString = UTF8ByteArrayToString(memoryStream.ToArray());
                sp.Parameters["@XMLCollectionString"].Value = xmlString.ToString().Substring(39);
                sp.Parameters["@outTransID"].Value = "";
                proc.ExecuteSP(sp);

                std.ResponseCodeStatus = StdResponseCode.Success;
                std.ResponseMessage = sp.Parameters["@outTransID"].Value.ToString();
            }
            catch (Exception ex)
            {
                std.ResponseCodeStatus = StdResponseCode.Failed;
                string msg = ExceptionManager.GetErrorMessage(8051);//Need to be updated for actual Business error code 
                std.ResponseMessage = msg;
                LogManager.LogErrorMessage(ex, 9078);
            }
            finally
            {
                proc = null;
            }
            return std;
        }
        #endregion

        //public StandardResponse MapAccount(AccountMappingInput[] Request)
        //{
        //    StandardResponse Std = new StandardResponse();
        //    try
        //    {
        //        DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
        //        DBStoredProcedure sp = proc["usp_ManageAccMapping"];

        //        string xmlString = null;
        //        MemoryStream memoryStream = new MemoryStream();
        //        XmlSerializer inputXML = new XmlSerializer(Request.GetType());
        //        XmlTextWriter xmlTextWriter = new XmlTextWriter(memoryStream, Encoding.UTF8);
        //        inputXML.Serialize(xmlTextWriter, Request);
        //        memoryStream = (MemoryStream)xmlTextWriter.BaseStream;
        //        xmlString = UTF8ByteArrayToString(memoryStream.ToArray());
        //        sp.Parameters["@XMLCollectionString"].Value = xmlString.ToString().Substring(39);
        //        proc.ExecuteSP(sp);
        //        Std.ResponseCodeStatus = StdResponseCode.Success;
        //    }
        //    catch (Exception ex)
        //    {

        //    }
        //    return Std;
        //}

        //#region MappingCity
        //public StandardResponse MapCity(CityMappingInput[] Request)
        //{
        //    StandardResponse Std = new StandardResponse();
        //    try
        //    {
        //        DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
        //        DBStoredProcedure sp = proc["usp_ManageCityMapping"];

        //        string xmlString = null;
        //        MemoryStream memoryStream = new MemoryStream();
        //        XmlSerializer inputXML = new XmlSerializer(Request.GetType());
        //        XmlTextWriter xmlTextWriter = new XmlTextWriter(memoryStream, Encoding.UTF8);
        //        inputXML.Serialize(xmlTextWriter, Request);
        //        memoryStream = (MemoryStream)xmlTextWriter.BaseStream;
        //        xmlString = UTF8ByteArrayToString(memoryStream.ToArray());
        //        sp.Parameters["@XMLCollectionString"].Value = xmlString.ToString().Substring(39);
        //        proc.ExecuteSP(sp);
        //        Std.ResponseCodeStatus = StdResponseCode.Success;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //    return Std;
        //}
        //#endregion

        /// <summary>
        /// 
        /// </summary>
        /// <param name="Request"></param>
        /// <returns></returns>
        public StandardResponse SaveClientReleaseInfo(ClientRelease Request)
        {
            StandardResponse std = new StandardResponse();
            try
            {
                DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);


                string xmlString = null;
                MemoryStream memoryStream = new MemoryStream();
                XmlSerializer inputXML = new XmlSerializer(Request.GetType());
                XmlTextWriter xmlTextWriter = new XmlTextWriter(memoryStream, Encoding.UTF8);
                inputXML.Serialize(xmlTextWriter, Request);
                memoryStream = (MemoryStream)xmlTextWriter.BaseStream;
                xmlString = UTF8ByteArrayToString(memoryStream.ToArray());
                //===================================================================================
                if (Request.ClientReleaseVer.System_CD == "GD")
                {
                    DBStoredProcedure sp = proc[Constants.CONSTSAVECLIENTRELEASE_GDU];
                    sp.Parameters["@XMLClientReleaseDetail"].Value = xmlString.ToString().Substring(39);
                    sp.Parameters["@outRELEASE_ID"].Value = "";
                    proc.ExecuteSP(sp);
                    std.ResponseCodeStatus = StdResponseCode.Success;
                    std.ResponseMessage = sp.Parameters["@outRELEASE_ID"].Value.ToString();
                }
                else
                {
                    DBStoredProcedure sp = proc[Constants.CONSTSAVECLIENTRELEASE];
                    sp.Parameters["@XMLClientReleaseDetail"].Value = xmlString.ToString().Substring(39);

                    proc.ExecuteSP(sp);
                    std.ResponseCodeStatus = StdResponseCode.Success;

                }

            }
            catch (Exception ex)
            {
                std.ResponseCodeStatus = StdResponseCode.Failed;
                string msg = ExceptionManager.GetErrorMessage(8051);//Need to be updated for actual Business error code 
                std.ResponseMessage = msg;
                LogManager.LogErrorMessage(ex, 9079);
            }
            return std;
        }

        #region Manage Client

        //public StandardResponse ManageClients(ManageClientInput Request)
        //{
        //    StandardResponse std = new StandardResponse();

        //    int status = 0;
        //    DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
        //    DBStoredProcedure sp = proc[Constants.CONSTSPMANAGECLIENT];
        //    try
        //    {
        //        sp.Parameters["@clientID"].Value = Request.ClientId;
        //        sp.Parameters["@clientName"].Value = Request.ClientName;
        //        sp.Parameters["@clientAbbriviation"].Value = Request.ClientAbbr;
        //        sp.Parameters["@createdDate"].Value = Request.CREATED_DT;
        //        sp.Parameters["@createdUserId"].Value = Request.CREATED_USER_ID;
        //        sp.Parameters["@inFlag"].Value = Request.Mode;
        //        sp.Parameters["@IsActive"].Value = 1;
        //        sp.Parameters["@modifiedDate"].Value = Request.CREATED_DT;
        //        sp.Parameters["@modifiedUserId"].Value = Request.CREATED_USER_ID;


        //        proc.ExecuteSP(sp);

        //        status = int.Parse(sp.Parameters["@outStatus"].Value.ToString());
        //        if (status != 0)
        //        {
        //            string message = ExceptionManager.GetErrorMessage(status);
        //            std.ResponseMessage = message;
        //            std.ResponseCodeStatus = StdResponseCode.Failed;
        //        }
        //        else
        //        {
        //            std.ResponseCodeStatus = StdResponseCode.Success;
        //        }



        //        return std;
        //    }
        //    catch (Exception ex)
        //    {
        //        std.ResponseCodeStatus = StdResponseCode.Failed;
        //        LogManager.LogErrorMessage(ex, 8101); ;///DO NOT KNOW WHAT SECOND PARAMETER IS? 
        //    }
        //    finally
        //    {
        //        proc = null;


        //    }
        //    return std;


        //}
        #endregion

        #region Manage Role
        public StandardResponse ManageRole(ManageRoleInput Request)
        {
            StandardResponse std = new StandardResponse();
            string authorizedFunctionIds = string.Empty;

            int status = 0;
            DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
            DBStoredProcedure sp = proc[Constants.CONSTSPMANAGEROLE];
            try
            {
                sp.Parameters["@inRoleCd"].Value = Request.RoleId;
                sp.Parameters["@inName"].Value = Request.RoleName;
                sp.Parameters["@inClientID"].Value = Request.ClientId;
                sp.Parameters["@inCreatedBy"].Value = Request.CreatedBy;
                sp.Parameters["@inModifiedDt"].Value = Request.ModifiedDt;
                sp.Parameters["@inFlag"].Value = Request.Flag;
                sp.Parameters["@roleTypeCd"].Value = Request.RoleTypeCD;
                sp.Parameters["@System_CD"].Value = Request.System_CD;

                authorizedFunctionIds = Request.AuthorizedFunctionIds;


                proc.ExecuteSP(sp);

                status = int.Parse(sp.Parameters["@outStatus"].Value.ToString());

                //if (Convert.ToInt32(status) != 0)
                //{
                //    proc.RollBackTransaction();
                //}
                //else
                //{
                if ((status == 0) && ((Request.Flag != "Delete") || (Request.Flag != "ACTIVATE")))
                {
                    if (!string.IsNullOrEmpty(authorizedFunctionIds) && authorizedFunctionIds.Length > 1)
                    {
                        string[] allFunctionIds = authorizedFunctionIds.Remove(authorizedFunctionIds.Length - 1, 1).Split(',');
                        for (int index = 0; index < allFunctionIds.Length; index++)
                        {
                            int funcId = Convert.ToInt32(allFunctionIds[index]);
                            sp = proc[Constants.CONSTMANAGEROLEFUNCTIONS];
                            sp.Parameters["@inRoleCd"].Value = Request.RoleId;
                            sp.Parameters["@inClientId"].Value = Request.ClientId;
                            sp.Parameters["@inFunctionID"].Value = funcId;//Request.FunctionId;
                            sp.Parameters["@inCreatedBy"].Value = Request.CreatedBy;
                            sp.Parameters["@System_CD"].Value = Request.System_CD;
                            proc.ExecuteSP(sp);
                        }
                    }
                }
                //proc.CommitTransaction();
                //}
                if (status != 0)
                {
                    string message = ExceptionManager.GetErrorMessage(status);
                    std.ResponseMessage = message;
                    std.ResponseCodeStatus = StdResponseCode.Failed;
                }
                else
                {
                    std.ResponseCodeStatus = StdResponseCode.Success;
                }
                return std;
            }
            catch (Exception ex)
            {
                std.ResponseCodeStatus = StdResponseCode.Failed;
                LogManager.LogErrorMessage(ex, 8101);
            }
            finally
            {
                proc = null;


            }
            return std;


        }
        #endregion

        public StandardResponse ManageDurationTime(DurationTimeInput Request)
        {
            StandardResponse std = new StandardResponse();
            DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
            DBStoredProcedure sp = proc[Constants.CONSTMANAGETIMEDURATION];
            string authorizedRoleIds = string.Empty;
            try
            {
                sp.Parameters["@InTimeDuration"].Value = Request.TimeDuration;
                sp.Parameters["@InTimeFormat"].Value = Request.TimeFormat;
                sp.Parameters["@UserIdentity"].Value = Request.UserId;
                proc.ExecuteSP(sp);
                std.ResponseCodeStatus = StdResponseCode.Success;
                return std;
            }
            catch (Exception ex)
            {
                std.ResponseCodeStatus = StdResponseCode.Failed;
                ExceptionManager.HandleException(ex, 1000);///DO NOT KNOW WHAT SECOND PARAMETER IS? 
            }
            finally
            {
                proc = null;
            }
            return std;
        }

        public StandardResponse ManageFocusApplications(FocusAppInput Request)
        {
            StandardResponse std = new StandardResponse();
            DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
            DBStoredProcedure sp = proc[Constants.CONSTMANAGEFOCUSAPP];
            string authorizedRoleIds = string.Empty;
            try
            {
                sp = proc[Constants.CONSTMANAGEFOCUSAPP];
                sp.Parameters["@Id"].Value = Request.ID;
                sp.Parameters["@App_DS"].Value = Request.App_DESC;
                proc.ExecuteSP(sp);
                std.ResponseCodeStatus = StdResponseCode.Success;
                return std;
            }
            catch (Exception ex)
            {
                std.ResponseCodeStatus = StdResponseCode.Failed;
                ExceptionManager.HandleException(ex, 1000);///DO NOT KNOW WHAT SECOND PARAMETER IS? 
            }
            finally
            {
                proc = null;
            }
            return std;
        }

        //public StandardResponse ManageAppFocusOffice(AppFocusOfficeInput Request)
        //{
        //    StandardResponse std = new StandardResponse();
        //    DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
        //    DBStoredProcedure sp = proc[Constants.CONSTMANAGEFOCUSAPPBYOFFICEID];
        //    string authorizedRoleIds = string.Empty;

        //    try
        //    {

        //        sp.Parameters["@Id"].Value = Request.ID;
        //        sp.Parameters["@OFFICE_DESC"].Value = Request.Office_Desc;
        //        proc.ExecuteSP(sp);
        //        std.ResponseCodeStatus = StdResponseCode.Success;
        //        return std;
        //    }
        //    catch (Exception ex)
        //    {
        //        std.ResponseCodeStatus = StdResponseCode.Failed;
        //        ExceptionManager.HandleException(ex, 1000);///DO NOT KNOW WHAT SECOND PARAMETER IS? 
        //    }
        //    finally
        //    {
        //        proc = null;
        //    }
        //    return std;
        //}

        public StandardResponse ManageAppFocusOffice(AppFocusOfficeInput Request)
        {
            int status = 0;
            StandardResponse std = new StandardResponse();
            DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
            DBStoredProcedure sp = proc[Constants.CONSTMANAGEFOCUSAPPBYOFFICEID];
            string authorizedRoleIds = string.Empty;

            try
            {

                sp.Parameters["@Id"].Value = Request.ID;
                sp.Parameters["@OFFICE_DESC"].Value = Request.Office_Desc;
                sp.Parameters["@UserID"].Value = Request.User_ID;
                sp.Parameters["@inFlag"].Value = Request.Mode;
                sp.Parameters["@isReport"].Value = Request.IsReport;
                proc.ExecuteSP(sp);
                status = int.Parse(sp.Parameters["@outStatus"].Value.ToString());
                std.ResponseCodeStatus = StdResponseCode.Success;
                return std;
            }
            catch (Exception ex)
            {
                string message = ExceptionManager.GetErrorMessage(status);
                std.ResponseCodeStatus = StdResponseCode.Failed;
                ExceptionManager.HandleException(ex, 1000);///DO NOT KNOW WHAT SECOND PARAMETER IS? 
            }
            finally
            {
                proc = null;
            }
            return std;
        }

        public StandardResponse ManageAppFocusGroup(FocusGroupInput Request)
        {
            int status = 0;
            StandardResponse std = new StandardResponse();
            DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
            DBStoredProcedure sp = proc[Constants.CONSTMANAGEAPPFOCUSGROUP];
            string authorizedRoleIds = string.Empty;

            try
            {

                sp.Parameters["@ID"].Value = Request.ID;
                sp.Parameters["@GROUP_NM"].Value = Request.Group_NM;
                sp.Parameters["@UserID"].Value = Request.User_ID;
                sp.Parameters["@inFlag"].Value = Request.Mode;
                proc.ExecuteSP(sp);

                status = int.Parse(sp.Parameters["@outStatus"].Value.ToString());
                if (status != 0)
                {
                    string message = ExceptionManager.GetErrorMessage(status);
                    std.ResponseMessage = message;
                    std.ResponseCodeStatus = StdResponseCode.Failed;

                }
                else
                {
                    std.ResponseCodeStatus = StdResponseCode.Success;
                }
                return std;
            }
            catch (Exception ex)
            {
                std.ResponseCodeStatus = StdResponseCode.Failed;
                ExceptionManager.HandleException(ex, 1000);///DO NOT KNOW WHAT SECOND PARAMETER IS? 
            }
            finally
            {
                proc = null;
            }
            return std;
        }

        public StandardResponse MappedOfficeGroupdtls(FocusGroupMappingInput Request)
        {
            StandardResponse Std = new StandardResponse();
            try
            {
                DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
                DBStoredProcedure sp = proc["usp_ManageFocusOfficeGroupMapping"];

                sp.Parameters["@GroupID"].Value = Request.GROUP_ID;
                sp.Parameters["@OfficeID"].Value = Request.OFFICE_ID;
                sp.Parameters["@UserID"].Value = Request.CreatedUserID;

                proc.ExecuteSP(sp);


                Std.ResponseCodeStatus = StdResponseCode.Success;
            }
            catch (Exception ex)
            {
                std.ResponseCodeStatus = StdResponseCode.Failed;
                ExceptionManager.HandleException(ex, 1000);///DO NOT KNOW WHAT SECOND PARAMETER IS? 
            }
            finally
            {
                //proc = null;
            }
            return Std;
        }

        public StandardResponse UpdatePreVersionRelease(ClientRelease Request)
        {
            StandardResponse std = new StandardResponse();
            try
            {
                DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
                DBStoredProcedure sp = proc[Constants.CONSTUPDATEPREVERSION];
                sp.Parameters["@RELEASE_VERSION_NM"].Value = Request.ClientReleaseVer.RELEASE_VERSION;
                sp.Parameters["@APP_ID"].Value = Request.ClientReleaseVer.App_ID;
                sp.Parameters["@Type"].Value = Request.ClientReleaseVer.APP_TYPE;
                proc.ExecuteSP(sp);
                std.ResponseCodeStatus = StdResponseCode.Success;
            }
            catch (Exception ex)
            {
                std.ResponseCodeStatus = StdResponseCode.Failed;
                string msg = ExceptionManager.GetErrorMessage(8051);//Need to be updated for actual Business error code 
                std.ResponseMessage = msg;
                LogManager.LogErrorMessage(ex, 9079);
            }
            return std;
        }

        public StandardResponse ImportPilotAppData(ManagePilotAppExcelSheetInput Request)
        {
            StandardResponse std = new StandardResponse();
            int status = 0;
            DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
            DBStoredProcedure sp = proc[Constants.CONSTIMPORTEXCELSHEET];
            try
            {
                if (Request.UploadType == "Excel")
                {

                    ////writing XML document
                    XmlDocument xDoc = new XmlDocument();
                    //File.Delete(ConfigurationSettings.AppSettings["UploadUtilityFilePath"].ToString() + "\\" + "AppPilotUser" + ".xml");
                    File.Delete(ConfigurationSettings.AppSettings["UploadUtilityFilePath"].ToString() + "\\" + "AppPilotUser" + ".xml");
                    //using (XmlWriter writer = XmlWriter.Create(ConfigurationSettings.AppSettings["UploadUtilityFilePath"].ToString() + "\\" + "AppPilotUser" + ".xml"))
                    using (XmlWriter writer = XmlWriter.Create(ConfigurationSettings.AppSettings["UploadUtilityFilePath"].ToString() + "\\" + "AppPilotUser" + ".xml"))
                    {
                        writer.WriteStartDocument();
                        writer.WriteStartElement("ROOT");

                        foreach (DataRow dr in Request.DtExcelData.Rows)
                        {
                            writer.WriteStartElement("Import");
                            writer.WriteElementString("OFFICE_ID", dr["OFFICE_ID"].ToString());
                            writer.WriteElementString("ADS_ID", dr["ADS_ID"].ToString());
                            writer.WriteElementString("USER_NM", dr["USER_NM"].ToString());
                            writer.WriteElementString("IP_ADDR_TXT", dr["IP_ADDR_TXT"].ToString());
                            writer.WriteElementString("COMPUTER_NM", dr["COMPUTER_NM"].ToString());
                            writer.WriteEndElement();
                        }

                        writer.WriteEndElement();
                        writer.WriteEndDocument();
                    }
                    //xDoc.Load(ConfigurationSettings.AppSettings["UploadUtilityFilePath"].ToString() + "\\" + "AppPilotUser" + ".xml");
                    xDoc.Load(ConfigurationSettings.AppSettings["UploadUtilityFilePath"].ToString() + "\\" + "AppPilotUser" + ".xml");
                    sp.Parameters["@INXMLDATA"].Value = xDoc.InnerXml;



                }
                else
                    sp.Parameters["@INXMLDATA"].Value = null;

                sp.Parameters["@GroupID"].Value = Request.GroupID;
                sp.Parameters["@AppId"].Value = Request.AppId;
                sp.Parameters["@AppVersion"].Value = Request.AppVersion;
                sp.Parameters["@CreatedBy"].Value = Request.CreatedUserId;
                sp.Parameters["@UploadType"].Value = Request.UploadType.ToUpper();
                proc.ExecuteSP(sp);
                status = int.Parse(sp.Parameters["@OUTSTATUS"].Value.ToString());
                if (status != 0)
                {
                    string message = ExceptionManager.GetErrorMessage(status);
                    std.ResponseMessage = message;
                    std.ResponseCodeStatus = StdResponseCode.Failed;
                }
                else
                {
                    std.ResponseCodeStatus = StdResponseCode.Success;
                }
                return std;
            }
            catch (Exception ex)
            {
                std.ResponseCodeStatus = StdResponseCode.Failed;
                LogManager.LogErrorMessage(ex, 8101);
            }
            finally
            {
                proc = null;
            }
            return std;
        }
        public StandardResponse ManageAppfAdsID(AppFOfficeAdsMappingID Request)
        {
            StandardResponse Std = new StandardResponse();
            try
            {
                DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB, 0);
                DBStoredProcedure sp = proc["usp_ManageFocusOfficeGroupMapping"];

                sp.Parameters["@GroupID"].Value = Request.GROUP_ID;
                sp.Parameters["@AdsID"].Value = Request.ADS_ID;
                sp.Parameters["@UserID"].Value = Request.CreatedUserID;
                sp.Parameters["@inType"].Value = Request.TYPE;
                proc.ExecuteSP(sp);
                Std.ResponseCodeStatus = StdResponseCode.Success;
            }
            catch (Exception ex)
            {
                std.ResponseCodeStatus = StdResponseCode.Failed;
                ExceptionManager.HandleException(ex, 1000);///DO NOT KNOW WHAT SECOND PARAMETER IS? 
            }
            finally
            {
                //proc = null;
            }
            return Std;
        }

        public StandardResponse AddOffice(AddOfficeInput Request)
        {
            StandardResponse Std = new StandardResponse();
            try
            {
                DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
                DBStoredProcedure sp = proc["usp_AddOffice"];

                sp.Parameters["@inOffice"].Value = Request.OfficeId;
                sp.Parameters["@inAdsId"].Value = Request.ADSId;
                sp.Parameters["@outActive"].Value = "";
                proc.ExecuteSP(sp);


                Std.ResponseCodeStatus = StdResponseCode.Success;
                Std.ResponseMessage = sp.Parameters["@outActive"].Value.ToString();
            }
            catch (Exception ex)
            {
                std.ResponseCodeStatus = StdResponseCode.Failed;
                ExceptionManager.HandleException(ex, 1000);///DO NOT KNOW WHAT SECOND PARAMETER IS? 
            }
            finally
            {
                //proc = null;
            }
            return Std;
        }

        //#region Manage Pending Approval

        //public StandardResponse ManagePendingApproval(ManagePendingApprovalInput[] Request)
        //{
        //    StandardResponse Std = new StandardResponse();
        //    try
        //    {
        //        DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
        //        DBStoredProcedure sp = proc[Constants.CONSTMANAGEPENDINGAPPROVAL];

        //        string xmlString = null;
        //        MemoryStream memoryStream = new MemoryStream();
        //        XmlSerializer inputXML = new XmlSerializer(Request.GetType());
        //        XmlTextWriter xmlTextWriter = new XmlTextWriter(memoryStream, Encoding.UTF8);
        //        inputXML.Serialize(xmlTextWriter, Request);
        //        memoryStream = (MemoryStream)xmlTextWriter.BaseStream;
        //        xmlString = UTF8ByteArrayToString(memoryStream.ToArray());
        //        sp.Parameters["@inXmlApproval"].Value = xmlString.ToString().Substring(39);
        //        proc.ExecuteSP(sp);
        //        Std.ResponseCodeStatus = StdResponseCode.Success;
        //    }
        //    catch (Exception ex)
        //    {

        //    }
        //    return Std;
        //}


        //#endregion

        //private void sendFileUplaodMail(string labelName, string uploadCrieteria, string fileURL)
        //{
        //    NotificationEmail notifyEmail = new NotificationEmail();
        //    MBSDAC mbsDAC = new MBSDAC();
        //    mbsDAC.NetworkUserId = ConfigurationSettings.AppSettings["NetworkUserId"].ToString();
        //    mbsDAC.NetworkPassword = ConfigurationSettings.AppSettings["NetworkPassword"].ToString();
        //    mbsDAC.SMTPServer = ConfigurationSettings.AppSettings["SMTPServer"].ToString();
        //    mbsDAC.EmailFrom = ConfigurationSettings.AppSettings["EmailFrom"].ToString();
        //    //mbsDAC.EmailTo = ConfigurationSettings.AppSettings["EmailTo"].ToString();

        //    AdminUserDetails[] adminEmail;
        //    adminEmail = this.PopulateAdminEmail();
        //    mbsDAC.EmailTo = adminEmail[0].Email;
        //    string mailBody = string.Empty;
        //    mailBody = "<font face='verdana' size='2'>Hi Recipient!<BR><BR>";
        //    mailBody += "A new file has been uploaded in GWiz." + "<BR><BR>";
        //    mailBody += "File Label Name:" + labelName + "<BR>";
        //    mailBody += "File Uploaded against crieteria :" + uploadCrieteria + "<BR>";
        //    mailBody += "File is pending for your approval.<BR> <a href='" + ConfigurationSettings.AppSettings["ApplicationPath"].ToString() + "PendingApproval.aspx" + "'>";
        //    mailBody += ConfigurationSettings.AppSettings["ApplicationPath"].ToString() + "PendingApproval.aspx" + "</a>";
        //    mailBody += "<BR><BR>Thanks <BR>";
        //    mailBody += "GWiz Admin <BR></font>";

        //    bool sendMail = notifyEmail.SendNotificationEmail(mbsDAC, mbsDAC.EmailFrom, mbsDAC.EmailTo, mbsDAC.SMTPServer, mbsDAC.NetworkUserId, mbsDAC.NetworkPassword, "A new file " + labelName + " uploaded in GWiz for approval", mailBody, null);

        //}

        //public string GetCode(string ClientCD, string AccountCD, string CountryCD, string CityCD, string OtherInfoID, string GlobalCD, string Mode)
        //{
        //    DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
        //    DBStoredProcedure sp = proc[Constants.CONSTSPFILEUP];

        //    sp.Parameters["@ClientCD"].Value = ClientCD;
        //    sp.Parameters["@AccountCD"].Value = AccountCD;
        //    sp.Parameters["@CountryCD"].Value = CountryCD;
        //    sp.Parameters["@CityCD"].Value = CityCD;
        //    sp.Parameters["@GlobalID"].Value = GlobalCD;
        //    sp.Parameters["@OtherInfoCD"].Value = OtherInfoID;
        //    sp.Parameters["@Mode"].Value = Mode;

        //    DataSet ds = new DataSet();
        //    string uploadCrieteria = string.Empty;
        //    try
        //    {
        //        ds = proc.GetDataset(sp);
        //        uploadCrieteria = ds.Tables[0].Rows[0][0].ToString();
        //    }
        //    catch (Exception ex)
        //    {
        //        uploadCrieteria = string.Empty;
        //    }
        //    finally
        //    {
        //        proc = null;
        //        ds = null;
        //    }
        //    return uploadCrieteria;
        //}

    }
}
