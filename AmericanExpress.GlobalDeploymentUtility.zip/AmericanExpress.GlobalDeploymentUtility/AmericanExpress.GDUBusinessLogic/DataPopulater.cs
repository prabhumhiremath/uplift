﻿//-----------------------------------------------------------------------
// <copyright file="GWizBusiness.cs" company="NIIT Technologies">
//  Copyright (c) NIIT Technologies. All rights reserved.
// </copyright>
// <summary>
// <Description>This is a partial class which used to take care of the business logic of data population</Description>
// <Author>NIIT Technologies</Author>
// <CreatedOn>11/03/2009</CreatedOn>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// </summary>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using AmericanExpress.GDU.BusinessEntities;
using AmericanExpress.GDU.Util.DataAccessHelper;
using AmericanExpress.GDU.Util.DBSchemaHelper;
using AmericanExpress.GDU.Utilities.ExceptionMgmt;
using AmericanExpress.GDU.Utilities.Diagnostics;
using System.Configuration;
namespace AmericanExpress.GDU.BusinessLogic
{
    public partial class GWizBusiness
    {
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        //public CategoryDetails[] PopulateCategory(SearchLinkInput input)
        //{
        //    CategoryDetails[] objLinkTypeDetails = null;
        //    DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
        //    DBStoredProcedure sp = proc[Constants.CONSTSPPOPCATNAME];
        //    DataSet ds = new DataSet();
        //    try
        //    {
        //        sp.Parameters["@inAccountCode"].Value = input.AccountCode;
        //        sp.Parameters["@inCountryCode"].Value = input.FromCountryCode;
        //        sp.Parameters["@inCityCode"].Value = input.FromCityCode;
        //        sp.Parameters["@inGlobalCode"].Value = input.GlobalCode;
        //        sp.Parameters["@inCarrierCode"].Value = input.CarrierCode;
        //        ds = proc.GetDataset(sp);
        //        objLinkTypeDetails = new CategoryDetails[ds.Tables[0].Rows.Count];

        //        for (int iCount = 0; iCount < ds.Tables[0].Rows.Count; iCount++)
        //        {
        //            objLinkTypeDetails[iCount] = new CategoryDetails();
        //            objLinkTypeDetails[iCount].CategoryCode = Convert.ToString(ds.Tables[0].Rows[iCount]["Label_ID"]);
        //            objLinkTypeDetails[iCount].CategoryName = Convert.ToString(ds.Tables[0].Rows[iCount]["Label_NM"]);
        //        }
        //        if (objLinkTypeDetails == null || objLinkTypeDetails.Length == 0)
        //        {
        //            objLinkTypeDetails = new CategoryDetails[1];
        //            objLinkTypeDetails[0] = new CategoryDetails();
        //        }
        //        objLinkTypeDetails[0].STDResponse = new StandardResponse();
        //        objLinkTypeDetails[0].STDResponse.ResponseCodeStatus = StdResponseCode.Success;
        //    }
        //    catch (Exception ex)
        //    {
        //        if (objLinkTypeDetails == null)
        //        {
        //            objLinkTypeDetails = new CategoryDetails[1];
        //            objLinkTypeDetails[0] = new CategoryDetails();
        //        }
        //        objLinkTypeDetails[0].STDResponse = new StandardResponse();
        //        string msg = ExceptionManager.GetErrorMessage(8050);
        //        objLinkTypeDetails[0].STDResponse.ResponseCodeStatus = StdResponseCode.Failed;
        //        objLinkTypeDetails[0].STDResponse.ResponseMessage = msg;
        //        LogManager.LogErrorMessage(msg, 9000);
        //    }
        //    finally
        //    {
        //        proc = null;
        //        ds = null;
        //    }
        //    return objLinkTypeDetails;
        //}

        public ApplicationDetailResponse[] PopulateApplicationResponse(ApplicationInput input)
        {
            ApplicationDetailResponse[] objApplicationDetails = null;
            DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
            DBStoredProcedure sp = proc[Constants.CONSTPOPACCNAME];
            DataSet ds = new DataSet();
            try
            {

                sp.Parameters["@ApplicationNM"].Value = input.ApplicationNM;
                sp.Parameters["@ApplicationAbbr"].Value = input.ApplicationAbbr;
                // sp.Parameters["@inType"].Value = input.STDinput.EnumType;

                ds = proc.GetDataset(sp);
                objApplicationDetails = new ApplicationDetailResponse[ds.Tables[0].Rows.Count];

                for (int iCount = 0; iCount < ds.Tables[0].Rows.Count; iCount++)
                {
                    objApplicationDetails[iCount] = new ApplicationDetailResponse();
                    objApplicationDetails[iCount].ApplicationNM = Convert.ToString(ds.Tables[0].Rows[iCount]["App_Name"]);
                    objApplicationDetails[iCount].ApplicationAbbr = Convert.ToString(ds.Tables[0].Rows[iCount]["App_Abbr_Name"]);
                    objApplicationDetails[iCount].ApplicationDeployPath = Convert.ToString(ds.Tables[0].Rows[iCount]["App_Deploy_Path"]);
                }
                if (objApplicationDetails == null || objApplicationDetails.Length == 0)
                {
                    objApplicationDetails = new ApplicationDetailResponse[1];
                    objApplicationDetails[0] = new ApplicationDetailResponse();
                }
                objApplicationDetails[0].STDResponse = new StandardResponse();
                objApplicationDetails[0].STDResponse.ResponseCodeStatus = StdResponseCode.Success;
            }
            catch (Exception ex)
            {
                if (objApplicationDetails == null)
                {
                    objApplicationDetails = new ApplicationDetailResponse[1];
                    objApplicationDetails[0] = new ApplicationDetailResponse();
                }
                objApplicationDetails[0].STDResponse = new StandardResponse();
                string msg = ExceptionManager.GetErrorMessage(8050);
                objApplicationDetails[0].STDResponse.ResponseCodeStatus = StdResponseCode.Failed;
                objApplicationDetails[0].STDResponse.ResponseMessage = msg;
                LogManager.LogErrorMessage(ex, 9080);
            }
            finally
            {
                proc = null;
                ds = null;
            }

            return objApplicationDetails;
        }

        public ApplicationDetails[] PopulateApplication()
        {
            ApplicationDetails[] objAppDetails = null;
            DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
            DBStoredProcedure sp = proc[Constants.CONSTPOPULATEAPPLICATION_GDU];
            DataSet ds = new DataSet();
            try
            {

                ds = proc.GetDataset(sp);
                objAppDetails = new ApplicationDetails[ds.Tables[0].Rows.Count];

                for (int iCount = 0; iCount < ds.Tables[0].Rows.Count; iCount++)
                {
                    objAppDetails[iCount] = new ApplicationDetails();
                    objAppDetails[iCount].AppID = Convert.ToInt32(ds.Tables[0].Rows[iCount]["App_ID"]);
                    objAppDetails[iCount].AppDeployPath = Convert.ToString(ds.Tables[0].Rows[iCount]["App_Deploy_Path"]);
                    objAppDetails[iCount].AppAbbrName = Convert.ToString(ds.Tables[0].Rows[iCount]["App_Abbr_Name"]);
                    objAppDetails[iCount].AppExeName = Convert.ToString(ds.Tables[0].Rows[iCount]["App_Exe_Name"]);
                    objAppDetails[iCount].AppAbbr = Convert.ToString(ds.Tables[0].Rows[iCount]["AppAbbr"]);
                    objAppDetails[iCount].EntryPoint = Convert.ToString(ds.Tables[0].Rows[iCount]["EntryPoint"]);
                    objAppDetails[iCount].App_Type = Convert.ToString(ds.Tables[0].Rows[iCount]["App_Type"]);

                }
                if (objAppDetails == null || objAppDetails.Length == 0)
                {
                    objAppDetails = new ApplicationDetails[1];
                    objAppDetails[0] = new ApplicationDetails();
                }
                objAppDetails[0].STDResponse = new StandardResponse();
                objAppDetails[0].STDResponse.ResponseCodeStatus = StdResponseCode.Success;
            }
            catch (Exception ex)
            {
                if (objAppDetails == null)
                {
                    objAppDetails = new ApplicationDetails[1];
                    objAppDetails[0] = new ApplicationDetails();
                }
                objAppDetails[0].STDResponse = new StandardResponse();
                string msg = ExceptionManager.GetErrorMessage(8050);
                objAppDetails[0].STDResponse.ResponseCodeStatus = StdResponseCode.Failed;
                objAppDetails[0].STDResponse.ResponseMessage = msg;
                LogManager.LogErrorMessage(ex, 9080);
            }
            finally
            {
                proc = null;
                ds = null;
            }

            return objAppDetails;
        }


        public AppUploadedReportDetail[] PopulateAppUploadedReport(AppUploadedReportInput Request)
        {
            AppUploadedReportDetail[] objDetails = null;
            DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
            DBStoredProcedure sp = proc[Constants.CONSTPOPAPPUPLOADEDREPORT];   //proc["usp_GetAppUploadedReport"];  
            DataSet ds = new DataSet();
            try
            {
                sp.Parameters["@UserID"].Value = Request.UserId;
                sp.Parameters["@From_Dt"].Value = Request.From_Dt;
                sp.Parameters["@To_Dt"].Value = Request.To_Date;
                sp.Parameters["@App_ID"].Value = Request.App_ID;
                sp.Parameters["@RollBack"].Value = Request.RollBack;

                sp.Parameters["@PageIndex"].Value = Request.CurrentPage;
                sp.Parameters["@PageSize"].Value = Request.PageSize;
                sp.Parameters["@SortColumn"].Value = Request.SortExpression;
                sp.Parameters["@SortOrder"].Value = Request.SortOrder;

                ds = proc.GetDataset(sp);
                //if (ds.Tables[0].Rows.Count > 0)
                //{
                objDetails = new AppUploadedReportDetail[ds.Tables[0].Rows.Count];
                //}
                for (int iCount = 0; iCount < ds.Tables[0].Rows.Count; iCount++)
                {
                    objDetails[iCount] = new AppUploadedReportDetail();
                    if (Convert.ToString(ds.Tables[0].Rows[iCount]["App_NM"]) != null)
                    {
                        objDetails[iCount].App_Name = Convert.ToString(ds.Tables[0].Rows[iCount]["App_NM"]);
                        objDetails[iCount].User_Name = Convert.ToString(ds.Tables[0].Rows[iCount]["User_NM"]);
                        objDetails[iCount].Version = Convert.ToString(ds.Tables[0].Rows[iCount]["Version"]);
                        objDetails[iCount].IP = Convert.ToString(ds.Tables[0].Rows[iCount]["IP"]);
                        objDetails[iCount].Computer_NM = Convert.ToString(ds.Tables[0].Rows[iCount]["Mac_NM"]);
                        objDetails[iCount].Upload_Dt = Convert.ToString(ds.Tables[0].Rows[iCount]["Upload_Dt"]);
                        objDetails[iCount].RollBack = Convert.ToString(ds.Tables[0].Rows[iCount]["RollBack"]);
                        objDetails[iCount].TotalRecords = Convert.ToInt32(ds.Tables[1].Rows[0]["TotalRecord"]);
                    }

                }

                if (objDetails == null || objDetails.Length == 0)
                {
                    objDetails = new AppUploadedReportDetail[1];
                    objDetails[0] = new AppUploadedReportDetail();
                }
                objDetails[0].STDResponse = new StandardResponse();
                objDetails[0].STDResponse.ResponseCodeStatus = StdResponseCode.Success;
            }
            catch (Exception ex)
            {
                if (objDetails == null)
                {
                    objDetails = new AppUploadedReportDetail[1];
                    objDetails[0] = new AppUploadedReportDetail();
                }
                objDetails[0].STDResponse = new StandardResponse();
                string msg = ExceptionManager.GetErrorMessage(8050);
                objDetails[0].STDResponse.ResponseCodeStatus = StdResponseCode.Failed;
                objDetails[0].STDResponse.ResponseMessage = msg;
                LogManager.LogErrorMessage(ex, 9080);
            }
            finally
            {
                proc = null;
                ds = null;
            }
            return objDetails;
        }



        /// <summary>
        /// GlobalCatergory
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        //public CategoryDetails[] PopulateGlobalCategory()
        //{
        //    CategoryDetails[] objLinkTypeDetails = null;
        //    DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
        //    DBStoredProcedure sp = proc[Constants.CONSTSPPOPGLOBALCATNAME];
        //    DataSet ds = new DataSet();
        //    try
        //    {
        //        ds = proc.GetDataset(sp);
        //        objLinkTypeDetails = new CategoryDetails[ds.Tables[0].Rows.Count];

        //        for (int iCount = 0; iCount < ds.Tables[0].Rows.Count; iCount++)
        //        {
        //            objLinkTypeDetails[iCount] = new CategoryDetails();
        //            objLinkTypeDetails[iCount].CategoryCode = Convert.ToString(ds.Tables[0].Rows[iCount]["Label_ID"]);
        //            objLinkTypeDetails[iCount].CategoryName = Convert.ToString(ds.Tables[0].Rows[iCount]["Label_NM"]);
        //        }
        //        if (objLinkTypeDetails == null || objLinkTypeDetails.Length == 0)
        //        {
        //            objLinkTypeDetails = new CategoryDetails[1];
        //            objLinkTypeDetails[0] = new CategoryDetails();
        //        }
        //        objLinkTypeDetails[0].STDResponse = new StandardResponse();
        //        objLinkTypeDetails[0].STDResponse.ResponseCodeStatus = StdResponseCode.Success;
        //    }
        //    catch (Exception ex)
        //    {
        //        if (objLinkTypeDetails == null)
        //        {
        //            objLinkTypeDetails = new CategoryDetails[1];
        //            objLinkTypeDetails[0] = new CategoryDetails();
        //        }
        //        objLinkTypeDetails[0].STDResponse = new StandardResponse();
        //        string msg = ExceptionManager.GetErrorMessage(8050);
        //        objLinkTypeDetails[0].STDResponse.ResponseCodeStatus = StdResponseCode.Failed;
        //        objLinkTypeDetails[0].STDResponse.ResponseMessage = msg;
        //        LogManager.LogErrorMessage(ex, 9080);
        //    }
        //    finally
        //    {
        //        proc = null;
        //        ds = null;
        //    }
        //    return objLinkTypeDetails;
        //}
        //public AggregationRule[] PopulateAggregationRule()
        //{
        //    AggregationRule[] aggregationRules = null;
        //    DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
        //    DBStoredProcedure sp = proc[Constants.CONSTSPPOPAGGRNAME];
        //    DataSet ds = new DataSet();
        //    try
        //    {
        //        ds = proc.GetDataset(sp);
        //        aggregationRules = new AggregationRule[ds.Tables[0].Rows.Count];

        //        for (int iCount = 0; iCount < ds.Tables[0].Rows.Count; iCount++)
        //        {
        //            aggregationRules[iCount] = new AggregationRule();
        //            aggregationRules[iCount].Aggregation_Rule_Id = Convert.ToInt32(ds.Tables[0].Rows[iCount]["Aggregation_Rule_Id"]);
        //            aggregationRules[iCount].Aggregation_Rule_NM = Convert.ToString(ds.Tables[0].Rows[iCount]["Aggregation_Rule_NM"]);
        //            aggregationRules[iCount].Aggregation_Rule_Sequence = Convert.ToInt32(ds.Tables[0].Rows[iCount]["Aggregation_Rule_Sequence"]);
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        ExceptionManager.HandleException(ex, 8000);//Need to be updated for actual Business error code 
        //    }
        //    finally
        //    {
        //        proc = null;
        //        ds = null;
        //    }
        //    return aggregationRules;


        //}

        //public CategoryDetails[] PopulateOtherInfoCategory(OtherInfoInput Request)
        //{
        //    CategoryDetails[] objLinkTypeDetails = null;
        //    DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
        //    DBStoredProcedure sp = proc[Constants.CONSTPOPOTHERCATNAME];
        //    DataSet ds = new DataSet();
        //    try
        //    {
        //        sp.Parameters["@inOtherInfoLabel_ID"].Value = Request.OtherInfoLabel_ID;
        //        ds = proc.GetDataset(sp);
        //        objLinkTypeDetails = new CategoryDetails[ds.Tables[0].Rows.Count];

        //        for (int iCount = 0; iCount < ds.Tables[0].Rows.Count; iCount++)
        //        {
        //            objLinkTypeDetails[iCount] = new CategoryDetails();
        //            objLinkTypeDetails[iCount].CategoryCode = Convert.ToString(ds.Tables[0].Rows[iCount]["Label_ID"]);
        //            objLinkTypeDetails[iCount].CategoryName = Convert.ToString(ds.Tables[0].Rows[iCount]["Label_NM"]);
        //        }
        //        if (objLinkTypeDetails.Length == 0 || objLinkTypeDetails == null)
        //        {
        //            objLinkTypeDetails = new CategoryDetails[1];
        //            objLinkTypeDetails[0] = new CategoryDetails();
        //        }
        //        objLinkTypeDetails[0].STDResponse = new StandardResponse();
        //        objLinkTypeDetails[0].STDResponse.ResponseCodeStatus = StdResponseCode.Success;
        //    }
        //    catch (Exception ex)
        //    {
        //        if (objLinkTypeDetails == null)
        //        {
        //            objLinkTypeDetails = new CategoryDetails[1];
        //            objLinkTypeDetails[0] = new CategoryDetails();
        //        }
        //        objLinkTypeDetails[0].STDResponse = new StandardResponse();
        //        string msg = ExceptionManager.GetErrorMessage(8050);
        //        objLinkTypeDetails[0].STDResponse.ResponseCodeStatus = StdResponseCode.Failed;
        //        objLinkTypeDetails[0].STDResponse.ResponseMessage = msg;
        //        LogManager.LogErrorMessage(ex, 9080);
        //    }

        //    finally
        //    {
        //        proc = null;
        //        ds = null;
        //    }
        //    return objLinkTypeDetails;
        //}

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        //public LinkTypeDetails[] PopulateLinkType()
        //{
        //    LinkTypeDetails[] objLinkTypeDetails = null;
        //    DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
        //    DBStoredProcedure sp = proc[Constants.CONSTPOPLINKTYPENAME];
        //    DataSet ds = new DataSet();
        //    try
        //    {
        //        ds = proc.GetDataset(sp);
        //        objLinkTypeDetails = new LinkTypeDetails[ds.Tables[0].Rows.Count];

        //        for (int iCount = 0; iCount < ds.Tables[0].Rows.Count; iCount++)
        //        {
        //            objLinkTypeDetails[iCount] = new LinkTypeDetails();
        //            objLinkTypeDetails[iCount].LinkTypeCode = Convert.ToString(ds.Tables[0].Rows[iCount]["LINKTYPE_CD"]);
        //            objLinkTypeDetails[iCount].LinkTypeName = Convert.ToString(ds.Tables[0].Rows[iCount]["LINKTYPE_NM"]);
        //        }
        //        if (objLinkTypeDetails == null || objLinkTypeDetails.Length == 0)
        //        {
        //            objLinkTypeDetails = new LinkTypeDetails[1];
        //            objLinkTypeDetails[0] = new LinkTypeDetails();
        //        }
        //        objLinkTypeDetails[0].STDResponse = new StandardResponse();
        //        objLinkTypeDetails[0].STDResponse.ResponseCodeStatus = StdResponseCode.Success;
        //    }
        //    catch (Exception ex)
        //    {
        //        if (objLinkTypeDetails == null)
        //        {
        //            objLinkTypeDetails = new LinkTypeDetails[1];
        //            objLinkTypeDetails[0] = new LinkTypeDetails();
        //        }
        //        objLinkTypeDetails[0].STDResponse = new StandardResponse();
        //        string msg = ExceptionManager.GetErrorMessage(8050);
        //        objLinkTypeDetails[0].STDResponse.ResponseCodeStatus = StdResponseCode.Failed;
        //        objLinkTypeDetails[0].STDResponse.ResponseMessage = msg;
        //        LogManager.LogErrorMessage(ex, 9080);
        //    }
        //    finally
        //    {
        //        proc = null;
        //        ds = null;
        //    }

        //    return objLinkTypeDetails;
        //}

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public LanguageDetails[] PopulateLanguage()
        {
            LanguageDetails[] objLanguageDetails = null;
            DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
            DBStoredProcedure sp = proc[Constants.CONSTPOPLANGNAME];
            DataSet ds = new DataSet();
            try
            {
                ds = proc.GetDataset(sp);
                objLanguageDetails = new LanguageDetails[ds.Tables[0].Rows.Count];

                for (int iCount = 0; iCount < ds.Tables[0].Rows.Count; iCount++)
                {
                    objLanguageDetails[iCount] = new LanguageDetails();
                    objLanguageDetails[iCount].LanguageCode = Convert.ToString(ds.Tables[0].Rows[iCount]["LANGUAGE_CD"]);
                    objLanguageDetails[iCount].LanguageName = Convert.ToString(ds.Tables[0].Rows[iCount]["LANGUAGE_NM"]);
                }
                if (objLanguageDetails == null || objLanguageDetails.Length == 0)
                {
                    objLanguageDetails = new LanguageDetails[1];
                    objLanguageDetails[0] = new LanguageDetails();
                }
                objLanguageDetails[0].STDResponse = new StandardResponse();
                objLanguageDetails[0].STDResponse.ResponseCodeStatus = StdResponseCode.Success;
            }
            catch (Exception ex)
            {
                if (objLanguageDetails == null)
                {
                    objLanguageDetails = new LanguageDetails[1];
                    objLanguageDetails[0] = new LanguageDetails();
                }
                objLanguageDetails[0].STDResponse = new StandardResponse();
                string msg = ExceptionManager.GetErrorMessage(8050);
                objLanguageDetails[0].STDResponse.ResponseCodeStatus = StdResponseCode.Failed;
                objLanguageDetails[0].STDResponse.ResponseMessage = msg;
                LogManager.LogErrorMessage(ex, 9080);
            }
            finally
            {
                proc = null;
                ds = null;
            }

            return objLanguageDetails;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        //public AccountDetails[] PopulateAccount(AccountInput input)
        //{
        //    AccountDetails[] objAccountDetails = null;
        //    DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
        //    DBStoredProcedure sp = proc[Constants.CONSTPOPACCNAME];
        //    DataSet ds = new DataSet();
        //    try
        //    {

        //        sp.Parameters["@inClientID"].Value = string.IsNullOrEmpty(input.ClientID) ? "0" : input.ClientID;
        //        sp.Parameters["@inType"].Value = input.STDinput.EnumType;

        //        ds = proc.GetDataset(sp);
        //        objAccountDetails = new AccountDetails[ds.Tables[0].Rows.Count];

        //        for (int iCount = 0; iCount < ds.Tables[0].Rows.Count; iCount++)
        //        {
        //            objAccountDetails[iCount] = new AccountDetails();
        //            objAccountDetails[iCount].AccountCode = Convert.ToString(ds.Tables[0].Rows[iCount]["ACCOUNT_CD"]);
        //            objAccountDetails[iCount].AccountName = Convert.ToString(ds.Tables[0].Rows[iCount]["ACCOUNT_NM"]);
        //            objAccountDetails[iCount].AccountType = Convert.ToBoolean(ds.Tables[0].Rows[iCount]["Is_Virtual"].ToString());
        //            objAccountDetails[iCount].IsGlobal = Convert.ToBoolean(ds.Tables[0].Rows[iCount]["IS_GLOBAL"].ToString());
        //        }
        //        if (objAccountDetails == null || objAccountDetails.Length == 0)
        //        {
        //            objAccountDetails = new AccountDetails[1];
        //            objAccountDetails[0] = new AccountDetails();
        //        }
        //        objAccountDetails[0].STDResponse = new StandardResponse();
        //        objAccountDetails[0].STDResponse.ResponseCodeStatus = StdResponseCode.Success;
        //    }
        //    catch (Exception ex)
        //    {
        //        if (objAccountDetails == null)
        //        {
        //            objAccountDetails = new AccountDetails[1];
        //            objAccountDetails[0] = new AccountDetails();
        //        }
        //        objAccountDetails[0].STDResponse = new StandardResponse();
        //        string msg = ExceptionManager.GetErrorMessage(8050);
        //        objAccountDetails[0].STDResponse.ResponseCodeStatus = StdResponseCode.Failed;
        //        objAccountDetails[0].STDResponse.ResponseMessage = msg;
        //        LogManager.LogErrorMessage(ex, 9080);
        //    }
        //    finally
        //    {
        //        proc = null;
        //        ds = null;
        //    }

        //    return objAccountDetails;
        //}

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        //public CountryDetails[] LoadCountry(CountryInput input)
        //{
        //    CountryDetails[] objCountryDetails = null;
        //    DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
        //    DBStoredProcedure sp = proc[Constants.CONSTPOPCOUNTNAME];
        //    DataSet ds = new DataSet();
        //    try
        //    {
        //        sp.Parameters["@inType"].Value = input.STDinput.EnumType;
        //        ds = proc.GetDataset(sp);
        //        objCountryDetails = new CountryDetails[ds.Tables[0].Rows.Count];

        //        for (int iCount = 0; iCount < ds.Tables[0].Rows.Count; iCount++)
        //        {
        //            objCountryDetails[iCount] = new CountryDetails();
        //            objCountryDetails[iCount].CountryCode = Convert.ToString(ds.Tables[0].Rows[iCount]["COUNTRY_CD"]);
        //            objCountryDetails[iCount].CountryName = Convert.ToString(ds.Tables[0].Rows[iCount]["COUNTRY_NM"]);
        //        }
        //        if (objCountryDetails == null || objCountryDetails.Length == 0)
        //        {
        //            objCountryDetails = new CountryDetails[1];
        //            objCountryDetails[0] = new CountryDetails();
        //        }
        //        objCountryDetails[0].STDResponse = new StandardResponse();
        //        objCountryDetails[0].STDResponse.ResponseCodeStatus = StdResponseCode.Success;
        //    }
        //    catch (Exception ex)
        //    {

        //        if (objCountryDetails == null)
        //        {
        //            objCountryDetails = new CountryDetails[1];
        //            objCountryDetails[0] = new CountryDetails();
        //        }

        //        objCountryDetails[0].STDResponse = new StandardResponse();
        //        string msg = ExceptionManager.GetErrorMessage(8050);
        //        objCountryDetails[0].STDResponse.ResponseCodeStatus = StdResponseCode.Failed;
        //        objCountryDetails[0].STDResponse.ResponseMessage = msg;
        //        LogManager.LogErrorMessage(ex, 9080);
        //    }
        //    finally
        //    {
        //        proc = null;
        //        ds = null;
        //    }

        //    return objCountryDetails;
        //}


        //public CountryDetails[] PopulateCountry(CountryInput input)
        //{
        //    CountryDetails[] objCountryDetails = null;
        //    DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
        //    DBStoredProcedure sp = proc[Constants.CONSTSPLOADCOUNTNAME];
        //    DataSet ds = new DataSet();
        //    try
        //    {
        //        sp.Parameters["@inType"].Value = input.STDinput.EnumType;
        //        sp.Parameters["@CountryName"].Value = input.CountryName;
        //        sp.Parameters["@MaxRecords"].Value = input.MaxRecord;
        //        ds = proc.GetDataset(sp);
        //        objCountryDetails = new CountryDetails[ds.Tables[0].Rows.Count];

        //        for (int iCount = 0; iCount < ds.Tables[0].Rows.Count; iCount++)
        //        {
        //            objCountryDetails[iCount] = new CountryDetails();
        //            objCountryDetails[iCount].CountryCode = Convert.ToString(ds.Tables[0].Rows[iCount]["COUNTRY_CD"]);
        //            objCountryDetails[iCount].CountryName = Convert.ToString(ds.Tables[0].Rows[iCount]["COUNTRY_NM"]);
        //            objCountryDetails[iCount].CountryType = Convert.ToBoolean(ds.Tables[0].Rows[iCount]["Is_Virtual"]);
        //            objCountryDetails[iCount].IsGlobal = Convert.ToBoolean(ds.Tables[0].Rows[iCount]["IS_GLOBAL"]);
        //        }
        //        if (objCountryDetails == null || objCountryDetails.Length == 0)
        //        {
        //            objCountryDetails = new CountryDetails[1];
        //            objCountryDetails[0] = new CountryDetails();
        //        }
        //        objCountryDetails[0].STDResponse = new StandardResponse();
        //        objCountryDetails[0].STDResponse.ResponseCodeStatus = StdResponseCode.Success;
        //    }
        //    catch (Exception ex)
        //    {
        //        if (objCountryDetails == null)
        //        {
        //            objCountryDetails = new CountryDetails[1];
        //            objCountryDetails[0] = new CountryDetails();
        //        }

        //        objCountryDetails[0].STDResponse = new StandardResponse();
        //        string msg = ExceptionManager.GetErrorMessage(8050);
        //        objCountryDetails[0].STDResponse.ResponseCodeStatus = StdResponseCode.Failed;
        //        objCountryDetails[0].STDResponse.ResponseMessage = msg;
        //        LogManager.LogErrorMessage(ex, 9080);
        //    }
        //    finally
        //    {
        //        proc = null;
        //        ds = null;
        //    }

        //    return objCountryDetails;
        //}

        /// <summary>
        /// 
        /// </summary>
        /// <param name="Request"></param>
        /// <returns></returns>
        //public CityDetails[] PopulateCity(CityInput Request)
        //{
        //    CityDetails[] objCityDetails = null;
        //    DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
        //    DBStoredProcedure sp = proc[Constants.CONSTSPPOPCITYNAME];
        //    DataSet ds = new DataSet();
        //    try
        //    {
        //        sp.Parameters["@inType"].Value = Request.STDinput.EnumType;
        //        sp.Parameters["@inCountryCd"].Value = Request.CountryCode;
        //        sp.Parameters["@inCityName"].Value = Request.CityName;
        //        sp.Parameters["@inMaxRecords"].Value = Request.MaxRecords;
        //        ds = proc.GetDataset(sp);
        //        objCityDetails = new CityDetails[ds.Tables[0].Rows.Count];

        //        for (int iCount = 0; iCount < ds.Tables[0].Rows.Count; iCount++)
        //        {
        //            objCityDetails[iCount] = new CityDetails();
        //            objCityDetails[iCount].CountryCode = Convert.ToString(ds.Tables[0].Rows[iCount]["COUNTRY_CD"]);
        //            objCityDetails[iCount].CityCode = Convert.ToString(ds.Tables[0].Rows[iCount]["CITY_CD"]);
        //            objCityDetails[iCount].CityName = Convert.ToString(ds.Tables[0].Rows[iCount]["CITY_NM"]);
        //            objCityDetails[iCount].CityType = Convert.ToBoolean(ds.Tables[0].Rows[iCount]["Is_Virtual"]);
        //            objCityDetails[iCount].IsGlobal = Convert.ToBoolean(ds.Tables[0].Rows[iCount]["IS_GLOBAL"]);
        //        }
        //        if (objCityDetails == null || objCityDetails.Length == 0)
        //        {
        //            objCityDetails = new CityDetails[1];
        //            objCityDetails[0] = new CityDetails();
        //        }
        //        objCityDetails[0].STDResponse = new StandardResponse();
        //        objCityDetails[0].STDResponse.ResponseCodeStatus = StdResponseCode.Success;
        //    }
        //    catch (Exception ex)
        //    {
        //        if (objCityDetails == null)
        //        {
        //            objCityDetails = new CityDetails[1];
        //            objCityDetails[0] = new CityDetails();

        //        }
        //        objCityDetails[0].STDResponse = new StandardResponse();
        //        string msg = ExceptionManager.GetErrorMessage(8050);
        //        objCityDetails[0].STDResponse.ResponseCodeStatus = StdResponseCode.Failed;
        //        objCityDetails[0].STDResponse.ResponseMessage = msg;
        //        LogManager.LogErrorMessage(ex, 9080); ;//Need to be updated for actual Business error code 
        //    }
        //    finally
        //    {
        //        proc = null;
        //        ds = null;
        //    }

        //    return objCityDetails;
        //}

        //public CityDetails[] PopulateCity12(CityInput Request)
        //{
        //    CityDetails[] objCityDetails = null;
        //    DBProceduresCollection proc = new DBProceduresCollection(Constants.DEVDB);
        //    DBStoredProcedure sp = proc["usp_PopulateCity"];
        //    DataSet ds = new DataSet();
        //    try
        //    {
        //        sp.Parameters["@inCountryCd"].Value = Request.CountryCode;
        //        ds = proc.GetDataset(sp);
        //        objCityDetails = new CityDetails[ds.Tables[0].Rows.Count];

        //        for (int iCount = 0; iCount < ds.Tables[0].Rows.Count; iCount++)
        //        {
        //            objCityDetails[iCount] = new CityDetails();
        //            objCityDetails[iCount].CountryCode = Convert.ToString(ds.Tables[0].Rows[iCount]["COUNTRY_CD"]);
        //            objCityDetails[iCount].CityCode = Convert.ToString(ds.Tables[0].Rows[iCount]["CITY_CD"]);
        //            objCityDetails[iCount].CityName = Convert.ToString(ds.Tables[0].Rows[iCount]["CITY_NM"]);
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        //ExceptionManager.HandleException(ex, 2014);
        //    }
        //    finally
        //    {
        //        proc = null;
        //        ds = null;
        //    }

        //    return objCityDetails;
        //}


        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        //public OtherInfoDetails[] PopulateOtherInfo()
        //{
        //    OtherInfoDetails[] objOtherInfoDetails = null;
        //    DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
        //    DBStoredProcedure sp = proc[Constants.CONSTPOPOTHERNAME];
        //    DataSet ds = new DataSet();
        //    try
        //    {
        //        ds = proc.GetDataset(sp);
        //        objOtherInfoDetails = new OtherInfoDetails[ds.Tables[0].Rows.Count];

        //        for (int iCount = 0; iCount < ds.Tables[0].Rows.Count; iCount++)
        //        {
        //            objOtherInfoDetails[iCount] = new OtherInfoDetails();
        //            objOtherInfoDetails[iCount].OtherInfoID = Convert.ToString(ds.Tables[0].Rows[iCount]["OTHERINFOLABEL_ID"]);
        //            objOtherInfoDetails[iCount].OtherInfoName = Convert.ToString(ds.Tables[0].Rows[iCount]["OTHERINFOLABEL_NM"]);
        //        }
        //        if (objOtherInfoDetails == null || objOtherInfoDetails.Length == 0)
        //        {
        //            objOtherInfoDetails = new OtherInfoDetails[1];
        //            objOtherInfoDetails[0] = new OtherInfoDetails();
        //        }
        //        objOtherInfoDetails[0].STDResponse = new StandardResponse();
        //        objOtherInfoDetails[0].STDResponse.ResponseCodeStatus = StdResponseCode.Success;
        //    }
        //    catch (Exception ex)
        //    {
        //        if (objOtherInfoDetails == null)
        //        {
        //            objOtherInfoDetails = new OtherInfoDetails[1];
        //            objOtherInfoDetails[0] = new OtherInfoDetails();
        //        }
        //        objOtherInfoDetails[0].STDResponse = new StandardResponse();
        //        string msg = ExceptionManager.GetErrorMessage(8050);
        //        objOtherInfoDetails[0].STDResponse.ResponseCodeStatus = StdResponseCode.Failed;
        //        objOtherInfoDetails[0].STDResponse.ResponseMessage = msg;
        //        LogManager.LogErrorMessage(ex, 9080);
        //    }
        //    finally
        //    {
        //        proc = null;
        //        ds = null;
        //    }

        //    return objOtherInfoDetails;
        //}


        /// <summary>
        /// 
        /// </summary>
        /// <param name="Request"></param>
        /// <returns></returns>
        public ReportDetails[] PopulateGwizReport(ReportInput Request)
        {
            ReportDetails[] objReportCollection = null;
            DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
            DBStoredProcedure sp = proc[Constants.CONSTSPADMINSEARCH];
            DataSet ds = new DataSet();
            String strAccount = null;
            String strCountry = null;
            String strCity = null;
            String strClientId = null;
            //String strOtherInfo = null;

            if (!String.IsNullOrEmpty(Request.strAccount))
            {
                strAccount = Request.strAccount.ToString();
            }
            if (!String.IsNullOrEmpty(Request.strCountry))
            {
                strCountry = Request.strCountry.ToString();
            }
            if (!String.IsNullOrEmpty(Request.strCity))
            {
                strCity = Request.strCity.ToString();
            }

            if (!String.IsNullOrEmpty(Request.strClientId))
            {
                strClientId = Request.strClientId.ToString();
            }
            try
            {
                sp.Parameters["@inAccountID"].Value = strAccount;
                sp.Parameters["@inCountryID"].Value = strCountry;
                sp.Parameters["@inCityID"].Value = strCity;
                sp.Parameters["@inClientID"].Value = strClientId;

                ds = proc.GetDataset(sp);
                objReportCollection = new ReportDetails[ds.Tables[0].Rows.Count];
                for (int iCount = 0; iCount < ds.Tables[0].Rows.Count; iCount++)
                {
                    objReportCollection[iCount] = new ReportDetails();
                    objReportCollection[iCount].Account = Convert.ToString(ds.Tables[0].Rows[iCount]["Account_NM"]);
                    objReportCollection[iCount].Country = Convert.ToString(ds.Tables[0].Rows[iCount]["Country_NM"]);
                    objReportCollection[iCount].City = Convert.ToString(ds.Tables[0].Rows[iCount]["CITY_NM"]);
                    objReportCollection[iCount].lc_LinkType_NM = Convert.ToString(ds.Tables[0].Rows[iCount]["LinkType_NM"]);
                    objReportCollection[iCount].lc_Link_Type = Convert.ToString(ds.Tables[0].Rows[iCount]["ld_linktype"]);
                    objReportCollection[iCount].lc_Hover_Txt = Convert.ToString(ds.Tables[0].Rows[iCount]["Hover_Txt"]);
                    objReportCollection[iCount].lc_Label = Convert.ToString(ds.Tables[0].Rows[iCount]["Label_NM"]);
                    objReportCollection[iCount].lc_Language = Convert.ToString(ds.Tables[0].Rows[iCount]["Language_NM"]);
                    objReportCollection[iCount].lc_Link = Convert.ToString(ds.Tables[0].Rows[iCount]["Link"]);
                    //objReportCollection[iCount].lc_Link_Type = Convert.ToString(ds.Tables[0].Rows[iCount]["ld_linktype"]);
                    objReportCollection[iCount].lcd_File_Path = Convert.ToString(ds.Tables[0].Rows[iCount]["Link_Type"]);
                    objReportCollection[iCount].lcd_Hover_Txt = Convert.ToString(ds.Tables[0].Rows[iCount]["LCD_Hover_Txt"]);
                    objReportCollection[iCount].lcd_Label = Convert.ToString(ds.Tables[0].Rows[iCount]["lcd_label"]);
                    objReportCollection[iCount].lcd_language = Convert.ToString(ds.Tables[0].Rows[iCount]["lcd_language"]);
                    objReportCollection[iCount].lcd_Link = Convert.ToString(ds.Tables[0].Rows[iCount]["LCD_LINK"]);
                    objReportCollection[iCount].lcd_Link_Type = Convert.ToString(ds.Tables[0].Rows[iCount]["Link_Type"]);
                    objReportCollection[iCount].Link_ID = Convert.ToString(ds.Tables[0].Rows[iCount]["Link_ID"]);
                    objReportCollection[iCount].Link_Dtl_ID = Convert.ToString(ds.Tables[0].Rows[iCount]["Link_Dtl_ID"]);
                    objReportCollection[iCount].Link_Cat_Dtl_ID = Convert.ToString(ds.Tables[0].Rows[iCount]["Link_Cat_Dtl_ID"]);
                }
            }
            catch (Exception ex)
            {
                ExceptionManager.HandleException(ex, 8000);//Need to be updated for actual Business error code 
            }
            finally
            {
                proc = null;
                ds = null;
            }
            return objReportCollection;

        }

        /// <summary>
        /// Populates OtherInfoReportDetails collection
        /// </summary>
        /// <param name="Request"></param>
        /// <returns></returns>
        //public OtherInfoReportDetails[] PopulateGWizOtherInfoReport(OtherInfoReportInput Request)
        //{
        //    OtherInfoReportDetails[] objOtherInfoReportDetails = null;
        //    DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
        //    DBStoredProcedure sp = proc[Constants.CONSTSPADMINSEARCH];
        //    DataSet ds = new DataSet();
        //    //String strAccount = null;
        //    //String strCountry = null;
        //    //String strCity = null;
        //    String OtherInfoLabelID = null;

        //    if (!String.IsNullOrEmpty(Request.OtherInfoLabelID))
        //    {
        //        OtherInfoLabelID = Request.OtherInfoLabelID.ToString();
        //    }
        //    try
        //    {
        //        sp.Parameters["@inOtherInfoLabelID"].Value = OtherInfoLabelID;
        //        ds = proc.GetDataset(sp);
        //        objOtherInfoReportDetails = new OtherInfoReportDetails[ds.Tables[0].Rows.Count];
        //        for (int iCount = 0; iCount < ds.Tables[0].Rows.Count; iCount++)
        //        {
        //            objOtherInfoReportDetails[iCount] = new OtherInfoReportDetails();
        //            objOtherInfoReportDetails[iCount].OtherInfoLable_Lable_NM = Convert.ToString(ds.Tables[0].Rows[iCount]["OTHERINFOLABEL_NM"]);
        //            objOtherInfoReportDetails[iCount].Label_NM = Convert.ToString(ds.Tables[0].Rows[iCount]["otherinfo_label"]);
        //            objOtherInfoReportDetails[iCount].LinkType_NM = Convert.ToString(ds.Tables[0].Rows[iCount]["LinkType_NM"]);
        //            objOtherInfoReportDetails[iCount].OtherInfo_Hover_Txt = Convert.ToString(ds.Tables[0].Rows[iCount]["OtherInfo_Hover_Txt"]);
        //            objOtherInfoReportDetails[iCount].OtherInfo_Language_NM = Convert.ToString(ds.Tables[0].Rows[iCount]["OtherInfo_Language"]);
        //            objOtherInfoReportDetails[iCount].OtherInfo_Link = Convert.ToString(ds.Tables[0].Rows[iCount]["OtherInfo_Link"]);
        //            objOtherInfoReportDetails[iCount].OtherInfo_Link_Type = Convert.ToString(ds.Tables[0].Rows[iCount]["OtherInfo_Link_Type"]);
        //            objOtherInfoReportDetails[iCount].OtherInfoDetail_hover_txt = Convert.ToString(ds.Tables[0].Rows[iCount]["OtherInfoDetail_hover_txt"]);
        //            objOtherInfoReportDetails[iCount].OtherInfoDetail_label = Convert.ToString(ds.Tables[0].Rows[iCount]["OtherInfoDetail_label"]);
        //            objOtherInfoReportDetails[iCount].OtherInfoDetail_language = Convert.ToString(ds.Tables[0].Rows[iCount]["OtherInfoDetail_language"]);
        //            objOtherInfoReportDetails[iCount].OtherInfoDetail_Link = Convert.ToString(ds.Tables[0].Rows[iCount]["OtherInfoDetail_Link"]);
        //            objOtherInfoReportDetails[iCount].OtherInfoDetail_Link_Type = Convert.ToString(ds.Tables[0].Rows[iCount]["OtherInfoDetail_Link_Type"]);
        //            objOtherInfoReportDetails[iCount].OtherInfoID = Convert.ToString(ds.Tables[0].Rows[iCount]["OtherInfo_ID"]);
        //            objOtherInfoReportDetails[iCount].OtherInfoDetailID = Convert.ToString(ds.Tables[0].Rows[iCount]["OtherInfo_Dtl_ID"]);
        //        }
        //        if (objOtherInfoReportDetails == null || objOtherInfoReportDetails.Length == 0)
        //        {
        //            objOtherInfoReportDetails = new OtherInfoReportDetails[1];
        //            objOtherInfoReportDetails[0] = new OtherInfoReportDetails();
        //        }
        //        objOtherInfoReportDetails[0].STDResponse = new StandardResponse();
        //        objOtherInfoReportDetails[0].STDResponse.ResponseCodeStatus = StdResponseCode.Success;
        //    }
        //    catch (Exception ex)
        //    {


        //        objOtherInfoReportDetails[0].STDResponse = new StandardResponse();
        //        string msg = ExceptionManager.GetErrorMessage(8050);
        //        objOtherInfoReportDetails[0].STDResponse.ResponseCodeStatus = StdResponseCode.Failed;
        //        objOtherInfoReportDetails[0].STDResponse.ResponseMessage = msg;
        //        LogManager.LogErrorMessage(ex, 9080);
        //    }
        //    finally
        //    {
        //        proc = null;
        //        ds = null;
        //    }
        //    return objOtherInfoReportDetails;
        //}

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        //public ReportDetails[] PupulateGWizBrokenInfoReport()
        //{
        //    ReportDetails[] objReportCollection = null;
        //    DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
        //    DBStoredProcedure sp = proc[Constants.CONSTSPBROKEN];
        //    DataSet ds = new DataSet();

        //    try
        //    {
        //        sp.Parameters["@inFlag"].Value = "Location";

        //        ds = proc.GetDataset(sp);
        //        objReportCollection = new ReportDetails[ds.Tables[0].Rows.Count];
        //        for (int iCount = 0; iCount < ds.Tables[0].Rows.Count; iCount++)
        //        {
        //            objReportCollection[iCount] = new ReportDetails();
        //            objReportCollection[iCount].lc_LinkType_NM = Convert.ToString(ds.Tables[0].Rows[iCount]["LinkType_NM"]);
        //            objReportCollection[iCount].lc_Link_Type = Convert.ToString(ds.Tables[0].Rows[iCount]["ld_linktype"]);
        //            objReportCollection[iCount].lc_Hover_Txt = Convert.ToString(ds.Tables[0].Rows[iCount]["Hover_Txt"]);
        //            objReportCollection[iCount].lc_Label = Convert.ToString(ds.Tables[0].Rows[iCount]["Label_NM"]);
        //            objReportCollection[iCount].lc_Language = Convert.ToString(ds.Tables[0].Rows[iCount]["Language_NM"]);
        //            objReportCollection[iCount].lc_Link = Convert.ToString(ds.Tables[0].Rows[iCount]["Link"]);
        //            objReportCollection[iCount].lcd_File_Path = Convert.ToString(ds.Tables[0].Rows[iCount]["Link_Type"]);
        //            objReportCollection[iCount].lcd_Hover_Txt = Convert.ToString(ds.Tables[0].Rows[iCount]["LCD_Hover_Txt"]);
        //            objReportCollection[iCount].lcd_Label = Convert.ToString(ds.Tables[0].Rows[iCount]["lcd_label"]);
        //            objReportCollection[iCount].lcd_language = Convert.ToString(ds.Tables[0].Rows[iCount]["lcd_language"]);
        //            objReportCollection[iCount].lcd_Link = Convert.ToString(ds.Tables[0].Rows[iCount]["LCD_LINK"]);
        //            objReportCollection[iCount].lcd_Link_Type = Convert.ToString(ds.Tables[0].Rows[iCount]["Link_Type"]);

        //        }

        //    }
        //    catch (Exception ex)
        //    {
        //        ExceptionManager.HandleException(ex, 8000);//Need to be updated for actual Business error code 
        //    }
        //    finally
        //    {
        //        proc = null;
        //        ds = null;
        //    }
        //    return objReportCollection;
        //}

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        //public OtherInfoReportDetails[] PupulateGWizOtherBrokenInfoReport()
        //{
        //    OtherInfoReportDetails[] objOtherInfoReportDetails = null;
        //    DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
        //    DBStoredProcedure sp = proc[Constants.CONSTSPBROKEN];
        //    DataSet ds = new DataSet();

        //    try
        //    {
        //        sp.Parameters["@inFlag"].Value = Constants.CONSTOTHR;
        //        ds = proc.GetDataset(sp);
        //        objOtherInfoReportDetails = new OtherInfoReportDetails[ds.Tables[0].Rows.Count];
        //        for (int iCount = 0; iCount < ds.Tables[0].Rows.Count; iCount++)
        //        {
        //            objOtherInfoReportDetails[iCount] = new OtherInfoReportDetails();
        //            objOtherInfoReportDetails[iCount].OtherInfoDetail_hover_txt = Convert.ToString(ds.Tables[0].Rows[iCount]["Hover_Txt"]);
        //            objOtherInfoReportDetails[iCount].OtherInfoDetail_label = Convert.ToString(ds.Tables[0].Rows[iCount]["Label_NM"]);
        //            objOtherInfoReportDetails[iCount].OtherInfoDetail_language = Convert.ToString(ds.Tables[0].Rows[iCount]["Language_NM"]);
        //            objOtherInfoReportDetails[iCount].OtherInfoDetail_Link = Convert.ToString(ds.Tables[0].Rows[iCount]["Link"]);
        //            objOtherInfoReportDetails[iCount].OtherInfoDetail_Link_Type = Convert.ToString(ds.Tables[0].Rows[iCount]["Link_Type"]);
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        ExceptionManager.HandleException(ex, 8000);//Need to be updated for actual Business error code 
        //    }
        //    finally
        //    {
        //        proc = null;
        //        ds = null;
        //    }
        //    return objOtherInfoReportDetails;
        //}

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public UserRoleDetails[] PopulateUserRole()
        {
            UserRoleDetails[] objRoleDetails = null;
            DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
            DBStoredProcedure sp = proc[Constants.CONSTPOPUSERROLE];
            DataSet ds = new DataSet();
            try
            {
                ds = proc.GetDataset(sp);
                objRoleDetails = new UserRoleDetails[ds.Tables[0].Rows.Count];

                for (int iCount = 0; iCount < ds.Tables[0].Rows.Count; iCount++)
                {
                    objRoleDetails[iCount] = new UserRoleDetails();
                    objRoleDetails[iCount].RoleCode = Convert.ToString(ds.Tables[0].Rows[iCount]["ROLE_CD"]);
                    objRoleDetails[iCount].RoleName = Convert.ToString(ds.Tables[0].Rows[iCount]["ROLE_NM"]);
                    objRoleDetails[iCount].ClientID = Convert.ToString(ds.Tables[0].Rows[iCount]["Client_ID"]);
                }
            }
            catch (Exception ex)
            {
                ExceptionManager.HandleException(ex, 8000);//Need to be updated for actual Business error code 
            }
            finally
            {
                proc = null;
                ds = null;
            }
            return objRoleDetails;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        //public FeedbackType[] PopulateFeedbackType()
        //{
        //    FeedbackType[] objDetails = null;
        //    DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
        //    DBStoredProcedure sp = proc[Constants.CONSTPOPFEEDTYPE];
        //    DataSet ds = new DataSet();
        //    try
        //    {
        //        ds = proc.GetDataset(sp);
        //        objDetails = new FeedbackType[ds.Tables[0].Rows.Count];

        //        for (int iCount = 0; iCount < ds.Tables[0].Rows.Count; iCount++)
        //        {
        //            objDetails[iCount] = new FeedbackType();
        //            objDetails[iCount].FeedbackTypeCode = Convert.ToString(ds.Tables[0].Rows[iCount]["FeedbackType_CD"]);
        //            objDetails[iCount].FeedbackTypeDesc = Convert.ToString(ds.Tables[0].Rows[iCount]["FeedbackType_NM"]);
        //        }
        //        if (objDetails == null || objDetails.Length == 0)
        //        {
        //            objDetails = new FeedbackType[1];
        //            objDetails[0] = new FeedbackType();
        //        }
        //        objDetails[0].STDResponse = new StandardResponse();
        //        objDetails[0].STDResponse.ResponseCodeStatus = StdResponseCode.Success;
        //    }
        //    catch (Exception ex)
        //    {
        //        if (objDetails == null)
        //        {
        //            objDetails = new FeedbackType[1];
        //            objDetails[0] = new FeedbackType();
        //        }
        //        objDetails[0].STDResponse = new StandardResponse();
        //        string msg = ExceptionManager.GetErrorMessage(8050);
        //        objDetails[0].STDResponse.ResponseCodeStatus = StdResponseCode.Failed;
        //        objDetails[0].STDResponse.ResponseMessage = msg;
        //        LogManager.LogErrorMessage(ex, 9080);
        //    }
        //    finally
        //    {
        //        proc = null;
        //        ds = null;
        //    }
        //    return objDetails;
        //}

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        //public FeedbackTypeDetails[] PopulateFeedbackTypeReport(FeedbackReportInput Request)
        //{
        //    FeedbackTypeDetails[] objDetails = null;
        //    DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
        //    DBStoredProcedure sp = proc[Constants.CONSTPOPFEEDREPORT];
        //    DataSet ds = new DataSet();
        //    try
        //    {
        //        sp.Parameters["@inFeedbackType"].Value = Request.FeedbackType;
        //        sp.Parameters["@inFromDate"].Value = Request.FromDate;
        //        sp.Parameters["@inToDate"].Value = Request.ToDate;
        //        sp.Parameters["@inFeedbackClient"].Value = Request.FeedbackClient;

        //        ds = proc.GetDataset(sp);
        //        objDetails = new FeedbackTypeDetails[ds.Tables[0].Rows.Count];

        //        for (int iCount = 0; iCount < ds.Tables[0].Rows.Count; iCount++)
        //        {
        //            objDetails[iCount] = new FeedbackTypeDetails();
        //            objDetails[iCount].FeedBackId = Convert.ToInt32(ds.Tables[0].Rows[iCount]["Feedback_ID"]);
        //            objDetails[iCount].FeedbackRemark = Convert.ToString(ds.Tables[0].Rows[iCount]["Remarks_Txt"]);
        //            objDetails[iCount].FeedBackType = Convert.ToString(ds.Tables[0].Rows[iCount]["FeedbackType_NM"]);
        //            objDetails[iCount].FeedbackLinkTypeCode = Convert.ToString(ds.Tables[0].Rows[iCount]["FeedbackType_CD"]);
        //            objDetails[iCount].FeedbackLinkType = Convert.ToString(ds.Tables[0].Rows[iCount]["FeedbackType_CD"]);
        //            objDetails[iCount].FeedbackMode = Convert.ToString(ds.Tables[0].Rows[iCount]["Mode"]);
        //            objDetails[iCount].FeedbackRating = Convert.ToInt32(ds.Tables[0].Rows[iCount]["Rating"]);
        //            objDetails[iCount].FeedbackAdsId = Convert.ToString(ds.Tables[0].Rows[iCount]["ADS_ID"]);
        //            objDetails[iCount].FeedbackAds = Convert.ToString(ds.Tables[0].Rows[iCount]["User_NM"]);
        //            objDetails[iCount].FeedbackLabel = Convert.ToString(ds.Tables[0].Rows[iCount]["FeedbackType_CD"]);
        //            objDetails[iCount].FeedbackLabelId = Convert.ToInt32(ds.Tables[0].Rows[iCount]["Label_ID"]);
        //            objDetails[iCount].FeedbackUserEmailAdd = Convert.ToString(ds.Tables[0].Rows[iCount]["Email_Add_Txt"]);
        //            objDetails[iCount].CreatedDate = Convert.ToString(ds.Tables[0].Rows[iCount]["Created_DT"]);
        //            objDetails[iCount].FeedbackFileURL = Convert.ToString(ds.Tables[0].Rows[iCount]["File_URL"]);
        //            // objDetails[iCount].FeedBackClient = Convert.ToString(ds.Tables[0].Rows[iCount]["Client"]);
        //        }

        //        if (objDetails == null || objDetails.Length == 0)
        //        {
        //            objDetails = new FeedbackTypeDetails[1];
        //            objDetails[0] = new FeedbackTypeDetails();
        //        }
        //        objDetails[0].STDResponse = new StandardResponse();
        //        objDetails[0].STDResponse.ResponseCodeStatus = StdResponseCode.Success;
        //    }
        //    catch (Exception ex)
        //    {
        //        if (objDetails == null)
        //        {
        //            objDetails = new FeedbackTypeDetails[1];
        //            objDetails[0] = new FeedbackTypeDetails();
        //        }
        //        objDetails[0].STDResponse = new StandardResponse();
        //        string msg = ExceptionManager.GetErrorMessage(8050);
        //        objDetails[0].STDResponse.ResponseCodeStatus = StdResponseCode.Failed;
        //        objDetails[0].STDResponse.ResponseMessage = msg;
        //        LogManager.LogErrorMessage(ex, 9080);
        //    }
        //    finally
        //    {
        //        proc = null;
        //        ds = null;
        //    }
        //    return objDetails;
        //}

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public ClientDeploymentReportDetail[] PopulateClientDeploymentReport(ClientDeploymentReportInput Request)
        {
            ClientDeploymentReportDetail[] objDetails = null;
            DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB, 0);
            DataSet ds = new DataSet();
            try
            {
                if (Request.System_CD == "GD")
                {
                    DBStoredProcedure sp = proc[Constants.CONSTPOPCLIENTDEPLOYMENTREPORT_GDU];

                    sp.Parameters["@UserID"].Value = Request.UserId;
                    sp.Parameters["@Version"].Value = Request.Version;
                    sp.Parameters["@NonMaxFlag"].Value = Request.NonMaxFlag;
                    sp.Parameters["@ClientId"].Value = Request.clientId;
                    sp.Parameters["@App_ID"].Value = Request.App_ID;

                    sp.Parameters["@PageIndex"].Value = Request.CurrentPage;
                    sp.Parameters["@PageSize"].Value = Request.PageSize;
                    sp.Parameters["@SortColumn"].Value = Request.SortExpression;
                    sp.Parameters["@SortOrder"].Value = Request.SortOrder;
                    ds = proc.GetDataset(sp);
                    objDetails = new ClientDeploymentReportDetail[ds.Tables[0].Rows.Count];

                    for (int iCount = 0; iCount < ds.Tables[0].Rows.Count; iCount++)
                    {
                        objDetails[iCount] = new ClientDeploymentReportDetail();
                        objDetails[iCount].App_Name = Convert.ToString(ds.Tables[0].Rows[iCount]["App_Name"]);
                        objDetails[iCount].UserId = Convert.ToString(ds.Tables[0].Rows[iCount]["User_Id"]);
                        objDetails[iCount].IPAddress = Convert.ToString(ds.Tables[0].Rows[iCount]["IP"]);
                        objDetails[iCount].NACId = Convert.ToString(ds.Tables[0].Rows[iCount]["Nac_Id"]);
                        objDetails[iCount].ExeVersionNo = Convert.ToString(ds.Tables[0].Rows[iCount]["Exe_VersionNo"]);
                        objDetails[iCount].ExeTimeStamp = Convert.ToDateTime(ds.Tables[0].Rows[iCount]["Exe_TimeStamp_DT"]);
                        objDetails[iCount].RecordTimeStamp = Convert.ToDateTime(ds.Tables[0].Rows[iCount]["RecordTimeStamp_DT"]);
                        objDetails[iCount].ApplicationPath = Convert.ToString(ds.Tables[0].Rows[iCount]["Application_Path"]);
                        objDetails[iCount].LatestVersionNo = Convert.ToString(ds.Tables[0].Rows[iCount]["Latest_VersionNo"]);
                        objDetails[iCount].ComputerName = Convert.ToString(ds.Tables[0].Rows[iCount]["Computer_Name"]);
                        objDetails[iCount].TotalRecords = Convert.ToInt32(ds.Tables[1].Rows[0]["TotalRecords"]);
                    }
                }
                else
                {
                    DBStoredProcedure sp = proc[Constants.CONSTPOPCLIENTDEPLOYMENTREPORT];

                    sp.Parameters["@UserID"].Value = Request.UserId;
                    sp.Parameters["@Version"].Value = Request.Version;
                    sp.Parameters["@NonMaxFlag"].Value = Request.NonMaxFlag;
                    sp.Parameters["@ClientId"].Value = Request.clientId;
                    ds = proc.GetDataset(sp);
                    objDetails = new ClientDeploymentReportDetail[ds.Tables[0].Rows.Count];

                    for (int iCount = 0; iCount < ds.Tables[0].Rows.Count; iCount++)
                    {
                        objDetails[iCount] = new ClientDeploymentReportDetail();
                        objDetails[iCount].App_Name = string.Empty;
                        objDetails[iCount].UserId = Convert.ToString(ds.Tables[0].Rows[iCount]["User_Id"]);
                        objDetails[iCount].IPAddress = Convert.ToString(ds.Tables[0].Rows[iCount]["IP"]);
                        objDetails[iCount].NACId = Convert.ToString(ds.Tables[0].Rows[iCount]["Nac_Id"]);
                        objDetails[iCount].ExeVersionNo = Convert.ToString(ds.Tables[0].Rows[iCount]["Exe_VersionNo"]);
                        objDetails[iCount].ExeTimeStamp = Convert.ToDateTime(ds.Tables[0].Rows[iCount]["Exe_TimeStamp_DT"]);
                        objDetails[iCount].RecordTimeStamp = Convert.ToDateTime(ds.Tables[0].Rows[iCount]["RecordTimeStamp_DT"]);
                        objDetails[iCount].ApplicationPath = Convert.ToString(ds.Tables[0].Rows[iCount]["Application_Path"]);
                        objDetails[iCount].LatestVersionNo = Convert.ToString(ds.Tables[0].Rows[iCount]["Latest_VersionNo"]);
                        objDetails[iCount].ComputerName = Convert.ToString(ds.Tables[0].Rows[iCount]["Computer_Name"]);
                    }

                }


                if (objDetails == null || objDetails.Length == 0)
                {
                    objDetails = new ClientDeploymentReportDetail[1];
                    objDetails[0] = new ClientDeploymentReportDetail();
                }
                objDetails[0].STDResponse = new StandardResponse();
                objDetails[0].STDResponse.ResponseCodeStatus = StdResponseCode.Success;
            }
            catch (Exception ex)
            {
                if (objDetails == null)
                {
                    objDetails = new ClientDeploymentReportDetail[1];
                    objDetails[0] = new ClientDeploymentReportDetail();
                }
                objDetails[0].STDResponse = new StandardResponse();
                string msg = ExceptionManager.GetErrorMessage(8050);
                objDetails[0].STDResponse.ResponseCodeStatus = StdResponseCode.Failed;
                objDetails[0].STDResponse.ResponseMessage = msg;
                LogManager.LogErrorMessage(ex, 9080);
            }
            finally
            {
                proc = null;
                ds = null;
            }
            return objDetails;
        }


        public ClientUsageReportDetail[] PopulateClientUsageReport(ClientUsageReportInput Request)
        {
            ClientUsageReportDetail[] objDetails = null;
            DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB, 0);
            DataSet ds = new DataSet();
            try
            {
                if (Request.System_CD == "GD")
                {
                    DBStoredProcedure sp = proc[Constants.CONSTPOPCLIENTUSAGEREPORT_GDU];
                    sp.Parameters["@UserID"].Value = (Request.UserId == null ? string.Empty : Request.UserId);
                    sp.Parameters["@Version"].Value = (Request.Version == null ? string.Empty : Request.Version);
                    sp.Parameters["@From_date"].Value = Request.FromDate;
                    sp.Parameters["@To_date"].Value = Request.ToDate;
                    sp.Parameters["@ClientID"].Value = Request.ClientID;
                    sp.Parameters["@App_ID"].Value = Request.App_ID;
                    sp.Parameters["@PageIndex"].Value = Request.PageIndex;
                    sp.Parameters["@PageSize"].Value = Request.PageSize;
                    sp.Parameters["@SortColumn"].Value = Request.SortColumn;
                    sp.Parameters["@SortOrder"].Value = Request.SortOrder;
                    ds = proc.GetDataset(sp);
                    objDetails = new ClientUsageReportDetail[ds.Tables[0].Rows.Count];

                    for (int iCount = 0; iCount < ds.Tables[0].Rows.Count; iCount++)
                    {
                        objDetails[iCount] = new ClientUsageReportDetail();
                        objDetails[iCount].App_Name = Convert.ToString(ds.Tables[0].Rows[iCount]["App_Abbr_Name"]);
                        objDetails[iCount].NACId = Convert.ToString(ds.Tables[0].Rows[iCount]["Nac_ID"]);
                        objDetails[iCount].Version = Convert.ToString(ds.Tables[0].Rows[iCount]["Version"]);
                        objDetails[iCount].From_DT = Convert.ToString(ds.Tables[0].Rows[iCount]["Start_DT"]);
                        objDetails[iCount].To_DT = Convert.ToString(ds.Tables[0].Rows[iCount]["End_DT"]);
                        objDetails[iCount].TotalUsage = Convert.ToString(ds.Tables[0].Rows[iCount]["Total_Usage"]);
                        objDetails[iCount].ComputerName = Convert.ToString(ds.Tables[0].Rows[iCount]["COMPUTER_NM"]);
                        objDetails[iCount].TotalRecord = Convert.ToInt32(ds.Tables[1].Rows[0]["TotalRecord"]);
                    }

                }
                else
                {
                    DBStoredProcedure sp = proc[Constants.CONSTPOPCLIENTUSAGEREPORT];
                    sp.Parameters["@UserID"].Value = (Request.UserId == null ? string.Empty : Request.UserId);
                    sp.Parameters["@Version"].Value = (Request.Version == null ? string.Empty : Request.Version);
                    sp.Parameters["@From_date"].Value = Request.FromDate;
                    sp.Parameters["@To_date"].Value = Request.ToDate;
                    sp.Parameters["@ClientID"].Value = Request.ClientID;
                    ds = proc.GetDataset(sp);
                    objDetails = new ClientUsageReportDetail[ds.Tables[0].Rows.Count];

                    for (int iCount = 0; iCount < ds.Tables[0].Rows.Count; iCount++)
                    {
                        objDetails[iCount] = new ClientUsageReportDetail();
                        objDetails[iCount].App_Name = string.Empty;
                        objDetails[iCount].NACId = Convert.ToString(ds.Tables[0].Rows[iCount]["Nac_ID"]);
                        objDetails[iCount].Version = Convert.ToString(ds.Tables[0].Rows[iCount]["Version"]);
                        objDetails[iCount].From_DT = Convert.ToString(ds.Tables[0].Rows[iCount]["Start_DT"]);
                        objDetails[iCount].To_DT = Convert.ToString(ds.Tables[0].Rows[iCount]["End_DT"]);
                        objDetails[iCount].TotalUsage = Convert.ToString(ds.Tables[0].Rows[iCount]["Total_Usage"]);
                    }

                }

                if (objDetails == null || objDetails.Length == 0)
                {
                    objDetails = new ClientUsageReportDetail[1];
                    objDetails[0] = new ClientUsageReportDetail();
                }
                objDetails[0].STDResponse = new StandardResponse();
                objDetails[0].STDResponse.ResponseCodeStatus = StdResponseCode.Success;
            }
            catch (Exception ex)
            {
                if (objDetails == null)
                {
                    objDetails = new ClientUsageReportDetail[1];
                    objDetails[0] = new ClientUsageReportDetail();
                }
                objDetails[0].STDResponse = new StandardResponse();
                string msg = ExceptionManager.GetErrorMessage(8050);
                objDetails[0].STDResponse.ResponseCodeStatus = StdResponseCode.Failed;
                objDetails[0].STDResponse.ResponseMessage = msg;
                LogManager.LogErrorMessage(ex, 9080);
            }
            finally
            {
                proc = null;
                ds = null;
            }
            return objDetails;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        //public ClientDetails[] PopulateClient()
        //{
        //    ClientDetails[] objClientDetails = null;
        //    DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
        //    DBStoredProcedure sp = proc["usp_PopulateClientInfo"];
        //    DataSet ds = new DataSet();
        //    try
        //    {

        //        ds = proc.GetDataset(sp);
        //        objClientDetails = new ClientDetails[ds.Tables[0].Rows.Count];

        //        for (int iCount = 0; iCount < ds.Tables[0].Rows.Count; iCount++)
        //        {
        //            objClientDetails[iCount] = new ClientDetails();
        //            objClientDetails[iCount].ClientID = Convert.ToInt32(ds.Tables[0].Rows[iCount]["Client_ID"]);
        //            objClientDetails[iCount].ClientName = Convert.ToString(ds.Tables[0].Rows[iCount]["Client_NM"]);
        //            objClientDetails[iCount].ClientAbbreviation = Convert.ToString(ds.Tables[0].Rows[iCount]["CLIENT_ABBREV_NM"]);
        //        }
        //        if (objClientDetails == null || objClientDetails.Length == 0)
        //        {
        //            objClientDetails = new ClientDetails[1];
        //            objClientDetails[0] = new ClientDetails();
        //        }
        //        objClientDetails[0].STDResponse = new StandardResponse();
        //        objClientDetails[0].STDResponse.ResponseCodeStatus = StdResponseCode.Success;
        //    }
        //    catch (Exception ex)
        //    {
        //        if (objClientDetails == null)
        //        {
        //            objClientDetails = new ClientDetails[1];
        //            objClientDetails[0] = new ClientDetails();
        //        }
        //        objClientDetails[0].STDResponse = new StandardResponse();
        //        string msg = ExceptionManager.GetErrorMessage(8050);
        //        objClientDetails[0].STDResponse.ResponseCodeStatus = StdResponseCode.Failed;
        //        objClientDetails[0].STDResponse.ResponseMessage = msg;
        //        LogManager.LogErrorMessage(ex, 9080);
        //    }
        //    finally
        //    {
        //        proc = null;
        //        ds = null;
        //    }

        //    return objClientDetails;
        //}

        //public ClientDetails[] PopulateUserClient(UserInput Request)
        //{
        //    ClientDetails[] objClientDetails = null;
        //    DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
        //    DBStoredProcedure sp = proc["usp_PopulateUserClientInfo"];
        //    DataSet ds = new DataSet();
        //    try
        //    {
        //        sp.Parameters["@inUserId"].Value = Request.UserId;
        //        ds = proc.GetDataset(sp);
        //        objClientDetails = new ClientDetails[ds.Tables[0].Rows.Count];

        //        for (int iCount = 0; iCount < ds.Tables[0].Rows.Count; iCount++)
        //        {
        //            objClientDetails[iCount] = new ClientDetails();
        //            objClientDetails[iCount].ClientID = Convert.ToInt32(ds.Tables[0].Rows[iCount]["Client_ID"]);
        //            objClientDetails[iCount].ClientName = Convert.ToString(ds.Tables[0].Rows[iCount]["Client_NM"]);
        //            objClientDetails[iCount].ClientAbbreviation = Convert.ToString(ds.Tables[0].Rows[iCount]["CLIENT_ABBREV_NM"]);
        //        }
        //        if (objClientDetails == null || objClientDetails.Length == 0)
        //        {
        //            objClientDetails = new ClientDetails[1];
        //            objClientDetails[0] = new ClientDetails();
        //        }
        //        objClientDetails[0].STDResponse = new StandardResponse();
        //        objClientDetails[0].STDResponse.ResponseCodeStatus = StdResponseCode.Success;
        //    }
        //    catch (Exception ex)
        //    {
        //        if (objClientDetails == null)
        //        {
        //            objClientDetails = new ClientDetails[1];
        //            objClientDetails[0] = new ClientDetails();
        //        }
        //        objClientDetails[0].STDResponse = new StandardResponse();
        //        string msg = ExceptionManager.GetErrorMessage(8050);
        //        objClientDetails[0].STDResponse.ResponseCodeStatus = StdResponseCode.Failed;
        //        objClientDetails[0].STDResponse.ResponseMessage = msg;
        //        LogManager.LogErrorMessage(ex, 9080);
        //    }
        //    finally
        //    {
        //        proc = null;
        //        ds = null;
        //    }

        //    return objClientDetails;
        //}
        #region Version

        /// <summary>
        /// <Description>This method is to search Version Data.</Description>
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public VersionDetails[] PopulateVersions(AppUserInput AppInput)
        {
            VersionDetails[] objVersionDetails = null;
            DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
            DataSet ds = new DataSet();
            try
            {
                if (AppInput.System_CD == "GD")
                {
                    DBStoredProcedure sp = proc[Constants.CONSTSPVERSION_GDU];
                    sp.Parameters["@AppId"].Value = AppInput.App_ID;
                    ds = proc.GetDataset(sp);
                    objVersionDetails = new VersionDetails[ds.Tables[0].Rows.Count];
                }
                else
                {
                    DBStoredProcedure sp = proc[Constants.CONSTSPVERSION];
                    ds = proc.GetDataset(sp);
                    objVersionDetails = new VersionDetails[ds.Tables[0].Rows.Count];
                }
                for (int iCount = 0; iCount < ds.Tables[0].Rows.Count; iCount++)
                {
                    objVersionDetails[iCount] = new VersionDetails();
                    objVersionDetails[iCount].VersionId = Convert.ToString(ds.Tables[0].Rows[iCount]["RELEASE_ID"]);
                    objVersionDetails[iCount].Version = Convert.ToString(ds.Tables[0].Rows[iCount]["RELEASE_VERSION"]);
                }

            }
            catch (Exception ex)
            {
                ExceptionManager.HandleException(ex, 8000);//Need to be updated for actual Business error code 
            }
            finally
            {
                proc = null;
                ds = null;
            }
            return objVersionDetails;
        }

        #endregion


        //public ClientDetailReponse[] PopulateClientResponse(ClientInput input)
        //{
        //    ClientDetailReponse[] objClientDetails = null;
        //    DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
        //    DBStoredProcedure sp = proc[Constants.CONSTPOPACCNAME];
        //    DataSet ds = new DataSet();
        //    try
        //    {

        //        sp.Parameters["@inClientID"].Value = input.ClientId;
        //        // sp.Parameters["@inType"].Value = input.STDinput.EnumType;

        //        ds = proc.GetDataset(sp);
        //        objClientDetails = new ClientDetailReponse[ds.Tables[0].Rows.Count];

        //        for (int iCount = 0; iCount < ds.Tables[0].Rows.Count; iCount++)
        //        {
        //            objClientDetails[iCount] = new ClientDetailReponse();
        //            objClientDetails[iCount].ClientId = Convert.ToString(ds.Tables[0].Rows[iCount]["ACCOUNT_CD"]);
        //            objClientDetails[iCount].ClientName = Convert.ToString(ds.Tables[0].Rows[iCount]["ACCOUNT_NM"]);
        //            objClientDetails[iCount].ClientAbbr = Convert.ToString(ds.Tables[0].Rows[iCount]["Is_Virtual"]);
        //            objClientDetails[iCount].CREATED_DT = Convert.ToDateTime(ds.Tables[0].Rows[iCount]["IS_GLOBAL"]);
        //        }
        //        if (objClientDetails == null || objClientDetails.Length == 0)
        //        {
        //            objClientDetails = new ClientDetailReponse[1];
        //            objClientDetails[0] = new ClientDetailReponse();
        //        }
        //        objClientDetails[0].STDResponse = new StandardResponse();
        //        objClientDetails[0].STDResponse.ResponseCodeStatus = StdResponseCode.Success;
        //    }
        //    catch (Exception ex)
        //    {
        //        if (objClientDetails == null)
        //        {
        //            objClientDetails = new ClientDetailReponse[1];
        //            objClientDetails[0] = new ClientDetailReponse();
        //        }
        //        objClientDetails[0].STDResponse = new StandardResponse();
        //        string msg = ExceptionManager.GetErrorMessage(8050);
        //        objClientDetails[0].STDResponse.ResponseCodeStatus = StdResponseCode.Failed;
        //        objClientDetails[0].STDResponse.ResponseMessage = msg;
        //        LogManager.LogErrorMessage(ex, 9080);
        //    }
        //    finally
        //    {
        //        proc = null;
        //        ds = null;
        //    }

        //    return objClientDetails;
        //}


        public FunctionDetails[] PopulateFunctions(FunctionInput input)
        {
            FunctionDetails[] objFunctionDetails = null;
            DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
            DBStoredProcedure sp = proc[Constants.CONSTPOPFUNCTIONS];
            DataSet ds = new DataSet();
            try
            {

                sp.Parameters["@inRoleCd"].Value = input.RoleCode;
                sp.Parameters["@inClientID"].Value = input.ClientId;
                sp.Parameters["@inType"].Value = input.FunctionType;
                sp.Parameters["@SYSTEM_CD"].Value = input.System_CD;

                ds = proc.GetDataset(sp);
                objFunctionDetails = new FunctionDetails[ds.Tables[0].Rows.Count];

                for (int iCount = 0; iCount < ds.Tables[0].Rows.Count; iCount++)
                {
                    objFunctionDetails[iCount] = new FunctionDetails();
                    objFunctionDetails[iCount].FuntionId = Convert.ToInt32(ds.Tables[0].Rows[iCount]["FUNCTION_ID"]);
                    objFunctionDetails[iCount].FunctionName = Convert.ToString(ds.Tables[0].Rows[iCount]["FUNCTION_NM"]);

                }
                if (objFunctionDetails == null || objFunctionDetails.Length == 0)
                {
                    objFunctionDetails = new FunctionDetails[1];
                    objFunctionDetails[0] = new FunctionDetails();
                }
                objFunctionDetails[0].STDResponse = new StandardResponse();
                objFunctionDetails[0].STDResponse.ResponseCodeStatus = StdResponseCode.Success;
            }
            catch (Exception ex)
            {
                if (objFunctionDetails == null || objFunctionDetails.Length == 0)
                {
                    objFunctionDetails = new FunctionDetails[1];
                    objFunctionDetails[0] = new FunctionDetails();
                }
                objFunctionDetails[0].STDResponse = new StandardResponse();
                string msg = ExceptionManager.GetErrorMessage(8050);
                objFunctionDetails[0].STDResponse.ResponseCodeStatus = StdResponseCode.Failed;
                objFunctionDetails[0].STDResponse.ResponseMessage = msg;
                LogManager.LogErrorMessage(ex, 9080);
            }
            finally
            {
                proc = null;
                ds = null;
            }

            return objFunctionDetails;
        }


        public RoleDetails[] PopulateRoles(RoleInput input)
        {
            RoleDetails[] objRoleDetails = null;
            DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
            DBStoredProcedure sp = proc[Constants.CONSTPOPROLES];
            DataSet ds = new DataSet();
            try
            {

                sp.Parameters["@inUserId"].Value = input.UserId;
                sp.Parameters["@inType"].Value = input.RoleType;
                sp.Parameters["@SYSTEM_CD"].Value = input.System_CD;


                ds = proc.GetDataset(sp);
                objRoleDetails = new RoleDetails[ds.Tables[0].Rows.Count];

                for (int iCount = 0; iCount < ds.Tables[0].Rows.Count; iCount++)
                {
                    objRoleDetails[iCount] = new RoleDetails();
                    objRoleDetails[iCount].RoleClientId = Convert.ToString(ds.Tables[0].Rows[iCount]["ROLE_CLIENT_ID"]);
                    objRoleDetails[iCount].RoleName = Convert.ToString(ds.Tables[0].Rows[iCount]["ROLE"]);

                }
                if (objRoleDetails == null || objRoleDetails.Length == 0)
                {
                    objRoleDetails = new RoleDetails[1];
                    objRoleDetails[0] = new RoleDetails();
                }
                objRoleDetails[0].STDResponse = new StandardResponse();
                objRoleDetails[0].STDResponse.ResponseCodeStatus = StdResponseCode.Success;
            }
            catch (Exception ex)
            {
                /*if (objFunctionDetails == null)
                {
                    objAccountDetails = new AccountDetails[1];
                    objAccountDetails[0] = new AccountDetails();
                }*/
                objRoleDetails[0].STDResponse = new StandardResponse();
                string msg = ExceptionManager.GetErrorMessage(8050);
                objRoleDetails[0].STDResponse.ResponseCodeStatus = StdResponseCode.Failed;
                objRoleDetails[0].STDResponse.ResponseMessage = msg;
                LogManager.LogErrorMessage(ex, 9080);
            }
            finally
            {
                proc = null;
                ds = null;
            }

            return objRoleDetails;
        }

        public RoleMasterDetails[] PopulateRoleMaster()
        {
            RoleMasterDetails[] objRoleMasterDetails = null;
            DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
            DBStoredProcedure sp = proc[Constants.CONSTPOPROLEMASTER];
            DataSet ds = new DataSet();
            try
            {


                ds = proc.GetDataset(sp);
                objRoleMasterDetails = new RoleMasterDetails[ds.Tables[0].Rows.Count];

                for (int iCount = 0; iCount < ds.Tables[0].Rows.Count; iCount++)
                {
                    objRoleMasterDetails[iCount] = new RoleMasterDetails();
                    objRoleMasterDetails[iCount].RoleCD = Convert.ToString(ds.Tables[0].Rows[iCount]["ROLE_CD"]);
                    objRoleMasterDetails[iCount].RoleName = Convert.ToString(ds.Tables[0].Rows[iCount]["ROLE_NM"]);

                }
                if (objRoleMasterDetails == null || objRoleMasterDetails.Length == 0)
                {
                    objRoleMasterDetails = new RoleMasterDetails[1];
                    objRoleMasterDetails[0] = new RoleMasterDetails();
                }
                objRoleMasterDetails[0].STDResponse = new StandardResponse();
                objRoleMasterDetails[0].STDResponse.ResponseCodeStatus = StdResponseCode.Success;
            }
            catch (Exception ex)
            {
                /*if (objFunctionDetails == null)
                {
                    objAccountDetails = new AccountDetails[1];
                    objAccountDetails[0] = new AccountDetails();
                }*/
                objRoleMasterDetails[0].STDResponse = new StandardResponse();
                string msg = ExceptionManager.GetErrorMessage(8050);
                objRoleMasterDetails[0].STDResponse.ResponseCodeStatus = StdResponseCode.Failed;
                objRoleMasterDetails[0].STDResponse.ResponseMessage = msg;
                LogManager.LogErrorMessage(ex, 9080);
            }
            finally
            {
                proc = null;
                ds = null;
            }

            return objRoleMasterDetails;
        }

        public AppFocusReportDetails[] PopulateAppFocusReport(AppFocusReportInput Request)
        {
            AppFocusReportDetails[] objReportCollection = null;
            DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB, 0);
            DBStoredProcedure sp = proc[Constants.CONSTSPAPPFOCUSREPORT];
            DataSet ds = new DataSet();

            try
            {
                sp.Parameters["@AppName"].Value = Request.AppName;
                sp.Parameters["@FromDate"].Value = Request.FromDate;
                sp.Parameters["@ToDate"].Value = Request.ToDate;
                sp.Parameters["@OfficeId"].Value = Request.OfficeId;
                sp.Parameters["@UserName"].Value = Request.UserName;
                sp.Parameters["@GroupID"].Value = Request.OfficeGroupId;

                sp.Parameters["@PageIndex"].Value = Request.CurrentPage;
                sp.Parameters["@PageSize"].Value = Request.PageSize;
                sp.Parameters["@SortColumn"].Value = Request.SortExpression;
                sp.Parameters["@SortOrder"].Value = Request.SortOrder;

                ds = proc.GetDataset(sp);
                objReportCollection = new AppFocusReportDetails[ds.Tables[0].Rows.Count];
                for (int iCount = 0; iCount < ds.Tables[0].Rows.Count; iCount++)
                {
                    objReportCollection[iCount] = new AppFocusReportDetails();
                    //objReportCollection[iCount].SequenceNo = Convert.ToInt32(ds.Tables[0].Rows[iCount]["SEQUENCENO"]);
                    objReportCollection[iCount].AppName = Convert.ToString(ds.Tables[0].Rows[iCount]["APP_DS"]);
                    objReportCollection[iCount].ComputerName = Convert.ToString(ds.Tables[0].Rows[iCount]["COMPUTER_NM"]);
                    objReportCollection[iCount].UserName = Convert.ToString(ds.Tables[0].Rows[iCount]["USERNAME"]);
                    objReportCollection[iCount].OfficeId = Convert.ToString(ds.Tables[0].Rows[iCount]["OFFICE_ID"]);
                    objReportCollection[iCount].IpAddress = Convert.ToString(ds.Tables[0].Rows[iCount]["IP_ADDR_TXT"]);
                    objReportCollection[iCount].UsageDate = Convert.ToString(ds.Tables[0].Rows[iCount]["ACTIVEDEACTIVETIME"]);
                    objReportCollection[iCount].TotalUsage = Convert.ToString(ds.Tables[0].Rows[iCount]["TOTAL_USAGE_TIME"]);
                    objReportCollection[iCount].GroupSeqNo = Convert.ToString(ds.Tables[0].Rows[iCount]["SEQUENCENO"]);
                    objReportCollection[iCount].ApplEndDate = Convert.ToString(ds.Tables[0].Rows[iCount]["APP_ENDDATE"]);
                    objReportCollection[iCount].ADS_ID = Convert.ToString(ds.Tables[0].Rows[iCount]["ADS_ID"]);

                }
                objReportCollection[0].TotalRecords = Convert.ToInt32(ds.Tables[1].Rows[0]["TotalRecords"]);
            }
            catch (Exception ex)
            {
                ExceptionManager.HandleException(ex, 8000);//Need to be updated for actual Business error code 
            }
            finally
            {
                proc = null;
                ds = null;
            }
            return objReportCollection;

        }

        public AppFocusReportDetails[] PopulateAppFocusReportDetail(AppFocusReportInput Request)
        {
            AppFocusReportDetails[] objReportCollection = null;
            DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
            DBStoredProcedure sp = proc[Constants.CONSTSPAPPFOCUSREPORTDETAIL];
            DataSet ds = new DataSet();

            try
            {
                sp.Parameters["@SequenceNo"].Value = Request.GroupSeqNo;
                sp.Parameters["@REQBY"].Value = Request.AppName;

                sp.Parameters["@PageIndex"].Value = Request.CurrentPage;
                sp.Parameters["@PageSize"].Value = Request.PageSize;
                sp.Parameters["@SortColumn"].Value = Request.SortExpression;
                sp.Parameters["@SortOrder"].Value = Request.SortOrder;

                ds = proc.GetDataset(sp);
                objReportCollection = new AppFocusReportDetails[ds.Tables[0].Rows.Count];
                for (int iCount = 0; iCount < ds.Tables[0].Rows.Count; iCount++)
                {
                    objReportCollection[iCount] = new AppFocusReportDetails();
                    objReportCollection[iCount].ProcessName = Convert.ToString(ds.Tables[0].Rows[iCount]["PROCESS_NM"]);
                    objReportCollection[iCount].ToDate = Convert.ToDateTime(ds.Tables[0].Rows[iCount]["APP_FOCUS_ENDDATE"]);
                    objReportCollection[iCount].FromDate = Convert.ToDateTime(ds.Tables[0].Rows[iCount]["APP_FOCUS_STARTDATE"]);
                    objReportCollection[iCount].TotalUsage = Convert.ToString(ds.Tables[0].Rows[iCount]["TotalUsage"]);
                    objReportCollection[iCount].UserName = Convert.ToString(ds.Tables[0].Rows[iCount]["UserName"]);
                    objReportCollection[iCount].AppName = Convert.ToString(ds.Tables[0].Rows[iCount]["APP_NM"]);
                    objReportCollection[iCount].TotalRecords = Convert.ToInt32(ds.Tables[1].Rows[0]["TotalRecords"]);
                }
            }
            catch (Exception ex)
            {
                ExceptionManager.HandleException(ex, 8000);//Need to be updated for actual Business error code 
            }
            finally
            {
                proc = null;
                ds = null;
            }
            return objReportCollection;

        }

        public RptFocusAppDetails[] PopulateFocusReportAppName()
        {
            RptFocusAppDetails[] objAPPFAppDetails = null;
            DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
            DBStoredProcedure sp = proc[Constants.CONSTPOPFOCUSRPTAPPNAME];
            DataSet ds = new DataSet();
            try
            {
                ds = proc.GetDataset(sp);
                objAPPFAppDetails = new RptFocusAppDetails[ds.Tables[0].Rows.Count];

                for (int iCount = 0; iCount < ds.Tables[0].Rows.Count; iCount++)
                {
                    objAPPFAppDetails[iCount] = new RptFocusAppDetails();
                    objAPPFAppDetails[iCount].ID = Convert.ToInt32(ds.Tables[0].Rows[iCount]["ID"]);
                    objAPPFAppDetails[iCount].App_ID = Convert.ToString(ds.Tables[0].Rows[iCount]["APP_ID"]);
                    objAPPFAppDetails[iCount].App_DESC = Convert.ToString(ds.Tables[0].Rows[iCount]["APP_DS"]);
                }
                if (objAPPFAppDetails == null || objAPPFAppDetails.Length == 0)
                {
                    objAPPFAppDetails = new RptFocusAppDetails[1];
                    objAPPFAppDetails[0] = new RptFocusAppDetails();
                }
                objAPPFAppDetails[0].STDResponse = new StandardResponse();
                objAPPFAppDetails[0].STDResponse.ResponseCodeStatus = StdResponseCode.Success;
            }
            catch (Exception ex)
            {
                if (objAPPFAppDetails == null)
                {
                    objAPPFAppDetails = new RptFocusAppDetails[1];
                    objAPPFAppDetails[0] = new RptFocusAppDetails();
                }
                objAPPFAppDetails[0].STDResponse = new StandardResponse();
                string msg = ExceptionManager.GetErrorMessage(8050);
                objAPPFAppDetails[0].STDResponse.ResponseCodeStatus = StdResponseCode.Failed;
                objAPPFAppDetails[0].STDResponse.ResponseMessage = msg;
                LogManager.LogErrorMessage(ex, 9080);
            }
            finally
            {
                proc = null;
                ds = null;
            }

            return objAPPFAppDetails;
        }
        public RptFocusOfficeIdDetails[] PopulateFocusReportOfficeID(FocusGroupInput Request)
        {
            RptFocusOfficeIdDetails[] objAPPFOfficeDetails = null;
            DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
            DBStoredProcedure sp = proc[Constants.CONSTPOPFOCUSRPTOFFICEID];
            DataSet ds = new DataSet();
            try
            {
                sp.Parameters["@inAPPFOfficeGroupID"].Value = Request.ID;
                ds = proc.GetDataset(sp);
                objAPPFOfficeDetails = new RptFocusOfficeIdDetails[ds.Tables[0].Rows.Count];

                for (int iCount = 0; iCount < ds.Tables[0].Rows.Count; iCount++)
                {
                    objAPPFOfficeDetails[iCount] = new RptFocusOfficeIdDetails();
                    objAPPFOfficeDetails[iCount].OfficeID = Convert.ToString(ds.Tables[0].Rows[iCount]["OFFICE_ID"]);
                    objAPPFOfficeDetails[iCount].Office_DESC = Convert.ToString(ds.Tables[0].Rows[iCount]["OFFICE_DS"]);
                }
                if (objAPPFOfficeDetails == null || objAPPFOfficeDetails.Length == 0)
                {
                    objAPPFOfficeDetails = new RptFocusOfficeIdDetails[1];
                    objAPPFOfficeDetails[0] = new RptFocusOfficeIdDetails();
                }
                objAPPFOfficeDetails[0].STDResponse = new StandardResponse();
                objAPPFOfficeDetails[0].STDResponse.ResponseCodeStatus = StdResponseCode.Success;
            }
            catch (Exception ex)
            {
                if (objAPPFOfficeDetails == null)
                {
                    objAPPFOfficeDetails = new RptFocusOfficeIdDetails[1];
                    objAPPFOfficeDetails[0] = new RptFocusOfficeIdDetails();
                }
                objAPPFOfficeDetails[0].STDResponse = new StandardResponse();
                string msg = ExceptionManager.GetErrorMessage(8050);
                objAPPFOfficeDetails[0].STDResponse.ResponseCodeStatus = StdResponseCode.Failed;
                objAPPFOfficeDetails[0].STDResponse.ResponseMessage = msg;
                LogManager.LogErrorMessage(ex, 9080);
            }
            finally
            {
                proc = null;
                ds = null;
            }

            return objAPPFOfficeDetails;
        }

        public AppFocusReportDetails[] PopulateAppUserFocusReportDetail(AppFocusReportInput Request)
        {
            AppFocusReportDetails[] objReportCollection = null;
            DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB, 0);
            DBStoredProcedure sp = proc[Constants.CONSTSPAPPFOCUSREPORTDETAILBYUSER];
            DataSet ds = new DataSet();

            try
            {
                sp.Parameters["@ADS_ID"].Value = Request.ADS_ID;
                sp.Parameters["@ActiveDeactiveTime"].Value = Request.FromDate;
                sp.Parameters["@REQBY"].Value = Request.AppName;

                sp.Parameters["@PageIndex"].Value = Request.CurrentPage;
                sp.Parameters["@PageSize"].Value = Request.PageSize;
                sp.Parameters["@SortColumn"].Value = Request.SortExpression;
                sp.Parameters["@SortOrder"].Value = Request.SortOrder;

                ds = proc.GetDataset(sp);
                objReportCollection = new AppFocusReportDetails[ds.Tables[0].Rows.Count];
                for (int iCount = 0; iCount < ds.Tables[0].Rows.Count; iCount++)
                {
                    objReportCollection[iCount] = new AppFocusReportDetails();
                    objReportCollection[iCount].ProcessName = Convert.ToString(ds.Tables[0].Rows[iCount]["PROCESS_NM"]);
                    objReportCollection[iCount].ToDate = Convert.ToDateTime(ds.Tables[0].Rows[iCount]["APP_FOCUS_ENDDATE"]);
                    objReportCollection[iCount].FromDate = Convert.ToDateTime(ds.Tables[0].Rows[iCount]["APP_FOCUS_STARTDATE"]);
                    objReportCollection[iCount].TotalUsage = Convert.ToString(ds.Tables[0].Rows[iCount]["TotalUsage"]);
                    objReportCollection[iCount].UserName = Convert.ToString(ds.Tables[0].Rows[iCount]["UserName"]);
                    objReportCollection[iCount].AppName = Convert.ToString(ds.Tables[0].Rows[iCount]["APP_NM"]);
                    objReportCollection[iCount].TotalRecords = Convert.ToInt32(ds.Tables[1].Rows[0]["TotalRecords"]);
                }
            }
            catch (Exception ex)
            {
                ExceptionManager.HandleException(ex, 8000);//Need to be updated for actual Business error code 
            }
            finally
            {
                proc = null;
                ds = null;
            }
            return objReportCollection;

        }

        public PopulateFocusGroupDetails[] PopulateOfficeGroup(FocusGroupInput input)
        {
            PopulateFocusGroupDetails[] objGroupDetails = null;
            DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
            DBStoredProcedure sp = proc[Constants.CONSTPOPOFFICEGROUP];
            DataSet ds = new DataSet();
            try
            {
                sp.Parameters["@inType"].Value = input.STDinput.EnumType;
                sp.Parameters["@GroupID"].Value = input.ID;
                ds = proc.GetDataset(sp);
                objGroupDetails = new PopulateFocusGroupDetails[ds.Tables[0].Rows.Count];

                for (int iCount = 0; iCount < ds.Tables[0].Rows.Count; iCount++)
                {
                    objGroupDetails[iCount] = new PopulateFocusGroupDetails();
                    objGroupDetails[iCount].ID = Convert.ToString(ds.Tables[0].Rows[iCount]["ID"]);
                    objGroupDetails[iCount].Group_NM = Convert.ToString(ds.Tables[0].Rows[iCount]["GROUP_NM"]);
                }
                if (objGroupDetails == null || objGroupDetails.Length == 0)
                {
                    objGroupDetails = new PopulateFocusGroupDetails[1];
                    objGroupDetails[0] = new PopulateFocusGroupDetails();
                }
                objGroupDetails[0].STDResponse = new StandardResponse();
                objGroupDetails[0].STDResponse.ResponseCodeStatus = StdResponseCode.Success;
            }
            catch (Exception ex)
            {

                if (objGroupDetails == null)
                {
                    objGroupDetails = new PopulateFocusGroupDetails[1];
                    objGroupDetails[0] = new PopulateFocusGroupDetails();
                }

                objGroupDetails[0].STDResponse = new StandardResponse();
                string msg = ExceptionManager.GetErrorMessage(8050);
                objGroupDetails[0].STDResponse.ResponseCodeStatus = StdResponseCode.Failed;
                objGroupDetails[0].STDResponse.ResponseMessage = msg;
                LogManager.LogErrorMessage(ex, 9080);
            }
            finally
            {
                proc = null;
                ds = null;
            }

            return objGroupDetails;
        }

        public AppUploadedReportDetail[] PopulatePilotAppReport(AppUploadedReportInput Request)
        {
            AppUploadedReportDetail[] objDetails = null;
            DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB, 0);
            DBStoredProcedure sp = proc[Constants.CONSTPOPPILOTAPPREPORT];   //proc["usp_GetAppUploadedReport"];  
            DataSet ds = new DataSet();
            try
            {
                sp.Parameters["@UserID"].Value = Request.UserId;
                sp.Parameters["@From_Dt"].Value = Request.From_Dt;
                sp.Parameters["@To_Dt"].Value = Request.To_Date;
                sp.Parameters["@App_ID"].Value = Request.App_ID;
                sp.Parameters["@RollBack"].Value = Request.RollBack;
                sp.Parameters["@APP_TYPE"].Value = Request.APP_TYPE;

                sp.Parameters["@PageIndex"].Value = Request.CurrentPage;
                sp.Parameters["@PageSize"].Value = Request.PageSize;
                sp.Parameters["@SortColumn"].Value = Request.SortExpression;
                sp.Parameters["@SortOrder"].Value = Request.SortOrder;

                ds = proc.GetDataset(sp);
                //if (ds.Tables[0].Rows.Count > 0)
                //{
                objDetails = new AppUploadedReportDetail[ds.Tables[0].Rows.Count];
                //}
                for (int iCount = 0; iCount < ds.Tables[0].Rows.Count; iCount++)
                {
                    objDetails[iCount] = new AppUploadedReportDetail();
                    if (Convert.ToString(ds.Tables[0].Rows[iCount]["App_NM"]) != null)
                    {
                        objDetails[iCount].App_Name = Convert.ToString(ds.Tables[0].Rows[iCount]["App_NM"]);
                        objDetails[iCount].User_Name = Convert.ToString(ds.Tables[0].Rows[iCount]["User_NM"]);
                        objDetails[iCount].Version = Convert.ToString(ds.Tables[0].Rows[iCount]["Version"]);
                        objDetails[iCount].IP = Convert.ToString(ds.Tables[0].Rows[iCount]["IP"]);
                        objDetails[iCount].Upload_Dt = Convert.ToString(ds.Tables[0].Rows[iCount]["Upload_Dt"]);
                        objDetails[iCount].RollBack = Convert.ToString(ds.Tables[0].Rows[iCount]["RollBack"]);
                        objDetails[iCount].App_ID = Convert.ToInt32(ds.Tables[0].Rows[iCount]["App_ID"]);
                        objDetails[iCount].APP_TYPE = Convert.ToString(ds.Tables[0].Rows[iCount]["App_Type"]);
                        objDetails[iCount].TotalRecords = Convert.ToInt32(ds.Tables[1].Rows[0]["TotalRecord"]);
                    }
                }

                if (objDetails == null || objDetails.Length == 0)
                {
                    objDetails = new AppUploadedReportDetail[1];
                    objDetails[0] = new AppUploadedReportDetail();
                }
                objDetails[0].STDResponse = new StandardResponse();
                objDetails[0].STDResponse.ResponseCodeStatus = StdResponseCode.Success;
            }
            catch (Exception ex)
            {
                if (objDetails == null)
                {
                    objDetails = new AppUploadedReportDetail[1];
                    objDetails[0] = new AppUploadedReportDetail();
                }
                objDetails[0].STDResponse = new StandardResponse();
                string msg = ExceptionManager.GetErrorMessage(8050);
                objDetails[0].STDResponse.ResponseCodeStatus = StdResponseCode.Failed;
                objDetails[0].STDResponse.ResponseMessage = msg;
                LogManager.LogErrorMessage(ex, 9080);
            }
            finally
            {
                proc = null;
                ds = null;
            }
            return objDetails;
        }

        public PilotAppUploadDetails[] PopulatePilotUserDetails(PilotAppUploadInput Request)
        {
            PilotAppUploadDetails[] objDetails = null;
            DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
            DBStoredProcedure sp = proc[Constants.CONSTPOPPILOTUSERREPORT];   //proc["usp_GetAppUploadedReport"];  
            DataSet ds = new DataSet();
            try
            {
                sp.Parameters["@AppId"].Value = Request.AppId;
                sp.Parameters["@Version"].Value = Request.AppVersion;
                sp.Parameters["@PageIndex"].Value = Request.CurrentPage;
                sp.Parameters["@PageSize"].Value = Request.PageSize;
                sp.Parameters["@SortColumn"].Value = Request.SortExpression;
                sp.Parameters["@SortOrder"].Value = Request.SortOrder;
                ds = proc.GetDataset(sp);
                //if (ds.Tables[0].Rows.Count > 0)
                //{
                objDetails = new PilotAppUploadDetails[ds.Tables[0].Rows.Count];
                //}
                for (int iCount = 0; iCount < ds.Tables[0].Rows.Count; iCount++)
                {
                    objDetails[iCount] = new PilotAppUploadDetails();
                    if (Convert.ToString(ds.Tables[0].Rows[iCount]["User_ID"]) != null)
                    {
                        objDetails[iCount].UserId = Convert.ToString(ds.Tables[0].Rows[iCount]["User_ID"]);
                        objDetails[iCount].UserName = Convert.ToString(ds.Tables[0].Rows[iCount]["User_NM"]);
                        objDetails[iCount].MachineName = Convert.ToString(ds.Tables[0].Rows[iCount]["Computer_NM"]);
                        objDetails[iCount].IPAddress = Convert.ToString(ds.Tables[0].Rows[iCount]["IP_ADDR_TXT"]);
                        objDetails[iCount].TotalRecords = Convert.ToInt32(ds.Tables[1].Rows[0]["TotalRecord"]);
                    }
                }

                if (objDetails == null || objDetails.Length == 0)
                {
                    objDetails = new PilotAppUploadDetails[1];
                    objDetails[0] = new PilotAppUploadDetails();
                }
                objDetails[0].STDResponse = new StandardResponse();
                objDetails[0].STDResponse.ResponseCodeStatus = StdResponseCode.Success;
            }
            catch (Exception ex)
            {
                if (objDetails == null)
                {
                    objDetails = new PilotAppUploadDetails[1];
                    objDetails[0] = new PilotAppUploadDetails();
                }
                objDetails[0].STDResponse = new StandardResponse();
                string msg = ExceptionManager.GetErrorMessage(8050);
                objDetails[0].STDResponse.ResponseCodeStatus = StdResponseCode.Failed;
                objDetails[0].STDResponse.ResponseMessage = msg;
                LogManager.LogErrorMessage(ex, 9080);
            }
            finally
            {
                proc = null;
                ds = null;
            }
            return objDetails;
        }

        public AppFOfficeAdsID[] PopulateAppfAdsID(AppFOfficeAdsMappingID input)
        {
            AppFOfficeAdsID[] objGroupDetails = null;
            DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
            DBStoredProcedure sp = proc[Constants.CONSTPOPAPPFOFFICEADSID];
            DataSet ds = new DataSet();
            try
            {
                sp.Parameters["@inAPPFOfficeID"].Value = input.ADS_ID;
                sp.Parameters["@GroupID"].Value = input.GROUP_ID;
                sp.Parameters["@inType"].Value = input.TYPE;
                ds = proc.GetDataset(sp);
                objGroupDetails = new AppFOfficeAdsID[ds.Tables[0].Rows.Count];

                for (int iCount = 0; iCount < ds.Tables[0].Rows.Count; iCount++)
                {
                    objGroupDetails[iCount] = new AppFOfficeAdsID();
                    objGroupDetails[iCount].ADS_ID = Convert.ToString(ds.Tables[0].Rows[iCount]["ADS_ID"]);
                    objGroupDetails[iCount].OFFICE_ID = Convert.ToString(ds.Tables[0].Rows[iCount]["OFFICE_ID"]);
                    objGroupDetails[iCount].MACHINE_NM = Convert.ToString(ds.Tables[0].Rows[iCount]["COMPUTER_NM"]);
                    objGroupDetails[iCount].USER_NM = Convert.ToString(ds.Tables[0].Rows[iCount]["USER_NM"]);
                    objGroupDetails[iCount].OFFICE_DS = Convert.ToString(ds.Tables[0].Rows[iCount]["OFFICE_DS"]);
                }
                if (objGroupDetails == null || objGroupDetails.Length == 0)
                {
                    objGroupDetails = new AppFOfficeAdsID[1];
                    objGroupDetails[0] = new AppFOfficeAdsID();
                }
                objGroupDetails[0].STDResponse = new StandardResponse();
                objGroupDetails[0].STDResponse.ResponseCodeStatus = StdResponseCode.Success;
            }
            catch (Exception ex)
            {
                if (objGroupDetails == null)
                {
                    objGroupDetails = new AppFOfficeAdsID[1];
                    objGroupDetails[0] = new AppFOfficeAdsID();
                }

                objGroupDetails[0].STDResponse = new StandardResponse();
                string msg = ExceptionManager.GetErrorMessage(8050);
                objGroupDetails[0].STDResponse.ResponseCodeStatus = StdResponseCode.Failed;
                objGroupDetails[0].STDResponse.ResponseMessage = msg;
                LogManager.LogErrorMessage(ex, 9080);
            }
            finally
            {
                proc = null;
                ds = null;
            }

            return objGroupDetails;
        }

        public TravelSuiteAppFocusReportDetails[] PopulateTravelSuiteAppFocusReport(TravelSuiteAppFocusReportInput Request)
        {
            TravelSuiteAppFocusReportDetails[] objReportCollection = null;
            DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB, 0);
            DBStoredProcedure sp = proc[Constants.CONSTSPTRAVELSUITEAPPFOCUSREPORT];
            DataSet ds = new DataSet();

            try
            {
                sp.Parameters["@AppName"].Value = Request.AppName;
                sp.Parameters["@FromDate"].Value = Request.FromDate;
                sp.Parameters["@ToDate"].Value = Request.ToDate;
                sp.Parameters["@OfficeId"].Value = Request.OfficeId;
                sp.Parameters["@UserName"].Value = Request.UserName;
                sp.Parameters["@GroupID"].Value = Request.OfficeGroupId;

                sp.Parameters["@PageIndex"].Value = Request.CurrentPage;
                sp.Parameters["@PageSize"].Value = Request.PageSize;
                sp.Parameters["@SortColumn"].Value = Request.SortExpression;
                sp.Parameters["@SortOrder"].Value = Request.SortOrder;

                ds = proc.GetDataset(sp);
                objReportCollection = new TravelSuiteAppFocusReportDetails[ds.Tables[0].Rows.Count];
                for (int iCount = 0; iCount < ds.Tables[0].Rows.Count; iCount++)
                {
                    objReportCollection[iCount] = new TravelSuiteAppFocusReportDetails();
                    objReportCollection[iCount].AppName = Convert.ToString(ds.Tables[0].Rows[iCount]["APP_DS"]);
                    objReportCollection[iCount].ComputerName = Convert.ToString(ds.Tables[0].Rows[iCount]["COMPUTER_NM"]);
                    objReportCollection[iCount].UserName = Convert.ToString(ds.Tables[0].Rows[iCount]["USERNAME"]);
                    objReportCollection[iCount].OfficeId = Convert.ToString(ds.Tables[0].Rows[iCount]["OFFICE_ID"]);
                    objReportCollection[iCount].IpAddress = Convert.ToString(ds.Tables[0].Rows[iCount]["IP_ADDR_TXT"]);
                    objReportCollection[iCount].UsageDate = Convert.ToString(ds.Tables[0].Rows[iCount]["ACTIVEDEACTIVETIME"]);
                    objReportCollection[iCount].TotalUsage = Convert.ToString(ds.Tables[0].Rows[iCount]["TOTAL_USAGE_TIME"]);
                    objReportCollection[iCount].GroupSeqNo = Convert.ToString(ds.Tables[0].Rows[iCount]["SEQUENCENO"]);
                    objReportCollection[iCount].ApplEndDate = Convert.ToString(ds.Tables[0].Rows[iCount]["APP_ENDDATE"]);
                    objReportCollection[iCount].ADS_ID = Convert.ToString(ds.Tables[0].Rows[iCount]["ADS_ID"]);
                    objReportCollection[iCount].TotalRecord = Convert.ToInt32(ds.Tables[1].Rows[0]["TotalRecords"]);

                }
            }
            catch (Exception ex)
            {
                ExceptionManager.HandleException(ex, 8000);//Need to be updated for actual Business error code 
            }
            finally
            {
                proc = null;
                ds = null;
            }
            return objReportCollection;

        }

        public PilotApplicationDeploymentReportDetail[] PopulatePilotApplicationDeploymentReport(PilotApplicationDeploymentReportInput Request)
        {
            PilotApplicationDeploymentReportDetail[] objDetails = null;
            DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB, 0);
            DataSet ds = new DataSet();
            try
            {
                if (Request.System_CD == "GD")
                {
                    DBStoredProcedure sp = proc[Constants.CONSTPILOTAPPDEPLOYREPORT_GDU];

                    sp.Parameters["@UserID"].Value = Request.UserId;
                    sp.Parameters["@Version"].Value = Request.Version;
                    sp.Parameters["@NonMaxFlag"].Value = Request.NonMaxFlag;
                    sp.Parameters["@ClientId"].Value = Request.clientId;
                    sp.Parameters["@App_ID"].Value = Request.App_ID;

                    sp.Parameters["@PageIndex"].Value = Request.PageIndex;
                    sp.Parameters["@PageSize"].Value = Request.PageSize;
                    sp.Parameters["@SortColumn"].Value = Request.SortColumn;
                    sp.Parameters["@SortOrder"].Value = Request.SortOrder;

                    ds = proc.GetDataset(sp);
                    objDetails = new PilotApplicationDeploymentReportDetail[ds.Tables[0].Rows.Count];

                    for (int iCount = 0; iCount < ds.Tables[0].Rows.Count; iCount++)
                    {
                        objDetails[iCount] = new PilotApplicationDeploymentReportDetail();
                        objDetails[iCount].App_Name = Convert.ToString(ds.Tables[0].Rows[iCount]["App_Name"]);
                        objDetails[iCount].UserId = Convert.ToString(ds.Tables[0].Rows[iCount]["User_Id"]);
                        objDetails[iCount].IPAddress = Convert.ToString(ds.Tables[0].Rows[iCount]["IP"]);
                        objDetails[iCount].NACId = Convert.ToString(ds.Tables[0].Rows[iCount]["Nac_Id"]);
                        objDetails[iCount].ExeVersionNo = Convert.ToString(ds.Tables[0].Rows[iCount]["Exe_VersionNo"]);
                        objDetails[iCount].ExeTimeStamp = Convert.ToDateTime(ds.Tables[0].Rows[iCount]["Exe_TimeStamp_DT"]);
                        objDetails[iCount].RecordTimeStamp = Convert.ToDateTime(ds.Tables[0].Rows[iCount]["RecordTimeStamp_DT"]);
                        objDetails[iCount].ApplicationPath = Convert.ToString(ds.Tables[0].Rows[iCount]["Application_Path"]);
                        objDetails[iCount].LatestVersionNo = Convert.ToString(ds.Tables[0].Rows[iCount]["Latest_VersionNo"]);
                        objDetails[iCount].ComputerName = Convert.ToString(ds.Tables[0].Rows[iCount]["Computer_Name"]);
                        objDetails[iCount].TotalRecords = Convert.ToInt32(ds.Tables[1].Rows[0]["TotalRecords"]);
                    }
                }
                else
                {
                    DBStoredProcedure sp = proc[Constants.CONSTPOPCLIENTDEPLOYMENTREPORT];

                    sp.Parameters["@UserID"].Value = Request.UserId;
                    sp.Parameters["@Version"].Value = Request.Version;
                    sp.Parameters["@NonMaxFlag"].Value = Request.NonMaxFlag;
                    sp.Parameters["@ClientId"].Value = Request.clientId;
                    ds = proc.GetDataset(sp);
                    objDetails = new PilotApplicationDeploymentReportDetail[ds.Tables[0].Rows.Count];

                    for (int iCount = 0; iCount < ds.Tables[0].Rows.Count; iCount++)
                    {
                        objDetails[iCount] = new PilotApplicationDeploymentReportDetail();
                        objDetails[iCount].App_Name = string.Empty;
                        objDetails[iCount].UserId = Convert.ToString(ds.Tables[0].Rows[iCount]["User_Id"]);
                        objDetails[iCount].IPAddress = Convert.ToString(ds.Tables[0].Rows[iCount]["IP"]);
                        objDetails[iCount].NACId = Convert.ToString(ds.Tables[0].Rows[iCount]["Nac_Id"]);
                        objDetails[iCount].ExeVersionNo = Convert.ToString(ds.Tables[0].Rows[iCount]["Exe_VersionNo"]);
                        objDetails[iCount].ExeTimeStamp = Convert.ToDateTime(ds.Tables[0].Rows[iCount]["Exe_TimeStamp_DT"]);
                        objDetails[iCount].RecordTimeStamp = Convert.ToDateTime(ds.Tables[0].Rows[iCount]["RecordTimeStamp_DT"]);
                        objDetails[iCount].ApplicationPath = Convert.ToString(ds.Tables[0].Rows[iCount]["Application_Path"]);
                        objDetails[iCount].LatestVersionNo = Convert.ToString(ds.Tables[0].Rows[iCount]["Latest_VersionNo"]);
                        objDetails[iCount].ComputerName = Convert.ToString(ds.Tables[0].Rows[iCount]["Computer_Name"]);
                    }

                }


                if (objDetails == null || objDetails.Length == 0)
                {
                    objDetails = new PilotApplicationDeploymentReportDetail[1];
                    objDetails[0] = new PilotApplicationDeploymentReportDetail();
                }
                objDetails[0].STDResponse = new StandardResponse();
                objDetails[0].STDResponse.ResponseCodeStatus = StdResponseCode.Success;
            }
            catch (Exception ex)
            {
                if (objDetails == null)
                {
                    objDetails = new PilotApplicationDeploymentReportDetail[1];
                    objDetails[0] = new PilotApplicationDeploymentReportDetail();
                }
                objDetails[0].STDResponse = new StandardResponse();
                string msg = ExceptionManager.GetErrorMessage(8050);
                objDetails[0].STDResponse.ResponseCodeStatus = StdResponseCode.Failed;
                objDetails[0].STDResponse.ResponseMessage = msg;
                LogManager.LogErrorMessage(ex, 9080);
            }
            finally
            {
                proc = null;
                ds = null;
            }
            return objDetails;
        }

        #region PopulateAcwReport
        public ACWReportDetails[] PopulateACWReport(ACWReportInput input)
        {
            ACWReportDetails[] objAcwReport = null;
            DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
            DBStoredProcedure sp = proc[Constants.CONSTSPACWREPORT];
            DataSet ds = new DataSet();
            try
            {
                sp.Parameters["@FromDate"].Value = input.FromDate;
                sp.Parameters["@ToDate"].Value = input.ToDate;
                sp.Parameters["@OfficeId"].Value = input.OfficeId;
                sp.Parameters["@GroupID"].Value = input.GroupId;
                sp.Parameters["@UserName"].Value = input.UserName;
                sp.Parameters["@AppName"].Value = input.AppName;
                ds = proc.GetDataset(sp);
                objAcwReport = new ACWReportDetails[ds.Tables[0].Rows.Count];
                for (int iCount = 0; iCount < ds.Tables[0].Rows.Count; iCount++)
                {
                    objAcwReport[iCount] = new ACWReportDetails();
                    objAcwReport[iCount].ADSId = Convert.ToString(ds.Tables[0].Rows[iCount]["PHONEID"]);
                    objAcwReport[iCount].Server = Convert.ToString(ds.Tables[0].Rows[iCount]["SERVER"]);
                    objAcwReport[iCount].StartDt = Convert.ToString(ds.Tables[0].Rows[iCount]["STARTDATE"]);
                    objAcwReport[iCount].EndDt = Convert.ToString(ds.Tables[0].Rows[iCount]["ENDDATE"]);
                    objAcwReport[iCount].TIMEZONE = Convert.ToString(ds.Tables[0].Rows[iCount]["TIMEZONE"]);
                    objAcwReport[iCount].ACWDuration = Convert.ToString(ds.Tables[0].Rows[iCount]["ACW"]);
                }
            }
            catch
            {
                if (objAcwReport == null)
                {
                    objAcwReport = new ACWReportDetails[1];
                    objAcwReport[0] = new ACWReportDetails();
                }
                objAcwReport[0].STDResponse = new StandardResponse();
                string msg = ExceptionManager.GetErrorMessage(8050);
                objAcwReport[0].STDResponse.ResponseCodeStatus = StdResponseCode.Failed;
                objAcwReport[0].STDResponse.ResponseMessage = msg;
                LogManager.LogErrorMessage(msg, 9000);

            }

            finally
            {
                proc = null;
                ds = null;
            }
            return objAcwReport;

        }

        #endregion

        #region PopulateAppFocusIndicator
        public AppFocusIndicatorDetails[] PopulateAppFocusIndicator()
        {
            AppFocusIndicatorDetails[] objAppFocusIndicatorDetails = null;
            DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
            DBStoredProcedure sp = proc[Constants.CONSTSPAPPFINDICATOR];
            DataSet ds = new DataSet();
            try
            {

                ds = proc.GetDataset(sp);
                objAppFocusIndicatorDetails = new AppFocusIndicatorDetails[ds.Tables[0].Rows.Count];
                for (int iCount = 0; iCount < ds.Tables[0].Rows.Count; iCount++)
                {
                    objAppFocusIndicatorDetails[iCount] = new AppFocusIndicatorDetails();
                    objAppFocusIndicatorDetails[iCount].AppFocusIndicator = Convert.ToString(ds.Tables[0].Rows[iCount]["APPF_INDICATOR"]);
                    objAppFocusIndicatorDetails[iCount].IndicatorName = Convert.ToString(ds.Tables[0].Rows[iCount]["APP_TYPE"]);
                }
            }
            catch
            {
                if (objAppFocusIndicatorDetails == null)
                {
                    objAppFocusIndicatorDetails = new AppFocusIndicatorDetails[1];
                    objAppFocusIndicatorDetails[0] = new AppFocusIndicatorDetails();
                }
                objAppFocusIndicatorDetails[0].STDResponse = new StandardResponse();
                string msg = ExceptionManager.GetErrorMessage(8050);
                objAppFocusIndicatorDetails[0].STDResponse.ResponseCodeStatus = StdResponseCode.Failed;
                objAppFocusIndicatorDetails[0].STDResponse.ResponseMessage = msg;
                LogManager.LogErrorMessage(msg, 9000);

            }

            finally
            {
                proc = null;
                ds = null;
            }
            return objAppFocusIndicatorDetails;

        }

        #endregion

        #region PopulateGlobalAlert
        //public SearchLinkDetails[] PopulateGlobalAlert()
        //{
        //    SearchLinkDetails[] objAppFocusIndicatorDetails = null;
        //    DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
        //    DBStoredProcedure sp = proc[Constants.CONSTSPGLOBALALERT];
        //    DataSet ds = new DataSet();
        //    try
        //    {
        //        ds = proc.GetDataset(sp);
        //        objAppFocusIndicatorDetails = new SearchLinkDetails[ds.Tables[0].Rows.Count];
        //        for (int iCount = 0; iCount < ds.Tables[0].Rows.Count; iCount++)
        //        {
        //            objAppFocusIndicatorDetails[iCount] = new SearchLinkDetails();
        //            objAppFocusIndicatorDetails[iCount].AppFocusIndicator = Convert.ToString(ds.Tables[0].Rows[iCount]["APPF_INDICATOR"]);

        //        }
        //    }
        //    catch
        //    {
        //        if (objAppFocusIndicatorDetails == null)
        //        {
        //            objAppFocusIndicatorDetails = new SearchLinkDetails[1];
        //            objAppFocusIndicatorDetails[0] = new SearchLinkDetails();
        //        }
        //        objAppFocusIndicatorDetails[0].STDResponse = new StandardResponse();
        //        string msg = ExceptionManager.GetErrorMessage(8050);
        //        objAppFocusIndicatorDetails[0].STDResponse.ResponseCodeStatus = StdResponseCode.Failed;
        //        objAppFocusIndicatorDetails[0].STDResponse.ResponseMessage = msg;
        //        LogManager.LogErrorMessage(msg, 9000);

        //    }

        //    finally
        //    {
        //        proc = null;
        //        ds = null;
        //    }
        //    return objAppFocusIndicatorDetails;

        //}

        #endregion
        //#region Populate PendingApproval Report
        //public PendingApprovalDetails[] PopulatePendingApproval(PendingApprovalInput input)
        //{
        //    PendingApprovalDetails[] objPendingApprovalDetails = null;
        //    DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
        //    DBStoredProcedure sp = proc[Constants.CONSTSPPENDINGAPPROVAL];
        //    DataSet ds = new DataSet();
        //    try
        //    {
        //        string SharePointURL = ConfigurationSettings.AppSettings[Constants.CONSTSPURL].ToString();

        //        //sp.Parameters["@accountCode"].Value = input.AccountCode;
        //        //sp.Parameters["@carrierCode"].Value = input.CarrierCode;
        //        //sp.Parameters["@cityCode"].Value = input.CityCode;
        //        //sp.Parameters["@clientCode"].Value = input.ClientCode;
        //        //sp.Parameters["@countryCode"].Value = input.CountryCode;
        //        //sp.Parameters["@globalCategoryCode"].Value = input.GlobalCategoryCode;
        //        sp.Parameters["@mode"].Value = input.Mode;
        //        // sp.Parameters["@otherInfoCode"].Value = input.OtherInfoCode;

        //        ds = proc.GetDataset(sp);
        //        objPendingApprovalDetails = new PendingApprovalDetails[ds.Tables[0].Rows.Count];
        //        for (int iCount = 0; iCount < ds.Tables[0].Rows.Count; iCount++)
        //        {
        //            objPendingApprovalDetails[iCount] = new PendingApprovalDetails();
        //            objPendingApprovalDetails[iCount].DocLink = Convert.ToString(ds.Tables[0].Rows[iCount]["Dtl_Label_NM"]);
        //            objPendingApprovalDetails[iCount].UploadedBy = Convert.ToString(ds.Tables[0].Rows[iCount]["Uploaded_User_Id"]);
        //            objPendingApprovalDetails[iCount].UploadedDate = Convert.ToString(ds.Tables[0].Rows[iCount]["Uploaded_Date"]);
        //            objPendingApprovalDetails[iCount].Label_Id = Convert.ToInt32(ds.Tables[0].Rows[iCount]["Label_Id"]);
        //            objPendingApprovalDetails[iCount].Link_Cat_Dtl_Id = Convert.ToInt32(ds.Tables[0].Rows[iCount]["Link_Cat_Dtl_Id"]);
        //            objPendingApprovalDetails[iCount].Link_Dtl_Id = Convert.ToInt32(ds.Tables[0].Rows[iCount]["Link_Dtl_Id"]);
        //            objPendingApprovalDetails[iCount].Link_Id = Convert.ToInt32(ds.Tables[0].Rows[iCount]["Link_Id"]);

        //            objPendingApprovalDetails[iCount].Mode = Convert.ToString(ds.Tables[0].Rows[iCount]["Mode"]);
        //            objPendingApprovalDetails[iCount].Upload_Type = Convert.ToString(ds.Tables[0].Rows[iCount]["UploadType"]);
        //            objPendingApprovalDetails[iCount].Link = SharePointURL + Convert.ToString(ds.Tables[0].Rows[iCount]["Link"]);

        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        if (objPendingApprovalDetails == null)
        //        {
        //            objPendingApprovalDetails = new PendingApprovalDetails[1];
        //            objPendingApprovalDetails[0] = new PendingApprovalDetails();
        //        }
        //        objPendingApprovalDetails[0].STDResponse = new StandardResponse();
        //        string msg = ExceptionManager.GetErrorMessage(8050);
        //        objPendingApprovalDetails[0].STDResponse.ResponseCodeStatus = StdResponseCode.Failed;
        //        objPendingApprovalDetails[0].STDResponse.ResponseMessage = msg;
        //        LogManager.LogErrorMessage(msg, 9000);

        //    }

        //    finally
        //    {
        //        proc = null;
        //        ds = null;
        //    }
        //    return objPendingApprovalDetails;

        //}
        //#endregion

        public TransitDataDetails[] PopulateTransitData(TransitDataInput input)
        {
            TransitDataDetails[] objTransitDataDetails = null;
            DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
            DBStoredProcedure sp = proc[Constants.CONSTPOPTRANSITDATA];
            DataSet ds = new DataSet();
            try
            {
                sp.Parameters["@mode"].Value = input.mode;
                sp.Parameters["@code"].Value = input.code;

                ds = proc.GetDataset(sp);
                objTransitDataDetails = new TransitDataDetails[ds.Tables[0].Rows.Count];
                for (int iCount = 0; iCount < ds.Tables[0].Rows.Count; iCount++)
                {
                    objTransitDataDetails[iCount] = new TransitDataDetails();
                    objTransitDataDetails[iCount].filePath = Convert.ToString(ds.Tables[0].Rows[iCount]["FilePath"]);

                }
            }
            catch (Exception ex)
            {
                ExceptionManager.HandleException(ex, 8000);
            }
            finally
            {
                proc = null;
                ds = null;
            }

            return objTransitDataDetails;
        }

        public AdminUserDetails[] PopulateAdminEmail()
        {
            AdminUserDetails[] objAdmin = null;
            DBProceduresCollection proc = new DBProceduresCollection(AmericanExpress.GDU.Util.DBSchemaHelper.Constants.DEVDB);
            DBStoredProcedure sp = proc[Constants.CONSTSPADMINEMAIL];
            DataSet ds = new DataSet();
            try
            {
                ds = proc.GetDataset(sp);
                objAdmin = new AdminUserDetails[ds.Tables[0].Rows.Count];
                for (int iCount = 0; iCount < ds.Tables[0].Rows.Count; iCount++)
                {
                    objAdmin[iCount] = new AdminUserDetails();
                    objAdmin[iCount].Email = Convert.ToString(ds.Tables[0].Rows[iCount]["EMAIL"]);
                }
            }
            catch
            {
                if (objAdmin == null)
                {
                    objAdmin = new AdminUserDetails[1];
                    objAdmin[0] = new AdminUserDetails();
                }
                string msg = ExceptionManager.GetErrorMessage(8050);
                LogManager.LogErrorMessage(msg, 9000);
            }
            finally
            {
                proc = null;
                ds = null;
            }
            return objAdmin;
        }
    }
}

