﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;
using AmericanExpress.GDU.Model;
using System.Collections.Generic;
using System.IO;
using AmericanExpress.GDU.Utilities.Diagnostics;
using AmericanExpress.GDU;
using System.Diagnostics;
using System.Text;
using System.Net;

namespace AmericanExpress.GDU.GDUAdmin
{
    public partial class Publish : System.Web.UI.Page
    {
        GDUModel _gduModal;
        DataTable _dtDataTable;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                //if (Global.IsPageAuthorized(System.IO.Path.GetFileName(Request.Path)) == false)
                //{
                //    Response.Redirect("NotAuthorized.aspx", false);
                //}
                PopulateApplication();
            }
        }

        private void PopulateApplication()
        {
            try
            {
                _gduModal = new GDUModel();
                Dictionary<string, string> objDictonary = new Dictionary<string, string>();
                objDictonary = _gduModal.PopulateAppAbbrInfo();
                this.checkBoxApplication.DataSource = objDictonary;
                checkBoxApplication.DataValueField = AdmConstants.KEY;
                checkBoxApplication.DataTextField = AdmConstants.VALUE;
                checkBoxApplication.DataBind();

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        protected void btnInstall_Click(object sender, EventArgs e)
        {
            LogtoEvent("=====================================================================================");
            LogtoEvent(System.DateTime.Now.ToString() + System.Environment.NewLine);
            LogtoEvent("Click on Install");
            bool IsApplicationSelected = false;
            List<string> AppToUpload = new List<string>();
            Dictionary<string, string> dictAppToUpload = new Dictionary<string, string>();
            foreach (ListItem li in checkBoxApplication.Items)
            {
                if (li.Selected)
                {
                    IsApplicationSelected = true;
                    //AppToUpload.Add(li.Value);
                    dictAppToUpload.Add(li.Value, li.Text);
                    LogtoEvent("Application to install" + li.Value);

                }
            }

            if (IsApplicationSelected)
            {
                Session["AppToInstall"] = dictAppToUpload;
                Response.Redirect("ApplicationToInstall.aspx");
                //Process proc = null;
                //try
                //{
                //    //    string targetDir = ConfigurationManager.AppSettings["PushOnceDirectory"].ToString();//Server.MapPath("") + @"\";
                //    //    LogtoEvent("Target Directory=" + targetDir);
                //    //    proc = new Process();
                //    //    proc.StartInfo.WorkingDirectory = targetDir;
                //    //    proc.StartInfo.FileName = ConfigurationManager.AppSettings["PushOnceExeFile"].ToString();
                //    //    proc.StartInfo.CreateNoWindow = false;
                //    //    proc.Start();
                //    //    proc.WaitForExit();
                //    //    //System.Diagnostics.Process.Start(ConfigurationManager.AppSettings["PushOnceExeFile"].ToString());
                //    //    LogtoEvent("Push Once Installed Completed");

                //    foreach (string AppAbbr in AppToUpload)
                //    {
                //        try
                //        {
                //            HtmlAnchor htmlanchor = new HtmlAnchor();
                //            htmlanchor.HRef = AppAbbr + ".exe";
                //            htmlanchor.Title = "Click to Install" + AppAbbr;
                //            htmlanchor.InnerText = "Install" + AppAbbr;
                //            pnlContainer.Controls.Add(htmlanchor);
                //            pnlContainer.Controls.Add(new LiteralControl("<br>"));
                //            pnlContainer.Controls.Add(new LiteralControl("<br>"));




                //            //            LogtoEvent("Application Ready to Install=" + AppAbbr + ".exe");
                //            //            proc.StartInfo.FileName = AppAbbr + ".exe";
                //            //            proc.StartInfo.CreateNoWindow = false;
                //            //            proc.Start();
                //            //            proc.WaitForExit();
                //            //            LogtoEvent("Application Inatallation successfully=" + AppAbbr + ".exe");
                //        }
                //        catch (Exception ex)
                //        {
                //            LogtoEvent("Exception occur in Application= " + AppAbbr + ".exe " + ex.Message);
                //        }

                //    }
                //}
                //catch (Exception ex)
                //{
                //    LogtoEvent("Exception occur in Application= " + ex.Message);
                //}
                //checkBoxApplication.Visible = false;
                //Button1.Visible = false;
            }
        }

        private void LogtoEvent(string ex)
        {
            string TraceInfo = ConfigurationSettings.AppSettings["GDUPublishTraceInfo"].ToString();
            if (TraceInfo == "True")
            {
                string TraceFile = Server.MapPath("") + @"\" + ConfigurationSettings.AppSettings["GDUPublishTraceFile"].ToString();
                FileStream fs = null;
                if (!File.Exists(TraceFile))
                {
                    using (fs = File.Create(TraceFile))
                    {

                    }
                }
                if (File.Exists(TraceFile))
                {
                    StringBuilder sb = new StringBuilder();
                    StreamReader sr = new StreamReader(TraceFile);
                    {
                        sb.Append(sr.ReadToEnd());
                        sb.AppendLine();
                    }
                    sr.Close();
                    TextWriter tw = new StreamWriter(TraceFile);
                    sb.AppendLine(ex.ToString());
                    tw.WriteLine(sb.ToString());
                    tw.Close();
                }
            }
        }
    }
}
