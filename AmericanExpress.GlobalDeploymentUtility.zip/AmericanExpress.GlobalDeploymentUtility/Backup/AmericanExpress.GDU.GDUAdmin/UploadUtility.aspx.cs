﻿//-----------------------------------------------------------------------
// <copyright file="LocationMode.aspx.cs" company="NIIT Technologies">
//  Copyright (c) NIIT Technologies. All rights reserved.
// </copyright>
// <summary>
// <Description>This is a Interface to define signatures for implementing Business Logic.</Description>
// <Author>NIIT Technologies</Author>
// <CreatedOn>11/05/2009</CreatedOn>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// <Modified>
//     <On> mm/dd/yyyy </On>
//     <Desc>Modification Reason </Desc>
//     <By>xxx</By>
// </Modified>
// </summary>
//-----------------------------------------------------------------------
namespace AmericanExpress.GDU
{
    #region Page Level NameSpace

    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Configuration;
    using System.Data;
    using System.Linq;
    using System.Web;
    using System.Web.Security;
    using System.Web.UI;
    using System.Web.UI.HtmlControls;
    using System.Web.UI.WebControls;
    using System.Web.UI.WebControls.WebParts;
    using System.Xml.Linq;
    using System.Xml.Xsl;
    using System.Xml;
    using System.IO;
    using Shell32;
    using AmericanExpress.GWizAdmin.Utility;
    using AmericanExpress.GDU.Model;
    using AmericanExpress.GDU.Utilities.Diagnostics;
    using AmericanExpress.GDU.Utilities.ExceptionMgmt;
    using System.Deployment;
    using System.Xml.XPath;
    using System.Net;
    using System.Text;
    using System.Data.OleDb;
    using System.Management;

    #endregion

    /// <summary>
    /// Classes and evnets on location mode
    /// </summary>
    public partial class LocationMode : System.Web.UI.Page
    {
        DataTable releaseDtl;
        GDUModel _gduModel;
        string releaseVersion = string.Empty;
        string releaseDT = string.Empty;
        DataTable Dt = new DataTable();
        //bool isRollBacked = true;
        private string _targetLocation
        {
            get;
            set;
        }

        private string _targetLocationTemp
        {
            get;
            set;
        }

        private string _targetLocationVersion
        {
            get;
            set;
        }

        private int App_id
        {
            get;
            set;
        }

        private string _exeName
        {
            get;
            set;
        }

        private string IsRollBack
        {
            get;
            set;
        }

        //private string _BackupTargetLocation
        //{
        //    get;
        //    set;
        //}
        //private string _BackupTargetLocationVersion
        //{
        //    get;
        //    set;
        //}

        #region variables
        /// <summary>
        /// constant string
        /// </summary>
        public const string READONLY = "readonly";

        /// <summary>
        /// Transactiion Id
        /// </summary>       
        #endregion

        #region events

        /// <summary>
        /// Page load event.
        /// </summary>
        /// <param name="sender"> The parameter is not used.</param>
        /// <param name="e"> The parameter is not used.</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            //string aa = ddlVersion.SelectedItem.Text.ToString();
            string validate = string.Empty;
            try
            {

                if (!Page.IsPostBack)
                {
                    //if (Global.IsPageAuthorized(System.IO.Path.GetFileName(Request.Path)) == false)
                    //    Response.Redirect("NotAuthorized.aspx", false);

                    trMakeProd.Visible = true;
                    trSelectVersion.Visible = true;
                    trRollBack.Visible = false;
                    trSelectFile.Visible = false;

                    btnUpload.Visible = false;
                    btnUpdateVersion.Visible = true;

                    this._gduModel = new GDUModel();
                    this.PopulateApplication();
                    this.SetApplication(0);
                    btnUploadAmexFile.Visible = false;
                    trPilotFile.Visible = false;
                    if (chkRollBack.Checked == true)
                    {
                        this.IsRollBack = "Y";
                    }
                    else
                    {
                        this.IsRollBack = "N";
                    }

                    if (trRollBack.Visible)
                    {
                        if (chkRollBack.Checked)
                        {
                            trSelectFile.Visible = false;
                            //if (ddlApplication.SelectedItem.Text.ToLower().Contains("star apollo"))
                            //    trSelectVersion.Visible = false;
                            //else
                            trSelectVersion.Visible = true;

                            btnUpload.Visible = false;
                            btnUpdateVersion.Visible = true;

                        }
                        else
                        {
                            trSelectFile.Visible = true;

                            //if (ddlApplication.SelectedItem.Text.ToLower().Contains("star apollo"))
                            //    trSelectVersion.Visible = false;
                            //else
                            trSelectVersion.Visible = true;

                            btnUpload.Visible = true;
                            btnUpdateVersion.Visible = false;
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                if (ex is GenericException)
                {
                    Label lbl = (Label)Master.FindControl("lblMsgPanel");
                    string errmsg = ex.Message;
                    lbl.Text = errmsg;
                }
                else
                {
                    string msg = ExceptionManager.GetErrorMessage(8050);
                    LogManager.LogErrorMessage(ex, Convert.ToInt32(AdmConstants.MethodName.GWiz_LocationMode_Page_Load));
                    Label lbl = (Label)Master.FindControl("lblMsgPanel");
                    string errmsg = msg;
                    lbl.Text = errmsg;
                }
            }

            //string aa1 = ddlVersion.SelectedItem.Text.ToString();
        }

        /// <summary>
        /// Delete links
        /// </summary>
        /// <param name="sender"> The parameter is not used.</param>
        /// <param name="e"> The parameter is not used.</param>


        protected void ddlApplication_SelectedIndexChanged(object sender, EventArgs e)
        {
            //if ((chkRollBack.Checked) && (ddlApplication.SelectedItem.Text.ToLower().Contains("star apollo")))
            //    trSelectVersion.Visible = false;
            //else
            //    trSelectVersion.Visible = true;

            lblStatus.Text = "";
            lblStatus.Visible = false;

            if (rdoProduction.Checked)
            {
                if ((chkRollBack.Checked) || (trSelectVersion.Visible))
                {
                    this.SetApplication(ddlApplication.SelectedIndex);
                    if (ddlApplication.SelectedItem.Text.ToUpper() == "SELECT APPLICATION")
                    {
                        lblTargetPath.Text = string.Empty;

                        ddlVersion.Items.Clear();
                        ddlVersion.Items.Insert(0, new ListItem(AdmConstants.VERSION, "SELECT VERSION"));
                        this.ddlVersion.DataSource = null;
                        this.ddlVersion.DataBind();

                        lblLatestVersion.Text = "";
                        lblLatestVersion.Visible = false;
                    }

                    if (ddlApplication.SelectedValue.ToString().ToUpper() != "SELECT APPLICATION")
                    {

                        //GetAppVersionDB(ddlApplication.SelectedValue.ToString().Substring(0, ddlApplication.SelectedValue.ToString().IndexOf("~")), App_Type);
                        //if (ddlApplication.SelectedItem.Text.ToLower().Contains("star apollo") == false)
                        GetAppVersion(Int32.Parse(ddlApplication.SelectedValue.ToString().Substring(0, ddlApplication.SelectedValue.ToString().IndexOf("~"))));
                    }
                }
                else
                {
                    this.SetApplication(ddlApplication.SelectedIndex);
                    if (ddlApplication.SelectedItem.Text.ToUpper() == "SELECT APPLICATION")
                    {
                        lblTargetPath.Text = string.Empty;

                        ddlVersion.Items.Clear();
                        //ddlVersion.Items.Insert(0, new ListItem(AdmConstants.VERSION, "SELECT VERSION"));
                        this.ddlVersion.DataSource = null;
                        this.ddlVersion.DataBind();
                        ddlVersion.Items.Insert(0, new ListItem(AdmConstants.VERSION, "SELECT VERSION"));
                        lblLatestVersion.Text = "";
                        lblLatestVersion.Visible = false;
                    }
                }
            }
            else
            {
                if (trRollBack.Visible)
                {
                    if (chkRollBack.Checked)
                    {
                        this.SetApplication(ddlApplication.SelectedIndex);
                        if (ddlApplication.SelectedItem.Text.ToUpper() == "SELECT APPLICATION")
                        {
                            lblTargetPath.Text = string.Empty;

                            ddlVersion.Items.Clear();
                            ddlVersion.Items.Insert(0, new ListItem(AdmConstants.VERSION, "SELECT VERSION"));
                            this.ddlVersion.DataSource = null;
                            this.ddlVersion.DataBind();

                            lblLatestVersion.Text = "";
                            lblLatestVersion.Visible = false;
                        }

                        if (ddlApplication.SelectedValue.ToString().ToUpper() != "SELECT APPLICATION")
                        {
                            //GetAppVersionDB(ddlApplication.SelectedValue.ToString().Substring(0, ddlApplication.SelectedValue.ToString().IndexOf("~")), App_Type);
                            //if (ddlApplication.SelectedItem.Text.ToLower().Contains("star apollo") == false)
                            GetAppVersion(Int32.Parse(ddlApplication.SelectedValue.ToString().Substring(0, ddlApplication.SelectedValue.ToString().IndexOf("~"))));
                        }

                    }
                    else
                    {
                        this.SetApplication(ddlApplication.SelectedIndex);
                        if (ddlApplication.SelectedItem.Text.ToUpper() == "SELECT APPLICATION")
                        {
                            lblTargetPath.Text = string.Empty;
                        }
                    }
                }
                else
                {
                    this.SetApplication(ddlApplication.SelectedIndex);
                    if (ddlApplication.SelectedItem.Text.ToUpper() == "SELECT APPLICATION")
                    {
                        lblTargetPath.Text = string.Empty;

                        ddlVersion.Items.Clear();
                        ddlVersion.Items.Insert(0, new ListItem(AdmConstants.VERSION, "SELECT VERSION"));
                        this.ddlVersion.DataSource = null;
                        this.ddlVersion.DataBind();

                        lblLatestVersion.Text = "";
                        lblLatestVersion.Visible = false;
                    }

                    if (ddlApplication.SelectedValue.ToString().ToUpper() != "SELECT APPLICATION")
                    {
                        //GetAppVersionDB(ddlApplication.SelectedValue.ToString().Substring(0, ddlApplication.SelectedValue.ToString().IndexOf("~")), App_Type);
                        GetAppVersion(Int32.Parse(ddlApplication.SelectedValue.ToString().Substring(0, ddlApplication.SelectedValue.ToString().IndexOf("~"))));
                    }
                }
            }
        }

        public DataTable GetFileNamesWithVersion(string manifestFilePath)
        {
            try
            {
                releaseDtl = new DataTable();
                releaseDtl.Columns.Add(new DataColumn("FileVersion", System.Type.GetType("System.String")));
                releaseDtl.Columns.Add(new DataColumn("FileName", System.Type.GetType("System.String")));
                releaseDtl.Columns.Add(new DataColumn("FilePath", System.Type.GetType("System.String")));

                //ArrayList fileNames = new ArrayList();
                string[] files = Directory.GetFiles(manifestFilePath, "*.*", SearchOption.AllDirectories);
                //string[] files = Directory.GetFiles(manifestFilePath);

                string deploymentManifestPath = string.Empty;

                string AppName = manifestFilePath.Remove(0, manifestFilePath.LastIndexOf(@"\") + 1);

                string AppName1 = AppName.Substring(0, AppName.LastIndexOf("_"));
                string AppName2 = AppName1.Substring(0, AppName1.LastIndexOf("_"));
                string AppName3 = AppName2.Substring(0, AppName2.LastIndexOf("_"));
                string AppName4 = AppName3.Substring(0, AppName3.LastIndexOf("_"));

                //string[] s = AppName.Split('_');
                //string Mytextt = s[0].ToString();

                deploymentManifestPath = manifestFilePath + @"\" + AppName4 + ".exe.manifest";

                //foreach (string file in files)
                //{
                //    if (Path.GetExtension(file) == ".manifest")
                //    {
                //        deploymentManifestPath = file;
                //        break;
                //    }
                //}

                //Reading Version.

                if (!string.IsNullOrEmpty(deploymentManifestPath))
                {
                    XElement xElement = XElement.Load(deploymentManifestPath);
                    IEnumerable<XElement> dependentAssemblies = GetInstallableDependencies(true, xElement);
                    _exeName = xElement.Descendants().Attributes("name").ElementAt(0).Value.Replace(".exe", "");
                    IEnumerable<XElement> file1 = GetInstallableFiles(true, xElement);
                    foreach (XElement assembly in dependentAssemblies)
                    {
                        GenerateDeployTable(xElement.Descendants().Attributes("version").ElementAt(1).Value, assembly.Attribute("codebase").Value, _targetLocation + "\\" + assembly.Attribute("codebase").Value, releaseDtl);

                    }

                    foreach (XElement file in file1)
                    {
                        GenerateDeployTable(xElement.Descendants().Attributes("version").ElementAt(1).Value, file.Attribute("name").Value, _targetLocation + "\\" + file.Attribute("name").Value, releaseDtl);

                    }
                }

                return releaseDtl;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        protected void btnUpload_Click(object sender, EventArgs e)
        {
            if (rdoPilot.Checked)
            {
                if (rdbExcel.Checked)
                {
                    string FilePath = fileExcel.Value.ToString();
                    if (FilePath == null || FilePath == "")
                    {
                        string ErrorMessage = "Please select a Excel file.";
                        ShowAlertMessage(ErrorMessage);
                        return;
                    }
                    if (!ValidateExcel(FilePath))
                    {
                        string ErrorMessage = "Please select a valid Excel file only.";
                        ShowAlertMessage(ErrorMessage);
                        return;
                    }
                }
                else if (rdbGroup.Checked)
                {
                    if (ddlGroup.SelectedItem.Text == "Please Select")
                    {
                        string ErrorMessage = "Please select a Group.";
                        ShowAlertMessage(ErrorMessage);
                        return;
                    }
                }
            }


            if (chkRollBack.Checked == true)
            {
                this.IsRollBack = "Y";
            }
            else
            {
                this.IsRollBack = "N";
            }

            lblResponse.Text = string.Empty;

            // Validate if the temporary folder and destination folder exists.
            this.ValidateFolderPaths();

            // Access the uploaded files.
            HttpFileCollection uploadedFiles = Request.Files;

            for (int i = 0; i < uploadedFiles.Count; i++)
            {
                //if (uploadedFiles.GetKey(i) != SelectFile.Name)
                //{
                HttpPostedFile userPostedFile = uploadedFiles[i];
                try
                {
                    // If the uploaded file has data then only execute the copy.
                    if (userPostedFile.ContentLength > 0)
                    {
                        string fileName = System.IO.Path.GetFileName(userPostedFile.FileName);
                        string filepath = string.Empty;
                        // If the uploaded file is zip copy it first to temp location
                        // else copy at location.
                        if (fileName.Contains(".zip"))
                        {
                            filepath = _targetLocationTemp;

                        }
                        else
                        {
                            filepath = _targetLocation;
                        }
                        // Recalculate the filepath.
                        filepath = Path.Combine(filepath, fileName);

                        if (fileName.Contains(".zip"))
                        {
                            // Save the file.
                            userPostedFile.SaveAs(filepath);
                            // Log  the data to label.
                            lblResponse.Text += "<u>File #" + (i + 1) + "</u><br>";
                            lblResponse.Text += "File Content Type: " + userPostedFile.ContentType + "<br>";
                            lblResponse.Text += "File Size: " + userPostedFile.ContentLength + "kb<br>";
                            lblResponse.Text += "File Name: " + userPostedFile.FileName + "<br>";
                            // If file is a zip file, call decompress function.

                            lblResponse.Text += "File Name sent for unzip <br>";
                            try
                            {

                                this.ZipUtility(_targetLocationTemp, filepath, ddlApplication.SelectedItem.Text);
                                if (!object.Equals(releaseDtl, null))
                                {
                                    if (releaseDtl.Rows.Count > 0)
                                    {
                                        this.SaveReleaseInfo();
                                    }
                                    else
                                    {
                                        lblResponse.Text += "Could not find manifest file.!<br>";
                                    }
                                }
                                else
                                {
                                    lblResponse.Text += "Could not find manifest file.<br>";
                                }
                            }
                            catch (Exception ex)
                            {
                                lblResponse.Text += ex.Message;
                            }
                        }
                        else
                        {
                            //lblResponse.Text += "Location where saved: " + filepath + "<p>";
                        }
                    }
                }
                catch (Exception ex)
                {
                    LogManager.LogErrorMessage(ex, Convert.ToInt32(AdmConstants.MethodName.GWiz_UploadFiles_Upload_Click));
                    lblResponse.Text += "Error: <br>" + ex.Message;
                }
            }
        }

        #endregion

        #region methods

        /// <summary>
        /// populate drop downs on page.
        /// </summary>
        /// 
        private void ValidateFolderPaths()
        {
            try
            {
                this._targetLocation = ((lblTargetPath.Text.ToString().Substring(lblTargetPath.Text.ToString().IndexOf(":") + 1)).ToString().Replace("\\", @"\").Trim());
                this._targetLocationTemp = Path.Combine(((lblTargetPath.Text.ToString().Substring(lblTargetPath.Text.ToString().IndexOf(":") + 1)).ToString().Replace("\\", @"\").Trim()), "temp");
                // Check if Parent folder exists.
                if (!Directory.Exists(this._targetLocation))
                {
                    Directory.CreateDirectory(this._targetLocation);

                }

                // Check if temp location exists.
                if (!Directory.Exists(_targetLocationTemp))
                {
                    Directory.CreateDirectory(this._targetLocationTemp);
                }
                else
                {
                    Directory.Delete(_targetLocationTemp, true);
                    Directory.CreateDirectory(this._targetLocationTemp);
                }
            }
            catch (Exception ex)
            {
            }
        }

        private void ZipUtility(string outputDirectory, string inputFileName, string AppName)
        {
            lblResponse.Text += "unziping folder <br>";
            // Create a shell object.
            Shell shell = new ShellClass();
            // Get the name of folder.
            string folderName = System.IO.Path.GetFileNameWithoutExtension(inputFileName);
            //// Check if there is already a directory with same name. 
            if (Directory.Exists(outputDirectory))
            {

                if (Directory.Exists(Path.Combine(outputDirectory, folderName)))
                {
                    Directory.Delete(Path.Combine(outputDirectory, folderName), true);
                }

            }
            //// Create a new directory where files will be unzipped.
            //Directory.CreateDirectory(outputDirectory);
            lblResponse.Text += "Copying Folder at " + outputDirectory + "<br>";
            // Get the source folder.
            Folder sourceFolder = shell.NameSpace(inputFileName);
            // Get the destination folder.
            Folder destinationFolder2 = shell.NameSpace(outputDirectory);

            // Get the items in zip.
            Shell32.FolderItems items = sourceFolder.Items();
            // Copy the items to the location.

            //***************************************
            destinationFolder2.CopyHere(items, 16);

            //***************************************
            //Code added on 21 april 2011 to delete zip file from temp folder.

            if (File.Exists(inputFileName))
            {
                File.Delete(inputFileName);
            }

            //Create folder at target place with the virsion name.
            // this.GetFileNamesWithVersion(_targetLocation);//Comented 11 April 2011
            this.GetFileNamesWithVersion(Path.Combine(outputDirectory, folderName));
            // string targetPath = ((lblTargetPath.Text.ToString().Substring(lblTargetPath.Text.ToString().IndexOf(":") + 1)).ToString().Replace("\\", @"\").Trim());
            if (!object.Equals(releaseDtl, null))
            //if (releaseDtl != null)
            {
                if (releaseDtl.Rows.Count > 0)
                {
                    this._targetLocationVersion = string.Concat(_targetLocation, "\\", string.Concat(_exeName, '_', releaseDtl.Rows[0][0].ToString().Replace('.', '_')));

                    //if (folderName == string.Concat(_exeName, '_', releaseDtl.Rows[0][0].ToString().Replace('.', '_')))
                    //{
                    //    //if (!Directory.Exists(outputDirectory))
                    //    //{
                    //        //Directory.CreateDirectory(_targetLocationVersion);
                    //    Folder versionDest = shell.NameSpace(outputDirectory.Substring(0, outputDirectory.LastIndexOf('\\')));
                    //        versionDest.CopyHere(items, 16);
                    //    //}
                    //}
                    //else
                    //{
                    if (Directory.Exists(_targetLocationVersion))
                    {
                        Directory.Delete(_targetLocationVersion, true);
                    }
                    Directory.Move(Path.Combine(outputDirectory, folderName), _targetLocationVersion);

                    //Code To make A Copy adn zip of Actaul code
                    //==========================================
                    //try
                    //{
                    //    if (System.IO.Directory.Exists(_targetLocationVersion))
                    //    {
                    //        if (Directory.Exists((ConfigurationManager.AppSettings["DownloadAppPath"].ToString() + ViewState["App_Name"].ToString() + "\\" + ViewState["App_Name"].ToString()).Remove((ConfigurationManager.AppSettings["DownloadAppPath"].ToString() + ViewState["App_Name"].ToString() + "\\" + ViewState["App_Name"].ToString()).LastIndexOf(@"\"))))
                    //            Directory.Delete((ConfigurationManager.AppSettings["DownloadAppPath"].ToString() + ViewState["App_Name"].ToString() + "\\" + ViewState["App_Name"].ToString()).Remove((ConfigurationManager.AppSettings["DownloadAppPath"].ToString() + ViewState["App_Name"].ToString() + "\\" + ViewState["App_Name"].ToString()).LastIndexOf(@"\")), true);

                    //        CopyFolder(_targetLocationVersion, ConfigurationManager.AppSettings["DownloadAppPath"].ToString() + ViewState["App_Name"].ToString() + "\\" + ViewState["App_Name"].ToString());
                    //        CopyFolder(outputDirectory, ConfigurationManager.AppSettings["DownloadAppPath"].ToString() + ViewState["App_Name"].ToString() + "\\SupportFiles");
                    //        if (Directory.Exists(ConfigurationManager.AppSettings["DownloadAppPath"].ToString() + ViewState["App_Name"].ToString() + "\\SupportFiles"))
                    //        {
                    //            try
                    //            {
                    //                DirectoryInfo diSupportDirectory = new DirectoryInfo(ConfigurationManager.AppSettings["DownloadAppPath"].ToString() + ViewState["App_Name"].ToString() + "\\SupportFiles");
                    //                IEnumerable<FileInfo> rgFiles = diSupportDirectory.GetFiles().Where(y => !y.Name.Contains(".exe"));
                    //                foreach (FileInfo fi in rgFiles)
                    //                {
                    //                    if (File.Exists(ConfigurationManager.AppSettings["DownloadAppPath"].ToString() + ViewState["App_Name"].ToString() + "\\" + fi.Name))
                    //                        File.Delete(ConfigurationManager.AppSettings["DownloadAppPath"].ToString() + ViewState["App_Name"].ToString() + "\\" + fi.Name);
                    //                    File.Move(ConfigurationManager.AppSettings["DownloadAppPath"].ToString() + ViewState["App_Name"].ToString() + "\\SupportFiles" + @"\" + fi.Name, ConfigurationManager.AppSettings["DownloadAppPath"].ToString() + ViewState["App_Name"].ToString() + "\\" + fi.Name);
                    //                }
                    //                DirectoryInfo[] dirInfo = diSupportDirectory.GetDirectories();
                    //                foreach (DirectoryInfo dir in dirInfo)
                    //                {
                    //                    if (dir.Exists)
                    //                    {
                    //                        if (Directory.Exists(dir.FullName.Substring(0, dir.FullName.IndexOf("SupportFiles")) + dir.Name))
                    //                            Directory.Delete(dir.FullName.Substring(0, dir.FullName.IndexOf("SupportFiles")) + dir.Name, true);

                    //                        Directory.Move(dir.FullName, dir.FullName.Substring(0, dir.FullName.IndexOf("SupportFiles")) + dir.Name);
                    //                    }
                    //                }

                    //                Directory.Delete(ConfigurationManager.AppSettings["DownloadAppPath"].ToString() + ViewState["App_Name"].ToString() + "\\SupportFiles", true);
                    //            }
                    //            catch (Exception ex)
                    //            {
                    //            }
                    //        }
                    //        UpdateFileInFolder(ConfigurationManager.AppSettings["DownloadAppPath"].ToString() + ViewState["App_Name"].ToString() + "\\" + ViewState["App_Name"].ToString(), ConfigurationManager.AppSettings["DownloadAppPath"].ToString() + ViewState["App_Name"].ToString() + "\\" + ViewState["App_Name"].ToString());
                    //        MakeZip(ConfigurationManager.AppSettings["DownloadAppPath"].ToString() + ViewState["App_Name"].ToString());                            
                    //    }
                    //}
                    //catch (Exception ex)
                    //{
                    //}
                    //==========================================

                    //Create folder at target place with the virsion name.

                    lblResponse.Text += "Unzip complete <br>";
                    DirectoryInfo di = new DirectoryInfo(outputDirectory);
                    //DirectoryInfo di = new DirectoryInfo(_targetLocation);               


                    //**********************************************************************************
                    try
                    {
                        // FileInfo[] rgFiles = di.GetFiles("*.amexapplication");
                        IEnumerable<FileInfo> rgFiles = di.GetFiles().Where(y => !y.Name.Contains(".exe"));//Added on 12 July.
                        //It would not consider .exe files in rgfiles.

                        // FileInfo[] rgFiles = di.GetFiles();//earlier it was used to copy only .amexapplication from temp. 
                        foreach (FileInfo fi in rgFiles)//Now all files including .amexapplication from temp are parallel to application files Folder.
                        {
                            if (File.Exists(_targetLocationVersion.Substring(0, _targetLocation.LastIndexOf(@"Application Files")) + fi.Name))
                                File.Delete(_targetLocationVersion.Substring(0, _targetLocation.LastIndexOf(@"Application Files")) + fi.Name);

                            File.Move(outputDirectory + @"\" + fi.Name, _targetLocationVersion.Substring(0, _targetLocation.LastIndexOf(@"Application Files")) + fi.Name);

                        }

                        DirectoryInfo[] dirInfo = di.GetDirectories();

                        foreach (DirectoryInfo dir in dirInfo)
                        {
                            if (dir.Exists)
                            {    //if dir already exist then delete it first
                                if (Directory.Exists(dir.FullName.Substring(0, dir.FullName.IndexOf("Application Files")) + dir.Name))
                                {
                                    Directory.Delete(dir.FullName.Substring(0, dir.FullName.IndexOf("Application Files")) + dir.Name, true);
                                }
                                Directory.Move(dir.FullName, dir.FullName.Substring(0, dir.FullName.IndexOf("Application Files")) + dir.Name);
                            }
                        }

                    }
                    catch (Exception ex)
                    {
                        LogManager.LogErrorMessage(ex.ToString(), Convert.ToInt32(AdmConstants.MethodName.GWiz_UploadFiles_Upload_Click));
                    }


                    //Copy the EXE file
                    try
                    {
                        FileInfo[] rgFiles = di.GetFiles("*.exe");

                        foreach (FileInfo fi in rgFiles)
                        {
                            if (File.Exists(Path.Combine(Request.MapPath(Request.ApplicationPath), fi.Name)))
                                File.Delete(Path.Combine(Request.MapPath(Request.ApplicationPath), fi.Name));

                            File.Move(outputDirectory + @"\" + fi.Name, Path.Combine(Request.MapPath(Request.ApplicationPath), fi.Name));
                        }
                    }
                    catch (Exception ex)
                    {
                        LogManager.LogErrorMessage(ex.ToString(), Convert.ToInt32(AdmConstants.MethodName.GWiz_UploadFiles_Upload_Click));
                    }

                    // **********************************************************************************

                }
            }
        }

        //To get release information from Manifest file
        private void GetReleaseInfoFromManifestFile()
        {
            releaseDtl = new DataTable();

            releaseDtl.Columns.Add(new DataColumn("FileVersion", System.Type.GetType("System.String")));
            releaseDtl.Columns.Add(new DataColumn("FileName", System.Type.GetType("System.String")));
            releaseDtl.Columns.Add(new DataColumn("FilePath", System.Type.GetType("System.String")));

            XmlDocument xmldoc = new XmlDocument();
            string configFileName = ConfigurationSettings.AppSettings["ReleaseConfigurationFile"].ToString();
            string xMLFilePath = _targetLocation + "\\" + configFileName;
            if (File.Exists(xMLFilePath))
            {
                string xmlFleName = System.IO.Path.GetFileName(xMLFilePath);
                if (configFileName == xmlFleName)
                {
                    xmldoc.Load(xMLFilePath);
                    XmlNodeList xmlRootnode = xmldoc.GetElementsByTagName("GWiz");
                    foreach (XmlNode xNode in xmlRootnode)
                    {
                        XmlAttributeCollection xGWizAttrtibute = xNode.Attributes;
                        releaseVersion = xGWizAttrtibute[0].Value;
                        releaseDT = xGWizAttrtibute[1].Value;
                    }
                    XmlNodeList xmlNode = xmldoc.GetElementsByTagName("File");
                    foreach (XmlNode xNode in xmlNode)
                    {
                        XmlAttributeCollection xAttribute = xNode.Attributes;
                        GenerateTable(releaseVersion, xAttribute[0].Value, xAttribute[1].Value, releaseDtl);
                    }
                }
            }
            else
            {
                lblResponse.Text += configFileName + " not found.";
            }
        }

        //Function to read information from Config File
        private void GetReleaseInfo()
        {
            releaseDtl = new DataTable();

            releaseDtl.Columns.Add(new DataColumn("FileVersion", System.Type.GetType("System.String")));
            releaseDtl.Columns.Add(new DataColumn("FileName", System.Type.GetType("System.String")));
            releaseDtl.Columns.Add(new DataColumn("FilePath", System.Type.GetType("System.String")));

            XmlDocument xmldoc = new XmlDocument();
            string configFileName = ConfigurationSettings.AppSettings["ReleaseConfigurationFile"].ToString();
            string xMLFilePath = _targetLocation + "\\" + configFileName;
            if (File.Exists(xMLFilePath))
            {
                string xmlFleName = System.IO.Path.GetFileName(xMLFilePath);
                if (configFileName == xmlFleName)
                {
                    xmldoc.Load(xMLFilePath);
                    XmlNodeList xmlRootnode = xmldoc.GetElementsByTagName("GWiz");
                    foreach (XmlNode xNode in xmlRootnode)
                    {
                        XmlAttributeCollection xGWizAttrtibute = xNode.Attributes;
                        releaseVersion = xGWizAttrtibute[0].Value;
                        releaseDT = xGWizAttrtibute[1].Value;
                    }
                    XmlNodeList xmlNode = xmldoc.GetElementsByTagName("File");
                    foreach (XmlNode xNode in xmlNode)
                    {
                        XmlAttributeCollection xAttribute = xNode.Attributes;
                        GenerateTable(releaseVersion, xAttribute[0].Value, xAttribute[1].Value, releaseDtl);
                    }
                }
            }
            else
            {
                lblResponse.Text += configFileName + " not found.";
            }
        }

        private void GenerateTable(string fileVersion, string fileName, string filePath, DataTable releaseDtl)
        {
            DataRow drReleaseDTL = null;
            drReleaseDTL = releaseDtl.NewRow();
            drReleaseDTL["FileVersion"] = fileVersion;
            drReleaseDTL["FileName"] = fileName;
            drReleaseDTL["FilePath"] = filePath;
            releaseDtl.Rows.Add(drReleaseDTL);

        }

        private void GenerateDeployTable(string fileVersion, string fileName, string filePath, DataTable releaseDtl)
        {
            DataRow drReleaseDTL = null;
            drReleaseDTL = releaseDtl.NewRow();
            drReleaseDTL["FileVersion"] = fileVersion;
            drReleaseDTL["FileName"] = fileName;
            drReleaseDTL["FilePath"] = filePath;
            releaseDtl.Rows.Add(drReleaseDTL);

        }

        private void SaveReleaseInfo()
        {
            string IP = string.Empty;
            string APP_TYPE = string.Empty;
            IP = GetIP();//Request.UserHostAddress;
            this.App_id = Int32.Parse(ViewState["App_ID"].ToString());
            _gduModel = new GDUModel();

            //GetReleaseInfo();
            //GetFileNamesWithVersion(_targetLocation);
            //string xMLFilePath = _targetLocation + "\\" + configFileName;

            if (rdoPilot.Checked)
                APP_TYPE = "OP";
            else if (rdoProduction.Checked)
                APP_TYPE = "PR";



            string ipAddress;
            ipAddress = Request.ServerVariables["HTTP_X_FORWARDED_FOR"];
            if (ipAddress == null) //may be the HTTP_X_FORWARDED_FOR is null
            {
                ipAddress = Request.ServerVariables["REMOTE_ADDR"];//we can use REMOTE_ADDR
                string add = HttpContext.Current.Request.UserHostAddress;
            }



            string clientMachineName;
            clientMachineName = System.Net.Dns.GetHostEntry(Request.UserHostAddress).HostName.ToString();
            //clientMachineName = (Dns.GetHostEntry(Request.ServerVariables["remote_addr"]).HostName);

            _gduModel.SaveReleaseInfo(releaseDtl, releaseDtl.Rows[0][0].ToString(), DateTime.Now.ToString(), this.App_id, this.IsRollBack, ipAddress, "GD", APP_TYPE, clientMachineName);


            //Pilot Applciation Data
            if (rdoPilot.Checked)
            {
                if (rdbExcel.Checked)
                {
                    DataTable dtExcelTable = new DataTable();
                    //"Provider=Microsoft.Jet.OLEDB.4.0;" & "Data Source=" + path + ";Extended Properties=""Excel 8.0;HDR=YES;"""
                    //OleDbConnection connection = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + fileExcel.Value.ToString() + @";Extended Properties=""Excel 8.0;IMEX=1;HDR=NO;TypeGuessRows=0;ImportMixedTypes=Text""");

                    HttpFileCollection uploadedFiles = Request.Files;
                    HttpPostedFile userPostedFile = uploadedFiles[1];

                    if (!Directory.Exists(Server.MapPath(@"AppToDownload\ExcelFile")))
                        Directory.CreateDirectory(Server.MapPath(@"AppToDownload\ExcelFile"));

                    string[] filesDelete = Directory.GetFiles(Server.MapPath(@"AppToDownload\ExcelFile"));
                    for (int i = 0; i < filesDelete.Length; i++)
                    {
                        System.IO.File.Delete(filesDelete[i]);
                    }

                    userPostedFile.SaveAs(Server.MapPath(@"AppToDownload\ExcelFile\" + "PilotAppUser" + userPostedFile.FileName.Substring(userPostedFile.FileName.LastIndexOf('.'))));
                    //userPostedFile.SaveAs(Server.MapPath(@"AppToDownload\ExcelFile\" + userPostedFile.FileName.Substring(userPostedFile.FileName.LastIndexOf('\\') + 1)));

                    string FilePath = Server.MapPath(@"AppToDownload\ExcelFile");
                    string myConnString = string.Empty;
                    string[] files = Directory.GetFiles(FilePath, "*.*", SearchOption.AllDirectories);
                    FileInfo fileInfo = new FileInfo(files[0]);

                    switch (fileInfo.Extension.ToUpper().Trim())
                    {
                        case ".XLS":
                            myConnString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + FilePath + "\\PilotAppUser.xls" + @";Extended Properties=""Excel 8.0;IMEX=1;HDR=YES;TypeGuessRows=0;ImportMixedTypes=Text""";
                            break;
                        case ".XLSX":
                            myConnString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + FilePath + "\\PilotAppUser.xlsx" + ";Extended Properties=\"Excel 12.0;HDR=YES;IMEX=1;MAXSCANROWS=0\"";
                            break;
                    }
                    //myConnString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + Server.MapPath(@"AppToDownload\PilotAppUser.xls") + @";Extended Properties=""Excel 8.0;IMEX=1;HDR=YES;TypeGuessRows=0;ImportMixedTypes=Text""";//String.Concat(@"Provider=Microsoft.ACE.OLEDB.4.0;Data Source=" + fileExcel.Value.ToString() + ";Extended Properties=\"Excel 11.0;HDR=YES;IMEX=1;");
                    string sql1 = "select * from [Sheet1$]";
                    OleDbConnection condati = new OleDbConnection(myConnString);
                    condati.Open();
                    DataTable dtbdati = new DataTable();
                    OleDbDataAdapter dtadati = new OleDbDataAdapter(sql1, condati);
                    dtadati.Fill(dtbdati);
                    condati.Close();

                    //writing XML document
                    //string XMLFile = Server.MapPath(@"AppToDownload\PilotAppExcelSheet");

                    //using (XmlWriter writer = XmlWriter.Create(XMLFile + ".xml"))
                    //{
                    //    writer.WriteStartDocument();
                    //    writer.WriteStartElement("ROOT");

                    //    foreach (DataRow dr in dtbdati.Rows)
                    //    {
                    //        writer.WriteStartElement("Import");
                    //        writer.WriteElementString("OFFICE_ID", dr["OFFICE_ID"].ToString());
                    //        writer.WriteElementString("ADS_ID", dr["ADS_ID"].ToString());
                    //        writer.WriteElementString("USER_NM", dr["USER_NM"].ToString());
                    //        writer.WriteElementString("IP_ADDR_TXT", dr["IP_ADDR_TXT"].ToString());
                    //        writer.WriteElementString("COMPUTER_NM", dr["COMPUTER_NM"].ToString());
                    //        writer.WriteEndElement();
                    //    }

                    //    writer.WriteEndElement();
                    //    writer.WriteEndDocument();
                    //}                    
                    //SaveXlData(XMLFile + ".xml", this.App_id, releaseDtl.Rows[0][0].ToString(), "Excel", 0);
                    SaveXlData(dtbdati, this.App_id, releaseDtl.Rows[0][0].ToString(), "Excel", 0);
                    //deleteXmlFile(XMLFile + ".xml");
                }
                else if (rdbGroup.Checked)
                    SaveXlData(null, this.App_id, releaseDtl.Rows[0][0].ToString(), "Group", Convert.ToInt32(ddlGroup.SelectedValue));
            }
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            string IP = string.Empty;
            string APP_TYPE = string.Empty;
            IP = Request.UserHostAddress; //Request.UserHostAddress;
            try
            {
                this.App_id = Int32.Parse(ViewState["App_ID"].ToString());
                _gduModel = new GDUModel();
                GetReleaseInfo();
                if (rdoPilot.Checked)
                    APP_TYPE = "OP";
                else if (rdoProduction.Checked)
                    APP_TYPE = "PR";


                string ipAddress;
                ipAddress = Request.ServerVariables["HTTP_X_FORWARDED_FOR"];
                if (ipAddress == null) //may be the HTTP_X_FORWARDED_FOR is null
                {
                    ipAddress = Request.ServerVariables["REMOTE_ADDR"];//we can use REMOTE_ADDR
                    string add = HttpContext.Current.Request.UserHostAddress;
                }

                string clientMachineName;
                clientMachineName = System.Net.Dns.GetHostEntry(Request.UserHostAddress).HostName.ToString();
                _gduModel.SaveReleaseInfo(releaseDtl, releaseVersion, releaseDT, this.App_id, this.IsRollBack, ipAddress, "GD", APP_TYPE, clientMachineName);
            }
            catch (Exception ex)
            {
                LogManager.LogErrorMessage(ex, Convert.ToInt32(AdmConstants.MethodName.GWiz_UploadFiles_Save_Clcik));
            }
        }

        private void PopulateApplication()
        {
            try
            {
                _gduModel = new GDUModel();
                Dictionary<string, string> objDictonaryapp = new Dictionary<string, string>();
                Dictionary<string, string> objUserApp = new Dictionary<string, string>();
                objDictonaryapp = _gduModel.PopulateApplicationInfo();

                //Get All User's Authorized application
                string User_Id = string.Empty;
                User_Id = System.Web.HttpContext.Current.Request.LogonUserIdentity.Name.Substring(System.Web.HttpContext.Current.Request.LogonUserIdentity.Name.LastIndexOf(@"\") + 1);

                DataTable searchAppUser = _gduModel.GetAppUserDetails(User_Id, 0, false, "SearchAppUser", 0, 100, "App_Name", "ASC");
                if (!object.Equals(searchAppUser, null))
                {

                    if (searchAppUser.Rows.Count > 0)
                    {

                        foreach (var pair in objDictonaryapp)
                        {
                            for (int i = 0; i < searchAppUser.Rows.Count; i++)
                            {
                                if (pair.Value.ToString() == searchAppUser.Rows[i]["AppName"].ToString())
                                    objUserApp.Add(pair.Key, pair.Value);
                            }
                        }

                        this.ddlApplication.DataSource = objUserApp;
                        ddlApplication.DataValueField = AdmConstants.KEY;
                        ddlApplication.DataTextField = AdmConstants.VALUE;
                        ddlApplication.DataBind();
                    }
                }
                ddlApplication.Items.Insert(0, new ListItem(AdmConstants.SELECT_APPLICATION, "SELECT APPLICATION"));
                lblTargetPath.Text = string.Empty;
            }
            catch (Exception ex)
            {
                throw ex;
            }


        }

        private void SetApplication(int index)
        {
            _gduModel = new GDUModel();
            Dictionary<string, string> objDictonaryapplication = new Dictionary<string, string>();
            Dictionary<string, string> objUserApp = new Dictionary<string, string>();
            objDictonaryapplication = _gduModel.PopulateApplicationInfo();
            ddlApplication.SelectedIndex = index;
            string User_Id = string.Empty;
            User_Id = System.Web.HttpContext.Current.Request.LogonUserIdentity.Name.Substring(System.Web.HttpContext.Current.Request.LogonUserIdentity.Name.LastIndexOf(@"\") + 1);
            DataTable searchAppUser = _gduModel.GetAppUserDetails(User_Id, 0, false, "SearchAppUser", 0, 100, "App_Name", "ASC");
            if (!object.Equals(searchAppUser, null))
            {
                if (searchAppUser.Rows.Count > 0)
                {
                    foreach (var pair in objDictonaryapplication)
                    {
                        for (int i = 0; i < searchAppUser.Rows.Count; i++)
                        {
                            if (pair.Value.ToString() == searchAppUser.Rows[i]["AppName"].ToString())
                                objUserApp.Add(pair.Key, pair.Value);
                        }
                    }


                    foreach (var pair in objUserApp)
                    {
                        if (pair.Value == ddlApplication.SelectedItem.ToString())
                        {
                            //ViewState["AppDeployPath"] = string.Format("Target Location :  {0}", pair.Key.ToString().Substring(pair.Key.ToString().LastIndexOf("~") + 1));
                            //ViewState["PilotAppDeployPath"] = string.Format("Target Location :  {0}", pair.Key.ToString().Substring(pair.Key.ToString().LastIndexOf("~") + 1)).Replace("DeployedApplication", "DeployedApplication\\Pilot");
                            //if (rdoPilot.Checked)
                            //    lblTargetPath.Text = ViewState["PilotAppDeployPath"].ToString();
                            //else if (rdoProduction.Checked)
                            //    lblTargetPath.Text = ViewState["AppDeployPath"].ToString();

                            lblTargetPath.Text = string.Format("Target Location :  {0}", pair.Key.ToString().Substring(pair.Key.ToString().LastIndexOf("~") + 1));
                            this._targetLocation = pair.Key.ToString().Substring(pair.Key.ToString().LastIndexOf("~") + 1);
                            this._targetLocationTemp = pair.Key.ToString().Substring(pair.Key.ToString().LastIndexOf("~") + 1) + "\\temp";
                            this.App_id = Int32.Parse(pair.Key.ToString().Substring(0, pair.Key.ToString().IndexOf("~")));
                            ViewState["App_Name"] = pair.Value.ToString();
                            ViewState["App_ID"] = this.App_id.ToString();
                        }
                    }
                }
            }
        }
        #endregion

        public IEnumerable<XElement> GetInstallableDependencies(bool isClickOnceManifest, XElement xManifest)
        {
            XmlReader reader = xManifest.CreateReader();
            XmlNamespaceManager namespaceManager = new XmlNamespaceManager(reader.NameTable);
            string xPath = string.Empty;

            if (isClickOnceManifest)
            {
                namespaceManager.AddNamespace("asmv1", "urn:schemas-microsoft-com:asm.v1");
                namespaceManager.AddNamespace("asmv2", "urn:schemas-microsoft-com:asm.v2");
                xPath = "asmv2:dependency/asmv2:dependentAssembly[@dependencyType='install']";
            }
            else
            {
                namespaceManager.AddNamespace("ns1", "http://www.devx.com/schemas/autoupgrade/1.0");
                xPath = "ns1:ManifestFiles/ns1:File[@method='version' and @action='copy']";
            }
            return xManifest.XPathSelectElements(xPath, namespaceManager);

        }

        public IEnumerable<XElement> GetInstallableFiles(bool isClickOnceManifest, XElement xManifest)
        {
            XmlReader reader = xManifest.CreateReader();
            XmlNamespaceManager namespaceManager = new XmlNamespaceManager(reader.NameTable);
            string xPath = string.Empty;

            if (isClickOnceManifest)
            {
                namespaceManager.AddNamespace("asmv1", "urn:schemas-microsoft-com:asm.v1");
                namespaceManager.AddNamespace("asmv2", "urn:schemas-microsoft-com:asm.v2");
                xPath = "asmv2:file";
            }
            else
            {
                namespaceManager.AddNamespace("ns1", "http://www.devx.com/schemas/autoupgrade/1.0");
                xPath = "ns1:ManifestFiles/ns1:File[@method='date' and @action='copy']";
            }
            return xManifest.XPathSelectElements(xPath, namespaceManager);

        }

        protected void btnUploadAmexFile_Click(object sender, EventArgs e)
        {
            try
            {
                this.ValidateFolderPaths();
                // Access the uploaded files.
                HttpFileCollection uploadedFiles = Request.Files;

                HttpPostedFile userPostedFile = uploadedFiles[0];
                if (userPostedFile.ContentLength > 0)
                {
                    string fileName = System.IO.Path.GetFileName(userPostedFile.FileName);
                    string filepath = string.Empty;
                    // If the uploaded file is zip copy it first to temp location
                    // else copy at location.
                    if (fileName.ToUpper().Contains(".AMEXAPPLICATION"))
                    {
                        filepath = lblTargetPath.Text;

                    }

                    // Recalculate the filepath.
                    filepath = Path.Combine(filepath, fileName);
                    // Save the file.

                    userPostedFile.SaveAs(filepath);
                    lblResponse.Text += "<u>File #" + (1) + "</u><br>";
                    lblResponse.Text += "File Content Type: " + userPostedFile.ContentType + "<br>";
                    lblResponse.Text += "File Size: " + userPostedFile.ContentLength + "kb<br>";
                    lblResponse.Text += "File Name: " + userPostedFile.FileName + "<br>";

                }

            }
            catch (Exception ex)
            {
                lblResponse.Text = ex.Message;
            }

        }

        private string GetIP()
        {
            //string strHostName = "";
            //strHostName = System.Net.Dns.GetHostName();
            //IPHostEntry ipEntry = System.Net.Dns.GetHostEntry(strHostName);
            //IPAddress[] addr = ipEntry.AddressList;
            //return addr[addr.Length - 1].ToString();
            string strHostName = "";
            string str = string.Empty;
            strHostName = System.Net.Dns.GetHostName();
            IPHostEntry ipEntry = System.Net.Dns.GetHostEntry(strHostName);
            IPAddress[] addr = ipEntry.AddressList;
            try
            {
                for (int i = 0; i < addr.Length; i++)
                {
                    str = addr[i].ToString();
                    string[] words = str.Split('.');
                    if (words.Length == 4)
                    {
                        str = addr[i].ToString();
                        break;
                    }
                }
            }
            catch (Exception ex)
            {
                str = addr[addr.Length - 1].ToString();
            }
            return str;
        }

        protected void chkRollBack_CheckedChanged(object sender, EventArgs e)
        {
            lblResponse.Text = "";
            lblStatus.Text = "";
            lblStatus.Visible = false;

            if (chkRollBack.Checked)
            {
                trSelectFile.Visible = false;
                trSelectVersion.Visible = true;
                btnUpload.Visible = false;
                btnUpdateVersion.Visible = true;

                if ((ddlApplication.SelectedValue.ToString().ToUpper() != "SELECT ALL") && (ddlApplication.SelectedValue.ToString().ToUpper() != "SELECT APPLICATION"))
                {
                    GetAppVersion(Int32.Parse(ddlApplication.SelectedValue.ToString().Substring(0, ddlApplication.SelectedValue.ToString().IndexOf("~"))));
                }

            }
            else
            {
                trSelectFile.Visible = true;
                trSelectVersion.Visible = false;

                btnUpload.Visible = true;
                btnUpdateVersion.Visible = false;

                lblLatestVersion.Visible = false;
            }

            if (rdoProduction.Checked)
            {
                //trMakeProd.Visible = false;
                trPilotFile.Visible = false;
                trGroup.Visible = false;
                trExcelFile.Visible = false;
                SampleExcelDownload.Visible = false;
                if (chkRollBack.Checked)
                {
                    trMakeProd.Visible = false;
                    trSelectFile.Visible = false;
                    trSelectVersion.Visible = true;
                    btnUpload.Visible = false;
                    btnUpdateVersion.Visible = true;
                }
                else
                {
                    trMakeProd.Visible = true;
                    //trSelectFile.Visible = true;
                    //trSelectVersion.Visible = false;
                    //btnUpload.Visible = true;
                    //btnUpdateVersion.Visible = false;

                    if (RBMakeProd.Checked)
                    {
                        trSelectFile.Visible = false;
                        trSelectVersion.Visible = true;
                        btnUpload.Visible = false;
                        btnUpdateVersion.Visible = true;
                    }
                    else if (RBNewPilotUpload.Checked)
                    {
                        trSelectFile.Visible = true;
                        trSelectVersion.Visible = false;
                        btnUpload.Visible = true;
                        btnUpdateVersion.Visible = false;
                    }
                }
            }
            else if (rdoPilot.Checked)
            {
                trMakeProd.Visible = false;
                if (chkRollBack.Checked)
                {

                    trPilotFile.Visible = false;
                    trGroup.Visible = false;
                    trExcelFile.Visible = false;
                    SampleExcelDownload.Visible = false;
                }
                else
                {
                    trPilotFile.Visible = true;
                    if (rdbExcel.Checked)
                    {
                        trGroup.Visible = false;
                        trExcelFile.Visible = true;
                        SampleExcelDownload.Visible = true;
                    }
                    else if (rdbGroup.Checked)
                    {
                        trGroup.Visible = true;
                        trExcelFile.Visible = false;
                    }
                }
            }

        }

        private void CopyFolder(string sourceFolder, string destFolder)
        {
            if (Directory.Exists(destFolder))
                Directory.Delete(destFolder, true);

            Directory.CreateDirectory(destFolder);
            string[] files = Directory.GetFiles(sourceFolder);
            foreach (string file in files)
            {
                string name = Path.GetFileName(file);
                string dest = Path.Combine(destFolder, name);
                if (!name.Contains(".amexapplication"))
                    File.Copy(file, dest, true);

            }
            string[] folders = Directory.GetDirectories(sourceFolder);
            foreach (string folder in folders)
            {
                string name = Path.GetFileName(folder);
                string dest = Path.Combine(destFolder, name);
                CopyFolder(folder, dest);
            }
        }

        private void UpdateFileInFolder(string sourceFolder, string destFolder)
        {
            string[] files = Directory.GetFiles(sourceFolder);
            foreach (string file in files)
            {
                string name = Path.GetFileName(file);
                if (name.Contains('.'))
                {
                    if (name.Substring(name.LastIndexOf('.')) == ".deploy")
                    {
                        string dest = Path.Combine(destFolder, name.Substring(0, name.LastIndexOf('.')));
                        System.IO.File.Move(file, dest);
                    }
                }
            }
            string[] folders = Directory.GetDirectories(sourceFolder);
            foreach (string folder in folders)
            {
                string name = Path.GetFileName(folder);
                string dest = Path.Combine(destFolder, name);
                UpdateFileInFolder(folder, dest);
            }
        }

        private void MakeZip(string AppToZip)
        {

            try
            {
                if (File.Exists(AppToZip + ".zip"))
                    File.Delete(AppToZip + ".zip");
                //Create an empty zip file                
                byte[] emptyzip = new byte[] { 80, 75, 5, 6, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
                FileStream fs = File.Create(AppToZip + ".zip");
                fs.Write(emptyzip, 0, emptyzip.Length);
                fs.Flush();
                fs.Close();
                fs = null;
                //Copy a folder and its contents into the newly created zip file
                Shell32.ShellClass sc = new Shell32.ShellClass();
                // returns a Folder of args parameter                
                Shell32.Folder SrcFlder = sc.NameSpace(AppToZip);
                Shell32.Folder DestFlder = sc.NameSpace(AppToZip + ".zip");
                Shell32.FolderItems items = SrcFlder.Items();
                DestFlder.CopyHere(items, 0);
                System.Threading.Thread.Sleep(1000);
            }
            catch (Exception ex)
            {
            }

        }

        private static void LogtoEvent(string ex)
        {
            string TraceInfo = ConfigurationSettings.AppSettings["GDUTracFileInfo"].ToString();
            if (TraceInfo == "True")
            {
                string TraceFile = Path.GetFullPath(ConfigurationSettings.AppSettings["GDUTracFile"].ToString());
                FileStream fs = null;
                if (!System.IO.File.Exists(TraceFile))
                {
                    using (fs = System.IO.File.Create(TraceFile))
                    {

                    }
                }
                if (System.IO.File.Exists(TraceFile))
                {
                    StringBuilder sb = new StringBuilder();
                    StreamReader sr = new StreamReader(TraceFile);
                    {
                        sb.Append(sr.ReadToEnd());
                        sb.AppendLine();
                    }
                    sr.Close();
                    TextWriter tw = new StreamWriter(TraceFile);
                    sb.AppendLine(ex.ToString());
                    tw.WriteLine(sb.ToString());
                    tw.Close();
                }
            }

        }

        protected void btnUpdateVersion_Click(object sender, EventArgs e)
        {

            string aa = ddlVersion.SelectedItem.Text.ToString();
            //if ((isRollBacked == true) && (ddlApplication.SelectedItem.Text.ToLower().Contains("star apollo") == true))
            //{
            //    ValidateFolderPaths();
            //    //LoadRollBacked(_targetLocation);
            //}
            //else
            //{
            if (ddlApplication.SelectedValue.ToString() == "SELECT APPLICATION")
            {
                string ErrorMessage = "Please select an application.";
                ShowAlertMessage(ErrorMessage);
                return;
            }
            else if (ddlVersion.SelectedValue.ToString() == "SELECT VERSION")
            {
                string ErrorMessage = "Please select version.";
                ShowAlertMessage(ErrorMessage);
                return;
            }
            else
            {
                try
                {
                    _gduModel = new GDUModel();
                    string Status = string.Empty;
                    if (chkRollBack.Checked)
                    {
                        _gduModel.ManageAppPrevVersion(Convert.ToInt32(ViewState["App_ID"].ToString()), ddlVersion.SelectedItem.Text.ToString(), "GD", out Status, "UpdateVersion");
                        lblStatus.Text = "Version Updated Successfully";
                    }
                    else
                    {
                        _gduModel.ManageAppPrevVersion(Convert.ToInt32(ViewState["App_ID"].ToString()), ddlVersion.SelectedItem.Text.ToString(), "GD", out Status, "MakeProdApp");
                        lblStatus.Text = "Production Application converted Successfully.";
                        //string ErrorMessage = "Production Application converted Successfully.";

                        //ShowAlertMessage(ErrorMessage);
                        //if ((ddlApplication.SelectedValue.ToString().ToUpper() != "SELECT ALL") && (ddlApplication.SelectedValue.ToString().ToUpper() != "SELECT APPLICATION"))
                        //    GetAppVersion(Int32.Parse(ddlApplication.SelectedValue.ToString().Substring(0, ddlApplication.SelectedValue.ToString().IndexOf("~"))));
                        //return;
                    }
                    if (Status == "Success")
                    {
                        string amexFilePath = string.Empty;
                        string appPath = string.Empty;
                        appPath = ((lblTargetPath.Text.ToString().Substring(lblTargetPath.Text.ToString().IndexOf(":") + 1)).ToString().Replace("\\", @"\").Trim());
                        appPath = appPath.Remove(appPath.LastIndexOf(@"\"));

                        string ExeNamePath = ddlVersion.SelectedValue.ToString().Split('~')[0].ToString();
                        ExeNamePath = ExeNamePath.Substring(0, ExeNamePath.LastIndexOf('.'));

                        string EntryPointPath = ddlVersion.SelectedValue.ToString().Split('~')[1].ToString();
                        EntryPointPath = EntryPointPath.Substring(0, EntryPointPath.LastIndexOf('.'));

                        if (File.Exists(appPath + @"\" + ExeNamePath + ".amexapplication"))
                            amexFilePath = appPath + @"\" + ExeNamePath + ".amexapplication";
                        else
                            amexFilePath = appPath + @"\" + EntryPointPath + ".amexapplication";

                        StringBuilder newFile = new StringBuilder();
                        string UpdatedVer = string.Empty;
                        string temp = "";
                        try
                        {
                            UpdatedVer = ddlVersion.SelectedItem.Text.ToString();
                            string[] file = File.ReadAllLines(amexFilePath);
                            foreach (string line in file)
                            {

                                if (line.Contains(ViewState["CurrentVersion"].ToString()))
                                {
                                    temp = line.Replace(ViewState["CurrentVersion"].ToString(), UpdatedVer);
                                    newFile.Append(temp + "\r\n");
                                    continue;
                                }
                                else if (line.Contains(ViewState["CurrentVersion"].ToString().Replace('.', '_')))
                                {
                                    temp = line.Replace(ViewState["CurrentVersion"].ToString().Replace('.', '_'), UpdatedVer.Replace('.', '_'));
                                    newFile.Append(temp + "\r\n");
                                    continue;
                                }
                                newFile.Append(line + "\r\n");
                            }
                            File.WriteAllText(amexFilePath, newFile.ToString());
                            lblStatus.Visible = true;

                            if ((ddlApplication.SelectedValue.ToString().ToUpper() != "SELECT ALL") && (ddlApplication.SelectedValue.ToString().ToUpper() != "SELECT APPLICATION"))
                                GetAppVersion(Int32.Parse(ddlApplication.SelectedValue.ToString().Substring(0, ddlApplication.SelectedValue.ToString().IndexOf("~"))));

                        }
                        catch (Exception ex)
                        {
                        }
                    }
                }
                catch (Exception ex)
                {
                }
            }
            //}
        }

        protected void rdoPilot_CheckedChanged(object sender, EventArgs e)
        {
            ddlApplication.SelectedIndex = 0;
            trRollBack.Visible = true;
            trMakeProd.Visible = false;
            rdbExcel.Checked = true;
            lblTargetPath.Text = string.Empty;
            lblLatestVersion.Text = string.Empty;
            lblStatus.Text = string.Empty;
            ddlVersion.Items.Clear();
            ddlVersion.Items.Insert(0, new ListItem(AdmConstants.VERSION, "SELECT VERSION"));
            this.ddlVersion.DataSource = null;
            this.ddlVersion.DataBind();
            if (chkRollBack.Checked)
            {
                chkRollBack.Checked = false;
            }

            //if (chkRollBack.Checked)
            //{
            //    trPilotFile.Visible = false;
            //    trExcelFile.Visible = false;
            //    SampleExcelDownload.Visible = false;
            //    trSelectFile.Visible = false;
            //    btnUpdateVersion.Visible = true;
            //    btnUpload.Visible = false;
            //}
            //else
            //{
            trPilotFile.Visible = true;
            trSelectVersion.Visible = false;
            trSelectFile.Visible = true;
            btnUpdateVersion.Visible = false;
            btnUpload.Visible = true;

            if (rdbExcel.Checked)
            {
                trGroup.Visible = false;
                trExcelFile.Visible = true;
                SampleExcelDownload.Visible = true;
                rdbGroup.Checked = false;
            }
            //else if (rdbGroup.Checked)
            //{
            //    trGroup.Visible = true;
            //    trExcelFile.Visible = false;
            //    SampleExcelDownload.Visible = false;
            //}
            //  }
            lblResponse.Text = "";
        }

        protected void rdoProduction_CheckedChanged(object sender, EventArgs e)
        {
            ddlApplication.SelectedIndex = 0;
            ddlVersion.Items.Clear();
            ddlVersion.Items.Insert(0, new ListItem(AdmConstants.VERSION, "SELECT VERSION"));
            this.ddlVersion.DataSource = null;
            this.ddlVersion.DataBind();
            lblTargetPath.Text = string.Empty;
            lblLatestVersion.Text = string.Empty;
            lblStatus.Text = string.Empty;
            trPilotFile.Visible = false;
            trGroup.Visible = false;
            trExcelFile.Visible = false;
            lblResponse.Text = "";
            SampleExcelDownload.Visible = false;
            btnUpload.Visible = true;
            btnUpdateVersion.Visible = false;

            if (chkRollBack.Checked)
            {
                chkRollBack.Checked = false;
            }
            RBMakeProd.Checked = true;
            //if (chkRollBack.Checked)
            //{
            //    trMakeProd.Visible = false;
            //    trSelectFile.Visible = false;
            //    trSelectVersion.Visible = true;
            //    btnUpload.Visible = false;
            //    btnUpdateVersion.Visible = true;
            //}
            //else
            //{
            trMakeProd.Visible = true;
            trSelectFile.Visible = true;
            trSelectVersion.Visible = false;
            btnUpload.Visible = true;
            btnUpdateVersion.Visible = false;
            if (RBMakeProd.Checked)
            {
                trSelectFile.Visible = false;
                trSelectVersion.Visible = true;
                btnUpload.Visible = false;
                btnUpdateVersion.Visible = true;
                trRollBack.Visible = false;
                RBNewPilotUpload.Checked = false;
            }
            //else if (RBNewPilotUpload.Checked)
            //{
            //    trSelectFile.Visible = true;
            //    trSelectVersion.Visible = false;
            //    btnUpload.Visible = true;
            //    btnUpdateVersion.Visible = false;
            //    trRollBack.Visible = true;
            //}
            // }


            //if ((!object.Equals(ViewState["AppDeployPath"], null)) || (!object.Equals(ViewState["PilotAppDeployPath"], null)))
            //    if (rdoPilot.Checked)
            //        lblTargetPath.Text = ViewState["PilotAppDeployPath"].ToString();
            //    else if (rdoProduction.Checked)
            //        lblTargetPath.Text = ViewState["AppDeployPath"].ToString();
        }

        protected void GetAppVersionDB(string App_ID, string App_Type)
        {
            _gduModel = new GDUModel();
        }

        protected void GetAppVersion(int App_ID)
        {
            string App_Type = string.Empty;
            string App_Version = string.Empty;
            if (rdoProduction.Checked)
            {
                App_Type = "PR";
            }
            else
            {
                App_Type = "OP";
            }

            _gduModel = new GDUModel();

            App_Version = _gduModel.GetAppVersionDB(App_ID, App_Type);

            Dictionary<string, string> objDictonary = new Dictionary<string, string>();
            Dictionary<string, string> objDict = new Dictionary<string, string>();
            if (chkRollBack.Checked)
            {
                string appPath = string.Empty;
                appPath = ((lblTargetPath.Text.ToString().Substring(lblTargetPath.Text.ToString().IndexOf(":") + 1)).ToString().Replace("\\", @"\").Trim());
                appPath = appPath.Remove(appPath.LastIndexOf(@"\"));

                if (Directory.Exists(appPath))
                {
                    string[] files = Directory.GetFiles(appPath, "*.amexapplication", SearchOption.AllDirectories);
                    if (files.Length > 0)
                    {
                        string FilePath = files[0].ToString();
                        string[] file = File.ReadAllLines(FilePath);
                        foreach (string line in file)
                        {
                            if (line.Contains("assemblyIdentity"))
                            {
                                string aa = line.Substring(line.LastIndexOf("version=")).Split(' ')[0];
                                aa = aa.Replace('"', '~');
                                int bb = aa.IndexOf("~");
                                int cc = aa.LastIndexOf("~");
                                ViewState["CurrentVersion"] = aa.Substring(bb + 1, (cc - bb) - 1);
                                lblLatestVersion.Text = "Current Version: " + ViewState["CurrentVersion"].ToString();
                                lblLatestVersion.Visible = true;
                                break;
                            }
                        }
                    }

                    if (!string.IsNullOrEmpty(App_Version))
                    {
                        ViewState["CurrentVersion"] = App_Version;
                        lblLatestVersion.Text = "Current Version: " + ViewState["CurrentVersion"].ToString();
                        lblLatestVersion.Visible = true;
                    }
                    if (!object.Equals(ViewState["CurrentVersion"], null))
                    {
                        if (rdoPilot.Checked)
                            objDictonary = _gduModel.GetAppPrevVersion(App_ID, ViewState["CurrentVersion"].ToString(), "GD", "RollBackPilot");
                        else
                            objDictonary = _gduModel.GetAppPrevVersion(App_ID, ViewState["CurrentVersion"].ToString(), "GD", "RollBack");
                    }

                    if (objDictonary.Count > 0)
                    {
                        this.ddlVersion.DataSource = objDictonary;
                        ddlVersion.DataTextField = AdmConstants.KEY;
                        ddlVersion.DataValueField = AdmConstants.VALUE;
                        ddlVersion.DataBind();
                        ddlVersion.Items.Insert(0, new ListItem(AdmConstants.VERSION, "SELECT VERSION"));
                    }
                    else
                    {
                        ddlVersion.Items.Clear();
                        ddlVersion.Items.Insert(0, new ListItem(AdmConstants.VERSION, "SELECT VERSION"));
                        this.ddlVersion.DataSource = null;
                        this.ddlVersion.DataBind();
                        //this.ddlVersion.DataSource = null;
                        //ddlVersion.DataValueField = AdmConstants.VALUE;
                        //ddlVersion.DataTextField = AdmConstants.KEY;
                        //ddlVersion.DataBind();
                        //ddlVersion.Items.Insert(0, new ListItem(AdmConstants.VERSION, "SELECT VERSION"));
                    }
                }
                else
                {
                    ddlVersion.Items.Clear();
                    ddlVersion.Items.Insert(0, new ListItem(AdmConstants.VERSION, "SELECT VERSION"));
                    this.ddlVersion.DataSource = null;
                    this.ddlVersion.DataBind();
                }
            }
            else
            {

                try
                {
                    string appPath = string.Empty;
                    appPath = ((lblTargetPath.Text.ToString().Substring(lblTargetPath.Text.ToString().IndexOf(":") + 1)).ToString().Replace("\\", @"\").Trim());
                    appPath = appPath.Remove(appPath.LastIndexOf(@"\"));

                    if (Directory.Exists(appPath))
                    {
                        string[] files = Directory.GetFiles(appPath, "*.amexapplication", SearchOption.AllDirectories);
                        if (files.Length > 0)
                        {
                            string FilePath = files[0].ToString();
                            string[] file = File.ReadAllLines(FilePath);
                            foreach (string line in file)
                            {
                                if (line.Contains("assemblyIdentity"))
                                {
                                    string aa = line.Substring(line.LastIndexOf("version=")).Split(' ')[0];
                                    aa = aa.Replace('"', '~');
                                    int bb = aa.IndexOf("~");
                                    int cc = aa.LastIndexOf("~");
                                    ViewState["CurrentVersion"] = aa.Substring(bb + 1, (cc - bb) - 1);
                                    lblLatestVersion.Text = "Current Version: " + ViewState["CurrentVersion"].ToString();
                                    lblLatestVersion.Visible = true;
                                    break;
                                }
                            }
                        }
                    }

                    if (!string.IsNullOrEmpty(App_Version))
                    {
                        ViewState["CurrentVersion"] = App_Version;
                        lblLatestVersion.Text = "Current Version: " + ViewState["CurrentVersion"].ToString();
                        lblLatestVersion.Visible = true;
                    }
                }
                catch (Exception ex)
                {
                }
                objDictonary = _gduModel.GetAppPrevVersion(App_ID, null, "GD", "Pilot");
                if (objDictonary.Count > 0)
                {
                    this.ddlVersion.DataSource = objDictonary;
                    ddlVersion.DataValueField = AdmConstants.VALUE;
                    ddlVersion.DataTextField = AdmConstants.KEY;
                    ddlVersion.DataBind();
                    ddlVersion.Items.Insert(0, new ListItem(AdmConstants.VERSION, "SELECT VERSION"));
                }
                else
                {
                    ddlVersion.Items.Clear();
                    ddlVersion.Items.Insert(0, new ListItem(AdmConstants.VERSION, "SELECT VERSION"));
                    this.ddlVersion.DataSource = null;
                    this.ddlVersion.DataBind();
                }
            }
        }

        protected void rdbExcel_CheckedChanged(object sender, EventArgs e)
        {
            lblStatus.Text = "";
            lblStatus.Visible = false;

            trGroup.Visible = false;
            trExcelFile.Visible = true;
            SampleExcelDownload.Visible = true;
        }

        protected void rdbGroup_CheckedChanged(object sender, EventArgs e)
        {
            lblStatus.Text = "";
            lblStatus.Visible = false;

            trGroup.Visible = true;
            trExcelFile.Visible = false;
            SampleExcelDownload.Visible = false;
            PopulateGroups();
        }

        private void PopulateGroups()
        {
            _gduModel = new GDUModel();
            Dictionary<string, string> dict = new Dictionary<string, string>();
            dict = this._gduModel.PopulateAppFGroup(string.Empty, 0, "Virtual");
            ddlGroup.DataSource = dict;
            ddlGroup.DataTextField = "Value";
            ddlGroup.DataValueField = "Key";
            this.ddlGroup.DataBind();
            this.ddlGroup.Items.Insert(0, new ListItem(AdmConstants.PLEASE_SELECT, "0"));
        }

        #region Excel File Functionality
        private void SaveXlData(DataTable FileToRead, int AppId, string AppVersion, string UploadType, int GroupId)
        {
            _gduModel = new GDUModel();
            _gduModel.SaveXlData(FileToRead, App_id, AppVersion, UploadType, GroupId);
        }

        private Boolean ValidateExcel(string FilePath)
        {
            bool Validflag = false;

            if (FilePath.Contains(".xls") || FilePath.Contains(".xlsx"))
            {
                Validflag = true;
            }
            else
            {
                Validflag = false;
            }
            return Validflag;
        }
        public static void ShowAlertMessage(string error)
        {
            Page page = HttpContext.Current.Handler as Page;
            if (page != null)
            {
                error = error.Replace("'", "\'");
                ScriptManager.RegisterStartupScript(page, page.GetType(), "err_msg", "alert('" + error + "');", true);
            }
        }
        private void deleteXmlFile(string FilePath)
        {
            if (System.IO.File.Exists(FilePath))
            {
                try
                {
                    System.IO.File.Delete(@FilePath);
                }
                catch (System.IO.IOException e)
                {
                    Console.WriteLine(e.Message);
                    return;
                }
            }
        }
        private void releaseObject(object obj)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                obj = null;
            }
            catch (Exception ex)
            {
                obj = null;
            }
            finally
            {
                GC.Collect();
            }
        }
        #endregion

        protected void RBMakeProd_CheckedChanged(object sender, EventArgs e)
        {
            lblStatus.Text = "";
            lblStatus.Visible = false;

            trSelectFile.Visible = false;
            trSelectVersion.Visible = true;
            trRollBack.Visible = false;
            trPilotFile.Visible = false;
            trGroup.Visible = false;
            trExcelFile.Visible = false;
            SampleExcelDownload.Visible = true;
            trGroup.Visible = false;
            trExcelFile.Visible = false;
            btnUpload.Visible = false;
            btnUpdateVersion.Visible = true;
            if ((ddlApplication.SelectedValue.ToString().ToUpper() != "SELECT ALL") && (ddlApplication.SelectedValue.ToString().ToUpper() != "SELECT APPLICATION"))
                GetAppVersion(Int32.Parse(ddlApplication.SelectedValue.ToString().Substring(0, ddlApplication.SelectedValue.ToString().IndexOf("~"))));
        }

        protected void RBNewPilotUpload_CheckedChanged(object sender, EventArgs e)
        {
            lblStatus.Text = "";
            lblStatus.Visible = false;

            trSelectFile.Visible = true;
            trSelectVersion.Visible = false;
            trRollBack.Visible = true;
            btnUpload.Visible = true;
            btnUpdateVersion.Visible = false;
        }

        //private void LoadRollBacked(string TargetBackupVersion)
        //{
        //    _BackupTargetLocation = TargetBackupVersion + @"\Backup";
        //    try
        //    {
        //        DirectoryInfo di = new DirectoryInfo(_BackupTargetLocation);
        //        if (Directory.Exists(_BackupTargetLocation))
        //        {
        //            DirectoryInfo[] dirInfo = di.GetDirectories();
        //            IEnumerable<FileInfo> rgFiles = di.GetFiles().Where(y => !y.Name.Contains(".exe"));//Added on 12 July.
        //            if (di.Exists)
        //            {
        //                //It would not consider .exe files in rgfiles.
        //                foreach (FileInfo fi in rgFiles)//Now all files including .amexapplication from temp are parallel to application files Folder.
        //                {
        //                    if (File.Exists(TargetBackupVersion.Substring(0, TargetBackupVersion.IndexOf("Application Files")) + fi.Name))
        //                        File.Delete(TargetBackupVersion.Substring(0, TargetBackupVersion.IndexOf("Application Files")) + fi.Name);

        //                    File.Move(_BackupTargetLocation + @"\" + fi.Name, TargetBackupVersion.Substring(0, TargetBackupVersion.IndexOf("Application Files")) + fi.Name);

        //                }
        //                foreach (DirectoryInfo dir in dirInfo)
        //                {
        //                    if (dir.Exists)
        //                    {
        //                        if (Directory.Exists(TargetBackupVersion + @"\" + dir.Name))
        //                        {
        //                            Directory.Delete(TargetBackupVersion + @"\" + dir.Name, true);
        //                        }
        //                        Directory.Move(dir.FullName, TargetBackupVersion + @"\" + dir.Name);
        //                    }
        //                }
        //            }
        //            else
        //            {
        //                lblResponse.Text = "No Backup Version Uploaded";
        //            }
        //        }
        //        else
        //        { lblResponse.Text = "No Backup Version Uploaded"; }
        //    }
        //    catch (Exception ex)
        //    {
        //        LogManager.LogErrorMessage(ex.ToString(), Convert.ToInt32(AdmConstants.MethodName.GWiz_UploadFiles_Upload_Click));
        //    }

        //}
    }
}