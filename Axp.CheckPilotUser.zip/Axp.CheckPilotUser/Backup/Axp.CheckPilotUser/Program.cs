﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Axp.CheckPilotUser.GDUService;
using System.Security.Principal;
using System.Configuration;
using System.IO;
using System.ServiceModel;

namespace Axp.CheckPilotUser
{
    class Program
    {
        static IGDUService _GDUServiceClient = null;
        static ChannelFactory<IGDUService> _serviceChanel = null;
        static string serviceStatus = string.Empty;

        private static string LowTraceInfo = "L";
        private static string HighTraceInfo = "H";
        private static string FilePath = string.Empty;
        private static string mainDirectory = string.Empty;

        [STAThread]
        static void Main(string[] args)
        {
            DeleteFile();
            string App_Name = string.Empty;
            string App_Version = string.Empty;
            string WCF_URL = string.Empty;
            string App_CodeBase = string.Empty;

            string result = string.Empty;
            try
            {
                LogtoEvent("CPU:: HL in Main method: Entered into Main method", HighTraceInfo);
                LogtoEvent("CPU:: HL in Main method: Calling DeleteFile method", HighTraceInfo);
                LogtoEvent("CPU:: LL in Step 0.1 Main method: Calling DeleteFile method", LowTraceInfo);

                LogtoEvent("CPU:: LL Step 1 on Main method : Capturing the todays date time**************************" + System.DateTime.Now, LowTraceInfo);

                //LogtoEvent("**************************" + System.DateTime.Now);

                //Console.SetWindowSize(1, 1);                
                LogtoEvent("CPU:: LL Step 2 on Main method : Entering into Main method", LowTraceInfo);

                LogtoEvent("CPU:: LL Step 3 on Main method: Argument Length=" + args.Length + System.Environment.NewLine, LowTraceInfo);
                for (int i = 0; i < args.Length; i++)
                {
                    if (i == 0)
                        App_Name = args[0].ToString().Replace("$", " ");
                    LogtoEvent("CPU:: LL Step 3a on Main method: App_Name=" + args[0].ToString() + System.Environment.NewLine, LowTraceInfo);
                    if (i == 1)
                        App_Version = args[1].ToString();
                    LogtoEvent("CPU:: LL Step 3b on Main method: App_Version=" + args[1].ToString() + System.Environment.NewLine, LowTraceInfo);
                    if (i == 2)
                        WCF_URL = args[2].ToString();
                    LogtoEvent("CPU:: LL Step 3c on Main method: WCF_URL=" + args[2].ToString() + System.Environment.NewLine, LowTraceInfo);
                    if (i == 3)
                        App_CodeBase = args[3].ToString().Replace("$", " "); //added on 24/July/2013 to handle case where the path contains space - Yogesh(market release)
                    LogtoEvent("CPU:: LL Step 3d on Main method: App_CodeBase=" + args[3].ToString() + System.Environment.NewLine, LowTraceInfo);
                }

                LogtoEvent("CPU:: LL Step 4 on Main method: Calling InitialiseWCFClient method " + System.Environment.NewLine, LowTraceInfo);
                InitialiseWCFClient(WCF_URL);
                if (serviceStatus.Contains("ServiceException"))
                {
                    if (ConfigurationSettings.AppSettings["AppUpdateIndicator"].ToString() == "Y")
                    {
                        LogtoEvent("CPU:: LL Step 5 on Main method: In Service Exception", LowTraceInfo);
                        //LogtoEvent("In Service Exception");
                        LogtoEvent("CPU:: LL Step 6 on Main method: App_Name1 in If condition is: " + App_Name, LowTraceInfo);
                        //LogtoEvent("App_Name1: " + App_Name);
                        LogtoEvent("CPU:: LL Step 7 on Main method: App_Version1 in If condition is: " + App_Version, LowTraceInfo);
                        //LogtoEvent("App_Version1: " + App_Version);
                        LogtoEvent("CPU:: LL Step 8 on Main method: WCF Service URL1 in If condition is: " + WCF_URL, LowTraceInfo);
                        //LogtoEvent("WCF Service URL1: " + WCF_URL);
                        Console.Write("Prod");
                    }
                    else
                    {
                        Console.WriteLine("Exception");
                    }
                }

                else
                {
                    LogtoEvent("CPU:: LL Step 9 on Main method: App_Name in Else condition is: " + App_Name, LowTraceInfo);
                    //LogtoEvent("App_Name: " + App_Name);
                    LogtoEvent("CPU:: LL Step 10 on Main method: App_Version in Else condition is: " + App_Version, LowTraceInfo);
                    //LogtoEvent("App_Version: " + App_Version);
                    LogtoEvent("CPU:: LL Step 11 on Main method: WCF Service URL in Else condition is: " + WCF_URL, LowTraceInfo);
                    //LogtoEvent("WCF Service URL: " + WCF_URL);
                    LogtoEvent("CPU:: LL Step 12 on Main method: Make Object" + System.Environment.NewLine, LowTraceInfo);
                    //LogtoEvent("Make Object");
                    //StandardResponse std;
                    ManupulateResponse response;
                    //GDUServiceClient gduApp = new GDUServiceClient();
                    PilotAppRepQuery pilotAppQuery = new PilotAppRepQuery();
                    PilotAppUploadRepRequest request = new PilotAppUploadRepRequest();

                    LogtoEvent("CPU:: LL Step 13 on Main method: Check Pilot App User" + System.Environment.NewLine, LowTraceInfo);
                    //LogtoEvent("Check Pilot App User Step 1");
                    //pilotAppQuery.APP_NAME = App_Name;
                    //pilotAppQuery.Version = App_Version;
                    //LogtoEvent("Check Pilot App User Step 2");
                    //pilotAppQuery.AdsId = (WindowsIdentity.GetCurrent().Name.Substring(WindowsIdentity.GetCurrent().Name.LastIndexOf(@"\"))).Replace(@"\", "");
                    //LogtoEvent("pilotAppQuery.AdsId" + pilotAppQuery.AdsId);
                    //pilotAppQuery.MachineName = System.Net.Dns.GetHostName();
                    //LogtoEvent("pilotAppQuery.MachineName" + pilotAppQuery.MachineName);
                    //pilotAppQuery.OfficeId = System.Net.Dns.GetHostName().ToString().Substring(0, 3);
                    //LogtoEvent("pilotAppQuery.OfficeId" + pilotAppQuery.OfficeId);
                    //std = gduApp.CheckPilotAppUser(pilotAppQuery);

                    request.PopulateRequest = new PilotAppRepQuery();

                    request.PopulateRequest.APP_NAME = App_Name;
                    request.PopulateRequest.Version = App_Version;
                    request.PopulateRequest.AdsId = (WindowsIdentity.GetCurrent().Name.Substring(WindowsIdentity.GetCurrent().Name.LastIndexOf(@"\"))).Replace(@"\", "");
                    request.PopulateRequest.MachineName = System.Net.Dns.GetHostName();
                    request.PopulateRequest.OfficeId = System.Net.Dns.GetHostName().ToString().Substring(0, 3);

                    string ss1 = App_CodeBase.Substring(0, App_CodeBase.LastIndexOf('/'));
                    int aa = App_CodeBase.IndexOf("DeployedApplication/");
                    string str2 = ss1.Substring(aa).Substring(20);
                    request.PopulateRequest.AppCodeBase = str2;

                    response = _GDUServiceClient.CheckPilotAppUser(request);

                    LogtoEvent("CPU:: LL Step 14 on Main method: Status" + response.Status.ResponseCodeStatus.ToString(), LowTraceInfo);
                    //LogtoEvent("Status" + response.Status.ResponseCodeStatus.ToString());

                    if (response.Status.ResponseCodeStatus.ToString() == "Success")
                        Console.Write("Prod");
                    else
                        Console.Write(response.Status.ResponseMessage.ToString());
                }

            }
            catch (Exception ex)
            {
                LogtoEvent("CPU:: HL Step 2 in Main method: In Service Exception", HighTraceInfo);
                //LogtoEvent("In Service Exception");
                LogtoEvent("CPU:: HL Step 3 in Main method: No Service Exist", HighTraceInfo);
                //LogtoEvent("No Service Exist");
                LogtoEvent("CPU:: HL Step 4 in Main method: App_Name Catch 1=" + App_Name, HighTraceInfo);
                LogtoEvent("CPU:: LL in Main method: App_Name Catch 1=" + App_Name, LowTraceInfo);
                //LogtoEvent("App_Name Catch 1=" + App_Name);
                if (ConfigurationSettings.AppSettings["AppUpdateIndicator"].ToString() == "Y")
                {
                    LogtoEvent("CPU:: HL Step 5 in Main method: Y Indicator=" + App_Name, HighTraceInfo);
                    LogtoEvent("CPU:: LL in Main method: Y Indicator=" + App_Name, LowTraceInfo);
                    //LogtoEvent("Y Indicator=" + App_Name);
                    LogtoEvent("CPU:: HL Step 6 in Main method: App_Name2: " + App_Name, HighTraceInfo);
                    LogtoEvent("CPU:: LL in Main method: App_Name2: " + App_Name, LowTraceInfo);
                    //LogtoEvent("App_Name2: " + App_Name);
                    LogtoEvent("CPU:: HL Step 7 in Main method: App_Version2: " + App_Version, HighTraceInfo);
                    LogtoEvent("CPU:: LL in Main method: App_Version2: " + App_Version, LowTraceInfo);
                    //LogtoEvent("App_Version2: " + App_Version);
                    LogtoEvent("CPU:: HL Step 8 in Main method: WCF Service URL2: " + WCF_URL, HighTraceInfo);
                    LogtoEvent("CPU:: LL in Main method: WCF Service URL2: " + WCF_URL, LowTraceInfo);
                    //LogtoEvent("WCF Service URL2: " + WCF_URL);
                    Console.Write("Prod");
                }
                else
                {
                    LogtoEvent("CPU:: HL Step 9 in Main method: N Indicator: = " + App_Name, HighTraceInfo);
                    LogtoEvent("CPU:: LL in Main method: N Indicator: = " + App_Name, LowTraceInfo);
                    //LogtoEvent("N Indicator=" + App_Name);
                    LogtoEvent("CPU:: HL Step 10 in Main method: Exception is: = " + ex.ToString(), HighTraceInfo);
                    LogtoEvent("CPU:: LL in Main method: Exception is: = " + ex.ToString(), LowTraceInfo);
                    //LogtoEvent(ex.ToString());
                    Console.WriteLine("Exception");
                }

            }
        }

        //private static void LogtoEvent(string ex)
        //{
        //    try
        //    {
        //        string TraceInfo = ConfigurationSettings.AppSettings["AxpCheckUserTraceInfo"].ToString();
        //        if (TraceInfo == "True")
        //        {
        //            string TraceFile = Path.GetFullPath(ConfigurationSettings.AppSettings["AxpCheckUserTraceFile"].ToString());
        //            FileStream fs = null;
        //            if (!File.Exists(TraceFile))
        //            {
        //                using (fs = File.Create(TraceFile))
        //                {

        //                }
        //            }
        //            if (File.Exists(TraceFile))
        //            {
        //                StringBuilder sb = new StringBuilder();
        //                StreamReader sr = new StreamReader(TraceFile);
        //                {
        //                    sb.Append(sr.ReadToEnd());
        //                    sb.AppendLine();
        //                }
        //                sr.Close();
        //                TextWriter tw = new StreamWriter(TraceFile);
        //                sb.AppendLine(ex.ToString());
        //                tw.WriteLine(sb.ToString());
        //                tw.Close();
        //            }
        //        }
        //    }
        //    catch (Exception ex1)
        //    {
        //    }
        //}



        public static void InitialiseWCFClient(string service_URL)
        {
            try
            {
                LogtoEvent("CPU:: LL Step 4a in InitialiseWCFClient method: URL From AMEX " + service_URL, LowTraceInfo);
                //LogtoEvent("URL From AMEX " + service_URL);
                BasicHttpBinding esBinding = new BasicHttpBinding();
                Int32 MaxSize = Convert.ToInt32(ConfigurationSettings.AppSettings["MaxSize"]);
                string timeout = ConfigurationSettings.AppSettings["TimeOut"].ToString();

                string url = ConfigurationSettings.AppSettings["WCFServiceURL"].ToString();
                LogtoEvent("CPU:: LL Step 4b in InitialiseWCFClient method: URL From CheckPilot " + url, LowTraceInfo);
                //LogtoEvent("URL From CheckPilot " + url);
                string server = service_URL;
                url = url.Remove(0, url.IndexOf(":") + 1);
                url = server + url.Remove(0, url.IndexOf(":"));
                LogtoEvent("CPU:: LL Step 4c in InitialiseWCFClient method: New URL " + url, LowTraceInfo);
                //LogtoEvent("New URL " + url);
                EndpointAddress esEndpoint = new EndpointAddress(url);
                TimeSpan esSendTimeout;
                TimeSpan.TryParse(timeout, out esSendTimeout);
                esBinding.SendTimeout = esSendTimeout;
                esBinding.Security.Mode = BasicHttpSecurityMode.TransportCredentialOnly;
                esBinding.MaxBufferSize = MaxSize;
                esBinding.MaxBufferPoolSize = MaxSize;
                esBinding.MaxReceivedMessageSize = MaxSize;
                esBinding.ReaderQuotas.MaxStringContentLength = MaxSize;
                _serviceChanel = new ChannelFactory<IGDUService>(esBinding, esEndpoint);
                _GDUServiceClient = _serviceChanel.CreateChannel();
            }
            catch (Exception ex)
            {
                LogtoEvent("CPU:: LL Step 4d in InitialiseWCFClient method: Exception Now using Config URL ", LowTraceInfo);
                //LogtoEvent("Exception Now using Config URL ");
                if (ConfigurationSettings.AppSettings["AppUpdateIndicator"].ToString() == "Y")
                {
                    //LogtoEvent("TravelSuite indicator Y ");
                    LogtoEvent("CPU:: LL Step 4e in InitialiseWCFClient method: TravelSuite indicator Y ", LowTraceInfo);
                    serviceStatus = "ServiceException";
                    LogtoEvent("CPU:: HL Step 1 in InitialiseWCFClient method: In InitialiseWCFClient, Exception= :" + ex.ToString(), HighTraceInfo);
                    //BasicHttpBinding esBinding = new BasicHttpBinding();
                    //Int32 MaxSizeT = Convert.ToInt32(ConfigurationSettings.AppSettings["MaxSize"]);
                    //string timeoutT = ConfigurationSettings.AppSettings["TimeOut"].ToString();
                    //string urlT = ConfigurationSettings.AppSettings["WCFServiceURL"].ToString();
                    //LogtoEvent("Exception And TravelSuite Ind Find T: " + urlT);

                    //EndpointAddress esEndpoint = new EndpointAddress(urlT);
                    //TimeSpan esSendTimeout;
                    //TimeSpan.TryParse(timeoutT, out esSendTimeout);
                    //esBinding.SendTimeout = esSendTimeout;
                    //esBinding.Security.Mode = BasicHttpSecurityMode.TransportCredentialOnly;
                    //esBinding.MaxBufferSize = MaxSizeT;
                    //esBinding.MaxBufferPoolSize = MaxSizeT;
                    //esBinding.MaxReceivedMessageSize = MaxSizeT;
                    //esBinding.ReaderQuotas.MaxStringContentLength = MaxSizeT;
                    //_serviceChanel = new ChannelFactory<IGDUService>(esBinding, esEndpoint);
                    //_GDUServiceClient = _serviceChanel.CreateChannel();
                }
            }
        }


        private static void DeleteFile()
        {
            try
            {
                LogtoEvent("CPU: HL in DeleteFile method: Entered into DeleteFile method", HighTraceInfo);
                LogtoEvent("CPU: LL Step 0.2 in DeleteFile method: Entered into DeleteFile method", LowTraceInfo);
                mainDirectory = Path.GetDirectoryName(System.Reflection.Assembly.GetEntryAssembly().Location);
                //string TraceFile = Path.GetFullPath(ConfigurationSettings.AppSettings["AxpCheckPilotUserLowLevelTraceFile"].ToString());
                string LowTraceFileName = ConfigurationSettings.AppSettings["AxpCheckPilotUserLowLevelTraceFileName"].ToString();
                string HighTraceFileName = ConfigurationSettings.AppSettings["AxpCheckPilotUserHighLevelTraceFileName"].ToString();
                string HLDuration = ConfigurationManager.AppSettings["HLDuration"];
                string LLDuration = ConfigurationManager.AppSettings["LLDuration"];
                foreach (string file in System.IO.Directory.GetFiles(mainDirectory, "*.txt"))
                {
                    string contents = file.ToString();
                    if (contents.Contains(LowTraceFileName))
                    {
                        FileInfo fi = new FileInfo(file);
                        TimeSpan ts = DateTime.Now.Subtract(fi.LastWriteTime);
                        LogtoEvent("PO: HL in DeleteFile method: File name is" + fi.Name.ToString(), HighTraceInfo);
                        LogtoEvent("PO: HL in DeleteFile method: File Creation time" + fi.LastWriteTime.ToString(), HighTraceInfo);
                        LogtoEvent("PO: HL in DeleteFile method: TimeSpan is" + ts.ToString(), HighTraceInfo);
                        if (ts.TotalDays > Convert.ToInt32(LLDuration))
                        {
                            double diff = ts.TotalDays - Convert.ToInt32(LLDuration);
                            LogtoEvent("PO: HL in DeleteFile method: Time difference " + diff.ToString(), HighTraceInfo);
                            fi.Delete();
                            LogtoEvent("PO: Low level file deleted ", HighTraceInfo);
                        }
                    }

                    if (contents.Contains(HighTraceFileName))
                    {
                        FileInfo fi = new FileInfo(file);
                        TimeSpan ts = DateTime.Now.Subtract(fi.LastWriteTime);
                        LogtoEvent("PO: HL in DeleteFile method: File name is" + fi.Name.ToString(), HighTraceInfo);
                        LogtoEvent("PO: HL in DeleteFile method: File Creation time" + fi.LastWriteTime.ToString(), HighTraceInfo);
                        LogtoEvent("PO: HL in DeleteFile method: TimeSpan is" + ts.ToString(), HighTraceInfo);
                        if (ts.TotalDays > Convert.ToInt32(HLDuration))
                        {
                            double diff1 = ts.TotalDays - Convert.ToInt32(HLDuration);
                            LogtoEvent("PO: HL in DeleteFile method: Time difference " + diff1.ToString(), HighTraceInfo);
                            fi.Delete();
                            LogtoEvent("PO: High level file deleted ", HighTraceInfo);
                        }
                    }
                }

            }

            catch (Exception ex2)
            {

            }


        }


        private static void LogtoEvent(string ex, string traceinfotype)
        {
            try
            {
                mainDirectory = Path.GetDirectoryName(System.Reflection.Assembly.GetEntryAssembly().Location);
                string LowTraceInfo = ConfigurationSettings.AppSettings["AxpCheckPilotUserLowLevelTraceInfo"].ToString();
                string HighTraceInfo = ConfigurationSettings.AppSettings["AxpCheckPilotUserHighLevelTraceInfo"].ToString();

                if (LowTraceInfo == "True" && traceinfotype == "L")
                {
                    //string TraceFile = Path.GetFullPath(ConfigurationSettings.AppSettings["AxpCheckPilotUserLowLevelTraceFile"].ToString());
                    string LowLevelTraceFileName = ConfigurationSettings.AppSettings["AxpCheckPilotUserLowLevelTraceFileName"].ToString();
                    string FileNameSaved = String.Format("{1}_{0:MM_dd_yyyy}.txt", DateTime.Now, LowLevelTraceFileName);
                    FilePath = Path.Combine(mainDirectory, FileNameSaved);

                    FileStream fs = null;
                    if (!File.Exists(FilePath))
                    {
                        using (fs = File.Create(FilePath))
                        {

                        }
                    }
                    if (File.Exists(FilePath))
                    {
                        StringBuilder sb = new StringBuilder();
                        StreamReader sr = new StreamReader(FilePath);
                        {
                            sb.Append(sr.ReadToEnd());
                            sb.AppendLine();
                        }
                        sr.Close();
                        TextWriter tw = new StreamWriter(FilePath);
                        sb.AppendLine(ex.ToString());
                        tw.WriteLine(sb.ToString());
                        tw.Close();
                    }
                }
                if (HighTraceInfo == "True" && traceinfotype == "H")
                {
                    //string TraceFile = Path.GetFullPath(ConfigurationSettings.AppSettings["AxpCheckPilotUserLowLevelTraceFile"].ToString());
                    string HighLevelTraceFileName = ConfigurationSettings.AppSettings["AxpCheckPilotUserHighLevelTraceFileName"].ToString();
                    string FileNameSaved = String.Format("{1}_{0:MM_dd_yyyy}.txt", DateTime.Now, HighLevelTraceFileName);
                    FilePath = Path.Combine(mainDirectory, FileNameSaved);

                    FileStream fs = null;
                    if (!File.Exists(FilePath))
                    {
                        using (fs = File.Create(FilePath))
                        {

                        }
                    }
                    if (File.Exists(FilePath))
                    {
                        StringBuilder sb = new StringBuilder();
                        StreamReader sr = new StreamReader(FilePath);
                        {
                            sb.Append(sr.ReadToEnd());
                            sb.AppendLine();
                        }
                        sr.Close();
                        TextWriter tw = new StreamWriter(FilePath);
                        sb.AppendLine(ex.ToString());
                        tw.WriteLine(sb.ToString());
                        tw.Close();
                    }
                }
                
            }

            catch (Exception ex1)
            {

            }
        }

    }
}
