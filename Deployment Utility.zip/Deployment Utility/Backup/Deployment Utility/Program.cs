﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;
using System.Net;
using Axp.GDU.Deployment_Utility.GDUService;
using System.Security.Principal;
using System.IO;
using System.Data;
using System.Configuration;
using System.DirectoryServices;
using System.Globalization;
using System.Threading;

namespace Axp.GDU.Deployment_Utility
{
    public class Program
    {
        static ClientDeploymentInfo info;
        private static string LowTraceInfo = "L";
        private static string HighTraceInfo = "H";
        private static string FilePath = string.Empty;
        private static string mainDirectory = string.Empty;
        private static string App_CodeBase = string.Empty;

        public static void Main(string[] args)
        {
            LogtoEvent("DU:: HL in Main method: Entered into Main method", HighTraceInfo);
            LogtoEvent("DU:: HL in Main method: Entered into DeleteFile method", HighTraceInfo);
            LogtoEvent("DU:: LL Step 0.1 in Main method : Entered into DeleteFile method", LowTraceInfo);
            DeleteFile();

            //LL Step 75 on AddUser method: In AddUser method, userDetails.Mode=
            LogtoEvent("DU:: LL Step 1 on Main method : Capturing the todays date time**************************" + System.DateTime.Now, LowTraceInfo);
            //LogtoEvent("=========" + System.DateTime.Now + "==============");
            LogtoEvent("DU:: LL Step 2 on Main method : Entering into Main method", LowTraceInfo);
            //LogtoEvent("Step 1: enter Deployment");
            string ClientExePath = string.Empty;
            string ClientExeVersion = string.Empty;
            string ServerExeVersion = string.Empty;
            string ClientExeName = string.Empty;

            try
            {
                StandardResponse std;
                GDUServiceClient gduApp = new GDUServiceClient();
                LogtoEvent("DU:: LL Step 3 on Main method : Entering into Deployment", LowTraceInfo);

                try
                {
                    LogtoEvent("DU:: LL Step 4 on Main method : Check User Exist", LowTraceInfo);
                    bool UserExists = CheckUserExists();
                    if (UserExists == false)
                    {
                        LogtoEvent("DU:: LL Step 8 on Main method: Add User if user doesn't exist", LowTraceInfo);
                        //LogtoEvent("Add User Step 3a ");
                        AddUser();
                    }
                }
                catch (Exception ex)
                {
                    LogtoEvent("DU:: HL Step 2 on Main method: Add User Step 4a Exception" + ex.ToString(), HighTraceInfo);
                    LogtoEvent("DU:: LL on Main method: Add User Step 4a Exception" + ex.ToString(), LowTraceInfo);
                    //LogtoEvent("Add User Step 3a Exception " + ex.ToString());
                }
                LogtoEvent("DU:: LL Step 21 on Main method:" + System.Environment.NewLine, LowTraceInfo);
                //LogtoEvent("Step 4 " + System.Environment.NewLine);

                for (int i = 0; i < args.Length; i++)
                {
                    //Console.WriteLine("Argument[" + i + "] : " + args[i]);
                    LogtoEvent("DU:: LL Step 21a on Main method:" + "Argument[" + i + "] : " + args[i] + System.Environment.NewLine, LowTraceInfo);
                    //LogtoEvent("Step 4a " + "Argument[" + i + "] : " + args[i] + System.Environment.NewLine);
                }
                LogtoEvent("DU:: LL Step 22 on Main method: Argument Length=" + args.Length + System.Environment.NewLine, LowTraceInfo);
                //LogtoEvent("Step 5  Argument Length=" + args.Length + System.Environment.NewLine);
                for (int i = 0; i < args.Length; i++)
                {
                    if (i == 0)
                    {
                        ClientExePath = args[0].ToString().Replace("$", " ");
                        LogtoEvent("DU:: LL Step 22a on Main method: ClientExePath=" + args[0].ToString().Replace("$", " ") + System.Environment.NewLine, LowTraceInfo);
                        //LogtoEvent("Step 5a  ClientExePath=" + args[0].ToString().Replace("$", " ") + System.Environment.NewLine);
                    }
                    if (i == 1)
                    {
                        ClientExeVersion = args[1].ToString();
                        LogtoEvent("DU:: LL Step 22b on Main method: ClientExeVersion=" + args[1].ToString() + System.Environment.NewLine, LowTraceInfo);
                        //LogtoEvent("Step 5b  ClientExeVersion=" + args[1].ToString() + System.Environment.NewLine);
                    }
                    if (i == 2)
                    {
                        ServerExeVersion = args[2].ToString();
                        LogtoEvent("DU:: LL Step 22c on Main method: ServerExeVersion=" + args[2].ToString() + System.Environment.NewLine, LowTraceInfo);
                        //LogtoEvent("Step 5c  ServerExeVersion=" + args[2].ToString() + System.Environment.NewLine);
                    }
                    if (i == 3)
                    {
                        ClientExeName = args[3].ToString().Replace("$", " ");
                        LogtoEvent("DU:: LL Step 22d on Main method: ClientExeName=" + args[3].ToString().Replace("$", " ") + System.Environment.NewLine, LowTraceInfo);
                        //LogtoEvent("Step 5d  ClientExeName=" + args[3].ToString().Replace("$", " ") + System.Environment.NewLine);
                    }

                    if (i == 4)
                        App_CodeBase = args[4].ToString().Replace("$", " ");
                    LogtoEvent("DU:: LL Step 22d1 on Main method: App_CodeBase=" + args[4].ToString().Replace("$", " ") + System.Environment.NewLine, LowTraceInfo);
                }

                //Console.WriteLine();
                //Console.WriteLine("ClientExePath= " + ClientExePath);
                //Console.WriteLine("ClientExeVersion= " + ClientExeVersion);
                //Console.WriteLine("ServerExeVersion= " + ServerExeVersion);
                //Console.WriteLine("ClientExeName= " + ClientExeName);
                //Console.WriteLine();

                //Console.WriteLine("Executing Process...");
                LogtoEvent("DU:: LL Step 23 on Main method: Calling PopulateRequest method from Main method" + System.Environment.NewLine, LowTraceInfo);
                //LogtoEvent("Step 6 " + System.Environment.NewLine);
                PopulateRequest(ClientExePath, ClientExeVersion, ServerExeVersion, ClientExeName, App_CodeBase);
                LogtoEvent("DU:: LL Step 24 on Main method: Calling ClientDeploymentDetailResponse using GDU service from Main method" + System.Environment.NewLine, LowTraceInfo);
                //LogtoEvent("Step 7 " + System.Environment.NewLine);
                std = gduApp.ClientDeploymentDetailResponse(info);
                LogtoEvent("DU:: LL Step 25 on Main method:" + System.Environment.NewLine + std.ResponseCodeStatus, LowTraceInfo);
                //LogtoEvent("Step 8 " + System.Environment.NewLine);
                //Console.WriteLine("Process Executed...");
                //Console.WriteLine(std.ResponseCodeStatus.ToString());
                LogtoEvent("DU:: LL Step 26 on Main method:" + System.Environment.NewLine, LowTraceInfo);
                //LogtoEvent("Step 9 " + System.Environment.NewLine);
                Environment.Exit(0);
            }
            catch (Exception ex)
            {
                LogtoEvent("DU:: HL Step 4 on Main method: Exception:#" + ex.ToString(), HighTraceInfo);
                LogtoEvent("DU:: LL on Main method: Exception:#" + ex.ToString(), LowTraceInfo);
                //LogtoEvent("Exception:# " + ex.ToString());
            }
        }
        //private static void LogtoEvent(string ex)
        //{
        //    try
        //    {
        //        string TraceInfo = ConfigurationSettings.AppSettings["AxpGDUDeploymentTraceInfo"].ToString();
        //        if (TraceInfo == "True")
        //        {
        //            string TraceFile = Path.GetFullPath(ConfigurationSettings.AppSettings["AxpGDUDeploymentTraceFile"].ToString());
        //            FileStream fs = null;
        //            if (!File.Exists(TraceFile))
        //            {
        //                using (fs = File.Create(TraceFile))
        //                {

        //                }
        //            }
        //            if (File.Exists(TraceFile))
        //            {
        //                StringBuilder sb = new StringBuilder();
        //                StreamReader sr = new StreamReader(TraceFile);
        //                {
        //                    sb.Append(sr.ReadToEnd());
        //                    sb.AppendLine();
        //                }
        //                sr.Close();
        //                TextWriter tw = new StreamWriter(TraceFile);
        //                sb.AppendLine(ex.ToString());
        //                tw.WriteLine(sb.ToString());
        //                tw.Close();
        //            }
        //        }
        //    }
        //    catch (Exception ex1)
        //    { 
        //    }
        //}



        private static void LogtoEvent(string ex, string traceinfotype)
        {
            try
            {
                mainDirectory = Path.GetDirectoryName(System.Reflection.Assembly.GetEntryAssembly().Location);
                string LowTraceInfo = ConfigurationSettings.AppSettings["AxpDeploymentUtilityLowLevelTraceInfo"].ToString();
                string HighTraceInfo = ConfigurationSettings.AppSettings["AxpDeploymentUtilityHighLevelTraceInfo"].ToString();


                if (LowTraceInfo == "True" && traceinfotype == "L")
                {
                    //string TraceFile = Path.GetFullPath(ConfigurationSettings.AppSettings["AxpDUTraceFilePath"].ToString());
                    string LowLevelTraceFileName = ConfigurationSettings.AppSettings["AxpDeploymentUtilityLowLevelTraceFileName"].ToString();
                    string FileNameSaved = String.Format("{1}_{0:MM_dd_yyyy}.txt", DateTime.Now, LowLevelTraceFileName);
                    //FilePath = Path.Combine(TraceFile, FileNameSaved);
                    FilePath = Path.Combine(mainDirectory, FileNameSaved);

                    FileStream fs = null;
                    if (!File.Exists(FilePath))
                    {
                        using (fs = File.Create(FilePath))
                        {

                        }
                    }
                    if (File.Exists(FilePath))
                    {
                        StringBuilder sb = new StringBuilder();
                        StreamReader sr = new StreamReader(FilePath);
                        {
                            sb.Append(sr.ReadToEnd());
                            sb.AppendLine();
                        }
                        sr.Close();
                        TextWriter tw = new StreamWriter(FilePath);
                        sb.AppendLine(ex.ToString());
                        tw.WriteLine(sb.ToString());
                        tw.Close();
                    }
                }
                if (HighTraceInfo == "True" && traceinfotype == "H")
                {
                    //string TraceFile = Path.GetFullPath(ConfigurationSettings.AppSettings["AxpDUTraceFilePath"].ToString());
                    string HighLevelTraceFileName = ConfigurationSettings.AppSettings["AxpDeploymentUtilityHighLevelTraceFileName"].ToString();
                    string FileNameSaved = String.Format("{1}_{0:MM_dd_yyyy}.txt", DateTime.Now, HighLevelTraceFileName);
                    //FilePath = Path.Combine(TraceFile, FileNameSaved);
                    FilePath = Path.Combine(mainDirectory, FileNameSaved);

                    FileStream fs = null;
                    if (!File.Exists(FilePath))
                    {
                        using (fs = File.Create(FilePath))
                        {

                        }
                    }
                    if (File.Exists(FilePath))
                    {
                        StringBuilder sb = new StringBuilder();
                        StreamReader sr = new StreamReader(FilePath);
                        {
                            sb.Append(sr.ReadToEnd());
                            sb.AppendLine();
                        }
                        sr.Close();
                        TextWriter tw = new StreamWriter(FilePath);
                        sb.AppendLine(ex.ToString());
                        tw.WriteLine(sb.ToString());
                        tw.Close();
                    }
                }
                
            }

            catch (Exception ex1)
            {

            }
        }

        private static void PopulateRequest(string ClientExePath, string ClientExeVersion, string ServerExeVersion, string ClientExeName, string App_CodeBase)
        {
            CultureInfo cul_Info = new CultureInfo("en-US");
            Thread.CurrentThread.CurrentCulture = cul_Info;

            info = new ClientDeploymentInfo();
            info.ApplicationPath = ClientExePath;
            info.ComputerName = System.Net.Dns.GetHostName();
            info.ExeTimeStamp = GetEXETimeStamp(ClientExePath);
            info.ExeVersionNo = ClientExeVersion;
            info.IPAddress = GetIP();
            info.LatestVersionNo = ServerExeVersion;
            info.NACId = (WindowsIdentity.GetCurrent().Name.Substring(WindowsIdentity.GetCurrent().Name.LastIndexOf(@"\"))).Replace(@"\", "");
            info.TimeStamp = DateTime.Now;
            info.UserId = (WindowsIdentity.GetCurrent().Name.Substring(WindowsIdentity.GetCurrent().Name.LastIndexOf(@"\"))).Replace(@"\", "");
            info.App_ID = ClientExeName;

            string ss1 = App_CodeBase.Substring(0, App_CodeBase.LastIndexOf('/'));
            int aa = App_CodeBase.IndexOf("DeployedApplication/");
            string str2 = ss1.Substring(aa).Substring(20);

            info.App_Name = str2;

            try
            {
                LogtoEvent("DU: HL on PopulateRequest method: Entered into PopulateRequest method", HighTraceInfo);
                LogtoEvent("DU:: LL Step 23a on PopulateRequest method: Entered into PopulateRequest method" + System.Environment.NewLine, LowTraceInfo);

                LogtoEvent("DU:: LL Step 23b on PopulateRequest method: Step 23b info.ApplicationPath= " + info.ApplicationPath + System.Environment.NewLine, LowTraceInfo);
                //LogtoEvent("Step 6a info.ApplicationPath= " + info.ApplicationPath + System.Environment.NewLine);
                LogtoEvent("DU:: LL Step 23c on PopulateRequest method: Step 23c info.ComputerName= " + info.ComputerName + System.Environment.NewLine, LowTraceInfo);
                //LogtoEvent("Step 6b info.ComputerName= " + info.ComputerName + System.Environment.NewLine);
                LogtoEvent("DU:: LL Step 23d on PopulateRequest method: Step 23d info.ExeTimeStamp= " + info.ExeTimeStamp + System.Environment.NewLine, LowTraceInfo);
                //LogtoEvent("Step 6c info.ExeTimeStamp= " + info.ExeTimeStamp + System.Environment.NewLine);
                LogtoEvent("DU:: LL Step 23e on PopulateRequest method: Step 23e info.ExeVersionNo= " + info.ExeVersionNo + System.Environment.NewLine, LowTraceInfo);
                //LogtoEvent("Step 6d info.ExeVersionNo= " + info.ExeVersionNo + System.Environment.NewLine);
                LogtoEvent("DU:: LL Step 23f on PopulateRequest method: Step 23f info.IPAddress= " + info.IPAddress + System.Environment.NewLine, LowTraceInfo);
                //LogtoEvent("Step 6e info.IPAddress= " + info.IPAddress + System.Environment.NewLine);
                LogtoEvent("DU:: LL Step 23g on PopulateRequest method: Step 23g info.LatestVersionNo= " + info.LatestVersionNo + System.Environment.NewLine, LowTraceInfo);
                //LogtoEvent("Step 6f info.LatestVersionNo= " + info.LatestVersionNo + System.Environment.NewLine);
                LogtoEvent("DU:: LL Step 23h on PopulateRequest method: Step 23h info.NACId= " + info.NACId + System.Environment.NewLine, LowTraceInfo);
                //LogtoEvent("Step 6g info.NACId= " + info.NACId + System.Environment.NewLine);
                LogtoEvent("DU:: LL Step 23i on PopulateRequest method: Step 23i info.TimeStamp= " + info.TimeStamp + System.Environment.NewLine, LowTraceInfo);
                //LogtoEvent("Step 6h info.TimeStamp= " + info.TimeStamp + System.Environment.NewLine);
                LogtoEvent("DU:: LL Step 23j on PopulateRequest method: Step 23j info.UserId= " + info.UserId + System.Environment.NewLine, LowTraceInfo);
                //LogtoEvent("Step 6i info.UserId= " + info.UserId + System.Environment.NewLine);
                LogtoEvent("DU:: LL Step 23k on PopulateRequest method: Step 23k info.App_ID= " + info.App_ID + System.Environment.NewLine, LowTraceInfo);
                //LogtoEvent("Step 6k info.App_ID= " + info.App_ID + System.Environment.NewLine);
            }
            catch (Exception ex)
            {
                LogtoEvent("DU:: HL Step 5 on PopulateRequest method: Exception is " + ex.ToString(), HighTraceInfo);
                LogtoEvent("DU:: LL on PopulateRequest method: Exception is " + ex.ToString(), LowTraceInfo);
            }
        }

        private static DateTime GetEXETimeStamp(string exepath)
        {
            try
            {
                LogtoEvent("DU: HL on GetEXETimeStamp method: Entered into GetEXETimeStamp method", HighTraceInfo);
                LogtoEvent("DU:: LL Step 27 on GetEXETimeStamp method:" + System.Environment.NewLine, LowTraceInfo);
                DateTime lastWriteTimeUtc;
                if (System.IO.File.Exists(exepath))
                    lastWriteTimeUtc = File.GetLastWriteTimeUtc(exepath);
                else
                    lastWriteTimeUtc = System.DateTime.Now;
                return lastWriteTimeUtc;
            }
            catch (Exception ex)
            {
                LogtoEvent("DU:: HL Step 6 on PopulateRequest method: Exception is " + ex.ToString(), HighTraceInfo);
                LogtoEvent("DU:: LL on PopulateRequest method: Exception is " + ex.ToString(), LowTraceInfo);
                return Convert.ToDateTime(null);
            }
        }

        private static string GetIP()
        {
            //string strHostName = "";
            //strHostName = System.Net.Dns.GetHostName();
            //IPHostEntry ipEntry = System.Net.Dns.GetHostEntry(strHostName);
            //IPAddress[] addr = ipEntry.AddressList;
            //return addr[addr.Length - 1].ToString();

            string strHostName = "";
            string str = string.Empty;

            strHostName = System.Net.Dns.GetHostName();
            IPHostEntry ipEntry = System.Net.Dns.GetHostEntry(strHostName);
            IPAddress[] addr = ipEntry.AddressList;
            try
            {
                LogtoEvent("DU: HL on GetIP method: Entered into GetIP method", HighTraceInfo);
                LogtoEvent("DU:: LL Step 28 on GetIP() method: IP Address logic in GetIP() method", LowTraceInfo);
                for (int i = 0; i < addr.Length; i++)
                {
                    str = addr[i].ToString();
                    string[] words = str.Split('.');
                    if (words.Length == 4)
                    {
                        str = addr[i].ToString();
                        break;
                    }
                }

            }
            catch (Exception ex)
            {
                str = addr[addr.Length - 1].ToString();
                LogtoEvent("HL Step 7 on GetIP() method: Exception is  :" + ex.ToString(), HighTraceInfo);
                LogtoEvent("LL on GetIP() method: Exception is  :" + ex.ToString(), LowTraceInfo);
            }
            return str;
        }

        private static bool CheckUserExists()
        {
            try
            {
                LogtoEvent("DU: HL on CheckUserExists method: Entered into CheckUserExists method", HighTraceInfo);
                string userId = (WindowsIdentity.GetCurrent().Name.Substring(WindowsIdentity.GetCurrent().Name.LastIndexOf(@"\"))).Replace(@"\", "");
                LogtoEvent("DU:: LL Step 5 on CheckUserExists method: In CheckUserExists method, userId= " + userId, LowTraceInfo);
                //LogtoEvent("In CheckUserExists userId= " + userId);
                DataTable userDetail = GetUserDetails(null, userId, false);
                if (userDetail.Rows.Count > 0)
                {
                    LogtoEvent("DU:: LL Step 6 on CheckUserExists method: In CheckUserExists userId Exist=", LowTraceInfo);
                    //LogtoEvent("In CheckUserExists userId Exist=");
                    return true;
                }
                LogtoEvent("DU:: LL Step 7 on CheckUserExists method: In CheckUserExists userId Not Exist=", LowTraceInfo);
                //LogtoEvent("In CheckUserExists userId Not Exist=");
                return false;
            }
            catch (Exception ex)
            {
                LogtoEvent("DU:: HL Step 1 on CheckUserExists method: Exception is  :" + ex.ToString(), HighTraceInfo);
                LogtoEvent("DU:: LL on CheckUserExists method: Exception is  :" + ex.ToString(), LowTraceInfo);
                return false;
            }
        }
        private static void AddUser()
        {
            try
            {
                LogtoEvent("DU: HL on AddUser method: Entered into AddUser method", HighTraceInfo);

                GDUServiceClient gduApp = new GDUServiceClient();
                UserQuery userDetails = new UserQuery();
                string userEmail = string.Empty;
                string userId = (WindowsIdentity.GetCurrent().Name.Substring(WindowsIdentity.GetCurrent().Name.LastIndexOf(@"\"))).Replace(@"\", "");
                string userName = WindowsIdentity.GetCurrent().Name;
                LogtoEvent("DU:: LL Step 9 on AddUser method: In AddUser method, userId= " + userId, LowTraceInfo);
                //LogtoEvent("In AddUser Step 1 userId= " + userId);
                LogtoEvent("DU:: LL Step 10 on AddUser method: In AddUser method, userName= " + userName, LowTraceInfo);
                //LogtoEvent("In AddUser Step 2 userName= " + userName);
                int len = userName.LastIndexOf(@"\");
                string principal = userName.Remove(0, len + 1);
                string filter = string.Format("(&(ObjectClass={0})(sAMAccountName={1}))", "person", principal);
                string domain = ConfigurationSettings.AppSettings["DomainName"].ToString();
                string[] properties = new string[] { "fullname" };
                DirectoryEntry adRoot = new DirectoryEntry("LDAP://" + domain, null, null, AuthenticationTypes.Secure);
                DirectorySearcher searcher = new DirectorySearcher(adRoot);
                searcher.SearchScope = SearchScope.Subtree;
                searcher.ReferralChasing = ReferralChasingOption.All;
                searcher.PropertiesToLoad.AddRange(properties);
                searcher.Filter = filter;
                SearchResult result = searcher.FindOne();
                DirectoryEntry directoryEntry = result.GetDirectoryEntry();
                string displayName = directoryEntry.Properties["displayName"][0].ToString();
                userEmail = directoryEntry.Properties["mail"][0].ToString();
                LogtoEvent("DU:: LL Step 11 on AddUser method: In AddUser method, displayName= " + displayName, LowTraceInfo);
                //LogtoEvent("In AddUser Step 3 displayName= " + displayName);
                LogtoEvent("DU:: LL Step 12 on AddUser method: In AddUser method, userEmail= " + userEmail, LowTraceInfo);
                // LogtoEvent("In AddUser Step 4 userEmail= " + userEmail);

                userDetails.UserId = userId;
                userDetails.UserName = displayName;
                userDetails.LanguageCode = "ENG";
                userDetails.UserRoleCode = "DC";
                userDetails.EmailAddress = userEmail;
                userDetails.ModifiedUserDate = DateTime.Now;
                userDetails.ModifiedUserID = userId;
                userDetails.Mode = "ADD";

                LogtoEvent("DU:: LL Step 13 on AddUser method: In AddUser method, userDetails.UserId= " + userDetails.UserId, LowTraceInfo);
                //LogtoEvent("In AddUser Step 5 userDetails.UserId= " + userDetails.UserId);
                LogtoEvent("DU:: LL Step 14 on AddUser method: In AddUser method, userDetails.UserName= " + userDetails.UserName, LowTraceInfo);
                //LogtoEvent("In AddUser Step 6 userDetails.UserName= " + userDetails.UserName);
                LogtoEvent("DU:: LL Step 15 on AddUser method: In AddUser method, userDetails.LanguageCode= " + userDetails.LanguageCode, LowTraceInfo);
                //LogtoEvent("In AddUser Step 7 userDetails.LanguageCode= " + userDetails.LanguageCode);
                LogtoEvent("DU:: LL Step 16 on AddUser method: In AddUser method, userDetails.UserRoleCode= " + userDetails.UserRoleCode, LowTraceInfo);
                //LogtoEvent("In AddUser Step 8 userDetails.UserRoleCode= " + userDetails.UserRoleCode);
                LogtoEvent("DU:: LL Step 17 on AddUser method: In AddUser method, userDetails.EmailAddress= " + userDetails.EmailAddress, LowTraceInfo);
                //LogtoEvent("In AddUser Step 9 userDetails.EmailAddress= " + userDetails.EmailAddress);
                LogtoEvent("DU:: LL Step 18 on AddUser method: In AddUser method, userDetails.ModifiedUserDate= " + userDetails.ModifiedUserDate, LowTraceInfo);
                //LogtoEvent("In AddUser Step 10 userDetails.ModifiedUserDate= " + userDetails.ModifiedUserDate);
                LogtoEvent("DU:: LL Step 19 on AddUser method: In AddUser method, userDetails.ModifiedUserID= " + userDetails.ModifiedUserID, LowTraceInfo);
                //LogtoEvent("In AddUser Step 11 userDetails.ModifiedUserID= " + userDetails.ModifiedUserID);
                LogtoEvent("DU:: LL Step 20 on AddUser method: In AddUser method, userDetails.Mode= " + userDetails.Mode, LowTraceInfo);
                //LogtoEvent("In AddUser Step 12 userDetails.Mode= " + userDetails.Mode);

                gduApp.ManageUsers(userDetails);
            }
            catch (Exception ex)
            {
                LogtoEvent("DU:: HL Step 3 on AddUser method: Exception is  :" + ex.ToString(), HighTraceInfo);
                LogtoEvent("DU:: LL on AddUser method: Exception is  :" + ex.ToString(), LowTraceInfo);
                //LogtoEvent("In AddUser  Exception= " + ex.ToString());
            }
        }
        public static DataTable GetUserDetails(string userName, string userId, bool isDeactive)
        {
            DataTable dtUser = new DataTable();
            UserDetails[] userDetails;
            DataRow drUserInfo;
            try
            {
                LogtoEvent("DU: HL on GetUserDetails method: Entered into GetUserDetails method", HighTraceInfo);
                GDUServiceClient gduApp = new GDUServiceClient();

                dtUser.Columns.Add("UserID", Type.GetType("System.String"));
                dtUser.Columns.Add("UserName", Type.GetType("System.String"));
                dtUser.Columns.Add("EmailAddress", Type.GetType("System.String"));
                dtUser.Columns.Add("Language", Type.GetType("System.String"));
                dtUser.Columns.Add("Role", Type.GetType("System.String"));
                dtUser.Columns.Add("LanguageCode", Type.GetType("System.String"));
                dtUser.Columns.Add("RoleCode", Type.GetType("System.String"));
                dtUser.Columns.Add("ModifiedDT", Type.GetType("System.DateTime"));
                dtUser.Columns.Add("DefaultClientID", Type.GetType("System.Int32"));
                UserQuery userQuery = new UserQuery();
                userQuery.UserId = userId;
                userQuery.UserName = userName;
                userQuery.IsDeactive = isDeactive;
                userDetails = gduApp.SearchUsers(userQuery);
                LogtoEvent("LL Step 29 on GetUserDetails method: In GetUserDetails method, filling the UserDetails[] from GDU Service", LowTraceInfo);

                for (int iCount = 0; iCount < userDetails.Length; iCount++)
                {
                    drUserInfo = dtUser.NewRow();
                    drUserInfo["UserID"] = userDetails[iCount].UserId;
                    drUserInfo["UserName"] = userDetails[iCount].UserName;
                    drUserInfo["EmailAddress"] = userDetails[iCount].EmailAddress;
                    drUserInfo["LanguageCode"] = userDetails[iCount].LanguageCode;
                    drUserInfo["Language"] = userDetails[iCount].Language;
                    drUserInfo["Role"] = userDetails[iCount].UserRole;
                    drUserInfo["RoleCode"] = userDetails[iCount].UserRoleCode;
                    drUserInfo["ModifiedDT"] = userDetails[iCount].ModifiedUserDate;
                    drUserInfo["DefaultClientID"] = userDetails[iCount].DefaultClientID;
                    dtUser.Rows.Add(drUserInfo);
                }
            }
            catch (Exception ex)
            {
                LogtoEvent("DU:: HL Step 8 on GetUserDetails method: In GetUserDetails  Exception= :" + ex.ToString(), HighTraceInfo);
                LogtoEvent("DU:: LL on GetUserDetails method: In GetUserDetails  Exception= :" + ex.ToString(), LowTraceInfo);
                //LogtoEvent("In GetUserDetails  Exception= " + ex.ToString());
            }
            return dtUser;
        }

        private static void DeleteFile()
        {
            LogtoEvent("DU: HL in DeleteFile method: Entered into DeleteFile method", HighTraceInfo);
            LogtoEvent("DU: LL Step 0.2 in DeleteFile method: Entered into DeleteFile method", LowTraceInfo);
            try
            {

                //string TraceFile = Path.GetFullPath(ConfigurationSettings.AppSettings["AxpDUTraceFilePath"].ToString());
                mainDirectory = Path.GetDirectoryName(System.Reflection.Assembly.GetEntryAssembly().Location);
                string LowTraceFileName = ConfigurationSettings.AppSettings["AxpDeploymentUtilityLowLevelTraceFileName"].ToString();
                string HighTraceFileName = ConfigurationSettings.AppSettings["AxpDeploymentUtilityHighLevelTraceFileName"].ToString();
                string HLDuration = ConfigurationManager.AppSettings["HLDuration"];
                string LLDuration = ConfigurationManager.AppSettings["LLDuration"];
                foreach (string file in System.IO.Directory.GetFiles(mainDirectory, "*.txt"))
                {
                    string contents = file.ToString();
                    if (contents.Contains(LowTraceFileName))
                    {
                        FileInfo fi = new FileInfo(file);
                        TimeSpan ts = DateTime.Now.Subtract(fi.LastWriteTime);
                        LogtoEvent("PO: HL in DeleteFile method: File name is" + fi.Name.ToString(), HighTraceInfo);
                        LogtoEvent("PO: HL in DeleteFile method: File Creation time" + fi.LastWriteTime.ToString(), HighTraceInfo);
                        LogtoEvent("PO: HL in DeleteFile method: TimeSpan is" + ts.ToString(), HighTraceInfo);
                        if (ts.TotalDays >= Convert.ToInt32(LLDuration))
                        {
                            double diff = ts.TotalDays - Convert.ToInt32(LLDuration);
                            LogtoEvent("PO: HL in DeleteFile method: Time difference " + diff.ToString(), HighTraceInfo);
                            fi.Delete();
                            LogtoEvent("PO: Low level file deleted ", HighTraceInfo);
                        }
                    }

                    if (contents.Contains(HighTraceFileName))
                    {
                        FileInfo fi = new FileInfo(file);
                        TimeSpan ts = DateTime.Now.Subtract(fi.LastWriteTime);
                        LogtoEvent("PO: HL in DeleteFile method: File name is" + fi.Name.ToString(), HighTraceInfo);
                        LogtoEvent("PO: HL in DeleteFile method: File Creation time" + fi.LastWriteTime.ToString(), HighTraceInfo);
                        LogtoEvent("PO: HL in DeleteFile method: TimeSpan is" + ts.ToString(), HighTraceInfo);
                        if (ts.TotalDays >= Convert.ToInt32(HLDuration))
                        {
                            double diff1 = ts.TotalDays - Convert.ToInt32(HLDuration);
                            LogtoEvent("PO: HL in DeleteFile method: Time difference " + diff1.ToString(), HighTraceInfo);
                            fi.Delete();
                            LogtoEvent("PO: High level file deleted ", HighTraceInfo);
                        }
                    }

                }


            }
            catch (Exception ex2)
            {

            }

        }








    }
}
