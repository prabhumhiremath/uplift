﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;
using Axp.GDU.Process.GDUService;
using System.Management;
using System.IO;
using System.Security.Principal;
using System.Net;
using System.Xml;
using System.Xml.XPath;
using System.Xml.Xsl;
using System.Xml.Linq;
using System.Configuration;
using System.DirectoryServices;
using System.Globalization;
using System.Threading;


namespace Axp.GDU.Process
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private Dictionary<string, string> objDictionary = new Dictionary<string, string>();
        private Dictionary<string, string> objTransIDDictionary = new Dictionary<string, string>();
        private static DataTable AppDetails = null;
        private static string appNames = string.Empty;
        StandardResponse std = new StandardResponse();
        GDUServiceClient gduApp = new GDUServiceClient();
        ClientUsageInfo _clientUsageInfo;
        ApplicationDetails[] objAppDetails;
        private bool IsChecked = false;
        private static string LowTraceInfo = "L";
        private static string HighTraceInfo = "H";
        private static string FilePath = string.Empty;
        //Market Release
        DataTable dtAppfIndicator = new DataTable();
        DataRow drAppfInfo;
        AppFocusIndicator[] AppFIndicator;
        private string HLAppFocusIndicator;
        private string LLAppFocusIndicator;
        private static string mainDirectory = string.Empty;
        private static StringBuilder LowTraceText;
        private static StringBuilder HighTraceText;

        public string ProcID
        {
            get;
            set;
        }

        public bool IsProcessOpen()
        {

            string ApplicationPath = string.Empty;
            string processname = string.Empty;

            foreach (var pair in objDictionary)
            {
                processname = pair.Key.ToString().Substring(pair.Key.ToString().LastIndexOf("~") + 1).ToLower();
                String processID = System.Diagnostics.Process.GetProcessesByName(processname)[0].Id.ToString();
                var searcher = new ManagementObjectSearcher(new WqlObjectQuery(String.Format("Select ExecutablePath from Win32_Process where ProcessID = {0}", processID)));
                ManagementObject managementObject = null;
                foreach (ManagementObject obj in searcher.Get())
                {
                    managementObject = obj;
                    break;
                }
                ApplicationPath = managementObject["ExecutablePath"].ToString();

                foreach (System.Diagnostics.Process clsProcess in System.Diagnostics.Process.GetProcesses())
                {

                    if (clsProcess.ProcessName.Contains(processname))
                    {

                        listBox1.Items.Add(processname + " Is Running" + DateTime.Now);
                        return true;
                    }

                }
            }
            listBox1.Items.Add(processname + " Is not Running" + DateTime.Now);
            return false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            IsProcessOpen();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            //LowTraceText = new StringBuilder();
            //HighTraceText = new StringBuilder();
            try
            {
               
                try
                {
                    //LogtoEvent("PI:LL Step 75 on timer1_Tick method:In Timer Tick", LowTraceInfo);
                    LowTraceText.AppendLine("PI:LL Step 75 on timer1_Tick method:In Timer Tick");
                    //LogtoEvent("In Timer Tick");
                    StartEvent();
                }
                catch (Exception ex)
                {
                    //LogtoEvent("PI:HL Step 14 on timer1_Tick method: Exception in timer1_Tick" + ex.ToString(), HighTraceInfo);
                    HighTraceText.AppendLine("PI:HL Step 14 on timer1_Tick method: Exception in timer1_Tick" + ex.ToString());
                    //LogtoEvent("PI:LL on timer1_Tick method: Exception in timer1_Tick" + ex.ToString(), LowTraceInfo);
                    LowTraceText.AppendLine("PI:LL on timer1_Tick method: Exception in timer1_Tick" + ex.ToString());
                    //LogtoEvent("Exception in StartEvent: " + ex.ToString());
                }
            }
            finally
            {
                if (LowTraceText.Length > 0)
                {
                    LogtoEvent(LowTraceText.ToString(),LowTraceInfo);
                }
                if (HighTraceText.Length > 0)
                {
                    LogtoEvent(HighTraceText.ToString(), HighTraceInfo);
                }
                LowTraceText = new StringBuilder();
                HighTraceText = new StringBuilder();


            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            LowTraceText = new StringBuilder();
            HighTraceText = new StringBuilder();
            try
            {
                try
                {
                    CheckConfigSetting();
                    DeleteFile();
                    //LogtoEvent("PI::LL Step 0.8 in Form Load method: Came out of CheckConfigSetting method", LowTraceInfo);
                    LowTraceText.AppendLine("PI::LL Step 0.8 in Form Load method: Came out of CheckConfigSetting method");


                    //LogtoEvent("PI:: HL in Form Load method: Entered into Form Load method", HighTraceInfo);
                    HighTraceText.AppendLine("PI:: HL in Form Load method: Entered into Form Load method");
                    //LogtoEvent("PI:: HL in Form Load method: Calling CheckConfigSetting method", HighTraceInfo);
                    HighTraceText.AppendLine("PI:: HL in Form Load method: Calling CheckConfigSetting method");
                    //LogtoEvent("PI::LL Step 0.1 in Form Load method: Calling CheckConfigSetting method", LowTraceInfo);
                    LowTraceText.AppendLine("PI::LL Step 0.1 in Form Load method: Calling CheckConfigSetting method");



                    //LogtoEvent("PI:LL:**************************" + System.DateTime.Now, LowTraceInfo);
                    LowTraceText.AppendLine("PI:LL:**************************" + System.DateTime.Now);

                    //LogtoEvent(System.IO.Path.GetFileNameWithoutExtension(System.Reflection.Assembly.GetEntryAssembly().Location), LowTraceInfo);
                    LowTraceText.AppendLine(System.IO.Path.GetFileNameWithoutExtension(System.Reflection.Assembly.GetEntryAssembly().Location));
                    //LogtoEvent(System.Diagnostics.Process.GetProcessesByName(System.IO.Path.GetFileNameWithoutExtension(System.Reflection.Assembly.GetEntryAssembly().Location)).Count().ToString(), LowTraceInfo);
                    LowTraceText.AppendLine(System.Diagnostics.Process.GetProcessesByName(System.IO.Path.GetFileNameWithoutExtension(System.Reflection.Assembly.GetEntryAssembly().Location)).Count().ToString());
                    if (System.Diagnostics.Process.GetProcessesByName(System.IO.Path.GetFileNameWithoutExtension(System.Reflection.Assembly.GetEntryAssembly().Location)).Count() > 1)
                    {
                        //LogtoEvent("PI:LL Step 1 on Form Load: Process Exist more then 1", LowTraceInfo);
                        LowTraceText.AppendLine("PI:LL Step 1 on Form Load: Process Exist more then 1");
                        //Environment.Exit(0);
                        this.Dispose();
                        return;
                    }
                    listBox1.Visible = false;
                    button1.Visible = false;
                    //LogtoEvent("PI:LL Step 2 on Form Load: Load Start", LowTraceInfo);
                    LowTraceText.AppendLine("PI:LL Step 2 on Form Load: Load Start");
                    this.WindowState = FormWindowState.Minimized;
                    this.ShowInTaskbar = false;
                    this.Hide();
                    AppDetails = new DataTable();
                    AppDetails.Columns.Add("AppId", typeof(Int32));
                    AppDetails.Columns.Add("ExeName", typeof(string));
                    AppDetails.Columns.Add("EntryPoint", typeof(string));
                    AppDetails.Columns.Add("AppType", typeof(char));
                    AppDetails.Columns.Add("Used", typeof(char));
                    AppDetails.Columns.Add("ProcessID", typeof(Int32));
                    AppDetails.Columns.Add("TransID", typeof(Int32));
                    //Market Release
                    AppDetails.Columns.Add("AppDeployPath", typeof(string));
                    //Market Release
                    //LogtoEvent("PI:LL Step 3 on Form Load:Calling Populate Applications from GDU service ", LowTraceInfo);
                    LowTraceText.AppendLine("PI:LL Step 3 on Form Load:Calling Populate Applications from GDU service ");
                    std = gduApp.PopulateAppInfo(out objAppDetails);
                    //LogtoEvent("LL Step 4 on Form Load:Calling Application Indicators from GDU service on Form Load",LowTraceInfo);
                    //std = gduApp.PopulateAppFIndicator(out objAppIndicDetails);
                    int iCount = objAppDetails.Count();
                    //LogtoEvent("PI:LL Step 5  on Form Load: Populate Resonse", LowTraceInfo);
                    LowTraceText.AppendLine("PI:LL Step 5  on Form Load: Populate Resonse");
                    //LogtoEvent("PI:LL Step 6  on Form Load: Total Applicaiton are: " + iCount.ToString(), LowTraceInfo);
                    LowTraceText.AppendLine("PI:LL Step 6  on Form Load: Total Applicaiton are: " + iCount.ToString());
                    for (int iCounter = 0; iCounter < iCount; iCounter++)
                    {
                        DataRow drTmp = AppDetails.NewRow();

                        drTmp["AppId"] = objAppDetails[iCounter].AppID;
                        drTmp["ExeName"] = objAppDetails[iCounter].AppExeName.ToLower();
                        drTmp["EntryPoint"] = objAppDetails[iCounter].EntryPoint.ToLower();
                        drTmp["AppType"] = objAppDetails[iCounter].App_Type.ToUpper();
                        drTmp["Used"] = "N";
                        drTmp["ProcessID"] = "0";
                        drTmp["TransID"] = "0";
                        //Market Release
                        drTmp["AppDeployPath"] = objAppDetails[iCounter].AppDeployPath.ToUpper();
                        //Market Release
                        //F:\WWWROOT\DEPLOYEDAPPLICATION\ACW ROP PHASE1\APPLICATION FILES
                        AppDetails.Rows.Add(drTmp);
                        //LogtoEvent("PI:LL Step 6.1  on Form Load: Total Applicaiton are: " + objAppDetails[iCounter].AppID + "," + objAppDetails[iCounter].AppExeName.ToLower() + "," + objAppDetails[iCounter].EntryPoint.ToLower() + "," + objAppDetails[iCounter].App_Type.ToUpper(), LowTraceInfo);
                        LowTraceText.AppendLine("PI:LL Step 6.1  on Form Load: Total Applicaiton are: " + objAppDetails[iCounter].AppID + "," + objAppDetails[iCounter].AppExeName.ToLower() + "," + objAppDetails[iCounter].EntryPoint.ToLower() + "," + objAppDetails[iCounter].App_Type.ToUpper());
                        // LogtoEvent(objAppDetails[iCounter].AppID + " " + objAppDetails[iCounter].AppExeName.ToLower() + objAppDetails[iCounter].EntryPoint.ToLower() + objAppDetails[iCounter].App_Type.ToUpper());

                    }

                    try
                    {
                        //LogtoEvent("PI:LL Step 7 on Form Load:Check User Exist", LowTraceInfo);
                        LowTraceText.AppendLine("PI:LL Step 7 on Form Load:Check User Exist");
                        bool UserExists = CheckUserExists();
                        if (UserExists == false)
                        {
                            //LogtoEvent("PI:LL Step 8 on Form Load: Add User if user doesn't exist", LowTraceInfo);
                            LowTraceText.AppendLine("PI:LL Step 8 on Form Load: Add User if user doesn't exist");
                            AddUser();
                        }
                    }
                    catch (Exception ex)
                    {
                        //LogtoEvent("PI:HL Step 1 on Form Load: Add User Step 7a Exception" + ex.ToString(), HighTraceInfo);
                        LowTraceText.AppendLine("PI:HL Step 1 on Form Load: Add User Step 7a Exception" + ex.ToString());
                        //LogtoEvent("PI:LL on Form Load: Add User Step 7a Exception" + ex.ToString(), LowTraceInfo);
                        LowTraceText.AppendLine("PI:LL on Form Load: Add User Step 7a Exception" + ex.ToString());
                    }

                    timer1.Interval = Int32.Parse(ConfigurationSettings.AppSettings["Interval"].ToString());
                    timer1.Enabled = true;
                }
                catch (Exception ex)
                {
                    this.Dispose();
                    //LogtoEvent("PI:HL Step 15 on Form Load: Add User Step 7a Exception" + ex.ToString(), HighTraceInfo);
                    LowTraceText.AppendLine("PI:HL Step 15 on Form Load: Add User Step 7a Exception" + ex.ToString());
                    //LogtoEvent("PI:LL on Form Load: Add User Step 7a Exception" + ex.ToString(), LowTraceInfo);
                    LowTraceText.AppendLine("PI:LL on Form Load: Add User Step 7a Exception" + ex.ToString());
                }
            }
            finally
            {
                if (LowTraceText.Length > 0)
                {
                    LogtoEvent(LowTraceText.ToString(), LowTraceInfo);
                }
                if (HighTraceText.Length > 0)
                {
                    LogtoEvent(HighTraceText.ToString(), HighTraceInfo);
                }
                LowTraceText = new StringBuilder();
                HighTraceText = new StringBuilder();

            }
        }

        private void DeleteFile()
        {
            //LowTraceText = new StringBuilder();
            //HighTraceText = new StringBuilder();
            try
            {
                try
                {
                    //string TraceFile = Path.GetFullPath(ConfigurationSettings.AppSettings["AxpGDUProcessLowLevelTraceFile"].ToString());
                    mainDirectory = Path.GetDirectoryName(System.Reflection.Assembly.GetEntryAssembly().Location);
                    string LowTraceFileName = ConfigurationSettings.AppSettings["AxpGDUProcessLowLevelTraceFileName"].ToString();
                    string HighTraceFileName = ConfigurationSettings.AppSettings["AxpGDUProcessHighLevelTraceFileName"].ToString();
                    string HLDuration = ConfigurationManager.AppSettings["HLDuration"];
                    string LLDuration = ConfigurationManager.AppSettings["LLDuration"];




                    foreach (string file in System.IO.Directory.GetFiles(mainDirectory, "*.txt"))
                    {
                        string contents = file.ToString();
                        if (contents.Contains(LowTraceFileName))
                        {
                            FileInfo fi = new FileInfo(file);
                            TimeSpan ts = DateTime.Now.Subtract(fi.LastWriteTime);
                            //LogtoEvent("PO: HL in DeleteFile method: File name is" + fi.Name.ToString(), HighTraceInfo);
                            HighTraceText.AppendLine("PI: HL in DeleteFile method: File name is" + fi.Name.ToString());
                            //LogtoEvent("PO: HL in DeleteFile method: File Creation time" + fi.LastWriteTime.ToString(), HighTraceInfo);
                            HighTraceText.AppendLine("PI: HL in DeleteFile method: File Creation time" + fi.LastWriteTime.ToString());
                            //LogtoEvent("PO: HL in DeleteFile method: TimeSpan is" + ts.ToString(), HighTraceInfo);
                            HighTraceText.AppendLine("PI: HL in DeleteFile method: TimeSpan is" + ts.ToString());
                            if (ts.TotalDays > Convert.ToInt32(LLDuration))
                            {
                                double diff = ts.TotalDays - Convert.ToInt32(LLDuration);
                                //LogtoEvent("PO: HL in DeleteFile method: Time difference " + diff.ToString(), HighTraceInfo);
                                HighTraceText.AppendLine("PI: HL in DeleteFile method: Time difference " + diff.ToString());
                                fi.Delete();
                                //LogtoEvent("PO: Low level file deleted ", HighTraceInfo);
                                HighTraceText.AppendLine("PI: Low level file deleted ");
                            }
                        }

                        if (contents.Contains(HighTraceFileName))
                        {
                            FileInfo fi = new FileInfo(file);
                            TimeSpan ts = DateTime.Now.Subtract(fi.LastWriteTime);
                            //LogtoEvent("PO: HL in DeleteFile method: File name is" + fi.Name.ToString(), HighTraceInfo);
                            HighTraceText.AppendLine("PO: HL in DeleteFile method: File name is" + fi.Name.ToString());
                            //LogtoEvent("PO: HL in DeleteFile method: File Creation time" + fi.LastWriteTime.ToString(), HighTraceInfo);
                            HighTraceText.AppendLine("PO: HL in DeleteFile method: File Creation time" + fi.LastWriteTime.ToString());
                            //LogtoEvent("PO: HL in DeleteFile method: TimeSpan is" + ts.ToString(), HighTraceInfo);
                            HighTraceText.AppendLine("PO: HL in DeleteFile method: TimeSpan is" + ts.ToString());
                            if (ts.TotalDays > Convert.ToInt32(HLDuration))
                            {
                                double diff1 = ts.TotalDays - Convert.ToInt32(HLDuration);
                                //LogtoEvent("PO: HL in DeleteFile method: Time difference " + diff1.ToString(), HighTraceInfo);
                                HighTraceText.AppendLine("PO: HL in DeleteFile method: Time difference " + diff1.ToString());
                                fi.Delete();
                                //LogtoEvent("PO: High level file deleted ", HighTraceInfo);
                                HighTraceText.AppendLine("PO: High level file deleted ");
                            }
                        }
                    }

                }
                catch (Exception ex2)
                {

                }
            }
            finally
            {
                if (LowTraceText.Length > 0)
                {
                    LogtoEvent(LowTraceText.ToString(), LowTraceInfo);
                }
                if (HighTraceText.Length > 0)
                {
                    LogtoEvent(HighTraceText.ToString(), HighTraceInfo);
                }
                LowTraceText = new StringBuilder();
                HighTraceText = new StringBuilder();

            }

        }


        private void CheckConfigSetting()
        {

            //LowTraceText = new StringBuilder();
            //HighTraceText = new StringBuilder();
            try
            {
                //LogtoEvent("PI::HL in CheckConfigSetting method: Entered into CheckConfigSetting method", HighTraceInfo);
                HighTraceText.AppendLine("PI::HL in CheckConfigSetting method: Entered into CheckConfigSetting method");
                //LogtoEvent("PI::LL Step 0.2 in CheckConfigSetting method: Entered into CheckConfigSetting method", LowTraceInfo);
                LowTraceText.AppendLine("PI::LL Step 0.2 in CheckConfigSetting method: Entered into CheckConfigSetting method");

                try
                {
                    std = gduApp.PopulateAppFIndicator(out AppFIndicator);

                    dtAppfIndicator = new DataTable();
                    dtAppfIndicator.Columns.Add("IND_NAME", Type.GetType("System.String"));
                    dtAppfIndicator.Columns.Add("IND_VALUE", Type.GetType("System.String"));
                    mainDirectory = Path.GetDirectoryName(System.Reflection.Assembly.GetEntryAssembly().Location);


                    for (int iCount = 0; iCount < AppFIndicator.Length; iCount++)
                    {
                        drAppfInfo = dtAppfIndicator.NewRow();
                        drAppfInfo["IND_NAME"] = AppFIndicator[iCount].IndicatorName;
                        drAppfInfo["IND_VALUE"] = AppFIndicator[iCount].AppFIndicator;
                        dtAppfIndicator.Rows.Add(drAppfInfo);
                    }

                    if (!object.Equals(dtAppfIndicator, null))
                    {
                        if (dtAppfIndicator.Rows.Count > 0)
                        {
                            for (int i = 0; i < dtAppfIndicator.Rows.Count; i++)
                            {
                                if (dtAppfIndicator.Rows[i]["IND_NAME"].ToString() == "LoggingDuration_HL")
                                {
                                    HLAppFocusIndicator = dtAppfIndicator.Rows[i]["IND_VALUE"].ToString();
                                }
                                if (dtAppfIndicator.Rows[i]["IND_NAME"].ToString() == "LoggingDuration_LL")
                                {
                                    LLAppFocusIndicator = dtAppfIndicator.Rows[i]["IND_VALUE"].ToString();
                                }

                            }
                        }
                    }

                    foreach (string file in System.IO.Directory.GetFiles(mainDirectory, "*.config"))
                    {
                        //string contents = File.ReadAllText(file);
                        string HLDuration = ConfigurationManager.AppSettings["HLDuration"];
                        if (HLDuration.ToLower() != HLAppFocusIndicator.ToLower())
                        {
                            //LogtoEvent("PI::LL Step 0.3 in CheckConfigSetting method: Calling UpdateConfigKey method for HighLevel", LowTraceInfo);
                            LowTraceText.AppendLine("PI::LL Step 0.3 in CheckConfigSetting method: Calling UpdateConfigKey method for HighLevel");
                            UpdateConfigKey("HLDuration", HLAppFocusIndicator, file);
                            //LogtoEvent("PI::LL Step 0.5 in CheckConfigSetting method: Came out of UpdateConfigKey method for HighLevel", LowTraceInfo);
                            LowTraceText.AppendLine("PI::LL Step 0.5 in CheckConfigSetting method: Came out of UpdateConfigKey method for HighLevel");
                        }

                        string LLDuration = ConfigurationManager.AppSettings["LLDuration"];
                        if (LLDuration.ToLower() != LLAppFocusIndicator.ToLower())
                        {
                            //LogtoEvent("PI::LL Step 0.6 in CheckConfigSetting method: Calling UpdateConfigKey method for LowLwvel", LowTraceInfo);
                            LowTraceText.AppendLine("PI::LL Step 0.6 in CheckConfigSetting method: Calling UpdateConfigKey method for LowLwvel");
                            UpdateConfigKey("LLDuration", LLAppFocusIndicator, file);
                            //LogtoEvent("PI::LL Step 0.7 in CheckConfigSetting method: Came out of UpdateConfigKey method for LowLwvel", LowTraceInfo);
                            LowTraceText.AppendLine("PI::LL Step 0.7 in CheckConfigSetting method: Came out of UpdateConfigKey method for LowLwvel");
                        }


                    }

                }
                catch (Exception ex)
                {
                    //LogtoEvent("PI: HL Step 0.1 in CheckConfigSetting Method: CheckConfigSetting method Exception: " + ex.ToString(), HighTraceInfo);
                    HighTraceText.AppendLine("PI: HL Step 0.1 in CheckConfigSetting Method: CheckConfigSetting method Exception: " + ex.ToString());
                    //LogtoEvent("PI: LL in CheckConfigSetting Method: CheckConfigSetting method Exception: " + ex.ToString(), LowTraceInfo);
                    LowTraceText.AppendLine("PI: LL in CheckConfigSetting Method: CheckConfigSetting method Exception: " + ex.ToString());
                }
            }
            finally
            {
                if (LowTraceText.Length > 0)
                {
                    LogtoEvent(LowTraceText.ToString(), LowTraceInfo);
                }
                if (HighTraceText.Length > 0)
                {
                    LogtoEvent(HighTraceText.ToString(), HighTraceInfo);
                }
                LowTraceText = new StringBuilder();
                HighTraceText = new StringBuilder();

            }
        }



        private void UpdateConfigKey(string strKey, string newValue, string conFile)
        {

            //LowTraceText = new StringBuilder();
            //HighTraceText = new StringBuilder();

            try
            {
                //LogtoEvent("PI: HL in UpdateConfigKey method: Entered into UpdateConfigKey method", HighTraceInfo);
                HighTraceText.AppendLine("PI: HL in UpdateConfigKey method: Entered into UpdateConfigKey method");
                //LogtoEvent("PI: LL Step 0.4 in UpdateConfigKey method: Entered into UpdateConfigKey method", LowTraceInfo);
                LowTraceText.AppendLine("PI: LL Step 0.4 in UpdateConfigKey method: Entered into UpdateConfigKey method");
                try
                {
                    XmlDocument xmlDoc = new XmlDocument();
                    xmlDoc.Load(conFile);

                    if (!ConfigKeyExists(strKey, conFile))
                    {
                        throw new ArgumentNullException("key", "<" + strKey + "> not find in the configuration.");
                    }

                    XmlNode appSettingsNode = xmlDoc.SelectSingleNode("configuration/appSettings");

                    foreach (XmlNode childNode in appSettingsNode)
                    {

                        if (childNode.Attributes["key"].Value == strKey)

                            childNode.Attributes["value"].Value = newValue;

                    }

                    xmlDoc.Save(conFile);
                    ConfigurationManager.RefreshSection("appSettings");
                }
                catch (Exception ex)
                {
                    LogtoEvent("PI: HL Step 0.2 in UpdateConfigKey Method: UpdateConfigKey method Exception: " + ex.ToString(), HighTraceInfo);
                    LogtoEvent("PI: LL in UpdateConfigKey Method: UpdateConfigKey method Exception: " + ex.ToString(), LowTraceInfo);
                }
            }
            finally
            {
                if (LowTraceText.Length > 0)
                {
                    LogtoEvent(LowTraceText.ToString(), LowTraceInfo);
                }
                if (HighTraceText.Length > 0)
                {
                    LogtoEvent(HighTraceText.ToString(), HighTraceInfo);
                }
                LowTraceText = new StringBuilder();
                HighTraceText = new StringBuilder();

            }


        }

        private bool ConfigKeyExists(string strKey, string cnfgFile)
        {

            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.Load(cnfgFile);
            XmlNode appSettingsNode = xmlDoc.SelectSingleNode("configuration/appSettings");

            foreach (XmlNode childNode in appSettingsNode)
            {
                if (childNode.Attributes["key"].Value == strKey)
                    return true;
            }
            return false;

        }

        private void StartEvent()
        {
            //LowTraceText = new StringBuilder();
            //HighTraceText = new StringBuilder();
            try
            {
                try
                {
                    CultureInfo cul_Info = new CultureInfo("en-US");
                    Thread.CurrentThread.CurrentCulture = cul_Info;

                    string ApplicationPath = string.Empty;
                    string Version = string.Empty;
                    string AppPath = string.Empty;
                    string manifestFileName = string.Empty;
                    string appExeName = string.Empty;

                    DataRow[] drUsed = AppDetails.Select(" Used ='N'");

                    //LogtoEvent("PI:LL Step 9 on StartEvent: drUsed Count Where Used=N : " + drUsed.Count().ToString(), LowTraceInfo);
                    LowTraceText.AppendLine("PI:LL Step 9 on StartEvent: drUsed Count Where Used=N : " + drUsed.Count().ToString());

                    foreach (DataRow drTmp in drUsed)
                    {

                        string ProcessName = drTmp["EntryPoint"].ToString();

                        appExeName = drTmp["ExeName"].ToString();

                        string AppDeploypathDB = drTmp["AppDeployPath"].ToString();

                        //LogtoEvent("LL Step 10 on StartEvent: Calling ProcessExists method:" + drUsed.Count().ToString(), LowTraceInfo);
                        LowTraceText.AppendLine("LL Step 10 on StartEvent: Calling ProcessExists method:" + drUsed.Count().ToString());

                        ///Star Apollo Issue -14-Nov-2013 --Added sappExeName parameter below to resolve the issue
                        if (ProcessExists(ProcessName.Substring(0, ProcessName.Length - 4), AppDeploypathDB, appExeName))
                        {
                            //Tkare Procid from Property
                            //String processID = System.Diagnostics.Process.GetProcessesByName(drTmp["EntryPoint"].ToString().Substring(0, drTmp["EntryPoint"].ToString().Length - 4))[0].Id.ToString();
                            //ProcID
                            //var searcher = new ManagementObjectSearcher(new WqlObjectQuery(String.Format("Select ExecutablePath from Win32_Process where ProcessID = {0}", processID)));
                            var searcher = new ManagementObjectSearcher(new WqlObjectQuery(String.Format("Select ExecutablePath from Win32_Process where ProcessID = {0}", ProcID)));

                            ManagementObject managementObject = null;
                            foreach (ManagementObject obj in searcher.Get())
                            {
                                managementObject = obj;
                                break;
                            }
                            ApplicationPath = managementObject["ExecutablePath"].ToString();
                            AppPath = ApplicationPath;
                            AppPath = AppPath.ToLower().Replace(ProcessName.ToLower(), "");
                            //LogtoEvent("PI:LL Step 17 on StartEvent: AppPath is  : " + AppPath, LowTraceInfo);
                            LowTraceText.AppendLine("PI:LL Step 17 on StartEvent: AppPath is  : " + AppPath);

                            //Market Release Changes
                            DirectoryInfo di = new DirectoryInfo(AppPath);
                            FileInfo[] rgFiles = di.GetFiles("*.manifest");
                            foreach (FileInfo fi in rgFiles)
                            {
                                //LogtoEvent("PI:LL Step 18 on StartEvent: Checking Manifest:" + fi.Name, LowTraceInfo);
                                LowTraceText.AppendLine("PI:LL Step 18 on StartEvent: Checking Manifest:" + fi.Name);
                                //LogtoEvent("PI:LL Step 19 on StartEvent: App Manifest:" + appExeName + ".manifest", LowTraceInfo);
                                LowTraceText.AppendLine("PI:LL Step 19 on StartEvent: App Manifest:" + appExeName + ".manifest");
                                //if (fi.Name == ApplicationPath.Substring(ApplicationPath.LastIndexOf(@"\") + 1) + ".manifest")
                                if (fi.Name.ToLower() == appExeName.ToLower() + ".manifest")
                                {
                                    manifestFileName = fi.Name;
                                    //LogtoEvent("PI:LL Step 20 on StartEvent: Manifest Match:" + manifestFileName, LowTraceInfo);
                                    LowTraceText.AppendLine("PI:LL Step 20 on StartEvent: Manifest Match:" + manifestFileName);
                                }
                            }

                            _clientUsageInfo = new ClientUsageInfo();

                            _clientUsageInfo.NACId = GetUserName();
                            _clientUsageInfo.IP = GetIP();
                            _clientUsageInfo.Start_DT = DateTime.Now.ToString();
                            _clientUsageInfo.End_DT = "";
                            _clientUsageInfo.Version = GetAssemblyVersion(AppPath + manifestFileName);
                            _clientUsageInfo.ComputerName = System.Net.Dns.GetHostName();
                            _clientUsageInfo.App_ID = Int32.Parse(drTmp["AppId"].ToString());

                            //LogtoEvent("PI:LL Step 21 on StartEvent: Saving Details", LowTraceInfo);
                            //LogtoEvent("PI:LL Step 22 on StartEvent: Parameter1:", LowTraceInfo);
                            //LogtoEvent("PI:LL Step 24 on StartEvent: NACId is " + _clientUsageInfo.NACId, LowTraceInfo);
                            //LogtoEvent("PI:LL Step 25 on StartEvent: IP is " + _clientUsageInfo.IP, LowTraceInfo);
                            //LogtoEvent("PI:LL Step 26 on StartEvent: Start_DT is " + _clientUsageInfo.Start_DT, LowTraceInfo);
                            //LogtoEvent("PI:LL Step 27 on StartEvent: End_DT is " + _clientUsageInfo.End_DT, LowTraceInfo);
                            //LogtoEvent("PI:LL Step 28 on StartEvent: Version is " + _clientUsageInfo.Version, LowTraceInfo);
                            //LogtoEvent("PI:LL Step 29 on StartEvent: ComputerName is " + _clientUsageInfo.ComputerName, LowTraceInfo);
                            //LogtoEvent("PI:LL Step 30 on StartEvent: App_ID is " + _clientUsageInfo.App_ID.ToString(), LowTraceInfo);
                            //LogtoEvent("PI:LL Step 31 on StartEvent: TransID " + _clientUsageInfo.TransID.ToString(), LowTraceInfo);

                            LowTraceText.AppendLine("PI:LL Step 21 on StartEvent: Saving Details");
                            LowTraceText.AppendLine("PI:LL Step 22 on StartEvent: Parameter1:");
                            LowTraceText.AppendLine("PI:LL Step 24 on StartEvent: NACId is " + _clientUsageInfo.NACId);
                            LowTraceText.AppendLine("PI:LL Step 25 on StartEvent: IP is " + _clientUsageInfo.IP);
                            LowTraceText.AppendLine("PI:LL Step 26 on StartEvent: Start_DT is " + _clientUsageInfo.Start_DT);
                            LowTraceText.AppendLine("PI:LL Step 27 on StartEvent: End_DT is " + _clientUsageInfo.End_DT);
                            LowTraceText.AppendLine("PI:LL Step 28 on StartEvent: Version is " + _clientUsageInfo.Version);
                            LowTraceText.AppendLine("PI:LL Step 29 on StartEvent: ComputerName is " + _clientUsageInfo.ComputerName);
                            LowTraceText.AppendLine("PI:LL Step 30 on StartEvent: App_ID is " + _clientUsageInfo.App_ID.ToString());
                            LowTraceText.AppendLine("PI:LL Step 31 on StartEvent: TransID " + _clientUsageInfo.TransID.ToString());
                            std = gduApp.ClientUsageDetailResponse(_clientUsageInfo);

                            if (std.ResponseCodeStatus.ToString().ToUpper() == "SUCCESS")
                            {
                                //LogtoEvent("PI:LL Step 32 on StartEvent: Success", LowTraceInfo);
                                LowTraceText.AppendLine("PI:LL Step 32 on StartEvent: Success");
                                drTmp["Used"] = "Y";
                                //ProcID
                                //drTmp["ProcessID"] = Int32.Parse(processID);
                                drTmp["ProcessID"] = Int32.Parse(ProcID);

                                if (std.ResponseMessage.ToString() != string.Empty)
                                {
                                    drTmp["TransID"] = Int32.Parse(std.ResponseMessage);
                                    //LogtoEvent("PI:LL Step 33 on StartEvent: Trans ID" + std.ResponseMessage.ToString(), LowTraceInfo);
                                    LowTraceText.AppendLine("PI:LL Step 33 on StartEvent: Trans ID" + std.ResponseMessage.ToString());
                                    AppDetails.AcceptChanges();
                                    IsChecked = true;
                                }
                                else
                                {
                                    try
                                    {
                                        //LogtoEvent("PI:LL Step 34 on StartEvent: App Details Reject Changes", LowTraceInfo);
                                        //LogtoEvent("PI:LL Step 35 on StartEvent: Parameter2:", LowTraceInfo);
                                        LowTraceText.AppendLine("PI:LL Step 34 on StartEvent: App Details Reject Changes");
                                        LowTraceText.AppendLine("PI:LL Step 35 on StartEvent: Parameter2:");
                                        AppDetails.RejectChanges();
                                        //LogtoEvent("PI:LL Step 36 on StartEvent: Saving Details", LowTraceInfo);
                                        //LogtoEvent("PI:LL Step 37 on StartEvent: Parameter1:", LowTraceInfo);
                                        //LogtoEvent("PI:LL Step 38 on StartEvent: NACId is " + _clientUsageInfo.NACId, LowTraceInfo);
                                        //LogtoEvent("PI:LL Step 39 on StartEvent: IP is " + _clientUsageInfo.IP, LowTraceInfo);
                                        //LogtoEvent("PI:LL Step 40 on StartEvent: Start_DT is " + _clientUsageInfo.Start_DT, LowTraceInfo);
                                        //LogtoEvent("PI:LL Step 41 on StartEvent: End_DT is " + _clientUsageInfo.End_DT, LowTraceInfo);
                                        //LogtoEvent("PI:LL Step 42 on StartEvent: Version is " + _clientUsageInfo.Version, LowTraceInfo);
                                        //LogtoEvent("PI:LL Step 43 on StartEvent: ComputerName is " + _clientUsageInfo.ComputerName, LowTraceInfo);
                                        //LogtoEvent("PI:LL Step 44 on StartEvent: App_ID is " + _clientUsageInfo.App_ID.ToString(), LowTraceInfo);
                                        //LogtoEvent("PI:LL Step 45 on StartEvent: TransID " + _clientUsageInfo.TransID.ToString(), LowTraceInfo);

                                        LowTraceText.AppendLine("PI:LL Step 36 on StartEvent: Saving Details");
                                        LowTraceText.AppendLine("PI:LL Step 37 on StartEvent: Parameter1:");
                                        LowTraceText.AppendLine("PI:LL Step 38 on StartEvent: NACId is " + _clientUsageInfo.NACId);
                                        LowTraceText.AppendLine("PI:LL Step 39 on StartEvent: IP is " + _clientUsageInfo.IP);
                                        LowTraceText.AppendLine("PI:LL Step 40 on StartEvent: Start_DT is " + _clientUsageInfo.Start_DT);
                                        LowTraceText.AppendLine("PI:LL Step 41 on StartEvent: End_DT is " + _clientUsageInfo.End_DT);
                                        LowTraceText.AppendLine("PI:LL Step 42 on StartEvent: Version is " + _clientUsageInfo.Version);
                                        LowTraceText.AppendLine("PI:LL Step 43 on StartEvent: ComputerName is " + _clientUsageInfo.ComputerName);
                                        LowTraceText.AppendLine("PI:LL Step 44 on StartEvent: App_ID is " + _clientUsageInfo.App_ID.ToString());
                                        LowTraceText.AppendLine("PI:LL Step 45 on StartEvent: TransID " + _clientUsageInfo.TransID.ToString());
                                    }
                                    catch (Exception ex)
                                    {
                                        //LogtoEvent("PI:HL Step 2 on StartEvent: App Details Reject Exception" + ex.ToString(), HighTraceInfo);
                                        HighTraceText.AppendLine("PI:HL Step 2 on StartEvent: App Details Reject Exception" + ex.ToString());
                                        //LogtoEvent("PI:LL on StartEvent: App Details Reject Exception" + ex.ToString(), LowTraceInfo);
                                        LowTraceText.AppendLine("PI:LL on StartEvent: App Details Reject Exception" + ex.ToString());

                                    }
                                }
                            }
                            else
                            {
                                //LogtoEvent("PI:LL Step 46 on StartEvent: Exception ", LowTraceInfo);
                                LowTraceText.AppendLine("PI:LL Step 46 on StartEvent: Exception ");
                                drTmp["Used"] = "Y";
                                drTmp["ProcessID"] = 0;
                                if (std.ResponseMessage.ToString() != string.Empty)
                                {
                                    drTmp["TransID"] = 0;
                                    //LogtoEvent("PI:LL Step 47 on StartEvent: Trans ID" + 0, LowTraceInfo);
                                    LowTraceText.AppendLine("PI:LL Step 47 on StartEvent: Trans ID" + 0);
                                    //LogtoEvent("Step 6: Trans ID" + 0);
                                    AppDetails.AcceptChanges();
                                    IsChecked = true;
                                }
                                else
                                    AppDetails.RejectChanges();

                            }
                            //}
                        }
                    }
                }
                catch (Exception ex1)
                {
                    //LogtoEvent("PI:HL Step 3 on StartEvent : Catch exception for the StartEvent()" + ex1.ToString(), HighTraceInfo);
                    HighTraceText.AppendLine("PI:HL Step 3 on StartEvent : Catch exception for the StartEvent()" + ex1.ToString());
                    //LogtoEvent("PI:LL on StartEvent : Catch exception for the StartEvent()" + ex1.ToString(), LowTraceInfo);
                    LowTraceText.AppendLine("PI:LL on StartEvent : Catch exception for the StartEvent()" + ex1.ToString());
                }

               // LogtoEvent("PI:LL Step 48 on StartEvent method: Calling EndEvent() method", LowTraceInfo);
                LowTraceText.AppendLine("PI:LL Step 48 on StartEvent method: Calling EndEvent() method");

            }
            finally
            {
                if (LowTraceText.Length > 0)
                {
                    LogtoEvent(LowTraceText.ToString(), LowTraceInfo);
                }
                if (HighTraceText.Length > 0)
                {
                    LogtoEvent(HighTraceText.ToString(), HighTraceInfo);
                }
                LowTraceText = new StringBuilder();
                HighTraceText = new StringBuilder();

            }
            EndEvent();
        }
        private void EndEvent()
        {
            //LowTraceText = new StringBuilder();
            //HighTraceText = new StringBuilder();

            try
            {
                try
                {
                    //LogtoEvent("PI:: HL in EndEvent method: Entered into EndEvent method", HighTraceInfo);
                   
                    DataRow[] drUsed = AppDetails.Select(" Used ='Y'");
                    foreach (DataRow drTmp in drUsed)
                    {
                        //ProcessExists(Int32.Parse(drTmp["ProcessID"].ToString()));
                        //LogtoEvent("PI:LL Step 49 on EndEvent: Calling ProcessExists with Id parameter", LowTraceInfo);
                        if (ProcessExists(Int32.Parse(drTmp["ProcessID"].ToString())) == false)
                        {

                            _clientUsageInfo = new ClientUsageInfo();
                            _clientUsageInfo.TransID = Int32.Parse(drTmp["TransID"].ToString());
                            _clientUsageInfo.End_DT = DateTime.Now.ToString();

                            //LogtoEvent("Parameter3 EndEvent:");
                            //LogtoEvent(_clientUsageInfo.NACId);
                            //LogtoEvent(_clientUsageInfo.IP);
                            //LogtoEvent(_clientUsageInfo.Start_DT);
                            //LogtoEvent(_clientUsageInfo.End_DT);
                            //LogtoEvent(_clientUsageInfo.Version);
                            //LogtoEvent(_clientUsageInfo.ComputerName);
                            //LogtoEvent(_clientUsageInfo.App_ID.ToString());
                            //LogtoEvent(_clientUsageInfo.TransID.ToString());
                            std = gduApp.ClientUsageDetailResponse(_clientUsageInfo);

                            if (std.ResponseCodeStatus.ToString().ToUpper() == "SUCCESS")
                            {
                                LogtoEvent("PI:LL Step 50 on EndEvent: SUCCESS", LowTraceInfo);
                                drTmp["Used"] = "N";
                                drTmp["ProcessID"] = 0;
                                drTmp["TransID"] = 0;
                                AppDetails.AcceptChanges();
                            }
                        }
                    }

                    DataRow[] drCheckUsed = AppDetails.Select(" Used ='N'");
                    //LogtoEvent("Application With N: " + drCheckUsed.Length);

                    //LogtoEvent("@@@@ All Application List @@@");
                    //for (int i = 0; i < AppDetails.Rows.Count; i++)
                    //{
                    //    if (AppDetails.Rows[i]["Used"].ToString() == "Y")
                    //        LogtoEvent(AppDetails.Rows[i]["ExeName"].ToString() + "-" + AppDetails.Rows[i]["Used"].ToString());
                    //}

                    if ((drCheckUsed.Length == AppDetails.Rows.Count) && IsChecked == true)
                    {
                        this.Dispose();
                    }
                }
                catch (Exception ex)
                {
                    //LogtoEvent("PI:HL Step 4 on EndEvent : Exception in End Event :" + ex.ToString(), HighTraceInfo);
                    HighTraceText.AppendLine("PI:HL Step 4 on EndEvent : Exception in End Event :" + ex.ToString());
                    //LogtoEvent("PI:LL on EndEvent : Exception in End Event :" + ex.ToString(), LowTraceInfo);
                    LowTraceText.AppendLine("PI:LL on EndEvent : Exception in End Event :" + ex.ToString());
                    //LogtoEvent("Exception in End Event: " + ex.ToString());
                }
            }
            finally
            {
                if (LowTraceText.Length > 0)
                {
                    LogtoEvent(LowTraceText.ToString(), LowTraceInfo);
                }
                if (HighTraceText.Length > 0)
                {
                    LogtoEvent(HighTraceText.ToString(), HighTraceInfo);
                }
                LowTraceText = new StringBuilder();
                HighTraceText = new StringBuilder();

            }

        }
        private bool ProcessExists(int id)
        {
            return System.Diagnostics.Process.GetProcesses().Any(x => x.Id == id);
        }

        ///Star Apollo Issue -14-Nov-2013 --Added string exename parameter
        private bool ProcessExists(string name, string path, string exename)
        {

            try
            {
                //Market Release
                try
                {
                    var count = System.Diagnostics.Process.GetProcesses().Where(x => x.ProcessName.ToLower() == name).Count();
                    //LogtoEvent("PI:LL Step 10.01 on ProcessExists method: Count of duplicate exes on task manager are:" + count.ToString(), LowTraceInfo);
                    LowTraceText.AppendLine("PI:LL Step 10.01 on ProcessExists method: Count of duplicate exes on task manager are:" + count.ToString());
                    //LogtoEvent("PI:LL Step 10.1 on ProcessExists method: ProcessName.Substring(0, ProcessName.Length - 4:" + name.ToString(), LowTraceInfo);
                    LowTraceText.AppendLine("PI:LL Step 10.1 on ProcessExists method: ProcessName.Substring(0, ProcessName.Length - 4:" + name.ToString());
                    //LogtoEvent("PI:LL Step 10.2 on ProcessExists method: AppDeploypathDB from DB is:" + path.ToString(), LowTraceInfo);
                    LowTraceText.AppendLine("PI:LL Step 10.2 on ProcessExists method: AppDeploypathDB from DB is:" + path.ToString());
                    for (int i = 0; i < count; i++)
                    {
                        String processID = System.Diagnostics.Process.GetProcessesByName(name)[i].Id.ToString();

                        LowTraceText.AppendLine("PI:LL Step 10.2a on ProcessExists method: Process ID:" + processID.ToString());
                        DataRow[] drUsedPid = AppDetails.Select(" Used ='Y'");
                        LowTraceText.AppendLine("PI:LL Step 10.2a on ProcessExists method: drUsedPid.Count :" + drUsedPid.Count());

                        if (!object.Equals(drUsedPid.Count(), 0))
                        {
                            foreach (DataRow drTmp in drUsedPid)
                            {
                                if (drTmp["ProcessID"].ToString() != processID)
                                {
                                    System.Diagnostics.Process proc = System.Diagnostics.Process.GetProcessById(Convert.ToInt32(processID));
                                    string ExePath = proc.MainModule.FileName.ToString();

                                    string ExeBasepathpart = ExePath.TrimEnd('\\');
                                    ExeBasepathpart = ExePath.Remove(ExePath.LastIndexOf('\\'));
                                    ExeBasepathpart = ExePath.Substring(0, ExePath.LastIndexOf('\\'));
                                    //LogtoEvent("PI:LL Step 10.3 on ProcessExists method: ExeBasepathpart om machine is:" + ExeBasepathpart.ToString(), LowTraceInfo);
                                    LowTraceText.AppendLine("PI:LL Step 10.3 on ProcessExists method: ExeBasepathpart on machine is:" + ExeBasepathpart.ToString());


                                    //C:\Program Files\American Express\GWiz_SIT
                                    //******************

                                    XElement xDeploymentManifest = null;
                                    //xDeploymentManifest = XElement.Load(ExeBasepathpart + name.Substring(0, name.LastIndexOf('.')) + ".amexapplication");
                                    
                                    //Star Apollo Issue -14-Nov-2013 --Passed the exename rather than name
                                    //xDeploymentManifest = XElement.Load(ExeBasepathpart + @"\" + name + ".amexapplication");
                                    xDeploymentManifest = XElement.Load(ExeBasepathpart + @"\" + exename.Substring(0, exename.LastIndexOf('.')) + ".amexapplication");
                                    LowTraceText.AppendLine("PI:LL Step 10.3a on ProcessExists method: Amex application name on server is:" + ExeBasepathpart + @"\" + exename.Substring(0, exename.LastIndexOf('.')) + ".amexapplication");

                                    DeploymentManifestReader deploymentReader = null;
                                    deploymentReader = new DeploymentManifestReader(xDeploymentManifest);
                                    string applicationBasepath = deploymentReader.Codebase;
                                    string applicationBasepathpart = applicationBasepath.Substring(applicationBasepath.IndexOf("DeployedApplication"));
                                    // string appFoldername = applicationBasepathpart.Split('/')[1];
                                    string ExeFoldername = applicationBasepathpart.Split('/')[1];
                                    //LogtoEvent("PI:LL Step 10.4 on ProcessExists method: ExeFoldername on server is:" + ExeFoldername.ToString(), LowTraceInfo);
                                    LowTraceText.AppendLine("PI:LL Step 10.4 on ProcessExists method: ExeFoldername on server is:" + ExeFoldername.ToString());
                                    //LogtoEvent("PI:LL Step 11 on ProcessExists method: ExeFolder name from amex file is :  " + ExeFoldername,LowTraceInfo);
                                    //System.Diagnostics.Process proc = System.Diagnostics.Process.GetProcessById(Convert.ToInt32(processID));
                                    //string ExePath = proc.MainModule.FileName.ToString();

                                    //string ExeBasepathpart = ExePath.TrimEnd('\\');
                                    //ExeBasepathpart = ExePath.Remove(ExePath.LastIndexOf('\\'));
                                    //ExeBasepathpart = ExeBasepathpart.Substring(ExeBasepathpart.LastIndexOf("\\"));
                                    //string ExeFoldername = ExeBasepathpart.Remove(0, 1);


                                    string aa1 = path.Substring(0, path.LastIndexOf(@"\"));
                                    int aa2 = path.IndexOf(@"DEPLOYEDAPPLICATION\");
                                    string str5 = aa1.Substring(aa2).Substring(20);
                                    //LogtoEvent("PI:LL Step 10.5 on ProcessExists method: str5 from Client machine:" + str5.ToString(), LowTraceInfo);
                                    LowTraceText.AppendLine("PI:LL Step 10.5 on ProcessExists method: str5 from Client machine:" + str5.ToString());
                                    //LogtoEvent("LL Step 12 on ProcessExists method: Folder name from database is :  " + str5,LowTraceInfo);

                                    if (ExeFoldername.Trim().ToLower() == str5.Trim().ToLower())
                                    {
                                        //LogtoEvent("PI:LL Step 11 on ProcessExists method: ExeFolder name from amex file is :  " + ExeFoldername, LowTraceInfo);
                                        LowTraceText.AppendLine("PI:LL Step 11 on ProcessExists method: ExeFolder name from amex file is :  " + ExeFoldername);
                                        //LogtoEvent("PI:LL Step 12 on ProcessExists method: Folder name from database is :  " + str5, LowTraceInfo);
                                        LowTraceText.AppendLine("PI:LL Step 12 on ProcessExists method: Folder name from database is :  " + str5);
                                        ProcID = processID;
                                        //LogtoEvent("PI:LL Step 13 on ProcessExists method: Returned ProcID is :" + ProcID, LowTraceInfo);
                                        LowTraceText.AppendLine("PI:LL Step 13 on ProcessExists method: Returned ProcID is :" + ProcID);
                                        return true;
                                    }
                                }
                            }
                        }
                        else
                        {
                            System.Diagnostics.Process proc = System.Diagnostics.Process.GetProcessById(Convert.ToInt32(processID));
                            string ExePath = proc.MainModule.FileName.ToString();

                            string ExeBasepathpart = ExePath.TrimEnd('\\');
                            ExeBasepathpart = ExePath.Remove(ExePath.LastIndexOf('\\'));
                            ExeBasepathpart = ExePath.Substring(0, ExePath.LastIndexOf('\\'));
                            //LogtoEvent("PI:LL Step 10.3a on ProcessExists method: ExeBasepathpart on machine in else condition is:" + ExeBasepathpart.ToString(), LowTraceInfo);
                            LowTraceText.AppendLine("PI:LL Step 10.3 on ProcessExists method: ExeBasepathpart on machine in else condition is:" + ExeBasepathpart.ToString());


                            //C:\Program Files\American Express\GWiz_SIT
                            //******************

                            XElement xDeploymentManifest = null;
                            //xDeploymentManifest = XElement.Load(ExeBasepathpart + name.Substring(0, name.LastIndexOf('.')) + ".amexapplication");
                            //Star Apollo Issue -14-Nov-2013 --Passed the exename rather than name
                            //xDeploymentManifest = XElement.Load(ExeBasepathpart + @"\" + name + ".amexapplication");
                            xDeploymentManifest = XElement.Load(ExeBasepathpart + @"\" + exename.Substring(0, exename.LastIndexOf('.')) + ".amexapplication");
                            LowTraceText.AppendLine("PI:LL Step 10.3a on ProcessExists method: Amex application name on server is:" + ExeBasepathpart + @"\" + exename.Substring(0, exename.LastIndexOf('.')) + ".amexapplication");
                            
                            DeploymentManifestReader deploymentReader = null;
                            deploymentReader = new DeploymentManifestReader(xDeploymentManifest);
                            string applicationBasepath = deploymentReader.Codebase;
                            string applicationBasepathpart = applicationBasepath.Substring(applicationBasepath.IndexOf("DeployedApplication"));
                            // string appFoldername = applicationBasepathpart.Split('/')[1];
                            string ExeFoldername = applicationBasepathpart.Split('/')[1];
                            //LogtoEvent("PI:LL Step 10.4a on ProcessExists method: ExeFoldername in else condition on server is:" + ExeFoldername.ToString(), LowTraceInfo);
                            LowTraceText.AppendLine("PI:LL Step 10.4a on ProcessExists method: ExeFoldername in else condition on server is:" + ExeFoldername.ToString());
                            ////string ss1 = applicationBasepath.Substring(0, applicationBasepath.LastIndexOf('/'));
                            ////int aa = applicationBasepath.IndexOf("DeployedApplication/");
                            ////string str2 = ss1.Substring(aa).Substring(20);

                            //*****************

                            // ExeBasepathpart = ExeBasepathpart.Substring(ExeBasepathpart.LastIndexOf("\\"));
                            //\GWiz_SIT
                            // string ExeFoldername = ExeBasepathpart.Remove(0, 1);


                            string aa1 = path.Substring(0, path.LastIndexOf(@"\"));
                            int aa2 = path.IndexOf(@"DEPLOYEDAPPLICATION\");
                            string str5 = aa1.Substring(aa2).Substring(20);
                            //LogtoEvent("PI:LL Step 10.5a on ProcessExists method: str5 in else condition from Client machine:" + str5.ToString(), LowTraceInfo);
                            LowTraceText.AppendLine("PI:LL Step 10.5a on ProcessExists method: str5 in else condition from Client machine:" + str5.ToString());


                            if (ExeFoldername.Trim().ToLower() == str5.Trim().ToLower())
                            {
                                //LogtoEvent("PI:LL Step 14 on ProcessExists method: ExeFolder name from amex file in else condition is :  " + ExeFoldername, LowTraceInfo);
                                LowTraceText.AppendLine("PI:LL Step 14 on ProcessExists method: ExeFolder name from amex file in else condition is :  " + ExeFoldername);
                                //LogtoEvent("PI:LL Step 15 on ProcessExists method: Folder name from database in else condition is :  " + str5, LowTraceInfo);
                                LowTraceText.AppendLine("PI:LL Step 15 on ProcessExists method: Folder name from database in else condition is :  " + str5);
                                ProcID = processID;
                                //LogtoEvent("PI:LL Step 16 on ProcessExists method: Returned ProcID in else condition is :" + ProcID, LowTraceInfo);
                                LowTraceText.AppendLine("PI:LL Step 16 on ProcessExists method: Returned ProcID in else condition is :" + ProcID);
                                return true;
                            }
                        }
                    }

                    return false;
                    //return false;
                }

                catch (Exception ex)
                {
                    LowTraceText.AppendLine("PI:LL Step 13 on on ProcessExists method: Exception is  :" + ex.ToString());

                    //LogtoEvent("PI:HL Step 13 on on ProcessExists method: Exception is  :" + ex.ToString(), HighTraceInfo);
                    return false;

                }
            }
            finally
            {
                if (LowTraceText.Length > 0)
                {
                    LogtoEvent(LowTraceText.ToString(), LowTraceInfo);
                }
                if (HighTraceText.Length > 0)
                {
                    LogtoEvent(HighTraceText.ToString(), HighTraceInfo);
                }
                LowTraceText = new StringBuilder();
                HighTraceText = new StringBuilder();

            }

        }
        private string GetUserName()
        {
            
            string UserName = string.Empty;
            try
            {
                //LowTraceText = new StringBuilder();
                //HighTraceText = new StringBuilder();

                //LogtoEvent("PI:LL Step 51 on GetUserName() method: Entered into GetUserName() method", LowTraceInfo);
                LowTraceText.AppendLine("PI:LL Step 51 on GetUserName() method: Entered into GetUserName() method");
                UserName = (WindowsIdentity.GetCurrent().Name.Substring(WindowsIdentity.GetCurrent().Name.LastIndexOf(@"\"))).Replace(@"\", "");
                //LogtoEvent("PI:LL Step 52 on GetUserName() method: UserName is :" + UserName, LowTraceInfo);
                LowTraceText.AppendLine("PI:LL Step 52 on GetUserName() method: UserName is :" + UserName);
            }
            catch (Exception ex)
            {
                //LogtoEvent("PI:HL Step 5 on GetUserName() method: Exception is  :" + ex.ToString(), HighTraceInfo);

                HighTraceText.AppendLine("PI:HL Step 5 on GetUserName() method: Exception is  :" + ex.ToString());
                //LogtoEvent("PI:LL on GetUserName() method: Exception is  :" + ex.ToString(), LowTraceInfo);
                LowTraceText.AppendLine("PI:LL on GetUserName() method: Exception is  :" + ex.ToString());
                throw ex;
            }

            finally
            {
                if (LowTraceText.Length > 0)
                {
                    LogtoEvent(LowTraceText.ToString(), LowTraceInfo);
                }
                if (HighTraceText.Length > 0)
                {
                    LogtoEvent(HighTraceText.ToString(), HighTraceInfo);
                }
                LowTraceText = new StringBuilder();
                HighTraceText = new StringBuilder();
            }

            return UserName;

        }
        private string GetIP()
        {


            string strHostName = "";
            string str = string.Empty;

            strHostName = System.Net.Dns.GetHostName();
            IPHostEntry ipEntry = System.Net.Dns.GetHostEntry(strHostName);
            IPAddress[] addr = ipEntry.AddressList;
            try
            {
                //LowTraceText = new StringBuilder();
                //HighTraceText = new StringBuilder();
                //LogtoEvent("PI:LL Step 53 on GetIP() method: IP Address logic in GetIP() method", LowTraceInfo);
                LowTraceText.AppendLine("PI:LL Step 53 on GetIP() method: IP Address logic in GetIP() method");
                for (int i = 0; i < addr.Length; i++)
                {
                    str = addr[i].ToString();
                    string[] words = str.Split('.');
                    if (words.Length == 4)
                    {
                        str = addr[i].ToString();
                        break;
                    }
                }

            }
            catch (Exception ex)
            {
                str = addr[addr.Length - 1].ToString();
                //LogtoEvent("PI:HL Step 6 on GetIP() method: Exception is  :" + ex.ToString(), HighTraceInfo);

                HighTraceText.AppendLine("PI:HL Step 6 on GetIP() method: Exception is  :" + ex.ToString());
                //LogtoEvent("PI:LL on GetIP() method: Exception is  :" + ex.ToString(), LowTraceInfo);
                LowTraceText.AppendLine("PI:LL on GetIP() method: Exception is  :" + ex.ToString());
            }
            finally
            {
                if (LowTraceText.Length > 0)
                {
                    LogtoEvent(LowTraceText.ToString(), LowTraceInfo);
                }
                if (HighTraceText.Length > 0)
                {
                    LogtoEvent(HighTraceText.ToString(), HighTraceInfo);
                }
                LowTraceText = new StringBuilder();
                HighTraceText = new StringBuilder();

            }
            return str;
        }
        private string GetAssemblyVersion(string ApplicationPath)
        {
            string Version = string.Empty;
            //LowTraceText = new StringBuilder();
            //HighTraceText = new StringBuilder();
            try
            {
               

                if (!string.IsNullOrEmpty(ApplicationPath))
                {
                    try
                    {

                        //LogtoEvent("PI:LL Step 54 on GetAssemblyVersion method: Entered into GetAssemblyVersion method", LowTraceInfo);
                        LowTraceText.AppendLine("PI:LL Step 54 on GetAssemblyVersion method: Entered into GetAssemblyVersion method");
                        XElement xElement = XElement.Load(ApplicationPath);
                        IEnumerable<XElement> dependentAssemblies = GetInstallableDependencies(true, xElement);
                        // Version = xElement.Descendants().Attributes("Version").ElementAt(0).Value.Replace(".exe", "");
                        IEnumerable<XElement> file1 = GetInstallableFiles(true, xElement);
                        foreach (XElement assembly in dependentAssemblies)
                        {
                            Version = xElement.Descendants().Attributes("version").ElementAt(1).Value;
                            //GenerateDeployTable(xElement.Descendants().Attributes("version").ElementAt(1).Value, assembly.Attribute("codebase").Value, _targetLocation + "\\" + assembly.Attribute("codebase").Value, releaseDtl);
                            break;
                        }

                        //foreach (XElement file in file1)
                        //{
                        //    //GenerateDeployTable(xElement.Descendants().Attributes("version").ElementAt(1).Value, file.Attribute("name").Value, _targetLocation + "\\" + file.Attribute("name").Value, releaseDtl);
                        //}
                    }
                    catch (Exception ex)
                    {
                        Version = "12.0.0.0";
                        //LogtoEvent("PI:HL Step 7 on GetAssemblyVersion method: Exception is  :" + ex.ToString(), HighTraceInfo);
                        HighTraceText.AppendLine("PI:HL Step 7 on GetAssemblyVersion method: Exception is  :" + ex.ToString());
                        //LogtoEvent("PI:LL on GetAssemblyVersion method: Exception is  :" + ex.ToString(), LowTraceInfo);
                        LowTraceText.AppendLine("PI:LL on GetAssemblyVersion method: Exception is  :" + ex.ToString());
                        //  LogtoEvent(ex.ToString());
                    }
                }
                if (Version == string.Empty)
                    Version = "13.0.0.0";
            }
            finally
            {
                if (LowTraceText.Length > 0)
                {
                    LogtoEvent(LowTraceText.ToString(), LowTraceInfo);
                }
                if (HighTraceText.Length > 0)
                {
                    LogtoEvent(HighTraceText.ToString(), HighTraceInfo);
                }
                LowTraceText = new StringBuilder();
                HighTraceText = new StringBuilder();

            }

            return Version;

        }
        public IEnumerable<XElement> GetInstallableDependencies(bool isClickOnceManifest, XElement xManifest)
        {
            try
            {
                //LowTraceText = new StringBuilder();
                //HighTraceText = new StringBuilder();
                XmlReader reader = xManifest.CreateReader();
                XmlNamespaceManager namespaceManager = new XmlNamespaceManager(reader.NameTable);
                string xPath = string.Empty;


                if (isClickOnceManifest)
                {
                    //LogtoEvent("PI:LL Step 55 on GetInstallableDependencies method: Entered into GetInstallableDependencies method", LowTraceInfo);
                    LowTraceText.AppendLine("PI:LL Step 55 on GetInstallableDependencies method: Entered into GetInstallableDependencies method");
                    namespaceManager.AddNamespace("asmv1", "urn:schemas-microsoft-com:asm.v1");
                    namespaceManager.AddNamespace("asmv2", "urn:schemas-microsoft-com:asm.v2");
                    xPath = "asmv2:dependency/asmv2:dependentAssembly[@dependencyType='install']";
                }

                else
                {
                    //LogtoEvent("PI:LL Step 56 on GetInstallableDependencies method: Else condition of GetInstallableDependencies method", LowTraceInfo);
                    LowTraceText.AppendLine("PI:LL Step 56 on GetInstallableDependencies method: Else condition of GetInstallableDependencies method");
                    namespaceManager.AddNamespace("ns1", "http://www.devx.com/schemas/autoupgrade/1.0");
                    xPath = "ns1:ManifestFiles/ns1:File[@method='version' and @action='copy']";
                }

                return xManifest.XPathSelectElements(xPath, namespaceManager);
            }

            catch (Exception ex)
            {
                //LogtoEvent("PI:HL Step 8 on GetInstallableDependencies method: Exception is  :" + ex.ToString(), HighTraceInfo);
                HighTraceText.AppendLine("PI:HL Step 8 on GetInstallableDependencies method: Exception is  :" + ex.ToString());
                //LogtoEvent("PI:LL on GetInstallableDependencies method: Exception is  :" + ex.ToString(), LowTraceInfo);
                LowTraceText.AppendLine("PI:LL on GetInstallableDependencies method: Exception is  :" + ex.ToString());
                return null;
            }

            finally
            {
                if (LowTraceText.Length > 0)
                {
                    LogtoEvent(LowTraceText.ToString(), LowTraceInfo);
                }
                if (HighTraceText.Length > 0)
                {
                    LogtoEvent(HighTraceText.ToString(), HighTraceInfo);
                }
                LowTraceText = new StringBuilder();
                HighTraceText = new StringBuilder();

            }
        }
        public IEnumerable<XElement> GetInstallableFiles(bool isClickOnceManifest, XElement xManifest)
        {
            try
            {
                //LowTraceText = new StringBuilder();
                //HighTraceText = new StringBuilder();
                XmlReader reader = xManifest.CreateReader();
                XmlNamespaceManager namespaceManager = new XmlNamespaceManager(reader.NameTable);
                string xPath = string.Empty;

                if (isClickOnceManifest)
                {
                    //LogtoEvent("PI:LL Step 57 on GetInstallableFiles method: Entered into GetInstallableFiles method", LowTraceInfo);
                    LowTraceText.AppendLine("PI:LL Step 57 on GetInstallableFiles method: Entered into GetInstallableFiles method");
                    namespaceManager.AddNamespace("asmv1", "urn:schemas-microsoft-com:asm.v1");
                    namespaceManager.AddNamespace("asmv2", "urn:schemas-microsoft-com:asm.v2");
                    xPath = "asmv2:file";
                }

                else
                {
                    //LogtoEvent("PI:LL Step 58 on GetInstallableFiles method: Else condition of GetInstallableFiles method", LowTraceInfo);
                    LowTraceText.AppendLine("PI:LL Step 58 on GetInstallableFiles method: Else condition of GetInstallableFiles method");
                    namespaceManager.AddNamespace("ns1", "http://www.devx.com/schemas/autoupgrade/1.0");
                    xPath = "ns1:ManifestFiles/ns1:File[@method='date' and @action='copy']";
                }

                return xManifest.XPathSelectElements(xPath, namespaceManager);
            }
            catch (Exception ex)
            {
                //LogtoEvent("PI:HL Step 9 on GetInstallableFiles method: Exception is  :" + ex.ToString(), HighTraceInfo);
                HighTraceText.AppendLine("PI:HL Step 9 on GetInstallableFiles method: Exception is  :" + ex.ToString());
                //LogtoEvent("PI:LL on GetInstallableFiles method: Exception is  :" + ex.ToString(), LowTraceInfo);
                LowTraceText.AppendLine("PI:LL on GetInstallableFiles method: Exception is  :" + ex.ToString());
                return null;
            }

            finally
            {
                if (LowTraceText.Length > 0)
                {
                    LogtoEvent(LowTraceText.ToString(), LowTraceInfo);
                }
                if (HighTraceText.Length > 0)
                {
                    LogtoEvent(HighTraceText.ToString(), HighTraceInfo);
                }
                LowTraceText = new StringBuilder();
                HighTraceText = new StringBuilder();

            }
        }
        //<summary>
        //Method for logging the log
        //</summary>
        //<param name="ex"></param>

        private static void LogtoEvent(string ex, string traceinfotype)
        {
            try
            {
                string LowTraceInfo = ConfigurationSettings.AppSettings["AxpGDUProcessLowLevelTraceInfo"].ToString();
                string HighTraceInfo = ConfigurationSettings.AppSettings["AxpGDUProcessHighLevelTraceInfo"].ToString();
                mainDirectory = Path.GetDirectoryName(System.Reflection.Assembly.GetEntryAssembly().Location);

                if (LowTraceInfo == "True" && traceinfotype == "L")
                {
                    //string TraceFile = Path.GetFullPath(ConfigurationSettings.AppSettings["AxpGDUProcessTraceFilePath"].ToString());
                    string LowLevelTraceFileName = ConfigurationSettings.AppSettings["AxpGDUProcessLowLevelTraceFileName"].ToString();
                    string FileNameSaved = String.Format("{1}_{0:MM_dd_yyyy}.txt", DateTime.Now, LowLevelTraceFileName);
                    //FilePath = Path.Combine(TraceFile, FileNameSaved);
                    FilePath = Path.Combine(mainDirectory, FileNameSaved);

                    FileStream fs = null;
                    if (!File.Exists(FilePath))
                    {
                        using (fs = File.Create(FilePath))
                        {

                        }
                    }
                    if (File.Exists(FilePath))
                    {
                        StringBuilder sb = new StringBuilder();
                        StreamReader sr = new StreamReader(FilePath);
                        {
                            sb.Append(sr.ReadToEnd());
                            sb.AppendLine();
                        }
                        sr.Close();
                        TextWriter tw = new StreamWriter(FilePath);
                        sb.AppendLine(ex.ToString());
                        tw.WriteLine(sb.ToString());
                        tw.Close();
                    }
                }
                if (HighTraceInfo == "True" && traceinfotype == "H")
                {
                    //string TraceFile = Path.GetFullPath(ConfigurationSettings.AppSettings["AxpGDUProcessTraceFilePath"].ToString());
                    string HighLevelTraceFileName = ConfigurationSettings.AppSettings["AxpGDUProcessHighLevelTraceFileName"].ToString();
                    string FileNameSaved = String.Format("{1}_{0:MM_dd_yyyy}.txt", DateTime.Now, HighLevelTraceFileName);
                    //FilePath = Path.Combine(TraceFile, FileNameSaved);
                    FilePath = Path.Combine(mainDirectory, FileNameSaved);

                    FileStream fsH = null;
                    if (!File.Exists(FilePath))
                    {
                        using (fsH = File.Create(FilePath))
                        {

                        }
                    }
                    if (File.Exists(FilePath))
                    {
                        StringBuilder sb = new StringBuilder();
                        StreamReader sr = new StreamReader(FilePath);
                        {
                            sb.Append(sr.ReadToEnd());
                            sb.AppendLine();
                        }
                        sr.Close();
                        TextWriter tw = new StreamWriter(FilePath);
                        sb.AppendLine(ex.ToString());
                        tw.WriteLine(sb.ToString());
                        tw.Close();
                    }
                }
                
                
            }

            catch (Exception ex1)
            {

            }
        }
        //private static void LogtoEvent(string ex)
        //{
        //    try
        //    {
        //        string TraceInfo = ConfigurationSettings.AppSettings["AxpGDUProcessLowLevelTraceInfo"].ToString();
        //        if (TraceInfo == "True")
        //        {
        //            string TraceFile = Path.GetFullPath(ConfigurationSettings.AppSettings["AxpGDUProcessLowLevelTraceFile"].ToString());
        //            FileStream fs = null;
        //            if (!File.Exists(TraceFile))
        //            {
        //                using (fs = File.Create(TraceFile))
        //                {

        //                }
        //            }
        //            if (File.Exists(TraceFile))
        //            {
        //                StringBuilder sb = new StringBuilder();
        //                StreamReader sr = new StreamReader(TraceFile);
        //                {
        //                    sb.Append(sr.ReadToEnd());
        //                    sb.AppendLine();
        //                }
        //                sr.Close();
        //                TextWriter tw = new StreamWriter(TraceFile);
        //                sb.AppendLine(ex.ToString());
        //                tw.WriteLine(sb.ToString());
        //                tw.Close();
        //            }
        //        }
        //    }
        //    catch (Exception ex1)
        //    {
        //    }
        //}
        private static bool CheckUserExists()
        {
            try
            {
                //LowTraceText = new StringBuilder();
                //HighTraceText = new StringBuilder();
                //LogtoEvent("PI: HL on CheckUserExists method: Entered into CheckUserExists method", HighTraceInfo);
                HighTraceText.AppendLine("PI: HL on CheckUserExists method: Entered into CheckUserExists method");
                string userId = (WindowsIdentity.GetCurrent().Name.Substring(WindowsIdentity.GetCurrent().Name.LastIndexOf(@"\"))).Replace(@"\", "");
                //LogtoEvent("PI:LL Step 59 on CheckUserExists method: In CheckUserExists method, userId= " + userId, LowTraceInfo);
                LowTraceText.AppendLine("PI:LL Step 59 on CheckUserExists method: In CheckUserExists method, userId= " + userId);
                //LogtoEvent("In CheckUserExists userId= " + userId);
                DataTable userDetail = GetUserDetails(null, userId, false);
                if (userDetail.Rows.Count > 0)
                {
                    //LogtoEvent("PI:LL Step 60 on CheckUserExists method: In CheckUserExists userId Exist=", LowTraceInfo);
                    LowTraceText.AppendLine("PI:LL Step 60 on CheckUserExists method: In CheckUserExists userId Exist=");
                    //LogtoEvent("In CheckUserExists userId Exist=");
                    return true;
                }
                //LogtoEvent("PI:LL Step 61 on CheckUserExists method: In CheckUserExists userId Not Exist=", LowTraceInfo);
                LowTraceText.AppendLine("PI:LL Step 61 on CheckUserExists method: In CheckUserExists userId Not Exist=");
                //LogtoEvent("In CheckUserExists userId Not Exist=");
                return false;
            }

            catch (Exception ex)
            {
                //LogtoEvent("PI:HL Step 10 on CheckUserExists method: Exception is  :" + ex.ToString(), HighTraceInfo);
                HighTraceText.AppendLine("PI:HL Step 10 on CheckUserExists method: Exception is  :" + ex.ToString());
                //LogtoEvent("PI:LL on CheckUserExists method: Exception is  :" + ex.ToString(), LowTraceInfo);
                LowTraceText.AppendLine("PI:LL on CheckUserExists method: Exception is  :" + ex.ToString());
                return false;
            }
            finally
            {
                if (LowTraceText.Length > 0)
                {
                    LogtoEvent(LowTraceText.ToString(), LowTraceInfo);
                }
                if (HighTraceText.Length > 0)
                {
                    LogtoEvent(HighTraceText.ToString(), HighTraceInfo);
                }
                LowTraceText = new StringBuilder();
                HighTraceText = new StringBuilder();

            }
        }
        private static void AddUser()
        {
            try
            {
                //LowTraceText = new StringBuilder();
                //HighTraceText = new StringBuilder();

                //LogtoEvent("PI: HL on AddUser method: Entered into AddUser method", HighTraceInfo);
                HighTraceText.AppendLine("PI: HL on AddUser method: Entered into AddUser method");
                GDUServiceClient gduApp = new GDUServiceClient();
                UserQuery userDetails = new UserQuery();
                string userEmail = string.Empty;
                string userId = (WindowsIdentity.GetCurrent().Name.Substring(WindowsIdentity.GetCurrent().Name.LastIndexOf(@"\"))).Replace(@"\", "");
                string userName = WindowsIdentity.GetCurrent().Name;
                //LogtoEvent("PI:LL Step 62 on AddUser method: In AddUser method, userId= " + userId, LowTraceInfo);
                LowTraceText.AppendLine("PI:LL Step 62 on AddUser method: In AddUser method, userId= " + userId);
                //LogtoEvent("In AddUser Step 1 userId= " + userId);
                //LogtoEvent("PI:LL Step 63 on AddUser method: In AddUser method, userName= " + userName, LowTraceInfo);
                LowTraceText.AppendLine("PI:LL Step 63 on AddUser method: In AddUser method, userName= " + userName);
                //LogtoEvent("In AddUser Step 2 userName= " + userName);
                int len = userName.LastIndexOf(@"\");
                string principal = userName.Remove(0, len + 1);
                string filter = string.Format("(&(ObjectClass={0})(sAMAccountName={1}))", "person", principal);
                string domain = ConfigurationSettings.AppSettings["DomainName"].ToString();
                string[] properties = new string[] { "fullname" };
                DirectoryEntry adRoot = new DirectoryEntry("LDAP://" + domain, null, null, AuthenticationTypes.Secure);
                DirectorySearcher searcher = new DirectorySearcher(adRoot);
                searcher.SearchScope = SearchScope.Subtree;
                searcher.ReferralChasing = ReferralChasingOption.All;
                searcher.PropertiesToLoad.AddRange(properties);
                searcher.Filter = filter;
                SearchResult result = searcher.FindOne();
                DirectoryEntry directoryEntry = result.GetDirectoryEntry();
                string displayName = directoryEntry.Properties["displayName"][0].ToString();
                userEmail = directoryEntry.Properties["mail"][0].ToString();
                //LogtoEvent("PI:LL Step 64 on AddUser method: In AddUser method, displayName= " + displayName, LowTraceInfo);
                LowTraceText.AppendLine("PI:LL Step 64 on AddUser method: In AddUser method, displayName= " + displayName);
                //LogtoEvent("In AddUser Step 3 displayName= " + displayName);
                //LogtoEvent("PI:LL Step 65 on AddUser method: In AddUser method, userEmail= " + userEmail);
                LowTraceText.AppendLine("PI:LL Step 65 on AddUser method: In AddUser method, userEmail= " + userEmail);
                //LogtoEvent("In AddUser Step 4 userEmail= " + userEmail);

                userDetails.UserId = userId;
                userDetails.UserName = displayName;
                userDetails.LanguageCode = "ENG";
                userDetails.UserRoleCode = "DC";
                userDetails.EmailAddress = userEmail;
                userDetails.ModifiedUserDate = DateTime.Now;
                userDetails.ModifiedUserID = userId;
                userDetails.Mode = "ADD";

                //LogtoEvent("PI:LL Step 66 on AddUser method: In AddUser method, userDetails.UserId= " + userDetails.UserId, LowTraceInfo);
                ////LogtoEvent("In AddUser Step 5 userDetails.UserId= " + userDetails.UserId);
                //LogtoEvent("PI:LL Step 67 on AddUser method: In AddUser method, userDetails.UserName= " + userDetails.UserName, LowTraceInfo);
                ////LogtoEvent("In AddUser Step 6 userDetails.UserName= " + userDetails.UserName);
                //LogtoEvent("PI:LL Step 68 on AddUser method: In AddUser method, userDetails.LanguageCode= " + userDetails.LanguageCode, LowTraceInfo);
                ////LogtoEvent("In AddUser Step 7 userDetails.LanguageCode= " + userDetails.LanguageCode);
                //LogtoEvent("PI:LL Step 69 on AddUser method: In AddUser method, userDetails.UserRoleCode= " + userDetails.UserRoleCode, LowTraceInfo);
                ////LogtoEvent("In AddUser Step 8 userDetails.UserRoleCode= " + userDetails.UserRoleCode);
                //LogtoEvent("PI:LL Step 70 on AddUser method: In AddUser method, userDetails.EmailAddress= " + userDetails.EmailAddress, LowTraceInfo);
                ////LogtoEvent("In AddUser Step 9 userDetails.EmailAddress= " + userDetails.EmailAddress);
                //LogtoEvent("PI:LL Step 71 on AddUser method: In AddUser method, userDetails.ModifiedUserDate= " + userDetails.ModifiedUserDate, LowTraceInfo);
                ////LogtoEvent("In AddUser Step 10 userDetails.ModifiedUserDate= " + userDetails.ModifiedUserDate);
                //LogtoEvent("PI:LL Step 72 on AddUser method: In AddUser method, userDetails.ModifiedUserID= " + userDetails.ModifiedUserID, LowTraceInfo);
                ////LogtoEvent("In AddUser Step 11 userDetails.ModifiedUserID= " + userDetails.ModifiedUserID);
                //LogtoEvent("PI:LL Step 73 on AddUser method: In AddUser method, userDetails.Mode= " + userDetails.Mode, LowTraceInfo);
                ////LogtoEvent("In AddUser Step 12 userDetails.Mode= " + userDetails.Mode);


                LowTraceText.AppendLine("PI:LL Step 66 on AddUser method: In AddUser method, userDetails.UserId= " + userDetails.UserId);
                LowTraceText.AppendLine("PI:LL Step 67 on AddUser method: In AddUser method, userDetails.UserName= " + userDetails.UserName);
                LowTraceText.AppendLine("PI:LL Step 68 on AddUser method: In AddUser method, userDetails.LanguageCode= " + userDetails.LanguageCode);
                LowTraceText.AppendLine("PI:LL Step 69 on AddUser method: In AddUser method, userDetails.UserRoleCode= " + userDetails.UserRoleCode);
                LowTraceText.AppendLine("PI:LL Step 70 on AddUser method: In AddUser method, userDetails.EmailAddress= " + userDetails.EmailAddress);
                LowTraceText.AppendLine("PI:LL Step 71 on AddUser method: In AddUser method, userDetails.ModifiedUserDate= " + userDetails.ModifiedUserDate);
                LowTraceText.AppendLine("PI:LL Step 72 on AddUser method: In AddUser method, userDetails.ModifiedUserID= " + userDetails.ModifiedUserID);
                LowTraceText.AppendLine("PI:LL Step 73 on AddUser method: In AddUser method, userDetails.Mode= " + userDetails.Mode);


                gduApp.ManageUsers(userDetails);
            }
            catch (Exception ex)
            {

                //LogtoEvent("PI:HL Step 11 on AddUser method: Exception is  :" + ex.ToString(), HighTraceInfo);
                HighTraceText.AppendLine("PI:HL Step 11 on AddUser method: Exception is  :" + ex.ToString());
                //LogtoEvent("PI:LL on AddUser method: Exception is  :" + ex.ToString(), LowTraceInfo);
                LowTraceText.AppendLine("PI:LL on AddUser method: Exception is  :" + ex.ToString());
                //LogtoEvent("In AddUser  Exception= " + ex.ToString());
            }
            finally
            {
                if (LowTraceText.Length > 0)
                {
                    LogtoEvent(LowTraceText.ToString(), LowTraceInfo);
                }
                if (HighTraceText.Length > 0)
                {
                    LogtoEvent(HighTraceText.ToString(), HighTraceInfo);
                }
                LowTraceText = new StringBuilder();
                HighTraceText = new StringBuilder();

            }
        }
        public static DataTable GetUserDetails(string userName, string userId, bool isDeactive)
        {
            DataTable dtUser = new DataTable();
            UserDetails[] userDetails;
            DataRow drUserInfo;
            try
            {
                //LowTraceText = new StringBuilder();
                //HighTraceText = new StringBuilder();
                GDUServiceClient gduApp = new GDUServiceClient();

                dtUser.Columns.Add("UserID", Type.GetType("System.String"));
                dtUser.Columns.Add("UserName", Type.GetType("System.String"));
                dtUser.Columns.Add("EmailAddress", Type.GetType("System.String"));
                dtUser.Columns.Add("Language", Type.GetType("System.String"));
                dtUser.Columns.Add("Role", Type.GetType("System.String"));
                dtUser.Columns.Add("LanguageCode", Type.GetType("System.String"));
                dtUser.Columns.Add("RoleCode", Type.GetType("System.String"));
                dtUser.Columns.Add("ModifiedDT", Type.GetType("System.DateTime"));
                dtUser.Columns.Add("DefaultClientID", Type.GetType("System.Int32"));
                UserQuery userQuery = new UserQuery();
                userQuery.UserId = userId;
                userQuery.UserName = userName;
                userQuery.IsDeactive = isDeactive;
                userDetails = gduApp.SearchUsers(userQuery);
                //LogtoEvent("PI:LL Step 74 on GetUserDetails method: In GetUserDetails method, filling the UserDetails[] from GDU Service", LowTraceInfo);
                LowTraceText.AppendLine("PI:LL Step 74 on GetUserDetails method: In GetUserDetails method, filling the UserDetails[] from GDU Service");

                for (int iCount = 0; iCount < userDetails.Length; iCount++)
                {
                    drUserInfo = dtUser.NewRow();
                    drUserInfo["UserID"] = userDetails[iCount].UserId;
                    drUserInfo["UserName"] = userDetails[iCount].UserName;
                    drUserInfo["EmailAddress"] = userDetails[iCount].EmailAddress;
                    drUserInfo["LanguageCode"] = userDetails[iCount].LanguageCode;
                    drUserInfo["Language"] = userDetails[iCount].Language;
                    drUserInfo["Role"] = userDetails[iCount].UserRole;
                    drUserInfo["RoleCode"] = userDetails[iCount].UserRoleCode;
                    drUserInfo["ModifiedDT"] = userDetails[iCount].ModifiedUserDate;
                    drUserInfo["DefaultClientID"] = userDetails[iCount].DefaultClientID;
                    dtUser.Rows.Add(drUserInfo);
                }
            }
            catch (Exception ex)
            {
                //LogtoEvent("PI:HL Step 12 on GetUserDetails method: Exception is  :" + ex.ToString(), HighTraceInfo);
                HighTraceText.AppendLine("PI:HL Step 12 on GetUserDetails method: Exception is  :" + ex.ToString());
                //LogtoEvent("PI:LL on GetUserDetails method: Exception is  :" + ex.ToString(), LowTraceInfo);
                LowTraceText.AppendLine("PI:LL on GetUserDetails method: Exception is  :" + ex.ToString());
                //LogtoEvent("In GetUserDetails  Exception= " + ex.ToString());
            }
            finally
            {
                if (LowTraceText.Length > 0)
                {
                    LogtoEvent(LowTraceText.ToString(), LowTraceInfo);
                }
                if (HighTraceText.Length > 0)
                {
                    LogtoEvent(HighTraceText.ToString(), HighTraceInfo);
                }
                LowTraceText = new StringBuilder();
                HighTraceText = new StringBuilder();

            }
            return dtUser;
        }
    }
}
